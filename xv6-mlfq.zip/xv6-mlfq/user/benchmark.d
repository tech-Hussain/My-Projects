user/benchmark.o: user/benchmark.c kernel/types.h kernel/stat.h \
 user/user.h
