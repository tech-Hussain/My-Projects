
user/_benchcmp:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <cpu_intensive_task>:
// 3. Fair CPU distribution

#define NUM_CPU_PROCS 2
#define NUM_IO_PROCS 2

void cpu_intensive_task(int id) {
   0:	7135                	addi	sp,sp,-160
   2:	ed06                	sd	ra,152(sp)
   4:	e922                	sd	s0,144(sp)
   6:	e526                	sd	s1,136(sp)
   8:	e14a                	sd	s2,128(sp)
   a:	1100                	addi	s0,sp,160
   c:	892a                	mv	s2,a0
    struct procinfo info_start, info_end;
    int pid = getpid();
   e:	77e000ef          	jal	ra,78c <getpid>
  12:	84aa                	mv	s1,a0
    
    // Get initial stats
    getprocinfo(pid, &info_start);
  14:	fa840593          	addi	a1,s0,-88
  18:	794000ef          	jal	ra,7ac <getprocinfo>
    
    printf("[CPU-%d] PID %d starting at tick %lu, priority %d\n", 
  1c:	fac42703          	lw	a4,-84(s0)
  20:	fc043683          	ld	a3,-64(s0)
  24:	8626                	mv	a2,s1
  26:	85ca                	mv	a1,s2
  28:	00001517          	auipc	a0,0x1
  2c:	cc850513          	addi	a0,a0,-824 # cf0 <malloc+0x10c>
  30:	301000ef          	jal	ra,b30 <printf>
  34:	4815                	li	a6,5
    for (int phase = 0; phase < 5; phase++) {
        volatile long result = 0;
        for (long i = 0; i < 5000000; i++) {
            result += i * i;
            result ^= (i + 1) * (i - 1);
            if (i % 1000000 == 0) {
  36:	000f4537          	lui	a0,0xf4
  3a:	24050513          	addi	a0,a0,576 # f4240 <base+0xf2230>
        for (long i = 0; i < 5000000; i++) {
  3e:	004c55b7          	lui	a1,0x4c5
  42:	b4058593          	addi	a1,a1,-1216 # 4c4b40 <base+0x4c2b30>
  46:	a091                	j	8a <cpu_intensive_task+0x8a>
  48:	02b78e63          	beq	a5,a1,84 <cpu_intensive_task+0x84>
            result += i * i;
  4c:	f6843683          	ld	a3,-152(s0)
  50:	02f78733          	mul	a4,a5,a5
  54:	9736                	add	a4,a4,a3
  56:	f6e43423          	sd	a4,-152(s0)
            result ^= (i + 1) * (i - 1);
  5a:	86be                	mv	a3,a5
  5c:	0785                	addi	a5,a5,1
  5e:	f6843603          	ld	a2,-152(s0)
  62:	fff68713          	addi	a4,a3,-1
  66:	02f70733          	mul	a4,a4,a5
  6a:	8f31                	xor	a4,a4,a2
  6c:	f6e43423          	sd	a4,-152(s0)
            if (i % 1000000 == 0) {
  70:	02a6e6b3          	rem	a3,a3,a0
  74:	faf1                	bnez	a3,48 <cpu_intensive_task+0x48>
                result = result / (i + 1);  // Add more CPU work
  76:	f6843703          	ld	a4,-152(s0)
  7a:	02f74733          	div	a4,a4,a5
  7e:	f6e43423          	sd	a4,-152(s0)
  82:	b7d9                	j	48 <cpu_intensive_task+0x48>
    for (int phase = 0; phase < 5; phase++) {
  84:	387d                	addiw	a6,a6,-1
  86:	00080663          	beqz	a6,92 <cpu_intensive_task+0x92>
        volatile long result = 0;
  8a:	f6043423          	sd	zero,-152(s0)
        for (long i = 0; i < 5000000; i++) {
  8e:	4781                	li	a5,0
  90:	bf75                	j	4c <cpu_intensive_task+0x4c>
            }
        }
    }
    
    // Get final stats
    getprocinfo(pid, &info_end);
  92:	f7040593          	addi	a1,s0,-144
  96:	8526                	mv	a0,s1
  98:	714000ef          	jal	ra,7ac <getprocinfo>
    
    printf("[CPU-%d] PID %d FINISHED:\n", id, pid);
  9c:	8626                	mv	a2,s1
  9e:	85ca                	mv	a1,s2
  a0:	00001517          	auipc	a0,0x1
  a4:	c8850513          	addi	a0,a0,-888 # d28 <malloc+0x144>
  a8:	289000ef          	jal	ra,b30 <printf>
    printf("  - Turnaround Time: %lu ticks (start=%lu, end=%lu)\n", 
           info_end.end_time - info_end.start_time,
  ac:	f9043683          	ld	a3,-112(s0)
  b0:	f8843603          	ld	a2,-120(s0)
    printf("  - Turnaround Time: %lu ticks (start=%lu, end=%lu)\n", 
  b4:	40c685b3          	sub	a1,a3,a2
  b8:	00001517          	auipc	a0,0x1
  bc:	c9050513          	addi	a0,a0,-880 # d48 <malloc+0x164>
  c0:	271000ef          	jal	ra,b30 <printf>
           info_end.start_time, info_end.end_time);
    printf("  - Response Time:   %lu ticks (first scheduled at %lu)\n", 
           info_end.first_run - info_end.start_time, info_end.first_run);
  c4:	f9843603          	ld	a2,-104(s0)
    printf("  - Response Time:   %lu ticks (first scheduled at %lu)\n", 
  c8:	f8843583          	ld	a1,-120(s0)
  cc:	40b605b3          	sub	a1,a2,a1
  d0:	00001517          	auipc	a0,0x1
  d4:	cb050513          	addi	a0,a0,-848 # d80 <malloc+0x19c>
  d8:	259000ef          	jal	ra,b30 <printf>
    printf("  - Wait Time:       %lu ticks\n", info_end.total_wait);
  dc:	fa043583          	ld	a1,-96(s0)
  e0:	00001517          	auipc	a0,0x1
  e4:	ce050513          	addi	a0,a0,-800 # dc0 <malloc+0x1dc>
  e8:	249000ef          	jal	ra,b30 <printf>
    printf("  - CPU Ticks:       %d\n", info_end.cpu_ticks);
  ec:	f7842583          	lw	a1,-136(s0)
  f0:	00001517          	auipc	a0,0x1
  f4:	cf050513          	addi	a0,a0,-784 # de0 <malloc+0x1fc>
  f8:	239000ef          	jal	ra,b30 <printf>
    printf("  - Scheduled:       %d times\n", info_end.sched_count);
  fc:	f7c42583          	lw	a1,-132(s0)
 100:	00001517          	auipc	a0,0x1
 104:	d0050513          	addi	a0,a0,-768 # e00 <malloc+0x21c>
 108:	229000ef          	jal	ra,b30 <printf>
    printf("  - Final Priority:  %d%s\n", 
 10c:	f7442583          	lw	a1,-140(s0)
 110:	00001617          	auipc	a2,0x1
 114:	bc060613          	addi	a2,a2,-1088 # cd0 <malloc+0xec>
 118:	00b05b63          	blez	a1,12e <cpu_intensive_task+0x12e>
 11c:	00001517          	auipc	a0,0x1
 120:	d0450513          	addi	a0,a0,-764 # e20 <malloc+0x23c>
 124:	20d000ef          	jal	ra,b30 <printf>
           info_end.priority,
           info_end.priority > 0 ? " (DEMOTED by MLFQ)" : " (HIGH)");
    
    exit(0);
 128:	4501                	li	a0,0
 12a:	5e2000ef          	jal	ra,70c <exit>
    printf("  - Final Priority:  %d%s\n", 
 12e:	00001617          	auipc	a2,0x1
 132:	bba60613          	addi	a2,a2,-1094 # ce8 <malloc+0x104>
 136:	b7dd                	j	11c <cpu_intensive_task+0x11c>

0000000000000138 <io_intensive_task>:
}

void io_intensive_task(int id) {
 138:	7131                	addi	sp,sp,-192
 13a:	fd06                	sd	ra,184(sp)
 13c:	f922                	sd	s0,176(sp)
 13e:	f526                	sd	s1,168(sp)
 140:	f14a                	sd	s2,160(sp)
 142:	ed4e                	sd	s3,152(sp)
 144:	e952                	sd	s4,144(sp)
 146:	e556                	sd	s5,136(sp)
 148:	e15a                	sd	s6,128(sp)
 14a:	0180                	addi	s0,sp,192
 14c:	8b2a                	mv	s6,a0
    struct procinfo info_start, info_end;
    int pid = getpid();
 14e:	63e000ef          	jal	ra,78c <getpid>
 152:	8aaa                	mv	s5,a0
    
    // Get initial stats
    getprocinfo(pid, &info_start);
 154:	f8840593          	addi	a1,s0,-120
 158:	654000ef          	jal	ra,7ac <getprocinfo>
    
    printf("[I/O-%d] PID %d starting at tick %lu, priority %d\n", 
 15c:	f8c42703          	lw	a4,-116(s0)
 160:	fa043683          	ld	a3,-96(s0)
 164:	8656                	mv	a2,s5
 166:	85da                	mv	a1,s6
 168:	00001517          	auipc	a0,0x1
 16c:	d0050513          	addi	a0,a0,-768 # e68 <malloc+0x284>
 170:	1c1000ef          	jal	ra,b30 <printf>
 174:	4979                	li	s2,30
    
    // I/O-intensive work - lots of short bursts with I/O
    for (int i = 0; i < 30; i++) {
        // Small CPU burst
        volatile int x = 0;
        for (int j = 0; j < 50000; j++) {
 176:	4981                	li	s3,0
 178:	64b1                	lui	s1,0xc
 17a:	35048493          	addi	s1,s1,848 # c350 <base+0xa340>
            x += j;
        }
        
        // I/O operation
        write(1, ".", 1);
 17e:	00001a17          	auipc	s4,0x1
 182:	d22a0a13          	addi	s4,s4,-734 # ea0 <malloc+0x2bc>
        volatile int x = 0;
 186:	f4042623          	sw	zero,-180(s0)
        for (int j = 0; j < 50000; j++) {
 18a:	87ce                	mv	a5,s3
            x += j;
 18c:	f4c42703          	lw	a4,-180(s0)
 190:	9f3d                	addw	a4,a4,a5
 192:	f4e42623          	sw	a4,-180(s0)
        for (int j = 0; j < 50000; j++) {
 196:	2785                	addiw	a5,a5,1
 198:	fe979ae3          	bne	a5,s1,18c <io_intensive_task+0x54>
        write(1, ".", 1);
 19c:	4605                	li	a2,1
 19e:	85d2                	mv	a1,s4
 1a0:	4505                	li	a0,1
 1a2:	58a000ef          	jal	ra,72c <write>
        
        // Another small burst
        for (int j = 0; j < 50000; j++) {
 1a6:	87ce                	mv	a5,s3
            x += j;
 1a8:	f4c42703          	lw	a4,-180(s0)
 1ac:	9f3d                	addw	a4,a4,a5
 1ae:	f4e42623          	sw	a4,-180(s0)
        for (int j = 0; j < 50000; j++) {
 1b2:	2785                	addiw	a5,a5,1
 1b4:	fe979ae3          	bne	a5,s1,1a8 <io_intensive_task+0x70>
    for (int i = 0; i < 30; i++) {
 1b8:	397d                	addiw	s2,s2,-1
 1ba:	fc0916e3          	bnez	s2,186 <io_intensive_task+0x4e>
        }
    }
    
    printf("\n");
 1be:	00001517          	auipc	a0,0x1
 1c2:	fc250513          	addi	a0,a0,-62 # 1180 <malloc+0x59c>
 1c6:	16b000ef          	jal	ra,b30 <printf>
    
    // Get final stats
    getprocinfo(pid, &info_end);
 1ca:	f5040593          	addi	a1,s0,-176
 1ce:	8556                	mv	a0,s5
 1d0:	5dc000ef          	jal	ra,7ac <getprocinfo>
    
    printf("[I/O-%d] PID %d FINISHED:\n", id, pid);
 1d4:	8656                	mv	a2,s5
 1d6:	85da                	mv	a1,s6
 1d8:	00001517          	auipc	a0,0x1
 1dc:	cd050513          	addi	a0,a0,-816 # ea8 <malloc+0x2c4>
 1e0:	151000ef          	jal	ra,b30 <printf>
    printf("  - Turnaround Time: %lu ticks (start=%lu, end=%lu)\n", 
           info_end.end_time - info_end.start_time,
 1e4:	f7043683          	ld	a3,-144(s0)
 1e8:	f6843603          	ld	a2,-152(s0)
    printf("  - Turnaround Time: %lu ticks (start=%lu, end=%lu)\n", 
 1ec:	40c685b3          	sub	a1,a3,a2
 1f0:	00001517          	auipc	a0,0x1
 1f4:	b5850513          	addi	a0,a0,-1192 # d48 <malloc+0x164>
 1f8:	139000ef          	jal	ra,b30 <printf>
           info_end.start_time, info_end.end_time);
    printf("  - Response Time:   %lu ticks (first scheduled at %lu)\n", 
           info_end.first_run - info_end.start_time, info_end.first_run);
 1fc:	f7843603          	ld	a2,-136(s0)
    printf("  - Response Time:   %lu ticks (first scheduled at %lu)\n", 
 200:	f6843583          	ld	a1,-152(s0)
 204:	40b605b3          	sub	a1,a2,a1
 208:	00001517          	auipc	a0,0x1
 20c:	b7850513          	addi	a0,a0,-1160 # d80 <malloc+0x19c>
 210:	121000ef          	jal	ra,b30 <printf>
    printf("  - Wait Time:       %lu ticks\n", info_end.total_wait);
 214:	f8043583          	ld	a1,-128(s0)
 218:	00001517          	auipc	a0,0x1
 21c:	ba850513          	addi	a0,a0,-1112 # dc0 <malloc+0x1dc>
 220:	111000ef          	jal	ra,b30 <printf>
    printf("  - CPU Ticks:       %d\n", info_end.cpu_ticks);
 224:	f5842583          	lw	a1,-168(s0)
 228:	00001517          	auipc	a0,0x1
 22c:	bb850513          	addi	a0,a0,-1096 # de0 <malloc+0x1fc>
 230:	101000ef          	jal	ra,b30 <printf>
    printf("  - Scheduled:       %d times\n", info_end.sched_count);
 234:	f5c42583          	lw	a1,-164(s0)
 238:	00001517          	auipc	a0,0x1
 23c:	bc850513          	addi	a0,a0,-1080 # e00 <malloc+0x21c>
 240:	0f1000ef          	jal	ra,b30 <printf>
    printf("  - Final Priority:  %d%s\n", 
 244:	f5442583          	lw	a1,-172(s0)
 248:	00001617          	auipc	a2,0x1
 24c:	bf860613          	addi	a2,a2,-1032 # e40 <malloc+0x25c>
 250:	c589                	beqz	a1,25a <io_intensive_task+0x122>
 252:	00001617          	auipc	a2,0x1
 256:	c0660613          	addi	a2,a2,-1018 # e58 <malloc+0x274>
 25a:	00001517          	auipc	a0,0x1
 25e:	bc650513          	addi	a0,a0,-1082 # e20 <malloc+0x23c>
 262:	0cf000ef          	jal	ra,b30 <printf>
           info_end.priority,
           info_end.priority == 0 ? " (HIGH - I/O rewarded)" : " (lower)");
    
    exit(0);
 266:	4501                	li	a0,0
 268:	4a4000ef          	jal	ra,70c <exit>

000000000000026c <main>:
}

int main(int argc, char *argv[]) {
 26c:	1101                	addi	sp,sp,-32
 26e:	ec06                	sd	ra,24(sp)
 270:	e822                	sd	s0,16(sp)
 272:	e426                	sd	s1,8(sp)
 274:	1000                	addi	s0,sp,32
    printf("\n");
 276:	00001517          	auipc	a0,0x1
 27a:	f0a50513          	addi	a0,a0,-246 # 1180 <malloc+0x59c>
 27e:	0b3000ef          	jal	ra,b30 <printf>
    printf("================================================================\n");
 282:	00001517          	auipc	a0,0x1
 286:	c4650513          	addi	a0,a0,-954 # ec8 <malloc+0x2e4>
 28a:	0a7000ef          	jal	ra,b30 <printf>
    printf("           SCHEDULER PERFORMANCE COMPARISON\n");
 28e:	00001517          	auipc	a0,0x1
 292:	c8250513          	addi	a0,a0,-894 # f10 <malloc+0x32c>
 296:	09b000ef          	jal	ra,b30 <printf>
    printf("================================================================\n");
 29a:	00001517          	auipc	a0,0x1
 29e:	c2e50513          	addi	a0,a0,-978 # ec8 <malloc+0x2e4>
 2a2:	08f000ef          	jal	ra,b30 <printf>
    printf("This benchmark measures key performance metrics:\n");
 2a6:	00001517          	auipc	a0,0x1
 2aa:	c9a50513          	addi	a0,a0,-870 # f40 <malloc+0x35c>
 2ae:	083000ef          	jal	ra,b30 <printf>
    printf("  • Turnaround Time: Total time from creation to completion\n");
 2b2:	00001517          	auipc	a0,0x1
 2b6:	cc650513          	addi	a0,a0,-826 # f78 <malloc+0x394>
 2ba:	077000ef          	jal	ra,b30 <printf>
    printf("  • Response Time:   Time until first CPU allocation\n");
 2be:	00001517          	auipc	a0,0x1
 2c2:	cfa50513          	addi	a0,a0,-774 # fb8 <malloc+0x3d4>
 2c6:	06b000ef          	jal	ra,b30 <printf>
    printf("  • Wait Time:       Total time spent waiting for CPU\n");
 2ca:	00001517          	auipc	a0,0x1
 2ce:	d2650513          	addi	a0,a0,-730 # ff0 <malloc+0x40c>
 2d2:	05f000ef          	jal	ra,b30 <printf>
    printf("  • Priority:        Final priority (shows MLFQ adaptation)\n");
 2d6:	00001517          	auipc	a0,0x1
 2da:	d5a50513          	addi	a0,a0,-678 # 1030 <malloc+0x44c>
 2de:	053000ef          	jal	ra,b30 <printf>
    printf("================================================================\n\n");
 2e2:	00001517          	auipc	a0,0x1
 2e6:	d8e50513          	addi	a0,a0,-626 # 1070 <malloc+0x48c>
 2ea:	047000ef          	jal	ra,b30 <printf>
    
    uint64 benchmark_start = uptime();
 2ee:	4b6000ef          	jal	ra,7a4 <uptime>
 2f2:	84aa                	mv	s1,a0
    
    printf("Starting %d CPU-bound and %d I/O-bound processes...\n\n", 
 2f4:	4609                	li	a2,2
 2f6:	4589                	li	a1,2
 2f8:	00001517          	auipc	a0,0x1
 2fc:	dc050513          	addi	a0,a0,-576 # 10b8 <malloc+0x4d4>
 300:	031000ef          	jal	ra,b30 <printf>
           NUM_CPU_PROCS, NUM_IO_PROCS);
    
    // Fork CPU-bound processes
    for (int i = 0; i < NUM_CPU_PROCS; i++) {
        int pid = fork();
 304:	400000ef          	jal	ra,704 <fork>
        if (pid == 0) {
 308:	16050363          	beqz	a0,46e <main+0x202>
        int pid = fork();
 30c:	3f8000ef          	jal	ra,704 <fork>
        if (pid == 0) {
 310:	14050e63          	beqz	a0,46c <main+0x200>
        }
    }
    
    // Fork I/O-bound processes
    for (int i = 0; i < NUM_IO_PROCS; i++) {
        int pid = fork();
 314:	3f0000ef          	jal	ra,704 <fork>
        if (pid == 0) {
 318:	14050e63          	beqz	a0,474 <main+0x208>
        int pid = fork();
 31c:	3e8000ef          	jal	ra,704 <fork>
        if (pid == 0) {
 320:	14050963          	beqz	a0,472 <main+0x206>
        }
    }
    
    // Wait for all children
    for (int i = 0; i < NUM_CPU_PROCS + NUM_IO_PROCS; i++) {
        wait(0);
 324:	4501                	li	a0,0
 326:	3ee000ef          	jal	ra,714 <wait>
 32a:	4501                	li	a0,0
 32c:	3e8000ef          	jal	ra,714 <wait>
 330:	4501                	li	a0,0
 332:	3e2000ef          	jal	ra,714 <wait>
 336:	4501                	li	a0,0
 338:	3dc000ef          	jal	ra,714 <wait>
    }
    
    uint64 benchmark_end = uptime();
 33c:	468000ef          	jal	ra,7a4 <uptime>
    uint64 total_time = benchmark_end - benchmark_start;
 340:	409504b3          	sub	s1,a0,s1
    
    printf("\n================================================================\n");
 344:	00001517          	auipc	a0,0x1
 348:	dac50513          	addi	a0,a0,-596 # 10f0 <malloc+0x50c>
 34c:	7e4000ef          	jal	ra,b30 <printf>
    printf("                    BENCHMARK COMPLETE\n");
 350:	00001517          	auipc	a0,0x1
 354:	de850513          	addi	a0,a0,-536 # 1138 <malloc+0x554>
 358:	7d8000ef          	jal	ra,b30 <printf>
    printf("================================================================\n");
 35c:	00001517          	auipc	a0,0x1
 360:	b6c50513          	addi	a0,a0,-1172 # ec8 <malloc+0x2e4>
 364:	7cc000ef          	jal	ra,b30 <printf>
    printf("Total Execution Time: %lu ticks\n\n", total_time);
 368:	85a6                	mv	a1,s1
 36a:	00001517          	auipc	a0,0x1
 36e:	df650513          	addi	a0,a0,-522 # 1160 <malloc+0x57c>
 372:	7be000ef          	jal	ra,b30 <printf>
    
    printf("KEY OBSERVATIONS:\n");
 376:	00001517          	auipc	a0,0x1
 37a:	e1250513          	addi	a0,a0,-494 # 1188 <malloc+0x5a4>
 37e:	7b2000ef          	jal	ra,b30 <printf>
    printf("----------------------------------------------------------------\n");
 382:	00001517          	auipc	a0,0x1
 386:	e1e50513          	addi	a0,a0,-482 # 11a0 <malloc+0x5bc>
 38a:	7a6000ef          	jal	ra,b30 <printf>
    printf("In MLFQ:\n");
 38e:	00001517          	auipc	a0,0x1
 392:	e5a50513          	addi	a0,a0,-422 # 11e8 <malloc+0x604>
 396:	79a000ef          	jal	ra,b30 <printf>
    printf("  ✓ CPU-bound processes are demoted to lower priority\n");
 39a:	00001517          	auipc	a0,0x1
 39e:	e5e50513          	addi	a0,a0,-418 # 11f8 <malloc+0x614>
 3a2:	78e000ef          	jal	ra,b30 <printf>
    printf("  ✓ I/O-bound processes stay at high priority\n");
 3a6:	00001517          	auipc	a0,0x1
 3aa:	e9250513          	addi	a0,a0,-366 # 1238 <malloc+0x654>
 3ae:	782000ef          	jal	ra,b30 <printf>
    printf("  ✓ I/O processes get better response time\n");
 3b2:	00001517          	auipc	a0,0x1
 3b6:	ebe50513          	addi	a0,a0,-322 # 1270 <malloc+0x68c>
 3ba:	776000ef          	jal	ra,b30 <printf>
    printf("  ✓ Better interactive responsiveness\n");
 3be:	00001517          	auipc	a0,0x1
 3c2:	ee250513          	addi	a0,a0,-286 # 12a0 <malloc+0x6bc>
 3c6:	76a000ef          	jal	ra,b30 <printf>
    printf("  ✓ Adaptive scheduling based on behavior\n\n");
 3ca:	00001517          	auipc	a0,0x1
 3ce:	f0650513          	addi	a0,a0,-250 # 12d0 <malloc+0x6ec>
 3d2:	75e000ef          	jal	ra,b30 <printf>
    
    printf("In Round-Robin:\n");
 3d6:	00001517          	auipc	a0,0x1
 3da:	f2a50513          	addi	a0,a0,-214 # 1300 <malloc+0x71c>
 3de:	752000ef          	jal	ra,b30 <printf>
    printf("  • All processes stay at priority 0\n");
 3e2:	00001517          	auipc	a0,0x1
 3e6:	f3650513          	addi	a0,a0,-202 # 1318 <malloc+0x734>
 3ea:	746000ef          	jal	ra,b30 <printf>
    printf("  • No differentiation between CPU/I/O bound\n");
 3ee:	00001517          	auipc	a0,0x1
 3f2:	f5250513          	addi	a0,a0,-174 # 1340 <malloc+0x75c>
 3f6:	73a000ef          	jal	ra,b30 <printf>
    printf("  • Equal treatment regardless of behavior\n");
 3fa:	00001517          	auipc	a0,0x1
 3fe:	f7650513          	addi	a0,a0,-138 # 1370 <malloc+0x78c>
 402:	72e000ef          	jal	ra,b30 <printf>
    printf("  • I/O processes may wait longer\n");
 406:	00001517          	auipc	a0,0x1
 40a:	f9a50513          	addi	a0,a0,-102 # 13a0 <malloc+0x7bc>
 40e:	722000ef          	jal	ra,b30 <printf>
    printf("  • Longer response times for interactive tasks\n\n");
 412:	00001517          	auipc	a0,0x1
 416:	fb650513          	addi	a0,a0,-74 # 13c8 <malloc+0x7e4>
 41a:	716000ef          	jal	ra,b30 <printf>
    
    printf("EXPECTED MLFQ ADVANTAGES:\n");
 41e:	00001517          	auipc	a0,0x1
 422:	fe250513          	addi	a0,a0,-30 # 1400 <malloc+0x81c>
 426:	70a000ef          	jal	ra,b30 <printf>
    printf("  → Lower response time for I/O processes\n");
 42a:	00001517          	auipc	a0,0x1
 42e:	ff650513          	addi	a0,a0,-10 # 1420 <malloc+0x83c>
 432:	6fe000ef          	jal	ra,b30 <printf>
    printf("  → Better overall turnaround time\n");
 436:	00001517          	auipc	a0,0x1
 43a:	01a50513          	addi	a0,a0,26 # 1450 <malloc+0x86c>
 43e:	6f2000ef          	jal	ra,b30 <printf>
    printf("  → More context switches (better interactivity)\n");
 442:	00001517          	auipc	a0,0x1
 446:	03650513          	addi	a0,a0,54 # 1478 <malloc+0x894>
 44a:	6e6000ef          	jal	ra,b30 <printf>
    printf("  → Visible priority adaptation\n");
 44e:	00001517          	auipc	a0,0x1
 452:	06250513          	addi	a0,a0,98 # 14b0 <malloc+0x8cc>
 456:	6da000ef          	jal	ra,b30 <printf>
    printf("================================================================\n\n");
 45a:	00001517          	auipc	a0,0x1
 45e:	c1650513          	addi	a0,a0,-1002 # 1070 <malloc+0x48c>
 462:	6ce000ef          	jal	ra,b30 <printf>
    
    exit(0);
 466:	4501                	li	a0,0
 468:	2a4000ef          	jal	ra,70c <exit>
    for (int i = 0; i < NUM_CPU_PROCS; i++) {
 46c:	4505                	li	a0,1
            cpu_intensive_task(i);
 46e:	b93ff0ef          	jal	ra,0 <cpu_intensive_task>
    for (int i = 0; i < NUM_IO_PROCS; i++) {
 472:	4505                	li	a0,1
            io_intensive_task(i);
 474:	cc5ff0ef          	jal	ra,138 <io_intensive_task>

0000000000000478 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 478:	1141                	addi	sp,sp,-16
 47a:	e406                	sd	ra,8(sp)
 47c:	e022                	sd	s0,0(sp)
 47e:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 480:	dedff0ef          	jal	ra,26c <main>
  exit(r);
 484:	288000ef          	jal	ra,70c <exit>

0000000000000488 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 488:	1141                	addi	sp,sp,-16
 48a:	e422                	sd	s0,8(sp)
 48c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 48e:	87aa                	mv	a5,a0
 490:	0585                	addi	a1,a1,1
 492:	0785                	addi	a5,a5,1
 494:	fff5c703          	lbu	a4,-1(a1)
 498:	fee78fa3          	sb	a4,-1(a5)
 49c:	fb75                	bnez	a4,490 <strcpy+0x8>
    ;
  return os;
}
 49e:	6422                	ld	s0,8(sp)
 4a0:	0141                	addi	sp,sp,16
 4a2:	8082                	ret

00000000000004a4 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 4a4:	1141                	addi	sp,sp,-16
 4a6:	e422                	sd	s0,8(sp)
 4a8:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 4aa:	00054783          	lbu	a5,0(a0)
 4ae:	cb91                	beqz	a5,4c2 <strcmp+0x1e>
 4b0:	0005c703          	lbu	a4,0(a1)
 4b4:	00f71763          	bne	a4,a5,4c2 <strcmp+0x1e>
    p++, q++;
 4b8:	0505                	addi	a0,a0,1
 4ba:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 4bc:	00054783          	lbu	a5,0(a0)
 4c0:	fbe5                	bnez	a5,4b0 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 4c2:	0005c503          	lbu	a0,0(a1)
}
 4c6:	40a7853b          	subw	a0,a5,a0
 4ca:	6422                	ld	s0,8(sp)
 4cc:	0141                	addi	sp,sp,16
 4ce:	8082                	ret

00000000000004d0 <strlen>:

uint
strlen(const char *s)
{
 4d0:	1141                	addi	sp,sp,-16
 4d2:	e422                	sd	s0,8(sp)
 4d4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 4d6:	00054783          	lbu	a5,0(a0)
 4da:	cf91                	beqz	a5,4f6 <strlen+0x26>
 4dc:	0505                	addi	a0,a0,1
 4de:	87aa                	mv	a5,a0
 4e0:	4685                	li	a3,1
 4e2:	9e89                	subw	a3,a3,a0
 4e4:	00f6853b          	addw	a0,a3,a5
 4e8:	0785                	addi	a5,a5,1
 4ea:	fff7c703          	lbu	a4,-1(a5)
 4ee:	fb7d                	bnez	a4,4e4 <strlen+0x14>
    ;
  return n;
}
 4f0:	6422                	ld	s0,8(sp)
 4f2:	0141                	addi	sp,sp,16
 4f4:	8082                	ret
  for(n = 0; s[n]; n++)
 4f6:	4501                	li	a0,0
 4f8:	bfe5                	j	4f0 <strlen+0x20>

00000000000004fa <memset>:

void*
memset(void *dst, int c, uint n)
{
 4fa:	1141                	addi	sp,sp,-16
 4fc:	e422                	sd	s0,8(sp)
 4fe:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 500:	ca19                	beqz	a2,516 <memset+0x1c>
 502:	87aa                	mv	a5,a0
 504:	1602                	slli	a2,a2,0x20
 506:	9201                	srli	a2,a2,0x20
 508:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 50c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 510:	0785                	addi	a5,a5,1
 512:	fee79de3          	bne	a5,a4,50c <memset+0x12>
  }
  return dst;
}
 516:	6422                	ld	s0,8(sp)
 518:	0141                	addi	sp,sp,16
 51a:	8082                	ret

000000000000051c <strchr>:

char*
strchr(const char *s, char c)
{
 51c:	1141                	addi	sp,sp,-16
 51e:	e422                	sd	s0,8(sp)
 520:	0800                	addi	s0,sp,16
  for(; *s; s++)
 522:	00054783          	lbu	a5,0(a0)
 526:	cb99                	beqz	a5,53c <strchr+0x20>
    if(*s == c)
 528:	00f58763          	beq	a1,a5,536 <strchr+0x1a>
  for(; *s; s++)
 52c:	0505                	addi	a0,a0,1
 52e:	00054783          	lbu	a5,0(a0)
 532:	fbfd                	bnez	a5,528 <strchr+0xc>
      return (char*)s;
  return 0;
 534:	4501                	li	a0,0
}
 536:	6422                	ld	s0,8(sp)
 538:	0141                	addi	sp,sp,16
 53a:	8082                	ret
  return 0;
 53c:	4501                	li	a0,0
 53e:	bfe5                	j	536 <strchr+0x1a>

0000000000000540 <gets>:

char*
gets(char *buf, int max)
{
 540:	711d                	addi	sp,sp,-96
 542:	ec86                	sd	ra,88(sp)
 544:	e8a2                	sd	s0,80(sp)
 546:	e4a6                	sd	s1,72(sp)
 548:	e0ca                	sd	s2,64(sp)
 54a:	fc4e                	sd	s3,56(sp)
 54c:	f852                	sd	s4,48(sp)
 54e:	f456                	sd	s5,40(sp)
 550:	f05a                	sd	s6,32(sp)
 552:	ec5e                	sd	s7,24(sp)
 554:	1080                	addi	s0,sp,96
 556:	8baa                	mv	s7,a0
 558:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 55a:	892a                	mv	s2,a0
 55c:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 55e:	4aa9                	li	s5,10
 560:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 562:	89a6                	mv	s3,s1
 564:	2485                	addiw	s1,s1,1
 566:	0344d663          	bge	s1,s4,592 <gets+0x52>
    cc = read(0, &c, 1);
 56a:	4605                	li	a2,1
 56c:	faf40593          	addi	a1,s0,-81
 570:	4501                	li	a0,0
 572:	1b2000ef          	jal	ra,724 <read>
    if(cc < 1)
 576:	00a05e63          	blez	a0,592 <gets+0x52>
    buf[i++] = c;
 57a:	faf44783          	lbu	a5,-81(s0)
 57e:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 582:	01578763          	beq	a5,s5,590 <gets+0x50>
 586:	0905                	addi	s2,s2,1
 588:	fd679de3          	bne	a5,s6,562 <gets+0x22>
  for(i=0; i+1 < max; ){
 58c:	89a6                	mv	s3,s1
 58e:	a011                	j	592 <gets+0x52>
 590:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 592:	99de                	add	s3,s3,s7
 594:	00098023          	sb	zero,0(s3)
  return buf;
}
 598:	855e                	mv	a0,s7
 59a:	60e6                	ld	ra,88(sp)
 59c:	6446                	ld	s0,80(sp)
 59e:	64a6                	ld	s1,72(sp)
 5a0:	6906                	ld	s2,64(sp)
 5a2:	79e2                	ld	s3,56(sp)
 5a4:	7a42                	ld	s4,48(sp)
 5a6:	7aa2                	ld	s5,40(sp)
 5a8:	7b02                	ld	s6,32(sp)
 5aa:	6be2                	ld	s7,24(sp)
 5ac:	6125                	addi	sp,sp,96
 5ae:	8082                	ret

00000000000005b0 <stat>:

int
stat(const char *n, struct stat *st)
{
 5b0:	1101                	addi	sp,sp,-32
 5b2:	ec06                	sd	ra,24(sp)
 5b4:	e822                	sd	s0,16(sp)
 5b6:	e426                	sd	s1,8(sp)
 5b8:	e04a                	sd	s2,0(sp)
 5ba:	1000                	addi	s0,sp,32
 5bc:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 5be:	4581                	li	a1,0
 5c0:	18c000ef          	jal	ra,74c <open>
  if(fd < 0)
 5c4:	02054163          	bltz	a0,5e6 <stat+0x36>
 5c8:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 5ca:	85ca                	mv	a1,s2
 5cc:	198000ef          	jal	ra,764 <fstat>
 5d0:	892a                	mv	s2,a0
  close(fd);
 5d2:	8526                	mv	a0,s1
 5d4:	160000ef          	jal	ra,734 <close>
  return r;
}
 5d8:	854a                	mv	a0,s2
 5da:	60e2                	ld	ra,24(sp)
 5dc:	6442                	ld	s0,16(sp)
 5de:	64a2                	ld	s1,8(sp)
 5e0:	6902                	ld	s2,0(sp)
 5e2:	6105                	addi	sp,sp,32
 5e4:	8082                	ret
    return -1;
 5e6:	597d                	li	s2,-1
 5e8:	bfc5                	j	5d8 <stat+0x28>

00000000000005ea <atoi>:

int
atoi(const char *s)
{
 5ea:	1141                	addi	sp,sp,-16
 5ec:	e422                	sd	s0,8(sp)
 5ee:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 5f0:	00054683          	lbu	a3,0(a0)
 5f4:	fd06879b          	addiw	a5,a3,-48
 5f8:	0ff7f793          	zext.b	a5,a5
 5fc:	4625                	li	a2,9
 5fe:	02f66863          	bltu	a2,a5,62e <atoi+0x44>
 602:	872a                	mv	a4,a0
  n = 0;
 604:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 606:	0705                	addi	a4,a4,1
 608:	0025179b          	slliw	a5,a0,0x2
 60c:	9fa9                	addw	a5,a5,a0
 60e:	0017979b          	slliw	a5,a5,0x1
 612:	9fb5                	addw	a5,a5,a3
 614:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 618:	00074683          	lbu	a3,0(a4)
 61c:	fd06879b          	addiw	a5,a3,-48
 620:	0ff7f793          	zext.b	a5,a5
 624:	fef671e3          	bgeu	a2,a5,606 <atoi+0x1c>
  return n;
}
 628:	6422                	ld	s0,8(sp)
 62a:	0141                	addi	sp,sp,16
 62c:	8082                	ret
  n = 0;
 62e:	4501                	li	a0,0
 630:	bfe5                	j	628 <atoi+0x3e>

0000000000000632 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 632:	1141                	addi	sp,sp,-16
 634:	e422                	sd	s0,8(sp)
 636:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 638:	02b57463          	bgeu	a0,a1,660 <memmove+0x2e>
    while(n-- > 0)
 63c:	00c05f63          	blez	a2,65a <memmove+0x28>
 640:	1602                	slli	a2,a2,0x20
 642:	9201                	srli	a2,a2,0x20
 644:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 648:	872a                	mv	a4,a0
      *dst++ = *src++;
 64a:	0585                	addi	a1,a1,1
 64c:	0705                	addi	a4,a4,1
 64e:	fff5c683          	lbu	a3,-1(a1)
 652:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 656:	fee79ae3          	bne	a5,a4,64a <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 65a:	6422                	ld	s0,8(sp)
 65c:	0141                	addi	sp,sp,16
 65e:	8082                	ret
    dst += n;
 660:	00c50733          	add	a4,a0,a2
    src += n;
 664:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 666:	fec05ae3          	blez	a2,65a <memmove+0x28>
 66a:	fff6079b          	addiw	a5,a2,-1
 66e:	1782                	slli	a5,a5,0x20
 670:	9381                	srli	a5,a5,0x20
 672:	fff7c793          	not	a5,a5
 676:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 678:	15fd                	addi	a1,a1,-1
 67a:	177d                	addi	a4,a4,-1
 67c:	0005c683          	lbu	a3,0(a1)
 680:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 684:	fee79ae3          	bne	a5,a4,678 <memmove+0x46>
 688:	bfc9                	j	65a <memmove+0x28>

000000000000068a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 68a:	1141                	addi	sp,sp,-16
 68c:	e422                	sd	s0,8(sp)
 68e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 690:	ca05                	beqz	a2,6c0 <memcmp+0x36>
 692:	fff6069b          	addiw	a3,a2,-1
 696:	1682                	slli	a3,a3,0x20
 698:	9281                	srli	a3,a3,0x20
 69a:	0685                	addi	a3,a3,1
 69c:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 69e:	00054783          	lbu	a5,0(a0)
 6a2:	0005c703          	lbu	a4,0(a1)
 6a6:	00e79863          	bne	a5,a4,6b6 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 6aa:	0505                	addi	a0,a0,1
    p2++;
 6ac:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 6ae:	fed518e3          	bne	a0,a3,69e <memcmp+0x14>
  }
  return 0;
 6b2:	4501                	li	a0,0
 6b4:	a019                	j	6ba <memcmp+0x30>
      return *p1 - *p2;
 6b6:	40e7853b          	subw	a0,a5,a4
}
 6ba:	6422                	ld	s0,8(sp)
 6bc:	0141                	addi	sp,sp,16
 6be:	8082                	ret
  return 0;
 6c0:	4501                	li	a0,0
 6c2:	bfe5                	j	6ba <memcmp+0x30>

00000000000006c4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 6c4:	1141                	addi	sp,sp,-16
 6c6:	e406                	sd	ra,8(sp)
 6c8:	e022                	sd	s0,0(sp)
 6ca:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 6cc:	f67ff0ef          	jal	ra,632 <memmove>
}
 6d0:	60a2                	ld	ra,8(sp)
 6d2:	6402                	ld	s0,0(sp)
 6d4:	0141                	addi	sp,sp,16
 6d6:	8082                	ret

00000000000006d8 <sbrk>:

char *
sbrk(int n) {
 6d8:	1141                	addi	sp,sp,-16
 6da:	e406                	sd	ra,8(sp)
 6dc:	e022                	sd	s0,0(sp)
 6de:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 6e0:	4585                	li	a1,1
 6e2:	0b2000ef          	jal	ra,794 <sys_sbrk>
}
 6e6:	60a2                	ld	ra,8(sp)
 6e8:	6402                	ld	s0,0(sp)
 6ea:	0141                	addi	sp,sp,16
 6ec:	8082                	ret

00000000000006ee <sbrklazy>:

char *
sbrklazy(int n) {
 6ee:	1141                	addi	sp,sp,-16
 6f0:	e406                	sd	ra,8(sp)
 6f2:	e022                	sd	s0,0(sp)
 6f4:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 6f6:	4589                	li	a1,2
 6f8:	09c000ef          	jal	ra,794 <sys_sbrk>
}
 6fc:	60a2                	ld	ra,8(sp)
 6fe:	6402                	ld	s0,0(sp)
 700:	0141                	addi	sp,sp,16
 702:	8082                	ret

0000000000000704 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 704:	4885                	li	a7,1
 ecall
 706:	00000073          	ecall
 ret
 70a:	8082                	ret

000000000000070c <exit>:
.global exit
exit:
 li a7, SYS_exit
 70c:	4889                	li	a7,2
 ecall
 70e:	00000073          	ecall
 ret
 712:	8082                	ret

0000000000000714 <wait>:
.global wait
wait:
 li a7, SYS_wait
 714:	488d                	li	a7,3
 ecall
 716:	00000073          	ecall
 ret
 71a:	8082                	ret

000000000000071c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 71c:	4891                	li	a7,4
 ecall
 71e:	00000073          	ecall
 ret
 722:	8082                	ret

0000000000000724 <read>:
.global read
read:
 li a7, SYS_read
 724:	4895                	li	a7,5
 ecall
 726:	00000073          	ecall
 ret
 72a:	8082                	ret

000000000000072c <write>:
.global write
write:
 li a7, SYS_write
 72c:	48c1                	li	a7,16
 ecall
 72e:	00000073          	ecall
 ret
 732:	8082                	ret

0000000000000734 <close>:
.global close
close:
 li a7, SYS_close
 734:	48d5                	li	a7,21
 ecall
 736:	00000073          	ecall
 ret
 73a:	8082                	ret

000000000000073c <kill>:
.global kill
kill:
 li a7, SYS_kill
 73c:	4899                	li	a7,6
 ecall
 73e:	00000073          	ecall
 ret
 742:	8082                	ret

0000000000000744 <exec>:
.global exec
exec:
 li a7, SYS_exec
 744:	489d                	li	a7,7
 ecall
 746:	00000073          	ecall
 ret
 74a:	8082                	ret

000000000000074c <open>:
.global open
open:
 li a7, SYS_open
 74c:	48bd                	li	a7,15
 ecall
 74e:	00000073          	ecall
 ret
 752:	8082                	ret

0000000000000754 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 754:	48c5                	li	a7,17
 ecall
 756:	00000073          	ecall
 ret
 75a:	8082                	ret

000000000000075c <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 75c:	48c9                	li	a7,18
 ecall
 75e:	00000073          	ecall
 ret
 762:	8082                	ret

0000000000000764 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 764:	48a1                	li	a7,8
 ecall
 766:	00000073          	ecall
 ret
 76a:	8082                	ret

000000000000076c <link>:
.global link
link:
 li a7, SYS_link
 76c:	48cd                	li	a7,19
 ecall
 76e:	00000073          	ecall
 ret
 772:	8082                	ret

0000000000000774 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 774:	48d1                	li	a7,20
 ecall
 776:	00000073          	ecall
 ret
 77a:	8082                	ret

000000000000077c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 77c:	48a5                	li	a7,9
 ecall
 77e:	00000073          	ecall
 ret
 782:	8082                	ret

0000000000000784 <dup>:
.global dup
dup:
 li a7, SYS_dup
 784:	48a9                	li	a7,10
 ecall
 786:	00000073          	ecall
 ret
 78a:	8082                	ret

000000000000078c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 78c:	48ad                	li	a7,11
 ecall
 78e:	00000073          	ecall
 ret
 792:	8082                	ret

0000000000000794 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 794:	48b1                	li	a7,12
 ecall
 796:	00000073          	ecall
 ret
 79a:	8082                	ret

000000000000079c <pause>:
.global pause
pause:
 li a7, SYS_pause
 79c:	48b5                	li	a7,13
 ecall
 79e:	00000073          	ecall
 ret
 7a2:	8082                	ret

00000000000007a4 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 7a4:	48b9                	li	a7,14
 ecall
 7a6:	00000073          	ecall
 ret
 7aa:	8082                	ret

00000000000007ac <getprocinfo>:
.global getprocinfo
getprocinfo:
 li a7, SYS_getprocinfo
 7ac:	48d9                	li	a7,22
 ecall
 7ae:	00000073          	ecall
 ret
 7b2:	8082                	ret

00000000000007b4 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 7b4:	1101                	addi	sp,sp,-32
 7b6:	ec06                	sd	ra,24(sp)
 7b8:	e822                	sd	s0,16(sp)
 7ba:	1000                	addi	s0,sp,32
 7bc:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 7c0:	4605                	li	a2,1
 7c2:	fef40593          	addi	a1,s0,-17
 7c6:	f67ff0ef          	jal	ra,72c <write>
}
 7ca:	60e2                	ld	ra,24(sp)
 7cc:	6442                	ld	s0,16(sp)
 7ce:	6105                	addi	sp,sp,32
 7d0:	8082                	ret

00000000000007d2 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 7d2:	715d                	addi	sp,sp,-80
 7d4:	e486                	sd	ra,72(sp)
 7d6:	e0a2                	sd	s0,64(sp)
 7d8:	fc26                	sd	s1,56(sp)
 7da:	f84a                	sd	s2,48(sp)
 7dc:	f44e                	sd	s3,40(sp)
 7de:	0880                	addi	s0,sp,80
 7e0:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 7e2:	c299                	beqz	a3,7e8 <printint+0x16>
 7e4:	0805c163          	bltz	a1,866 <printint+0x94>
  neg = 0;
 7e8:	4881                	li	a7,0
 7ea:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 7ee:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 7f0:	00001517          	auipc	a0,0x1
 7f4:	cf050513          	addi	a0,a0,-784 # 14e0 <digits>
 7f8:	883e                	mv	a6,a5
 7fa:	2785                	addiw	a5,a5,1
 7fc:	02c5f733          	remu	a4,a1,a2
 800:	972a                	add	a4,a4,a0
 802:	00074703          	lbu	a4,0(a4)
 806:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 80a:	872e                	mv	a4,a1
 80c:	02c5d5b3          	divu	a1,a1,a2
 810:	0685                	addi	a3,a3,1
 812:	fec773e3          	bgeu	a4,a2,7f8 <printint+0x26>
  if(neg)
 816:	00088b63          	beqz	a7,82c <printint+0x5a>
    buf[i++] = '-';
 81a:	fd078793          	addi	a5,a5,-48
 81e:	97a2                	add	a5,a5,s0
 820:	02d00713          	li	a4,45
 824:	fee78423          	sb	a4,-24(a5)
 828:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 82c:	02f05663          	blez	a5,858 <printint+0x86>
 830:	fb840713          	addi	a4,s0,-72
 834:	00f704b3          	add	s1,a4,a5
 838:	fff70993          	addi	s3,a4,-1
 83c:	99be                	add	s3,s3,a5
 83e:	37fd                	addiw	a5,a5,-1
 840:	1782                	slli	a5,a5,0x20
 842:	9381                	srli	a5,a5,0x20
 844:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 848:	fff4c583          	lbu	a1,-1(s1)
 84c:	854a                	mv	a0,s2
 84e:	f67ff0ef          	jal	ra,7b4 <putc>
  while(--i >= 0)
 852:	14fd                	addi	s1,s1,-1
 854:	ff349ae3          	bne	s1,s3,848 <printint+0x76>
}
 858:	60a6                	ld	ra,72(sp)
 85a:	6406                	ld	s0,64(sp)
 85c:	74e2                	ld	s1,56(sp)
 85e:	7942                	ld	s2,48(sp)
 860:	79a2                	ld	s3,40(sp)
 862:	6161                	addi	sp,sp,80
 864:	8082                	ret
    x = -xx;
 866:	40b005b3          	neg	a1,a1
    neg = 1;
 86a:	4885                	li	a7,1
    x = -xx;
 86c:	bfbd                	j	7ea <printint+0x18>

000000000000086e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 86e:	7119                	addi	sp,sp,-128
 870:	fc86                	sd	ra,120(sp)
 872:	f8a2                	sd	s0,112(sp)
 874:	f4a6                	sd	s1,104(sp)
 876:	f0ca                	sd	s2,96(sp)
 878:	ecce                	sd	s3,88(sp)
 87a:	e8d2                	sd	s4,80(sp)
 87c:	e4d6                	sd	s5,72(sp)
 87e:	e0da                	sd	s6,64(sp)
 880:	fc5e                	sd	s7,56(sp)
 882:	f862                	sd	s8,48(sp)
 884:	f466                	sd	s9,40(sp)
 886:	f06a                	sd	s10,32(sp)
 888:	ec6e                	sd	s11,24(sp)
 88a:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 88c:	0005c903          	lbu	s2,0(a1)
 890:	24090c63          	beqz	s2,ae8 <vprintf+0x27a>
 894:	8b2a                	mv	s6,a0
 896:	8a2e                	mv	s4,a1
 898:	8bb2                	mv	s7,a2
  state = 0;
 89a:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 89c:	4481                	li	s1,0
 89e:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 8a0:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 8a4:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 8a8:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 8ac:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 8b0:	00001c97          	auipc	s9,0x1
 8b4:	c30c8c93          	addi	s9,s9,-976 # 14e0 <digits>
 8b8:	a005                	j	8d8 <vprintf+0x6a>
        putc(fd, c0);
 8ba:	85ca                	mv	a1,s2
 8bc:	855a                	mv	a0,s6
 8be:	ef7ff0ef          	jal	ra,7b4 <putc>
 8c2:	a019                	j	8c8 <vprintf+0x5a>
    } else if(state == '%'){
 8c4:	03598263          	beq	s3,s5,8e8 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 8c8:	2485                	addiw	s1,s1,1
 8ca:	8726                	mv	a4,s1
 8cc:	009a07b3          	add	a5,s4,s1
 8d0:	0007c903          	lbu	s2,0(a5)
 8d4:	20090a63          	beqz	s2,ae8 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 8d8:	0009079b          	sext.w	a5,s2
    if(state == 0){
 8dc:	fe0994e3          	bnez	s3,8c4 <vprintf+0x56>
      if(c0 == '%'){
 8e0:	fd579de3          	bne	a5,s5,8ba <vprintf+0x4c>
        state = '%';
 8e4:	89be                	mv	s3,a5
 8e6:	b7cd                	j	8c8 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 8e8:	c3c1                	beqz	a5,968 <vprintf+0xfa>
 8ea:	00ea06b3          	add	a3,s4,a4
 8ee:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 8f2:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 8f4:	c681                	beqz	a3,8fc <vprintf+0x8e>
 8f6:	9752                	add	a4,a4,s4
 8f8:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 8fc:	03878e63          	beq	a5,s8,938 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 900:	05a78863          	beq	a5,s10,950 <vprintf+0xe2>
      } else if(c0 == 'u'){
 904:	0db78b63          	beq	a5,s11,9da <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 908:	07800713          	li	a4,120
 90c:	10e78d63          	beq	a5,a4,a26 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 910:	07000713          	li	a4,112
 914:	14e78263          	beq	a5,a4,a58 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 918:	06300713          	li	a4,99
 91c:	16e78f63          	beq	a5,a4,a9a <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 920:	07300713          	li	a4,115
 924:	18e78563          	beq	a5,a4,aae <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 928:	05579063          	bne	a5,s5,968 <vprintf+0xfa>
        putc(fd, '%');
 92c:	85d6                	mv	a1,s5
 92e:	855a                	mv	a0,s6
 930:	e85ff0ef          	jal	ra,7b4 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 934:	4981                	li	s3,0
 936:	bf49                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 938:	008b8913          	addi	s2,s7,8
 93c:	4685                	li	a3,1
 93e:	4629                	li	a2,10
 940:	000ba583          	lw	a1,0(s7)
 944:	855a                	mv	a0,s6
 946:	e8dff0ef          	jal	ra,7d2 <printint>
 94a:	8bca                	mv	s7,s2
      state = 0;
 94c:	4981                	li	s3,0
 94e:	bfad                	j	8c8 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 950:	03868663          	beq	a3,s8,97c <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 954:	05a68163          	beq	a3,s10,996 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 958:	09b68d63          	beq	a3,s11,9f2 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 95c:	03a68f63          	beq	a3,s10,99a <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 960:	07800793          	li	a5,120
 964:	0cf68d63          	beq	a3,a5,a3e <vprintf+0x1d0>
        putc(fd, '%');
 968:	85d6                	mv	a1,s5
 96a:	855a                	mv	a0,s6
 96c:	e49ff0ef          	jal	ra,7b4 <putc>
        putc(fd, c0);
 970:	85ca                	mv	a1,s2
 972:	855a                	mv	a0,s6
 974:	e41ff0ef          	jal	ra,7b4 <putc>
      state = 0;
 978:	4981                	li	s3,0
 97a:	b7b9                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 97c:	008b8913          	addi	s2,s7,8
 980:	4685                	li	a3,1
 982:	4629                	li	a2,10
 984:	000bb583          	ld	a1,0(s7)
 988:	855a                	mv	a0,s6
 98a:	e49ff0ef          	jal	ra,7d2 <printint>
        i += 1;
 98e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 990:	8bca                	mv	s7,s2
      state = 0;
 992:	4981                	li	s3,0
        i += 1;
 994:	bf15                	j	8c8 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 996:	03860563          	beq	a2,s8,9c0 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 99a:	07b60963          	beq	a2,s11,a0c <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 99e:	07800793          	li	a5,120
 9a2:	fcf613e3          	bne	a2,a5,968 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9a6:	008b8913          	addi	s2,s7,8
 9aa:	4681                	li	a3,0
 9ac:	4641                	li	a2,16
 9ae:	000bb583          	ld	a1,0(s7)
 9b2:	855a                	mv	a0,s6
 9b4:	e1fff0ef          	jal	ra,7d2 <printint>
        i += 2;
 9b8:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 9ba:	8bca                	mv	s7,s2
      state = 0;
 9bc:	4981                	li	s3,0
        i += 2;
 9be:	b729                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 9c0:	008b8913          	addi	s2,s7,8
 9c4:	4685                	li	a3,1
 9c6:	4629                	li	a2,10
 9c8:	000bb583          	ld	a1,0(s7)
 9cc:	855a                	mv	a0,s6
 9ce:	e05ff0ef          	jal	ra,7d2 <printint>
        i += 2;
 9d2:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 9d4:	8bca                	mv	s7,s2
      state = 0;
 9d6:	4981                	li	s3,0
        i += 2;
 9d8:	bdc5                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 9da:	008b8913          	addi	s2,s7,8
 9de:	4681                	li	a3,0
 9e0:	4629                	li	a2,10
 9e2:	000be583          	lwu	a1,0(s7)
 9e6:	855a                	mv	a0,s6
 9e8:	debff0ef          	jal	ra,7d2 <printint>
 9ec:	8bca                	mv	s7,s2
      state = 0;
 9ee:	4981                	li	s3,0
 9f0:	bde1                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 9f2:	008b8913          	addi	s2,s7,8
 9f6:	4681                	li	a3,0
 9f8:	4629                	li	a2,10
 9fa:	000bb583          	ld	a1,0(s7)
 9fe:	855a                	mv	a0,s6
 a00:	dd3ff0ef          	jal	ra,7d2 <printint>
        i += 1;
 a04:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 a06:	8bca                	mv	s7,s2
      state = 0;
 a08:	4981                	li	s3,0
        i += 1;
 a0a:	bd7d                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 a0c:	008b8913          	addi	s2,s7,8
 a10:	4681                	li	a3,0
 a12:	4629                	li	a2,10
 a14:	000bb583          	ld	a1,0(s7)
 a18:	855a                	mv	a0,s6
 a1a:	db9ff0ef          	jal	ra,7d2 <printint>
        i += 2;
 a1e:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 a20:	8bca                	mv	s7,s2
      state = 0;
 a22:	4981                	li	s3,0
        i += 2;
 a24:	b555                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 a26:	008b8913          	addi	s2,s7,8
 a2a:	4681                	li	a3,0
 a2c:	4641                	li	a2,16
 a2e:	000be583          	lwu	a1,0(s7)
 a32:	855a                	mv	a0,s6
 a34:	d9fff0ef          	jal	ra,7d2 <printint>
 a38:	8bca                	mv	s7,s2
      state = 0;
 a3a:	4981                	li	s3,0
 a3c:	b571                	j	8c8 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 a3e:	008b8913          	addi	s2,s7,8
 a42:	4681                	li	a3,0
 a44:	4641                	li	a2,16
 a46:	000bb583          	ld	a1,0(s7)
 a4a:	855a                	mv	a0,s6
 a4c:	d87ff0ef          	jal	ra,7d2 <printint>
        i += 1;
 a50:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 a52:	8bca                	mv	s7,s2
      state = 0;
 a54:	4981                	li	s3,0
        i += 1;
 a56:	bd8d                	j	8c8 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 a58:	008b8793          	addi	a5,s7,8
 a5c:	f8f43423          	sd	a5,-120(s0)
 a60:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 a64:	03000593          	li	a1,48
 a68:	855a                	mv	a0,s6
 a6a:	d4bff0ef          	jal	ra,7b4 <putc>
  putc(fd, 'x');
 a6e:	07800593          	li	a1,120
 a72:	855a                	mv	a0,s6
 a74:	d41ff0ef          	jal	ra,7b4 <putc>
 a78:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a7a:	03c9d793          	srli	a5,s3,0x3c
 a7e:	97e6                	add	a5,a5,s9
 a80:	0007c583          	lbu	a1,0(a5)
 a84:	855a                	mv	a0,s6
 a86:	d2fff0ef          	jal	ra,7b4 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a8a:	0992                	slli	s3,s3,0x4
 a8c:	397d                	addiw	s2,s2,-1
 a8e:	fe0916e3          	bnez	s2,a7a <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 a92:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 a96:	4981                	li	s3,0
 a98:	bd05                	j	8c8 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 a9a:	008b8913          	addi	s2,s7,8
 a9e:	000bc583          	lbu	a1,0(s7)
 aa2:	855a                	mv	a0,s6
 aa4:	d11ff0ef          	jal	ra,7b4 <putc>
 aa8:	8bca                	mv	s7,s2
      state = 0;
 aaa:	4981                	li	s3,0
 aac:	bd31                	j	8c8 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 aae:	008b8993          	addi	s3,s7,8
 ab2:	000bb903          	ld	s2,0(s7)
 ab6:	00090f63          	beqz	s2,ad4 <vprintf+0x266>
        for(; *s; s++)
 aba:	00094583          	lbu	a1,0(s2)
 abe:	c195                	beqz	a1,ae2 <vprintf+0x274>
          putc(fd, *s);
 ac0:	855a                	mv	a0,s6
 ac2:	cf3ff0ef          	jal	ra,7b4 <putc>
        for(; *s; s++)
 ac6:	0905                	addi	s2,s2,1
 ac8:	00094583          	lbu	a1,0(s2)
 acc:	f9f5                	bnez	a1,ac0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 ace:	8bce                	mv	s7,s3
      state = 0;
 ad0:	4981                	li	s3,0
 ad2:	bbdd                	j	8c8 <vprintf+0x5a>
          s = "(null)";
 ad4:	00001917          	auipc	s2,0x1
 ad8:	a0490913          	addi	s2,s2,-1532 # 14d8 <malloc+0x8f4>
        for(; *s; s++)
 adc:	02800593          	li	a1,40
 ae0:	b7c5                	j	ac0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 ae2:	8bce                	mv	s7,s3
      state = 0;
 ae4:	4981                	li	s3,0
 ae6:	b3cd                	j	8c8 <vprintf+0x5a>
    }
  }
}
 ae8:	70e6                	ld	ra,120(sp)
 aea:	7446                	ld	s0,112(sp)
 aec:	74a6                	ld	s1,104(sp)
 aee:	7906                	ld	s2,96(sp)
 af0:	69e6                	ld	s3,88(sp)
 af2:	6a46                	ld	s4,80(sp)
 af4:	6aa6                	ld	s5,72(sp)
 af6:	6b06                	ld	s6,64(sp)
 af8:	7be2                	ld	s7,56(sp)
 afa:	7c42                	ld	s8,48(sp)
 afc:	7ca2                	ld	s9,40(sp)
 afe:	7d02                	ld	s10,32(sp)
 b00:	6de2                	ld	s11,24(sp)
 b02:	6109                	addi	sp,sp,128
 b04:	8082                	ret

0000000000000b06 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 b06:	715d                	addi	sp,sp,-80
 b08:	ec06                	sd	ra,24(sp)
 b0a:	e822                	sd	s0,16(sp)
 b0c:	1000                	addi	s0,sp,32
 b0e:	e010                	sd	a2,0(s0)
 b10:	e414                	sd	a3,8(s0)
 b12:	e818                	sd	a4,16(s0)
 b14:	ec1c                	sd	a5,24(s0)
 b16:	03043023          	sd	a6,32(s0)
 b1a:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 b1e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 b22:	8622                	mv	a2,s0
 b24:	d4bff0ef          	jal	ra,86e <vprintf>
}
 b28:	60e2                	ld	ra,24(sp)
 b2a:	6442                	ld	s0,16(sp)
 b2c:	6161                	addi	sp,sp,80
 b2e:	8082                	ret

0000000000000b30 <printf>:

void
printf(const char *fmt, ...)
{
 b30:	711d                	addi	sp,sp,-96
 b32:	ec06                	sd	ra,24(sp)
 b34:	e822                	sd	s0,16(sp)
 b36:	1000                	addi	s0,sp,32
 b38:	e40c                	sd	a1,8(s0)
 b3a:	e810                	sd	a2,16(s0)
 b3c:	ec14                	sd	a3,24(s0)
 b3e:	f018                	sd	a4,32(s0)
 b40:	f41c                	sd	a5,40(s0)
 b42:	03043823          	sd	a6,48(s0)
 b46:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 b4a:	00840613          	addi	a2,s0,8
 b4e:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 b52:	85aa                	mv	a1,a0
 b54:	4505                	li	a0,1
 b56:	d19ff0ef          	jal	ra,86e <vprintf>
}
 b5a:	60e2                	ld	ra,24(sp)
 b5c:	6442                	ld	s0,16(sp)
 b5e:	6125                	addi	sp,sp,96
 b60:	8082                	ret

0000000000000b62 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 b62:	1141                	addi	sp,sp,-16
 b64:	e422                	sd	s0,8(sp)
 b66:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 b68:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b6c:	00001797          	auipc	a5,0x1
 b70:	4947b783          	ld	a5,1172(a5) # 2000 <freep>
 b74:	a02d                	j	b9e <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 b76:	4618                	lw	a4,8(a2)
 b78:	9f2d                	addw	a4,a4,a1
 b7a:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 b7e:	6398                	ld	a4,0(a5)
 b80:	6310                	ld	a2,0(a4)
 b82:	a83d                	j	bc0 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 b84:	ff852703          	lw	a4,-8(a0)
 b88:	9f31                	addw	a4,a4,a2
 b8a:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 b8c:	ff053683          	ld	a3,-16(a0)
 b90:	a091                	j	bd4 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b92:	6398                	ld	a4,0(a5)
 b94:	00e7e463          	bltu	a5,a4,b9c <free+0x3a>
 b98:	00e6ea63          	bltu	a3,a4,bac <free+0x4a>
{
 b9c:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b9e:	fed7fae3          	bgeu	a5,a3,b92 <free+0x30>
 ba2:	6398                	ld	a4,0(a5)
 ba4:	00e6e463          	bltu	a3,a4,bac <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ba8:	fee7eae3          	bltu	a5,a4,b9c <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 bac:	ff852583          	lw	a1,-8(a0)
 bb0:	6390                	ld	a2,0(a5)
 bb2:	02059813          	slli	a6,a1,0x20
 bb6:	01c85713          	srli	a4,a6,0x1c
 bba:	9736                	add	a4,a4,a3
 bbc:	fae60de3          	beq	a2,a4,b76 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 bc0:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 bc4:	4790                	lw	a2,8(a5)
 bc6:	02061593          	slli	a1,a2,0x20
 bca:	01c5d713          	srli	a4,a1,0x1c
 bce:	973e                	add	a4,a4,a5
 bd0:	fae68ae3          	beq	a3,a4,b84 <free+0x22>
    p->s.ptr = bp->s.ptr;
 bd4:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 bd6:	00001717          	auipc	a4,0x1
 bda:	42f73523          	sd	a5,1066(a4) # 2000 <freep>
}
 bde:	6422                	ld	s0,8(sp)
 be0:	0141                	addi	sp,sp,16
 be2:	8082                	ret

0000000000000be4 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 be4:	7139                	addi	sp,sp,-64
 be6:	fc06                	sd	ra,56(sp)
 be8:	f822                	sd	s0,48(sp)
 bea:	f426                	sd	s1,40(sp)
 bec:	f04a                	sd	s2,32(sp)
 bee:	ec4e                	sd	s3,24(sp)
 bf0:	e852                	sd	s4,16(sp)
 bf2:	e456                	sd	s5,8(sp)
 bf4:	e05a                	sd	s6,0(sp)
 bf6:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 bf8:	02051493          	slli	s1,a0,0x20
 bfc:	9081                	srli	s1,s1,0x20
 bfe:	04bd                	addi	s1,s1,15
 c00:	8091                	srli	s1,s1,0x4
 c02:	0014899b          	addiw	s3,s1,1
 c06:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 c08:	00001517          	auipc	a0,0x1
 c0c:	3f853503          	ld	a0,1016(a0) # 2000 <freep>
 c10:	c515                	beqz	a0,c3c <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c12:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 c14:	4798                	lw	a4,8(a5)
 c16:	02977f63          	bgeu	a4,s1,c54 <malloc+0x70>
 c1a:	8a4e                	mv	s4,s3
 c1c:	0009871b          	sext.w	a4,s3
 c20:	6685                	lui	a3,0x1
 c22:	00d77363          	bgeu	a4,a3,c28 <malloc+0x44>
 c26:	6a05                	lui	s4,0x1
 c28:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 c2c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 c30:	00001917          	auipc	s2,0x1
 c34:	3d090913          	addi	s2,s2,976 # 2000 <freep>
  if(p == SBRK_ERROR)
 c38:	5afd                	li	s5,-1
 c3a:	a885                	j	caa <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 c3c:	00001797          	auipc	a5,0x1
 c40:	3d478793          	addi	a5,a5,980 # 2010 <base>
 c44:	00001717          	auipc	a4,0x1
 c48:	3af73e23          	sd	a5,956(a4) # 2000 <freep>
 c4c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 c4e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 c52:	b7e1                	j	c1a <malloc+0x36>
      if(p->s.size == nunits)
 c54:	02e48c63          	beq	s1,a4,c8c <malloc+0xa8>
        p->s.size -= nunits;
 c58:	4137073b          	subw	a4,a4,s3
 c5c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 c5e:	02071693          	slli	a3,a4,0x20
 c62:	01c6d713          	srli	a4,a3,0x1c
 c66:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 c68:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 c6c:	00001717          	auipc	a4,0x1
 c70:	38a73a23          	sd	a0,916(a4) # 2000 <freep>
      return (void*)(p + 1);
 c74:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 c78:	70e2                	ld	ra,56(sp)
 c7a:	7442                	ld	s0,48(sp)
 c7c:	74a2                	ld	s1,40(sp)
 c7e:	7902                	ld	s2,32(sp)
 c80:	69e2                	ld	s3,24(sp)
 c82:	6a42                	ld	s4,16(sp)
 c84:	6aa2                	ld	s5,8(sp)
 c86:	6b02                	ld	s6,0(sp)
 c88:	6121                	addi	sp,sp,64
 c8a:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 c8c:	6398                	ld	a4,0(a5)
 c8e:	e118                	sd	a4,0(a0)
 c90:	bff1                	j	c6c <malloc+0x88>
  hp->s.size = nu;
 c92:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 c96:	0541                	addi	a0,a0,16
 c98:	ecbff0ef          	jal	ra,b62 <free>
  return freep;
 c9c:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 ca0:	dd61                	beqz	a0,c78 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ca2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 ca4:	4798                	lw	a4,8(a5)
 ca6:	fa9777e3          	bgeu	a4,s1,c54 <malloc+0x70>
    if(p == freep)
 caa:	00093703          	ld	a4,0(s2)
 cae:	853e                	mv	a0,a5
 cb0:	fef719e3          	bne	a4,a5,ca2 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 cb4:	8552                	mv	a0,s4
 cb6:	a23ff0ef          	jal	ra,6d8 <sbrk>
  if(p == SBRK_ERROR)
 cba:	fd551ce3          	bne	a0,s5,c92 <malloc+0xae>
        return 0;
 cbe:	4501                	li	a0,0
 cc0:	bf65                	j	c78 <malloc+0x94>
