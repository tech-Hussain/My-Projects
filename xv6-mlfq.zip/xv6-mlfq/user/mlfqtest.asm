
user/_mlfqtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "user/user.h"

// Pure CPU-bound test program to verify MLFQ priority demotion
int
main(int argc, char *argv[])
{
   0:	711d                	addi	sp,sp,-96
   2:	ec86                	sd	ra,88(sp)
   4:	e8a2                	sd	s0,80(sp)
   6:	e4a6                	sd	s1,72(sp)
   8:	1080                	addi	s0,sp,96
  struct procinfo info;
  int pid;
  volatile int dummy = 0;  // volatile to prevent optimization
   a:	fa042223          	sw	zero,-92(s0)
  
  printf("=== MLFQ Priority Demotion Test ===\n");
   e:	00001517          	auipc	a0,0x1
  12:	9f250513          	addi	a0,a0,-1550 # a00 <malloc+0xea>
  16:	04d000ef          	jal	ra,862 <printf>
  
  pid = getpid();
  1a:	4a4000ef          	jal	ra,4be <getpid>
  1e:	84aa                	mv	s1,a0
  
  // Initial priority check
  if(getprocinfo(pid, &info) == 0) {
  20:	fa840593          	addi	a1,s0,-88
  24:	4ba000ef          	jal	ra,4de <getprocinfo>
  28:	c561                	beqz	a0,f0 <main+0xf0>
    printf("  Priority: %d (should be 0 - HIGH)\n", info.priority);
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
    printf("  Timeslice: %d ticks\n\n", info.timeslice_used);
  }
  
  printf("Starting PURE CPU-bound workload (no I/O)...\n");
  2a:	00001517          	auipc	a0,0x1
  2e:	a6650513          	addi	a0,a0,-1434 # a90 <malloc+0x17a>
  32:	031000ef          	jal	ra,862 <printf>
  printf("This will consume CPU continuously to trigger demotion.\n\n");
  36:	00001517          	auipc	a0,0x1
  3a:	a8a50513          	addi	a0,a0,-1398 # ac0 <malloc+0x1aa>
  3e:	025000ef          	jal	ra,862 <printf>
  42:	4681                	li	a3,0
  
  // PURE CPU-bound work - NO system calls or I/O during computation!
  // This will force the process to use its full timeslice and get demoted
  for(int i = 0; i < 50000000; i++) {
  44:	4781                	li	a5,0
    // Pure computation - no I/O, no system calls
    dummy = dummy + (i * 3) % 97;  // Some arithmetic to consume CPU
  46:	06100513          	li	a0,97
  for(int i = 0; i < 50000000; i++) {
  4a:	02faf5b7          	lui	a1,0x2faf
  4e:	08058593          	addi	a1,a1,128 # 2faf080 <base+0x2fae070>
    dummy = dummy + (i * 3) % 97;  // Some arithmetic to consume CPU
  52:	fa442603          	lw	a2,-92(s0)
  56:	02a6e73b          	remw	a4,a3,a0
  5a:	9f31                	addw	a4,a4,a2
  5c:	fae42223          	sw	a4,-92(s0)
    dummy = dummy ^ (i & 0xFF);     // More operations
  60:	fa442703          	lw	a4,-92(s0)
  64:	0ff7f613          	zext.b	a2,a5
  68:	8f31                	xor	a4,a4,a2
  6a:	fae42223          	sw	a4,-92(s0)
  for(int i = 0; i < 50000000; i++) {
  6e:	2785                	addiw	a5,a5,1
  70:	268d                	addiw	a3,a3,3
  72:	feb790e3          	bne	a5,a1,52 <main+0x52>
  }
  
  // Check priority after first burst
  if(getprocinfo(pid, &info) == 0) {
  76:	fa840593          	addi	a1,s0,-88
  7a:	8526                	mv	a0,s1
  7c:	462000ef          	jal	ra,4de <getprocinfo>
  80:	c55d                	beqz	a0,12e <main+0x12e>
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
    printf("  Schedule Count: %d\n\n", info.sched_count);
  }
  
  // Another CPU burst to potentially demote further
  printf("Running second CPU burst...\n");
  82:	00001517          	auipc	a0,0x1
  86:	ade50513          	addi	a0,a0,-1314 # b60 <malloc+0x24a>
  8a:	7d8000ef          	jal	ra,862 <printf>
  8e:	4681                	li	a3,0
  for(int i = 0; i < 50000000; i++) {
  90:	4781                	li	a5,0
    dummy = dummy + (i * 5) % 89;
  92:	05900513          	li	a0,89
  for(int i = 0; i < 50000000; i++) {
  96:	02faf5b7          	lui	a1,0x2faf
  9a:	08058593          	addi	a1,a1,128 # 2faf080 <base+0x2fae070>
    dummy = dummy + (i * 5) % 89;
  9e:	fa442603          	lw	a2,-92(s0)
  a2:	02a6e73b          	remw	a4,a3,a0
  a6:	9f31                	addw	a4,a4,a2
  a8:	fae42223          	sw	a4,-92(s0)
    dummy = dummy ^ (i & 0xAA);
  ac:	fa442703          	lw	a4,-92(s0)
  b0:	0aa7f613          	andi	a2,a5,170
  b4:	8f31                	xor	a4,a4,a2
  b6:	fae42223          	sw	a4,-92(s0)
  for(int i = 0; i < 50000000; i++) {
  ba:	2785                	addiw	a5,a5,1
  bc:	2695                	addiw	a3,a3,5
  be:	feb790e3          	bne	a5,a1,9e <main+0x9e>
  }
  
  // Final check
  if(getprocinfo(pid, &info) == 0) {
  c2:	fa840593          	addi	a1,s0,-88
  c6:	8526                	mv	a0,s1
  c8:	416000ef          	jal	ra,4de <getprocinfo>
  cc:	c145                	beqz	a0,16c <main+0x16c>
    printf("  Priority: %d (should be 2 - LOW)\n", info.priority);
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
    printf("  Schedule Count: %d\n", info.sched_count);
  }
  
  printf("\n=== Test Complete ===\n");
  ce:	00001517          	auipc	a0,0x1
  d2:	b0250513          	addi	a0,a0,-1278 # bd0 <malloc+0x2ba>
  d6:	78c000ef          	jal	ra,862 <printf>
  printf("Dummy value (to prevent optimization): %d\n", dummy);
  da:	fa442583          	lw	a1,-92(s0)
  de:	00001517          	auipc	a0,0x1
  e2:	b0a50513          	addi	a0,a0,-1270 # be8 <malloc+0x2d2>
  e6:	77c000ef          	jal	ra,862 <printf>
  
  exit(0);
  ea:	4501                	li	a0,0
  ec:	352000ef          	jal	ra,43e <exit>
    printf("Initial State:\n");
  f0:	00001517          	auipc	a0,0x1
  f4:	93850513          	addi	a0,a0,-1736 # a28 <malloc+0x112>
  f8:	76a000ef          	jal	ra,862 <printf>
    printf("  Priority: %d (should be 0 - HIGH)\n", info.priority);
  fc:	fac42583          	lw	a1,-84(s0)
 100:	00001517          	auipc	a0,0x1
 104:	93850513          	addi	a0,a0,-1736 # a38 <malloc+0x122>
 108:	75a000ef          	jal	ra,862 <printf>
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
 10c:	fb042583          	lw	a1,-80(s0)
 110:	00001517          	auipc	a0,0x1
 114:	95050513          	addi	a0,a0,-1712 # a60 <malloc+0x14a>
 118:	74a000ef          	jal	ra,862 <printf>
    printf("  Timeslice: %d ticks\n\n", info.timeslice_used);
 11c:	fb842583          	lw	a1,-72(s0)
 120:	00001517          	auipc	a0,0x1
 124:	95850513          	addi	a0,a0,-1704 # a78 <malloc+0x162>
 128:	73a000ef          	jal	ra,862 <printf>
 12c:	bdfd                	j	2a <main+0x2a>
    printf("After First CPU Burst:\n");
 12e:	00001517          	auipc	a0,0x1
 132:	9d250513          	addi	a0,a0,-1582 # b00 <malloc+0x1ea>
 136:	72c000ef          	jal	ra,862 <printf>
    printf("  Priority: %d (should be 1 or 2 - DEMOTED)\n", info.priority);
 13a:	fac42583          	lw	a1,-84(s0)
 13e:	00001517          	auipc	a0,0x1
 142:	9da50513          	addi	a0,a0,-1574 # b18 <malloc+0x202>
 146:	71c000ef          	jal	ra,862 <printf>
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
 14a:	fb042583          	lw	a1,-80(s0)
 14e:	00001517          	auipc	a0,0x1
 152:	91250513          	addi	a0,a0,-1774 # a60 <malloc+0x14a>
 156:	70c000ef          	jal	ra,862 <printf>
    printf("  Schedule Count: %d\n\n", info.sched_count);
 15a:	fb442583          	lw	a1,-76(s0)
 15e:	00001517          	auipc	a0,0x1
 162:	9ea50513          	addi	a0,a0,-1558 # b48 <malloc+0x232>
 166:	6fc000ef          	jal	ra,862 <printf>
 16a:	bf21                	j	82 <main+0x82>
    printf("\nFinal State:\n");
 16c:	00001517          	auipc	a0,0x1
 170:	a1450513          	addi	a0,a0,-1516 # b80 <malloc+0x26a>
 174:	6ee000ef          	jal	ra,862 <printf>
    printf("  Priority: %d (should be 2 - LOW)\n", info.priority);
 178:	fac42583          	lw	a1,-84(s0)
 17c:	00001517          	auipc	a0,0x1
 180:	a1450513          	addi	a0,a0,-1516 # b90 <malloc+0x27a>
 184:	6de000ef          	jal	ra,862 <printf>
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
 188:	fb042583          	lw	a1,-80(s0)
 18c:	00001517          	auipc	a0,0x1
 190:	8d450513          	addi	a0,a0,-1836 # a60 <malloc+0x14a>
 194:	6ce000ef          	jal	ra,862 <printf>
    printf("  Schedule Count: %d\n", info.sched_count);
 198:	fb442583          	lw	a1,-76(s0)
 19c:	00001517          	auipc	a0,0x1
 1a0:	a1c50513          	addi	a0,a0,-1508 # bb8 <malloc+0x2a2>
 1a4:	6be000ef          	jal	ra,862 <printf>
 1a8:	b71d                	j	ce <main+0xce>

00000000000001aa <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 1aa:	1141                	addi	sp,sp,-16
 1ac:	e406                	sd	ra,8(sp)
 1ae:	e022                	sd	s0,0(sp)
 1b0:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 1b2:	e4fff0ef          	jal	ra,0 <main>
  exit(r);
 1b6:	288000ef          	jal	ra,43e <exit>

00000000000001ba <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 1ba:	1141                	addi	sp,sp,-16
 1bc:	e422                	sd	s0,8(sp)
 1be:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1c0:	87aa                	mv	a5,a0
 1c2:	0585                	addi	a1,a1,1
 1c4:	0785                	addi	a5,a5,1
 1c6:	fff5c703          	lbu	a4,-1(a1)
 1ca:	fee78fa3          	sb	a4,-1(a5)
 1ce:	fb75                	bnez	a4,1c2 <strcpy+0x8>
    ;
  return os;
}
 1d0:	6422                	ld	s0,8(sp)
 1d2:	0141                	addi	sp,sp,16
 1d4:	8082                	ret

00000000000001d6 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1d6:	1141                	addi	sp,sp,-16
 1d8:	e422                	sd	s0,8(sp)
 1da:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 1dc:	00054783          	lbu	a5,0(a0)
 1e0:	cb91                	beqz	a5,1f4 <strcmp+0x1e>
 1e2:	0005c703          	lbu	a4,0(a1)
 1e6:	00f71763          	bne	a4,a5,1f4 <strcmp+0x1e>
    p++, q++;
 1ea:	0505                	addi	a0,a0,1
 1ec:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1ee:	00054783          	lbu	a5,0(a0)
 1f2:	fbe5                	bnez	a5,1e2 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 1f4:	0005c503          	lbu	a0,0(a1)
}
 1f8:	40a7853b          	subw	a0,a5,a0
 1fc:	6422                	ld	s0,8(sp)
 1fe:	0141                	addi	sp,sp,16
 200:	8082                	ret

0000000000000202 <strlen>:

uint
strlen(const char *s)
{
 202:	1141                	addi	sp,sp,-16
 204:	e422                	sd	s0,8(sp)
 206:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 208:	00054783          	lbu	a5,0(a0)
 20c:	cf91                	beqz	a5,228 <strlen+0x26>
 20e:	0505                	addi	a0,a0,1
 210:	87aa                	mv	a5,a0
 212:	4685                	li	a3,1
 214:	9e89                	subw	a3,a3,a0
 216:	00f6853b          	addw	a0,a3,a5
 21a:	0785                	addi	a5,a5,1
 21c:	fff7c703          	lbu	a4,-1(a5)
 220:	fb7d                	bnez	a4,216 <strlen+0x14>
    ;
  return n;
}
 222:	6422                	ld	s0,8(sp)
 224:	0141                	addi	sp,sp,16
 226:	8082                	ret
  for(n = 0; s[n]; n++)
 228:	4501                	li	a0,0
 22a:	bfe5                	j	222 <strlen+0x20>

000000000000022c <memset>:

void*
memset(void *dst, int c, uint n)
{
 22c:	1141                	addi	sp,sp,-16
 22e:	e422                	sd	s0,8(sp)
 230:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 232:	ca19                	beqz	a2,248 <memset+0x1c>
 234:	87aa                	mv	a5,a0
 236:	1602                	slli	a2,a2,0x20
 238:	9201                	srli	a2,a2,0x20
 23a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 23e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 242:	0785                	addi	a5,a5,1
 244:	fee79de3          	bne	a5,a4,23e <memset+0x12>
  }
  return dst;
}
 248:	6422                	ld	s0,8(sp)
 24a:	0141                	addi	sp,sp,16
 24c:	8082                	ret

000000000000024e <strchr>:

char*
strchr(const char *s, char c)
{
 24e:	1141                	addi	sp,sp,-16
 250:	e422                	sd	s0,8(sp)
 252:	0800                	addi	s0,sp,16
  for(; *s; s++)
 254:	00054783          	lbu	a5,0(a0)
 258:	cb99                	beqz	a5,26e <strchr+0x20>
    if(*s == c)
 25a:	00f58763          	beq	a1,a5,268 <strchr+0x1a>
  for(; *s; s++)
 25e:	0505                	addi	a0,a0,1
 260:	00054783          	lbu	a5,0(a0)
 264:	fbfd                	bnez	a5,25a <strchr+0xc>
      return (char*)s;
  return 0;
 266:	4501                	li	a0,0
}
 268:	6422                	ld	s0,8(sp)
 26a:	0141                	addi	sp,sp,16
 26c:	8082                	ret
  return 0;
 26e:	4501                	li	a0,0
 270:	bfe5                	j	268 <strchr+0x1a>

0000000000000272 <gets>:

char*
gets(char *buf, int max)
{
 272:	711d                	addi	sp,sp,-96
 274:	ec86                	sd	ra,88(sp)
 276:	e8a2                	sd	s0,80(sp)
 278:	e4a6                	sd	s1,72(sp)
 27a:	e0ca                	sd	s2,64(sp)
 27c:	fc4e                	sd	s3,56(sp)
 27e:	f852                	sd	s4,48(sp)
 280:	f456                	sd	s5,40(sp)
 282:	f05a                	sd	s6,32(sp)
 284:	ec5e                	sd	s7,24(sp)
 286:	1080                	addi	s0,sp,96
 288:	8baa                	mv	s7,a0
 28a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 28c:	892a                	mv	s2,a0
 28e:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 290:	4aa9                	li	s5,10
 292:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 294:	89a6                	mv	s3,s1
 296:	2485                	addiw	s1,s1,1
 298:	0344d663          	bge	s1,s4,2c4 <gets+0x52>
    cc = read(0, &c, 1);
 29c:	4605                	li	a2,1
 29e:	faf40593          	addi	a1,s0,-81
 2a2:	4501                	li	a0,0
 2a4:	1b2000ef          	jal	ra,456 <read>
    if(cc < 1)
 2a8:	00a05e63          	blez	a0,2c4 <gets+0x52>
    buf[i++] = c;
 2ac:	faf44783          	lbu	a5,-81(s0)
 2b0:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 2b4:	01578763          	beq	a5,s5,2c2 <gets+0x50>
 2b8:	0905                	addi	s2,s2,1
 2ba:	fd679de3          	bne	a5,s6,294 <gets+0x22>
  for(i=0; i+1 < max; ){
 2be:	89a6                	mv	s3,s1
 2c0:	a011                	j	2c4 <gets+0x52>
 2c2:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 2c4:	99de                	add	s3,s3,s7
 2c6:	00098023          	sb	zero,0(s3)
  return buf;
}
 2ca:	855e                	mv	a0,s7
 2cc:	60e6                	ld	ra,88(sp)
 2ce:	6446                	ld	s0,80(sp)
 2d0:	64a6                	ld	s1,72(sp)
 2d2:	6906                	ld	s2,64(sp)
 2d4:	79e2                	ld	s3,56(sp)
 2d6:	7a42                	ld	s4,48(sp)
 2d8:	7aa2                	ld	s5,40(sp)
 2da:	7b02                	ld	s6,32(sp)
 2dc:	6be2                	ld	s7,24(sp)
 2de:	6125                	addi	sp,sp,96
 2e0:	8082                	ret

00000000000002e2 <stat>:

int
stat(const char *n, struct stat *st)
{
 2e2:	1101                	addi	sp,sp,-32
 2e4:	ec06                	sd	ra,24(sp)
 2e6:	e822                	sd	s0,16(sp)
 2e8:	e426                	sd	s1,8(sp)
 2ea:	e04a                	sd	s2,0(sp)
 2ec:	1000                	addi	s0,sp,32
 2ee:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2f0:	4581                	li	a1,0
 2f2:	18c000ef          	jal	ra,47e <open>
  if(fd < 0)
 2f6:	02054163          	bltz	a0,318 <stat+0x36>
 2fa:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2fc:	85ca                	mv	a1,s2
 2fe:	198000ef          	jal	ra,496 <fstat>
 302:	892a                	mv	s2,a0
  close(fd);
 304:	8526                	mv	a0,s1
 306:	160000ef          	jal	ra,466 <close>
  return r;
}
 30a:	854a                	mv	a0,s2
 30c:	60e2                	ld	ra,24(sp)
 30e:	6442                	ld	s0,16(sp)
 310:	64a2                	ld	s1,8(sp)
 312:	6902                	ld	s2,0(sp)
 314:	6105                	addi	sp,sp,32
 316:	8082                	ret
    return -1;
 318:	597d                	li	s2,-1
 31a:	bfc5                	j	30a <stat+0x28>

000000000000031c <atoi>:

int
atoi(const char *s)
{
 31c:	1141                	addi	sp,sp,-16
 31e:	e422                	sd	s0,8(sp)
 320:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 322:	00054683          	lbu	a3,0(a0)
 326:	fd06879b          	addiw	a5,a3,-48
 32a:	0ff7f793          	zext.b	a5,a5
 32e:	4625                	li	a2,9
 330:	02f66863          	bltu	a2,a5,360 <atoi+0x44>
 334:	872a                	mv	a4,a0
  n = 0;
 336:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 338:	0705                	addi	a4,a4,1
 33a:	0025179b          	slliw	a5,a0,0x2
 33e:	9fa9                	addw	a5,a5,a0
 340:	0017979b          	slliw	a5,a5,0x1
 344:	9fb5                	addw	a5,a5,a3
 346:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 34a:	00074683          	lbu	a3,0(a4)
 34e:	fd06879b          	addiw	a5,a3,-48
 352:	0ff7f793          	zext.b	a5,a5
 356:	fef671e3          	bgeu	a2,a5,338 <atoi+0x1c>
  return n;
}
 35a:	6422                	ld	s0,8(sp)
 35c:	0141                	addi	sp,sp,16
 35e:	8082                	ret
  n = 0;
 360:	4501                	li	a0,0
 362:	bfe5                	j	35a <atoi+0x3e>

0000000000000364 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 364:	1141                	addi	sp,sp,-16
 366:	e422                	sd	s0,8(sp)
 368:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 36a:	02b57463          	bgeu	a0,a1,392 <memmove+0x2e>
    while(n-- > 0)
 36e:	00c05f63          	blez	a2,38c <memmove+0x28>
 372:	1602                	slli	a2,a2,0x20
 374:	9201                	srli	a2,a2,0x20
 376:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 37a:	872a                	mv	a4,a0
      *dst++ = *src++;
 37c:	0585                	addi	a1,a1,1
 37e:	0705                	addi	a4,a4,1
 380:	fff5c683          	lbu	a3,-1(a1)
 384:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 388:	fee79ae3          	bne	a5,a4,37c <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 38c:	6422                	ld	s0,8(sp)
 38e:	0141                	addi	sp,sp,16
 390:	8082                	ret
    dst += n;
 392:	00c50733          	add	a4,a0,a2
    src += n;
 396:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 398:	fec05ae3          	blez	a2,38c <memmove+0x28>
 39c:	fff6079b          	addiw	a5,a2,-1
 3a0:	1782                	slli	a5,a5,0x20
 3a2:	9381                	srli	a5,a5,0x20
 3a4:	fff7c793          	not	a5,a5
 3a8:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3aa:	15fd                	addi	a1,a1,-1
 3ac:	177d                	addi	a4,a4,-1
 3ae:	0005c683          	lbu	a3,0(a1)
 3b2:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 3b6:	fee79ae3          	bne	a5,a4,3aa <memmove+0x46>
 3ba:	bfc9                	j	38c <memmove+0x28>

00000000000003bc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3bc:	1141                	addi	sp,sp,-16
 3be:	e422                	sd	s0,8(sp)
 3c0:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3c2:	ca05                	beqz	a2,3f2 <memcmp+0x36>
 3c4:	fff6069b          	addiw	a3,a2,-1
 3c8:	1682                	slli	a3,a3,0x20
 3ca:	9281                	srli	a3,a3,0x20
 3cc:	0685                	addi	a3,a3,1
 3ce:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 3d0:	00054783          	lbu	a5,0(a0)
 3d4:	0005c703          	lbu	a4,0(a1)
 3d8:	00e79863          	bne	a5,a4,3e8 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 3dc:	0505                	addi	a0,a0,1
    p2++;
 3de:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3e0:	fed518e3          	bne	a0,a3,3d0 <memcmp+0x14>
  }
  return 0;
 3e4:	4501                	li	a0,0
 3e6:	a019                	j	3ec <memcmp+0x30>
      return *p1 - *p2;
 3e8:	40e7853b          	subw	a0,a5,a4
}
 3ec:	6422                	ld	s0,8(sp)
 3ee:	0141                	addi	sp,sp,16
 3f0:	8082                	ret
  return 0;
 3f2:	4501                	li	a0,0
 3f4:	bfe5                	j	3ec <memcmp+0x30>

00000000000003f6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3f6:	1141                	addi	sp,sp,-16
 3f8:	e406                	sd	ra,8(sp)
 3fa:	e022                	sd	s0,0(sp)
 3fc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3fe:	f67ff0ef          	jal	ra,364 <memmove>
}
 402:	60a2                	ld	ra,8(sp)
 404:	6402                	ld	s0,0(sp)
 406:	0141                	addi	sp,sp,16
 408:	8082                	ret

000000000000040a <sbrk>:

char *
sbrk(int n) {
 40a:	1141                	addi	sp,sp,-16
 40c:	e406                	sd	ra,8(sp)
 40e:	e022                	sd	s0,0(sp)
 410:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 412:	4585                	li	a1,1
 414:	0b2000ef          	jal	ra,4c6 <sys_sbrk>
}
 418:	60a2                	ld	ra,8(sp)
 41a:	6402                	ld	s0,0(sp)
 41c:	0141                	addi	sp,sp,16
 41e:	8082                	ret

0000000000000420 <sbrklazy>:

char *
sbrklazy(int n) {
 420:	1141                	addi	sp,sp,-16
 422:	e406                	sd	ra,8(sp)
 424:	e022                	sd	s0,0(sp)
 426:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 428:	4589                	li	a1,2
 42a:	09c000ef          	jal	ra,4c6 <sys_sbrk>
}
 42e:	60a2                	ld	ra,8(sp)
 430:	6402                	ld	s0,0(sp)
 432:	0141                	addi	sp,sp,16
 434:	8082                	ret

0000000000000436 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 436:	4885                	li	a7,1
 ecall
 438:	00000073          	ecall
 ret
 43c:	8082                	ret

000000000000043e <exit>:
.global exit
exit:
 li a7, SYS_exit
 43e:	4889                	li	a7,2
 ecall
 440:	00000073          	ecall
 ret
 444:	8082                	ret

0000000000000446 <wait>:
.global wait
wait:
 li a7, SYS_wait
 446:	488d                	li	a7,3
 ecall
 448:	00000073          	ecall
 ret
 44c:	8082                	ret

000000000000044e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 44e:	4891                	li	a7,4
 ecall
 450:	00000073          	ecall
 ret
 454:	8082                	ret

0000000000000456 <read>:
.global read
read:
 li a7, SYS_read
 456:	4895                	li	a7,5
 ecall
 458:	00000073          	ecall
 ret
 45c:	8082                	ret

000000000000045e <write>:
.global write
write:
 li a7, SYS_write
 45e:	48c1                	li	a7,16
 ecall
 460:	00000073          	ecall
 ret
 464:	8082                	ret

0000000000000466 <close>:
.global close
close:
 li a7, SYS_close
 466:	48d5                	li	a7,21
 ecall
 468:	00000073          	ecall
 ret
 46c:	8082                	ret

000000000000046e <kill>:
.global kill
kill:
 li a7, SYS_kill
 46e:	4899                	li	a7,6
 ecall
 470:	00000073          	ecall
 ret
 474:	8082                	ret

0000000000000476 <exec>:
.global exec
exec:
 li a7, SYS_exec
 476:	489d                	li	a7,7
 ecall
 478:	00000073          	ecall
 ret
 47c:	8082                	ret

000000000000047e <open>:
.global open
open:
 li a7, SYS_open
 47e:	48bd                	li	a7,15
 ecall
 480:	00000073          	ecall
 ret
 484:	8082                	ret

0000000000000486 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 486:	48c5                	li	a7,17
 ecall
 488:	00000073          	ecall
 ret
 48c:	8082                	ret

000000000000048e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 48e:	48c9                	li	a7,18
 ecall
 490:	00000073          	ecall
 ret
 494:	8082                	ret

0000000000000496 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 496:	48a1                	li	a7,8
 ecall
 498:	00000073          	ecall
 ret
 49c:	8082                	ret

000000000000049e <link>:
.global link
link:
 li a7, SYS_link
 49e:	48cd                	li	a7,19
 ecall
 4a0:	00000073          	ecall
 ret
 4a4:	8082                	ret

00000000000004a6 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4a6:	48d1                	li	a7,20
 ecall
 4a8:	00000073          	ecall
 ret
 4ac:	8082                	ret

00000000000004ae <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4ae:	48a5                	li	a7,9
 ecall
 4b0:	00000073          	ecall
 ret
 4b4:	8082                	ret

00000000000004b6 <dup>:
.global dup
dup:
 li a7, SYS_dup
 4b6:	48a9                	li	a7,10
 ecall
 4b8:	00000073          	ecall
 ret
 4bc:	8082                	ret

00000000000004be <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4be:	48ad                	li	a7,11
 ecall
 4c0:	00000073          	ecall
 ret
 4c4:	8082                	ret

00000000000004c6 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 4c6:	48b1                	li	a7,12
 ecall
 4c8:	00000073          	ecall
 ret
 4cc:	8082                	ret

00000000000004ce <pause>:
.global pause
pause:
 li a7, SYS_pause
 4ce:	48b5                	li	a7,13
 ecall
 4d0:	00000073          	ecall
 ret
 4d4:	8082                	ret

00000000000004d6 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 4d6:	48b9                	li	a7,14
 ecall
 4d8:	00000073          	ecall
 ret
 4dc:	8082                	ret

00000000000004de <getprocinfo>:
.global getprocinfo
getprocinfo:
 li a7, SYS_getprocinfo
 4de:	48d9                	li	a7,22
 ecall
 4e0:	00000073          	ecall
 ret
 4e4:	8082                	ret

00000000000004e6 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4e6:	1101                	addi	sp,sp,-32
 4e8:	ec06                	sd	ra,24(sp)
 4ea:	e822                	sd	s0,16(sp)
 4ec:	1000                	addi	s0,sp,32
 4ee:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4f2:	4605                	li	a2,1
 4f4:	fef40593          	addi	a1,s0,-17
 4f8:	f67ff0ef          	jal	ra,45e <write>
}
 4fc:	60e2                	ld	ra,24(sp)
 4fe:	6442                	ld	s0,16(sp)
 500:	6105                	addi	sp,sp,32
 502:	8082                	ret

0000000000000504 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 504:	715d                	addi	sp,sp,-80
 506:	e486                	sd	ra,72(sp)
 508:	e0a2                	sd	s0,64(sp)
 50a:	fc26                	sd	s1,56(sp)
 50c:	f84a                	sd	s2,48(sp)
 50e:	f44e                	sd	s3,40(sp)
 510:	0880                	addi	s0,sp,80
 512:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 514:	c299                	beqz	a3,51a <printint+0x16>
 516:	0805c163          	bltz	a1,598 <printint+0x94>
  neg = 0;
 51a:	4881                	li	a7,0
 51c:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 520:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 522:	00000517          	auipc	a0,0x0
 526:	6fe50513          	addi	a0,a0,1790 # c20 <digits>
 52a:	883e                	mv	a6,a5
 52c:	2785                	addiw	a5,a5,1
 52e:	02c5f733          	remu	a4,a1,a2
 532:	972a                	add	a4,a4,a0
 534:	00074703          	lbu	a4,0(a4)
 538:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 53c:	872e                	mv	a4,a1
 53e:	02c5d5b3          	divu	a1,a1,a2
 542:	0685                	addi	a3,a3,1
 544:	fec773e3          	bgeu	a4,a2,52a <printint+0x26>
  if(neg)
 548:	00088b63          	beqz	a7,55e <printint+0x5a>
    buf[i++] = '-';
 54c:	fd078793          	addi	a5,a5,-48
 550:	97a2                	add	a5,a5,s0
 552:	02d00713          	li	a4,45
 556:	fee78423          	sb	a4,-24(a5)
 55a:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 55e:	02f05663          	blez	a5,58a <printint+0x86>
 562:	fb840713          	addi	a4,s0,-72
 566:	00f704b3          	add	s1,a4,a5
 56a:	fff70993          	addi	s3,a4,-1
 56e:	99be                	add	s3,s3,a5
 570:	37fd                	addiw	a5,a5,-1
 572:	1782                	slli	a5,a5,0x20
 574:	9381                	srli	a5,a5,0x20
 576:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 57a:	fff4c583          	lbu	a1,-1(s1)
 57e:	854a                	mv	a0,s2
 580:	f67ff0ef          	jal	ra,4e6 <putc>
  while(--i >= 0)
 584:	14fd                	addi	s1,s1,-1
 586:	ff349ae3          	bne	s1,s3,57a <printint+0x76>
}
 58a:	60a6                	ld	ra,72(sp)
 58c:	6406                	ld	s0,64(sp)
 58e:	74e2                	ld	s1,56(sp)
 590:	7942                	ld	s2,48(sp)
 592:	79a2                	ld	s3,40(sp)
 594:	6161                	addi	sp,sp,80
 596:	8082                	ret
    x = -xx;
 598:	40b005b3          	neg	a1,a1
    neg = 1;
 59c:	4885                	li	a7,1
    x = -xx;
 59e:	bfbd                	j	51c <printint+0x18>

00000000000005a0 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5a0:	7119                	addi	sp,sp,-128
 5a2:	fc86                	sd	ra,120(sp)
 5a4:	f8a2                	sd	s0,112(sp)
 5a6:	f4a6                	sd	s1,104(sp)
 5a8:	f0ca                	sd	s2,96(sp)
 5aa:	ecce                	sd	s3,88(sp)
 5ac:	e8d2                	sd	s4,80(sp)
 5ae:	e4d6                	sd	s5,72(sp)
 5b0:	e0da                	sd	s6,64(sp)
 5b2:	fc5e                	sd	s7,56(sp)
 5b4:	f862                	sd	s8,48(sp)
 5b6:	f466                	sd	s9,40(sp)
 5b8:	f06a                	sd	s10,32(sp)
 5ba:	ec6e                	sd	s11,24(sp)
 5bc:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5be:	0005c903          	lbu	s2,0(a1)
 5c2:	24090c63          	beqz	s2,81a <vprintf+0x27a>
 5c6:	8b2a                	mv	s6,a0
 5c8:	8a2e                	mv	s4,a1
 5ca:	8bb2                	mv	s7,a2
  state = 0;
 5cc:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5ce:	4481                	li	s1,0
 5d0:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 5d2:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 5d6:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5da:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 5de:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5e2:	00000c97          	auipc	s9,0x0
 5e6:	63ec8c93          	addi	s9,s9,1598 # c20 <digits>
 5ea:	a005                	j	60a <vprintf+0x6a>
        putc(fd, c0);
 5ec:	85ca                	mv	a1,s2
 5ee:	855a                	mv	a0,s6
 5f0:	ef7ff0ef          	jal	ra,4e6 <putc>
 5f4:	a019                	j	5fa <vprintf+0x5a>
    } else if(state == '%'){
 5f6:	03598263          	beq	s3,s5,61a <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 5fa:	2485                	addiw	s1,s1,1
 5fc:	8726                	mv	a4,s1
 5fe:	009a07b3          	add	a5,s4,s1
 602:	0007c903          	lbu	s2,0(a5)
 606:	20090a63          	beqz	s2,81a <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 60a:	0009079b          	sext.w	a5,s2
    if(state == 0){
 60e:	fe0994e3          	bnez	s3,5f6 <vprintf+0x56>
      if(c0 == '%'){
 612:	fd579de3          	bne	a5,s5,5ec <vprintf+0x4c>
        state = '%';
 616:	89be                	mv	s3,a5
 618:	b7cd                	j	5fa <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 61a:	c3c1                	beqz	a5,69a <vprintf+0xfa>
 61c:	00ea06b3          	add	a3,s4,a4
 620:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 624:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 626:	c681                	beqz	a3,62e <vprintf+0x8e>
 628:	9752                	add	a4,a4,s4
 62a:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 62e:	03878e63          	beq	a5,s8,66a <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 632:	05a78863          	beq	a5,s10,682 <vprintf+0xe2>
      } else if(c0 == 'u'){
 636:	0db78b63          	beq	a5,s11,70c <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 63a:	07800713          	li	a4,120
 63e:	10e78d63          	beq	a5,a4,758 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 642:	07000713          	li	a4,112
 646:	14e78263          	beq	a5,a4,78a <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 64a:	06300713          	li	a4,99
 64e:	16e78f63          	beq	a5,a4,7cc <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 652:	07300713          	li	a4,115
 656:	18e78563          	beq	a5,a4,7e0 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 65a:	05579063          	bne	a5,s5,69a <vprintf+0xfa>
        putc(fd, '%');
 65e:	85d6                	mv	a1,s5
 660:	855a                	mv	a0,s6
 662:	e85ff0ef          	jal	ra,4e6 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 666:	4981                	li	s3,0
 668:	bf49                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 66a:	008b8913          	addi	s2,s7,8
 66e:	4685                	li	a3,1
 670:	4629                	li	a2,10
 672:	000ba583          	lw	a1,0(s7)
 676:	855a                	mv	a0,s6
 678:	e8dff0ef          	jal	ra,504 <printint>
 67c:	8bca                	mv	s7,s2
      state = 0;
 67e:	4981                	li	s3,0
 680:	bfad                	j	5fa <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 682:	03868663          	beq	a3,s8,6ae <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 686:	05a68163          	beq	a3,s10,6c8 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 68a:	09b68d63          	beq	a3,s11,724 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 68e:	03a68f63          	beq	a3,s10,6cc <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 692:	07800793          	li	a5,120
 696:	0cf68d63          	beq	a3,a5,770 <vprintf+0x1d0>
        putc(fd, '%');
 69a:	85d6                	mv	a1,s5
 69c:	855a                	mv	a0,s6
 69e:	e49ff0ef          	jal	ra,4e6 <putc>
        putc(fd, c0);
 6a2:	85ca                	mv	a1,s2
 6a4:	855a                	mv	a0,s6
 6a6:	e41ff0ef          	jal	ra,4e6 <putc>
      state = 0;
 6aa:	4981                	li	s3,0
 6ac:	b7b9                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6ae:	008b8913          	addi	s2,s7,8
 6b2:	4685                	li	a3,1
 6b4:	4629                	li	a2,10
 6b6:	000bb583          	ld	a1,0(s7)
 6ba:	855a                	mv	a0,s6
 6bc:	e49ff0ef          	jal	ra,504 <printint>
        i += 1;
 6c0:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 6c2:	8bca                	mv	s7,s2
      state = 0;
 6c4:	4981                	li	s3,0
        i += 1;
 6c6:	bf15                	j	5fa <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6c8:	03860563          	beq	a2,s8,6f2 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6cc:	07b60963          	beq	a2,s11,73e <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6d0:	07800793          	li	a5,120
 6d4:	fcf613e3          	bne	a2,a5,69a <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6d8:	008b8913          	addi	s2,s7,8
 6dc:	4681                	li	a3,0
 6de:	4641                	li	a2,16
 6e0:	000bb583          	ld	a1,0(s7)
 6e4:	855a                	mv	a0,s6
 6e6:	e1fff0ef          	jal	ra,504 <printint>
        i += 2;
 6ea:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ec:	8bca                	mv	s7,s2
      state = 0;
 6ee:	4981                	li	s3,0
        i += 2;
 6f0:	b729                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6f2:	008b8913          	addi	s2,s7,8
 6f6:	4685                	li	a3,1
 6f8:	4629                	li	a2,10
 6fa:	000bb583          	ld	a1,0(s7)
 6fe:	855a                	mv	a0,s6
 700:	e05ff0ef          	jal	ra,504 <printint>
        i += 2;
 704:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 706:	8bca                	mv	s7,s2
      state = 0;
 708:	4981                	li	s3,0
        i += 2;
 70a:	bdc5                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 70c:	008b8913          	addi	s2,s7,8
 710:	4681                	li	a3,0
 712:	4629                	li	a2,10
 714:	000be583          	lwu	a1,0(s7)
 718:	855a                	mv	a0,s6
 71a:	debff0ef          	jal	ra,504 <printint>
 71e:	8bca                	mv	s7,s2
      state = 0;
 720:	4981                	li	s3,0
 722:	bde1                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 724:	008b8913          	addi	s2,s7,8
 728:	4681                	li	a3,0
 72a:	4629                	li	a2,10
 72c:	000bb583          	ld	a1,0(s7)
 730:	855a                	mv	a0,s6
 732:	dd3ff0ef          	jal	ra,504 <printint>
        i += 1;
 736:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 738:	8bca                	mv	s7,s2
      state = 0;
 73a:	4981                	li	s3,0
        i += 1;
 73c:	bd7d                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 73e:	008b8913          	addi	s2,s7,8
 742:	4681                	li	a3,0
 744:	4629                	li	a2,10
 746:	000bb583          	ld	a1,0(s7)
 74a:	855a                	mv	a0,s6
 74c:	db9ff0ef          	jal	ra,504 <printint>
        i += 2;
 750:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 752:	8bca                	mv	s7,s2
      state = 0;
 754:	4981                	li	s3,0
        i += 2;
 756:	b555                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 758:	008b8913          	addi	s2,s7,8
 75c:	4681                	li	a3,0
 75e:	4641                	li	a2,16
 760:	000be583          	lwu	a1,0(s7)
 764:	855a                	mv	a0,s6
 766:	d9fff0ef          	jal	ra,504 <printint>
 76a:	8bca                	mv	s7,s2
      state = 0;
 76c:	4981                	li	s3,0
 76e:	b571                	j	5fa <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 770:	008b8913          	addi	s2,s7,8
 774:	4681                	li	a3,0
 776:	4641                	li	a2,16
 778:	000bb583          	ld	a1,0(s7)
 77c:	855a                	mv	a0,s6
 77e:	d87ff0ef          	jal	ra,504 <printint>
        i += 1;
 782:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 784:	8bca                	mv	s7,s2
      state = 0;
 786:	4981                	li	s3,0
        i += 1;
 788:	bd8d                	j	5fa <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 78a:	008b8793          	addi	a5,s7,8
 78e:	f8f43423          	sd	a5,-120(s0)
 792:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 796:	03000593          	li	a1,48
 79a:	855a                	mv	a0,s6
 79c:	d4bff0ef          	jal	ra,4e6 <putc>
  putc(fd, 'x');
 7a0:	07800593          	li	a1,120
 7a4:	855a                	mv	a0,s6
 7a6:	d41ff0ef          	jal	ra,4e6 <putc>
 7aa:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7ac:	03c9d793          	srli	a5,s3,0x3c
 7b0:	97e6                	add	a5,a5,s9
 7b2:	0007c583          	lbu	a1,0(a5)
 7b6:	855a                	mv	a0,s6
 7b8:	d2fff0ef          	jal	ra,4e6 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7bc:	0992                	slli	s3,s3,0x4
 7be:	397d                	addiw	s2,s2,-1
 7c0:	fe0916e3          	bnez	s2,7ac <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 7c4:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 7c8:	4981                	li	s3,0
 7ca:	bd05                	j	5fa <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 7cc:	008b8913          	addi	s2,s7,8
 7d0:	000bc583          	lbu	a1,0(s7)
 7d4:	855a                	mv	a0,s6
 7d6:	d11ff0ef          	jal	ra,4e6 <putc>
 7da:	8bca                	mv	s7,s2
      state = 0;
 7dc:	4981                	li	s3,0
 7de:	bd31                	j	5fa <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 7e0:	008b8993          	addi	s3,s7,8
 7e4:	000bb903          	ld	s2,0(s7)
 7e8:	00090f63          	beqz	s2,806 <vprintf+0x266>
        for(; *s; s++)
 7ec:	00094583          	lbu	a1,0(s2)
 7f0:	c195                	beqz	a1,814 <vprintf+0x274>
          putc(fd, *s);
 7f2:	855a                	mv	a0,s6
 7f4:	cf3ff0ef          	jal	ra,4e6 <putc>
        for(; *s; s++)
 7f8:	0905                	addi	s2,s2,1
 7fa:	00094583          	lbu	a1,0(s2)
 7fe:	f9f5                	bnez	a1,7f2 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 800:	8bce                	mv	s7,s3
      state = 0;
 802:	4981                	li	s3,0
 804:	bbdd                	j	5fa <vprintf+0x5a>
          s = "(null)";
 806:	00000917          	auipc	s2,0x0
 80a:	41290913          	addi	s2,s2,1042 # c18 <malloc+0x302>
        for(; *s; s++)
 80e:	02800593          	li	a1,40
 812:	b7c5                	j	7f2 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 814:	8bce                	mv	s7,s3
      state = 0;
 816:	4981                	li	s3,0
 818:	b3cd                	j	5fa <vprintf+0x5a>
    }
  }
}
 81a:	70e6                	ld	ra,120(sp)
 81c:	7446                	ld	s0,112(sp)
 81e:	74a6                	ld	s1,104(sp)
 820:	7906                	ld	s2,96(sp)
 822:	69e6                	ld	s3,88(sp)
 824:	6a46                	ld	s4,80(sp)
 826:	6aa6                	ld	s5,72(sp)
 828:	6b06                	ld	s6,64(sp)
 82a:	7be2                	ld	s7,56(sp)
 82c:	7c42                	ld	s8,48(sp)
 82e:	7ca2                	ld	s9,40(sp)
 830:	7d02                	ld	s10,32(sp)
 832:	6de2                	ld	s11,24(sp)
 834:	6109                	addi	sp,sp,128
 836:	8082                	ret

0000000000000838 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 838:	715d                	addi	sp,sp,-80
 83a:	ec06                	sd	ra,24(sp)
 83c:	e822                	sd	s0,16(sp)
 83e:	1000                	addi	s0,sp,32
 840:	e010                	sd	a2,0(s0)
 842:	e414                	sd	a3,8(s0)
 844:	e818                	sd	a4,16(s0)
 846:	ec1c                	sd	a5,24(s0)
 848:	03043023          	sd	a6,32(s0)
 84c:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 850:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 854:	8622                	mv	a2,s0
 856:	d4bff0ef          	jal	ra,5a0 <vprintf>
}
 85a:	60e2                	ld	ra,24(sp)
 85c:	6442                	ld	s0,16(sp)
 85e:	6161                	addi	sp,sp,80
 860:	8082                	ret

0000000000000862 <printf>:

void
printf(const char *fmt, ...)
{
 862:	711d                	addi	sp,sp,-96
 864:	ec06                	sd	ra,24(sp)
 866:	e822                	sd	s0,16(sp)
 868:	1000                	addi	s0,sp,32
 86a:	e40c                	sd	a1,8(s0)
 86c:	e810                	sd	a2,16(s0)
 86e:	ec14                	sd	a3,24(s0)
 870:	f018                	sd	a4,32(s0)
 872:	f41c                	sd	a5,40(s0)
 874:	03043823          	sd	a6,48(s0)
 878:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 87c:	00840613          	addi	a2,s0,8
 880:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 884:	85aa                	mv	a1,a0
 886:	4505                	li	a0,1
 888:	d19ff0ef          	jal	ra,5a0 <vprintf>
}
 88c:	60e2                	ld	ra,24(sp)
 88e:	6442                	ld	s0,16(sp)
 890:	6125                	addi	sp,sp,96
 892:	8082                	ret

0000000000000894 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 894:	1141                	addi	sp,sp,-16
 896:	e422                	sd	s0,8(sp)
 898:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 89a:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 89e:	00000797          	auipc	a5,0x0
 8a2:	7627b783          	ld	a5,1890(a5) # 1000 <freep>
 8a6:	a02d                	j	8d0 <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 8a8:	4618                	lw	a4,8(a2)
 8aa:	9f2d                	addw	a4,a4,a1
 8ac:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8b0:	6398                	ld	a4,0(a5)
 8b2:	6310                	ld	a2,0(a4)
 8b4:	a83d                	j	8f2 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 8b6:	ff852703          	lw	a4,-8(a0)
 8ba:	9f31                	addw	a4,a4,a2
 8bc:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8be:	ff053683          	ld	a3,-16(a0)
 8c2:	a091                	j	906 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8c4:	6398                	ld	a4,0(a5)
 8c6:	00e7e463          	bltu	a5,a4,8ce <free+0x3a>
 8ca:	00e6ea63          	bltu	a3,a4,8de <free+0x4a>
{
 8ce:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8d0:	fed7fae3          	bgeu	a5,a3,8c4 <free+0x30>
 8d4:	6398                	ld	a4,0(a5)
 8d6:	00e6e463          	bltu	a3,a4,8de <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8da:	fee7eae3          	bltu	a5,a4,8ce <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 8de:	ff852583          	lw	a1,-8(a0)
 8e2:	6390                	ld	a2,0(a5)
 8e4:	02059813          	slli	a6,a1,0x20
 8e8:	01c85713          	srli	a4,a6,0x1c
 8ec:	9736                	add	a4,a4,a3
 8ee:	fae60de3          	beq	a2,a4,8a8 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 8f2:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 8f6:	4790                	lw	a2,8(a5)
 8f8:	02061593          	slli	a1,a2,0x20
 8fc:	01c5d713          	srli	a4,a1,0x1c
 900:	973e                	add	a4,a4,a5
 902:	fae68ae3          	beq	a3,a4,8b6 <free+0x22>
    p->s.ptr = bp->s.ptr;
 906:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 908:	00000717          	auipc	a4,0x0
 90c:	6ef73c23          	sd	a5,1784(a4) # 1000 <freep>
}
 910:	6422                	ld	s0,8(sp)
 912:	0141                	addi	sp,sp,16
 914:	8082                	ret

0000000000000916 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 916:	7139                	addi	sp,sp,-64
 918:	fc06                	sd	ra,56(sp)
 91a:	f822                	sd	s0,48(sp)
 91c:	f426                	sd	s1,40(sp)
 91e:	f04a                	sd	s2,32(sp)
 920:	ec4e                	sd	s3,24(sp)
 922:	e852                	sd	s4,16(sp)
 924:	e456                	sd	s5,8(sp)
 926:	e05a                	sd	s6,0(sp)
 928:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 92a:	02051493          	slli	s1,a0,0x20
 92e:	9081                	srli	s1,s1,0x20
 930:	04bd                	addi	s1,s1,15
 932:	8091                	srli	s1,s1,0x4
 934:	0014899b          	addiw	s3,s1,1
 938:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 93a:	00000517          	auipc	a0,0x0
 93e:	6c653503          	ld	a0,1734(a0) # 1000 <freep>
 942:	c515                	beqz	a0,96e <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 944:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 946:	4798                	lw	a4,8(a5)
 948:	02977f63          	bgeu	a4,s1,986 <malloc+0x70>
 94c:	8a4e                	mv	s4,s3
 94e:	0009871b          	sext.w	a4,s3
 952:	6685                	lui	a3,0x1
 954:	00d77363          	bgeu	a4,a3,95a <malloc+0x44>
 958:	6a05                	lui	s4,0x1
 95a:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 95e:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 962:	00000917          	auipc	s2,0x0
 966:	69e90913          	addi	s2,s2,1694 # 1000 <freep>
  if(p == SBRK_ERROR)
 96a:	5afd                	li	s5,-1
 96c:	a885                	j	9dc <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 96e:	00000797          	auipc	a5,0x0
 972:	6a278793          	addi	a5,a5,1698 # 1010 <base>
 976:	00000717          	auipc	a4,0x0
 97a:	68f73523          	sd	a5,1674(a4) # 1000 <freep>
 97e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 980:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 984:	b7e1                	j	94c <malloc+0x36>
      if(p->s.size == nunits)
 986:	02e48c63          	beq	s1,a4,9be <malloc+0xa8>
        p->s.size -= nunits;
 98a:	4137073b          	subw	a4,a4,s3
 98e:	c798                	sw	a4,8(a5)
        p += p->s.size;
 990:	02071693          	slli	a3,a4,0x20
 994:	01c6d713          	srli	a4,a3,0x1c
 998:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 99a:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 99e:	00000717          	auipc	a4,0x0
 9a2:	66a73123          	sd	a0,1634(a4) # 1000 <freep>
      return (void*)(p + 1);
 9a6:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 9aa:	70e2                	ld	ra,56(sp)
 9ac:	7442                	ld	s0,48(sp)
 9ae:	74a2                	ld	s1,40(sp)
 9b0:	7902                	ld	s2,32(sp)
 9b2:	69e2                	ld	s3,24(sp)
 9b4:	6a42                	ld	s4,16(sp)
 9b6:	6aa2                	ld	s5,8(sp)
 9b8:	6b02                	ld	s6,0(sp)
 9ba:	6121                	addi	sp,sp,64
 9bc:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 9be:	6398                	ld	a4,0(a5)
 9c0:	e118                	sd	a4,0(a0)
 9c2:	bff1                	j	99e <malloc+0x88>
  hp->s.size = nu;
 9c4:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9c8:	0541                	addi	a0,a0,16
 9ca:	ecbff0ef          	jal	ra,894 <free>
  return freep;
 9ce:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 9d2:	dd61                	beqz	a0,9aa <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9d4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9d6:	4798                	lw	a4,8(a5)
 9d8:	fa9777e3          	bgeu	a4,s1,986 <malloc+0x70>
    if(p == freep)
 9dc:	00093703          	ld	a4,0(s2)
 9e0:	853e                	mv	a0,a5
 9e2:	fef719e3          	bne	a4,a5,9d4 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 9e6:	8552                	mv	a0,s4
 9e8:	a23ff0ef          	jal	ra,40a <sbrk>
  if(p == SBRK_ERROR)
 9ec:	fd551ce3          	bne	a0,s5,9c4 <malloc+0xae>
        return 0;
 9f0:	4501                	li	a0,0
 9f2:	bf65                	j	9aa <malloc+0x94>
