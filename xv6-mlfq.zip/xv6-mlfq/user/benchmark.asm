
user/_benchmark:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <cpu_task>:
#include "user/user.h"

// Benchmark test that runs both CPU-bound and I/O-bound processes
// simultaneously to compare scheduler performance

void cpu_task(int id) {
   0:	7119                	addi	sp,sp,-128
   2:	fc86                	sd	ra,120(sp)
   4:	f8a2                	sd	s0,112(sp)
   6:	f4a6                	sd	s1,104(sp)
   8:	f0ca                	sd	s2,96(sp)
   a:	ecce                	sd	s3,88(sp)
   c:	e8d2                	sd	s4,80(sp)
   e:	e4d6                	sd	s5,72(sp)
  10:	e0da                	sd	s6,64(sp)
  12:	0100                	addi	s0,sp,128
  14:	89aa                	mv	s3,a0
    struct procinfo info;
    int pid = getpid();
  16:	5c2000ef          	jal	ra,5d8 <getpid>
  1a:	8a2a                	mv	s4,a0
    
    printf("[MLFQ-CPU-%d] Starting CPU-bound task, PID: %d\n", id, pid);
  1c:	862a                	mv	a2,a0
  1e:	85ce                	mv	a1,s3
  20:	00001517          	auipc	a0,0x1
  24:	af050513          	addi	a0,a0,-1296 # b10 <malloc+0xe0>
  28:	155000ef          	jal	ra,97c <printf>
    getprocinfo(pid, &info);
  2c:	f8840593          	addi	a1,s0,-120
  30:	8552                	mv	a0,s4
  32:	5c6000ef          	jal	ra,5f8 <getprocinfo>
    printf("[MLFQ-CPU-%d] Initial priority: %d (HIGH in MLFQ)\n", id, info.priority);
  36:	f8c42603          	lw	a2,-116(s0)
  3a:	85ce                	mv	a1,s3
  3c:	00001517          	auipc	a0,0x1
  40:	b0450513          	addi	a0,a0,-1276 # b40 <malloc+0x110>
  44:	139000ef          	jal	ra,97c <printf>
    
    for (int phase = 0; phase < 3; phase++) {
  48:	4901                	li	s2,0
        // CPU-intensive work
        volatile long result = 0;
        for (long i = 0; i < 3000000; i++) {
  4a:	002dc4b7          	lui	s1,0x2dc
  4e:	6c048493          	addi	s1,s1,1728 # 2dc6c0 <base+0x2db6b0>
            result += i * i;
            result ^= (i + 1) * (i - 1);
        }
        
        getprocinfo(pid, &info);
        printf("[MLFQ-CPU-%d] Phase %d: Priority=%d (demoted?), CPU=%d, Sched=%d\n", 
  52:	00001b17          	auipc	s6,0x1
  56:	b26b0b13          	addi	s6,s6,-1242 # b78 <malloc+0x148>
    for (int phase = 0; phase < 3; phase++) {
  5a:	4a8d                	li	s5,3
        volatile long result = 0;
  5c:	f8043023          	sd	zero,-128(s0)
        for (long i = 0; i < 3000000; i++) {
  60:	4701                	li	a4,0
            result += i * i;
  62:	f8043683          	ld	a3,-128(s0)
  66:	02e707b3          	mul	a5,a4,a4
  6a:	97b6                	add	a5,a5,a3
  6c:	f8f43023          	sd	a5,-128(s0)
            result ^= (i + 1) * (i - 1);
  70:	87ba                	mv	a5,a4
  72:	0705                	addi	a4,a4,1
  74:	f8043683          	ld	a3,-128(s0)
  78:	17fd                	addi	a5,a5,-1
  7a:	02e787b3          	mul	a5,a5,a4
  7e:	8fb5                	xor	a5,a5,a3
  80:	f8f43023          	sd	a5,-128(s0)
        for (long i = 0; i < 3000000; i++) {
  84:	fc971fe3          	bne	a4,s1,62 <cpu_task+0x62>
        getprocinfo(pid, &info);
  88:	f8840593          	addi	a1,s0,-120
  8c:	8552                	mv	a0,s4
  8e:	56a000ef          	jal	ra,5f8 <getprocinfo>
        printf("[MLFQ-CPU-%d] Phase %d: Priority=%d (demoted?), CPU=%d, Sched=%d\n", 
  92:	f9442783          	lw	a5,-108(s0)
  96:	f9042703          	lw	a4,-112(s0)
  9a:	f8c42683          	lw	a3,-116(s0)
  9e:	864a                	mv	a2,s2
  a0:	85ce                	mv	a1,s3
  a2:	855a                	mv	a0,s6
  a4:	0d9000ef          	jal	ra,97c <printf>
    for (int phase = 0; phase < 3; phase++) {
  a8:	2905                	addiw	s2,s2,1
  aa:	fb5919e3          	bne	s2,s5,5c <cpu_task+0x5c>
               id, phase, info.priority, info.cpu_ticks, info.sched_count);
    }
    
    getprocinfo(pid, &info);
  ae:	f8840593          	addi	a1,s0,-120
  b2:	8552                	mv	a0,s4
  b4:	544000ef          	jal	ra,5f8 <getprocinfo>
    printf("[MLFQ-CPU-%d] DONE: Priority=%d (should be LOW), CPU=%d, Sched=%d\n",
  b8:	f9442703          	lw	a4,-108(s0)
  bc:	f9042683          	lw	a3,-112(s0)
  c0:	f8c42603          	lw	a2,-116(s0)
  c4:	85ce                	mv	a1,s3
  c6:	00001517          	auipc	a0,0x1
  ca:	afa50513          	addi	a0,a0,-1286 # bc0 <malloc+0x190>
  ce:	0af000ef          	jal	ra,97c <printf>
           id, info.priority, info.cpu_ticks, info.sched_count);
    exit(0);
  d2:	4501                	li	a0,0
  d4:	484000ef          	jal	ra,558 <exit>

00000000000000d8 <io_task>:
}

void io_task(int id) {
  d8:	7175                	addi	sp,sp,-144
  da:	e506                	sd	ra,136(sp)
  dc:	e122                	sd	s0,128(sp)
  de:	fca6                	sd	s1,120(sp)
  e0:	f8ca                	sd	s2,112(sp)
  e2:	f4ce                	sd	s3,104(sp)
  e4:	f0d2                	sd	s4,96(sp)
  e6:	ecd6                	sd	s5,88(sp)
  e8:	e8da                	sd	s6,80(sp)
  ea:	e4de                	sd	s7,72(sp)
  ec:	0900                	addi	s0,sp,144
  ee:	8aaa                	mv	s5,a0
    struct procinfo info;
    int pid = getpid();
  f0:	4e8000ef          	jal	ra,5d8 <getpid>
  f4:	8b2a                	mv	s6,a0
    
    printf("[MLFQ-I/O-%d] Starting I/O-bound task, PID: %d\n", id, pid);
  f6:	862a                	mv	a2,a0
  f8:	85d6                	mv	a1,s5
  fa:	00001517          	auipc	a0,0x1
  fe:	b0e50513          	addi	a0,a0,-1266 # c08 <malloc+0x1d8>
 102:	07b000ef          	jal	ra,97c <printf>
    getprocinfo(pid, &info);
 106:	f7840593          	addi	a1,s0,-136
 10a:	855a                	mv	a0,s6
 10c:	4ec000ef          	jal	ra,5f8 <getprocinfo>
    printf("[MLFQ-I/O-%d] Initial priority: %d (HIGH in MLFQ)\n", id, info.priority);
 110:	f7c42603          	lw	a2,-132(s0)
 114:	85d6                	mv	a1,s5
 116:	00001517          	auipc	a0,0x1
 11a:	b2250513          	addi	a0,a0,-1246 # c38 <malloc+0x208>
 11e:	05f000ef          	jal	ra,97c <printf>
    
    for (int i = 0; i < 20; i++) {
 122:	4481                	li	s1,0
        // I/O operations
        write(1, ".", 1);
 124:	00001a17          	auipc	s4,0x1
 128:	b4ca0a13          	addi	s4,s4,-1204 # c70 <malloc+0x240>
        
        if (i % 5 == 0) {
 12c:	4995                	li	s3,5
            getprocinfo(pid, &info);
            printf("\n[MLFQ-I/O-%d] Iter %d: Priority=%d (stays HIGH?), CPU=%d, Sched=%d\n", 
 12e:	00001b97          	auipc	s7,0x1
 132:	b4ab8b93          	addi	s7,s7,-1206 # c78 <malloc+0x248>
    for (int i = 0; i < 20; i++) {
 136:	4951                	li	s2,20
 138:	a021                	j	140 <io_task+0x68>
 13a:	2485                	addiw	s1,s1,1
 13c:	03248b63          	beq	s1,s2,172 <io_task+0x9a>
        write(1, ".", 1);
 140:	4605                	li	a2,1
 142:	85d2                	mv	a1,s4
 144:	4505                	li	a0,1
 146:	432000ef          	jal	ra,578 <write>
        if (i % 5 == 0) {
 14a:	0334e7bb          	remw	a5,s1,s3
 14e:	f7f5                	bnez	a5,13a <io_task+0x62>
            getprocinfo(pid, &info);
 150:	f7840593          	addi	a1,s0,-136
 154:	855a                	mv	a0,s6
 156:	4a2000ef          	jal	ra,5f8 <getprocinfo>
            printf("\n[MLFQ-I/O-%d] Iter %d: Priority=%d (stays HIGH?), CPU=%d, Sched=%d\n", 
 15a:	f8442783          	lw	a5,-124(s0)
 15e:	f8042703          	lw	a4,-128(s0)
 162:	f7c42683          	lw	a3,-132(s0)
 166:	8626                	mv	a2,s1
 168:	85d6                	mv	a1,s5
 16a:	855e                	mv	a0,s7
 16c:	011000ef          	jal	ra,97c <printf>
 170:	b7e9                	j	13a <io_task+0x62>
                   id, i, info.priority, info.cpu_ticks, info.sched_count);
        }
    }
    
    getprocinfo(pid, &info);
 172:	f7840593          	addi	a1,s0,-136
 176:	855a                	mv	a0,s6
 178:	480000ef          	jal	ra,5f8 <getprocinfo>
    printf("\n[MLFQ-I/O-%d] DONE: Priority=%d (should stay HIGH), CPU=%d, Sched=%d\n",
 17c:	f8442703          	lw	a4,-124(s0)
 180:	f8042683          	lw	a3,-128(s0)
 184:	f7c42603          	lw	a2,-132(s0)
 188:	85d6                	mv	a1,s5
 18a:	00001517          	auipc	a0,0x1
 18e:	b3650513          	addi	a0,a0,-1226 # cc0 <malloc+0x290>
 192:	7ea000ef          	jal	ra,97c <printf>
           id, info.priority, info.cpu_ticks, info.sched_count);
    exit(0);
 196:	4501                	li	a0,0
 198:	3c0000ef          	jal	ra,558 <exit>

000000000000019c <main>:
}

int main(int argc, char *argv[]) {
 19c:	1101                	addi	sp,sp,-32
 19e:	ec06                	sd	ra,24(sp)
 1a0:	e822                	sd	s0,16(sp)
 1a2:	e426                	sd	s1,8(sp)
 1a4:	e04a                	sd	s2,0(sp)
 1a6:	1000                	addi	s0,sp,32
    int num_cpu = 2;  // Number of CPU-bound processes
    int num_io = 2;   // Number of I/O-bound processes
    
    printf("=========================================\n");
 1a8:	00001517          	auipc	a0,0x1
 1ac:	b6050513          	addi	a0,a0,-1184 # d08 <malloc+0x2d8>
 1b0:	7cc000ef          	jal	ra,97c <printf>
    printf("    MULTI-PROCESS BENCHMARK TEST\n");
 1b4:	00001517          	auipc	a0,0x1
 1b8:	b8450513          	addi	a0,a0,-1148 # d38 <malloc+0x308>
 1bc:	7c0000ef          	jal	ra,97c <printf>
    printf("    Scheduler: MLFQ\n");
 1c0:	00001517          	auipc	a0,0x1
 1c4:	ba050513          	addi	a0,a0,-1120 # d60 <malloc+0x330>
 1c8:	7b4000ef          	jal	ra,97c <printf>
    printf("=========================================\n");
 1cc:	00001517          	auipc	a0,0x1
 1d0:	b3c50513          	addi	a0,a0,-1220 # d08 <malloc+0x2d8>
 1d4:	7a8000ef          	jal	ra,97c <printf>
    printf("Creating %d CPU-bound and %d I/O-bound processes\n\n", num_cpu, num_io);
 1d8:	4609                	li	a2,2
 1da:	4589                	li	a1,2
 1dc:	00001517          	auipc	a0,0x1
 1e0:	b9c50513          	addi	a0,a0,-1124 # d78 <malloc+0x348>
 1e4:	798000ef          	jal	ra,97c <printf>
    
    uint64 start_time = uptime();
 1e8:	408000ef          	jal	ra,5f0 <uptime>
 1ec:	84aa                	mv	s1,a0
    
    // Fork CPU-bound processes
    for (int i = 0; i < num_cpu; i++) {
        if (fork() == 0) {
 1ee:	362000ef          	jal	ra,550 <fork>
 1f2:	0c050463          	beqz	a0,2ba <main+0x11e>
 1f6:	35a000ef          	jal	ra,550 <fork>
 1fa:	0a050f63          	beqz	a0,2b8 <main+0x11c>
        }
    }
    
    // Fork I/O-bound processes
    for (int i = 0; i < num_io; i++) {
        if (fork() == 0) {
 1fe:	352000ef          	jal	ra,550 <fork>
 202:	0a050f63          	beqz	a0,2c0 <main+0x124>
 206:	34a000ef          	jal	ra,550 <fork>
 20a:	c955                	beqz	a0,2be <main+0x122>
        }
    }
    
    // Wait for all children to complete
    for (int i = 0; i < num_cpu + num_io; i++) {
        wait(0);
 20c:	4501                	li	a0,0
 20e:	352000ef          	jal	ra,560 <wait>
 212:	4501                	li	a0,0
 214:	34c000ef          	jal	ra,560 <wait>
 218:	4501                	li	a0,0
 21a:	346000ef          	jal	ra,560 <wait>
 21e:	4501                	li	a0,0
 220:	340000ef          	jal	ra,560 <wait>
    }
    
    uint64 end_time = uptime();
 224:	3cc000ef          	jal	ra,5f0 <uptime>
 228:	892a                	mv	s2,a0
    
    printf("\n=========================================\n");
 22a:	00001517          	auipc	a0,0x1
 22e:	b8650513          	addi	a0,a0,-1146 # db0 <malloc+0x380>
 232:	74a000ef          	jal	ra,97c <printf>
    printf("MLFQ BENCHMARK COMPLETE\n");
 236:	00001517          	auipc	a0,0x1
 23a:	baa50513          	addi	a0,a0,-1110 # de0 <malloc+0x3b0>
 23e:	73e000ef          	jal	ra,97c <printf>
    printf("Total execution time: %lu ticks\n", (unsigned long)(end_time - start_time));
 242:	409905b3          	sub	a1,s2,s1
 246:	00001517          	auipc	a0,0x1
 24a:	bba50513          	addi	a0,a0,-1094 # e00 <malloc+0x3d0>
 24e:	72e000ef          	jal	ra,97c <printf>
    printf("\nMLFQ CHARACTERISTICS:\n");
 252:	00001517          	auipc	a0,0x1
 256:	bd650513          	addi	a0,a0,-1066 # e28 <malloc+0x3f8>
 25a:	722000ef          	jal	ra,97c <printf>
    printf("- CPU-bound drops to priority 2 (LOW)\n");
 25e:	00001517          	auipc	a0,0x1
 262:	be250513          	addi	a0,a0,-1054 # e40 <malloc+0x410>
 266:	716000ef          	jal	ra,97c <printf>
    printf("- I/O-bound stays at priority 0 (HIGH)\n");
 26a:	00001517          	auipc	a0,0x1
 26e:	bfe50513          	addi	a0,a0,-1026 # e68 <malloc+0x438>
 272:	70a000ef          	jal	ra,97c <printf>
    printf("- Better I/O responsiveness\n");
 276:	00001517          	auipc	a0,0x1
 27a:	c1a50513          	addi	a0,a0,-998 # e90 <malloc+0x460>
 27e:	6fe000ef          	jal	ra,97c <printf>
    printf("\nCompare with RR where:\n");
 282:	00001517          	auipc	a0,0x1
 286:	c2e50513          	addi	a0,a0,-978 # eb0 <malloc+0x480>
 28a:	6f2000ef          	jal	ra,97c <printf>
    printf("- All processes stay at priority 0\n");
 28e:	00001517          	auipc	a0,0x1
 292:	c4250513          	addi	a0,a0,-958 # ed0 <malloc+0x4a0>
 296:	6e6000ef          	jal	ra,97c <printf>
    printf("- No workload differentiation\n");
 29a:	00001517          	auipc	a0,0x1
 29e:	c5e50513          	addi	a0,a0,-930 # ef8 <malloc+0x4c8>
 2a2:	6da000ef          	jal	ra,97c <printf>
    printf("=========================================\n");
 2a6:	00001517          	auipc	a0,0x1
 2aa:	a6250513          	addi	a0,a0,-1438 # d08 <malloc+0x2d8>
 2ae:	6ce000ef          	jal	ra,97c <printf>
    
    exit(0);
 2b2:	4501                	li	a0,0
 2b4:	2a4000ef          	jal	ra,558 <exit>
    for (int i = 0; i < num_cpu; i++) {
 2b8:	4505                	li	a0,1
            cpu_task(i);
 2ba:	d47ff0ef          	jal	ra,0 <cpu_task>
    for (int i = 0; i < num_io; i++) {
 2be:	4505                	li	a0,1
            io_task(i);
 2c0:	e19ff0ef          	jal	ra,d8 <io_task>

00000000000002c4 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 2c4:	1141                	addi	sp,sp,-16
 2c6:	e406                	sd	ra,8(sp)
 2c8:	e022                	sd	s0,0(sp)
 2ca:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 2cc:	ed1ff0ef          	jal	ra,19c <main>
  exit(r);
 2d0:	288000ef          	jal	ra,558 <exit>

00000000000002d4 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 2d4:	1141                	addi	sp,sp,-16
 2d6:	e422                	sd	s0,8(sp)
 2d8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2da:	87aa                	mv	a5,a0
 2dc:	0585                	addi	a1,a1,1
 2de:	0785                	addi	a5,a5,1
 2e0:	fff5c703          	lbu	a4,-1(a1)
 2e4:	fee78fa3          	sb	a4,-1(a5)
 2e8:	fb75                	bnez	a4,2dc <strcpy+0x8>
    ;
  return os;
}
 2ea:	6422                	ld	s0,8(sp)
 2ec:	0141                	addi	sp,sp,16
 2ee:	8082                	ret

00000000000002f0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2f0:	1141                	addi	sp,sp,-16
 2f2:	e422                	sd	s0,8(sp)
 2f4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 2f6:	00054783          	lbu	a5,0(a0)
 2fa:	cb91                	beqz	a5,30e <strcmp+0x1e>
 2fc:	0005c703          	lbu	a4,0(a1)
 300:	00f71763          	bne	a4,a5,30e <strcmp+0x1e>
    p++, q++;
 304:	0505                	addi	a0,a0,1
 306:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 308:	00054783          	lbu	a5,0(a0)
 30c:	fbe5                	bnez	a5,2fc <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 30e:	0005c503          	lbu	a0,0(a1)
}
 312:	40a7853b          	subw	a0,a5,a0
 316:	6422                	ld	s0,8(sp)
 318:	0141                	addi	sp,sp,16
 31a:	8082                	ret

000000000000031c <strlen>:

uint
strlen(const char *s)
{
 31c:	1141                	addi	sp,sp,-16
 31e:	e422                	sd	s0,8(sp)
 320:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 322:	00054783          	lbu	a5,0(a0)
 326:	cf91                	beqz	a5,342 <strlen+0x26>
 328:	0505                	addi	a0,a0,1
 32a:	87aa                	mv	a5,a0
 32c:	4685                	li	a3,1
 32e:	9e89                	subw	a3,a3,a0
 330:	00f6853b          	addw	a0,a3,a5
 334:	0785                	addi	a5,a5,1
 336:	fff7c703          	lbu	a4,-1(a5)
 33a:	fb7d                	bnez	a4,330 <strlen+0x14>
    ;
  return n;
}
 33c:	6422                	ld	s0,8(sp)
 33e:	0141                	addi	sp,sp,16
 340:	8082                	ret
  for(n = 0; s[n]; n++)
 342:	4501                	li	a0,0
 344:	bfe5                	j	33c <strlen+0x20>

0000000000000346 <memset>:

void*
memset(void *dst, int c, uint n)
{
 346:	1141                	addi	sp,sp,-16
 348:	e422                	sd	s0,8(sp)
 34a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 34c:	ca19                	beqz	a2,362 <memset+0x1c>
 34e:	87aa                	mv	a5,a0
 350:	1602                	slli	a2,a2,0x20
 352:	9201                	srli	a2,a2,0x20
 354:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 358:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 35c:	0785                	addi	a5,a5,1
 35e:	fee79de3          	bne	a5,a4,358 <memset+0x12>
  }
  return dst;
}
 362:	6422                	ld	s0,8(sp)
 364:	0141                	addi	sp,sp,16
 366:	8082                	ret

0000000000000368 <strchr>:

char*
strchr(const char *s, char c)
{
 368:	1141                	addi	sp,sp,-16
 36a:	e422                	sd	s0,8(sp)
 36c:	0800                	addi	s0,sp,16
  for(; *s; s++)
 36e:	00054783          	lbu	a5,0(a0)
 372:	cb99                	beqz	a5,388 <strchr+0x20>
    if(*s == c)
 374:	00f58763          	beq	a1,a5,382 <strchr+0x1a>
  for(; *s; s++)
 378:	0505                	addi	a0,a0,1
 37a:	00054783          	lbu	a5,0(a0)
 37e:	fbfd                	bnez	a5,374 <strchr+0xc>
      return (char*)s;
  return 0;
 380:	4501                	li	a0,0
}
 382:	6422                	ld	s0,8(sp)
 384:	0141                	addi	sp,sp,16
 386:	8082                	ret
  return 0;
 388:	4501                	li	a0,0
 38a:	bfe5                	j	382 <strchr+0x1a>

000000000000038c <gets>:

char*
gets(char *buf, int max)
{
 38c:	711d                	addi	sp,sp,-96
 38e:	ec86                	sd	ra,88(sp)
 390:	e8a2                	sd	s0,80(sp)
 392:	e4a6                	sd	s1,72(sp)
 394:	e0ca                	sd	s2,64(sp)
 396:	fc4e                	sd	s3,56(sp)
 398:	f852                	sd	s4,48(sp)
 39a:	f456                	sd	s5,40(sp)
 39c:	f05a                	sd	s6,32(sp)
 39e:	ec5e                	sd	s7,24(sp)
 3a0:	1080                	addi	s0,sp,96
 3a2:	8baa                	mv	s7,a0
 3a4:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 3a6:	892a                	mv	s2,a0
 3a8:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 3aa:	4aa9                	li	s5,10
 3ac:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 3ae:	89a6                	mv	s3,s1
 3b0:	2485                	addiw	s1,s1,1
 3b2:	0344d663          	bge	s1,s4,3de <gets+0x52>
    cc = read(0, &c, 1);
 3b6:	4605                	li	a2,1
 3b8:	faf40593          	addi	a1,s0,-81
 3bc:	4501                	li	a0,0
 3be:	1b2000ef          	jal	ra,570 <read>
    if(cc < 1)
 3c2:	00a05e63          	blez	a0,3de <gets+0x52>
    buf[i++] = c;
 3c6:	faf44783          	lbu	a5,-81(s0)
 3ca:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 3ce:	01578763          	beq	a5,s5,3dc <gets+0x50>
 3d2:	0905                	addi	s2,s2,1
 3d4:	fd679de3          	bne	a5,s6,3ae <gets+0x22>
  for(i=0; i+1 < max; ){
 3d8:	89a6                	mv	s3,s1
 3da:	a011                	j	3de <gets+0x52>
 3dc:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 3de:	99de                	add	s3,s3,s7
 3e0:	00098023          	sb	zero,0(s3)
  return buf;
}
 3e4:	855e                	mv	a0,s7
 3e6:	60e6                	ld	ra,88(sp)
 3e8:	6446                	ld	s0,80(sp)
 3ea:	64a6                	ld	s1,72(sp)
 3ec:	6906                	ld	s2,64(sp)
 3ee:	79e2                	ld	s3,56(sp)
 3f0:	7a42                	ld	s4,48(sp)
 3f2:	7aa2                	ld	s5,40(sp)
 3f4:	7b02                	ld	s6,32(sp)
 3f6:	6be2                	ld	s7,24(sp)
 3f8:	6125                	addi	sp,sp,96
 3fa:	8082                	ret

00000000000003fc <stat>:

int
stat(const char *n, struct stat *st)
{
 3fc:	1101                	addi	sp,sp,-32
 3fe:	ec06                	sd	ra,24(sp)
 400:	e822                	sd	s0,16(sp)
 402:	e426                	sd	s1,8(sp)
 404:	e04a                	sd	s2,0(sp)
 406:	1000                	addi	s0,sp,32
 408:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 40a:	4581                	li	a1,0
 40c:	18c000ef          	jal	ra,598 <open>
  if(fd < 0)
 410:	02054163          	bltz	a0,432 <stat+0x36>
 414:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 416:	85ca                	mv	a1,s2
 418:	198000ef          	jal	ra,5b0 <fstat>
 41c:	892a                	mv	s2,a0
  close(fd);
 41e:	8526                	mv	a0,s1
 420:	160000ef          	jal	ra,580 <close>
  return r;
}
 424:	854a                	mv	a0,s2
 426:	60e2                	ld	ra,24(sp)
 428:	6442                	ld	s0,16(sp)
 42a:	64a2                	ld	s1,8(sp)
 42c:	6902                	ld	s2,0(sp)
 42e:	6105                	addi	sp,sp,32
 430:	8082                	ret
    return -1;
 432:	597d                	li	s2,-1
 434:	bfc5                	j	424 <stat+0x28>

0000000000000436 <atoi>:

int
atoi(const char *s)
{
 436:	1141                	addi	sp,sp,-16
 438:	e422                	sd	s0,8(sp)
 43a:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 43c:	00054683          	lbu	a3,0(a0)
 440:	fd06879b          	addiw	a5,a3,-48
 444:	0ff7f793          	zext.b	a5,a5
 448:	4625                	li	a2,9
 44a:	02f66863          	bltu	a2,a5,47a <atoi+0x44>
 44e:	872a                	mv	a4,a0
  n = 0;
 450:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 452:	0705                	addi	a4,a4,1
 454:	0025179b          	slliw	a5,a0,0x2
 458:	9fa9                	addw	a5,a5,a0
 45a:	0017979b          	slliw	a5,a5,0x1
 45e:	9fb5                	addw	a5,a5,a3
 460:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 464:	00074683          	lbu	a3,0(a4)
 468:	fd06879b          	addiw	a5,a3,-48
 46c:	0ff7f793          	zext.b	a5,a5
 470:	fef671e3          	bgeu	a2,a5,452 <atoi+0x1c>
  return n;
}
 474:	6422                	ld	s0,8(sp)
 476:	0141                	addi	sp,sp,16
 478:	8082                	ret
  n = 0;
 47a:	4501                	li	a0,0
 47c:	bfe5                	j	474 <atoi+0x3e>

000000000000047e <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 47e:	1141                	addi	sp,sp,-16
 480:	e422                	sd	s0,8(sp)
 482:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 484:	02b57463          	bgeu	a0,a1,4ac <memmove+0x2e>
    while(n-- > 0)
 488:	00c05f63          	blez	a2,4a6 <memmove+0x28>
 48c:	1602                	slli	a2,a2,0x20
 48e:	9201                	srli	a2,a2,0x20
 490:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 494:	872a                	mv	a4,a0
      *dst++ = *src++;
 496:	0585                	addi	a1,a1,1
 498:	0705                	addi	a4,a4,1
 49a:	fff5c683          	lbu	a3,-1(a1)
 49e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 4a2:	fee79ae3          	bne	a5,a4,496 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 4a6:	6422                	ld	s0,8(sp)
 4a8:	0141                	addi	sp,sp,16
 4aa:	8082                	ret
    dst += n;
 4ac:	00c50733          	add	a4,a0,a2
    src += n;
 4b0:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 4b2:	fec05ae3          	blez	a2,4a6 <memmove+0x28>
 4b6:	fff6079b          	addiw	a5,a2,-1
 4ba:	1782                	slli	a5,a5,0x20
 4bc:	9381                	srli	a5,a5,0x20
 4be:	fff7c793          	not	a5,a5
 4c2:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 4c4:	15fd                	addi	a1,a1,-1
 4c6:	177d                	addi	a4,a4,-1
 4c8:	0005c683          	lbu	a3,0(a1)
 4cc:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 4d0:	fee79ae3          	bne	a5,a4,4c4 <memmove+0x46>
 4d4:	bfc9                	j	4a6 <memmove+0x28>

00000000000004d6 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 4d6:	1141                	addi	sp,sp,-16
 4d8:	e422                	sd	s0,8(sp)
 4da:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 4dc:	ca05                	beqz	a2,50c <memcmp+0x36>
 4de:	fff6069b          	addiw	a3,a2,-1
 4e2:	1682                	slli	a3,a3,0x20
 4e4:	9281                	srli	a3,a3,0x20
 4e6:	0685                	addi	a3,a3,1
 4e8:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 4ea:	00054783          	lbu	a5,0(a0)
 4ee:	0005c703          	lbu	a4,0(a1)
 4f2:	00e79863          	bne	a5,a4,502 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 4f6:	0505                	addi	a0,a0,1
    p2++;
 4f8:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4fa:	fed518e3          	bne	a0,a3,4ea <memcmp+0x14>
  }
  return 0;
 4fe:	4501                	li	a0,0
 500:	a019                	j	506 <memcmp+0x30>
      return *p1 - *p2;
 502:	40e7853b          	subw	a0,a5,a4
}
 506:	6422                	ld	s0,8(sp)
 508:	0141                	addi	sp,sp,16
 50a:	8082                	ret
  return 0;
 50c:	4501                	li	a0,0
 50e:	bfe5                	j	506 <memcmp+0x30>

0000000000000510 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 510:	1141                	addi	sp,sp,-16
 512:	e406                	sd	ra,8(sp)
 514:	e022                	sd	s0,0(sp)
 516:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 518:	f67ff0ef          	jal	ra,47e <memmove>
}
 51c:	60a2                	ld	ra,8(sp)
 51e:	6402                	ld	s0,0(sp)
 520:	0141                	addi	sp,sp,16
 522:	8082                	ret

0000000000000524 <sbrk>:

char *
sbrk(int n) {
 524:	1141                	addi	sp,sp,-16
 526:	e406                	sd	ra,8(sp)
 528:	e022                	sd	s0,0(sp)
 52a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 52c:	4585                	li	a1,1
 52e:	0b2000ef          	jal	ra,5e0 <sys_sbrk>
}
 532:	60a2                	ld	ra,8(sp)
 534:	6402                	ld	s0,0(sp)
 536:	0141                	addi	sp,sp,16
 538:	8082                	ret

000000000000053a <sbrklazy>:

char *
sbrklazy(int n) {
 53a:	1141                	addi	sp,sp,-16
 53c:	e406                	sd	ra,8(sp)
 53e:	e022                	sd	s0,0(sp)
 540:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 542:	4589                	li	a1,2
 544:	09c000ef          	jal	ra,5e0 <sys_sbrk>
}
 548:	60a2                	ld	ra,8(sp)
 54a:	6402                	ld	s0,0(sp)
 54c:	0141                	addi	sp,sp,16
 54e:	8082                	ret

0000000000000550 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 550:	4885                	li	a7,1
 ecall
 552:	00000073          	ecall
 ret
 556:	8082                	ret

0000000000000558 <exit>:
.global exit
exit:
 li a7, SYS_exit
 558:	4889                	li	a7,2
 ecall
 55a:	00000073          	ecall
 ret
 55e:	8082                	ret

0000000000000560 <wait>:
.global wait
wait:
 li a7, SYS_wait
 560:	488d                	li	a7,3
 ecall
 562:	00000073          	ecall
 ret
 566:	8082                	ret

0000000000000568 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 568:	4891                	li	a7,4
 ecall
 56a:	00000073          	ecall
 ret
 56e:	8082                	ret

0000000000000570 <read>:
.global read
read:
 li a7, SYS_read
 570:	4895                	li	a7,5
 ecall
 572:	00000073          	ecall
 ret
 576:	8082                	ret

0000000000000578 <write>:
.global write
write:
 li a7, SYS_write
 578:	48c1                	li	a7,16
 ecall
 57a:	00000073          	ecall
 ret
 57e:	8082                	ret

0000000000000580 <close>:
.global close
close:
 li a7, SYS_close
 580:	48d5                	li	a7,21
 ecall
 582:	00000073          	ecall
 ret
 586:	8082                	ret

0000000000000588 <kill>:
.global kill
kill:
 li a7, SYS_kill
 588:	4899                	li	a7,6
 ecall
 58a:	00000073          	ecall
 ret
 58e:	8082                	ret

0000000000000590 <exec>:
.global exec
exec:
 li a7, SYS_exec
 590:	489d                	li	a7,7
 ecall
 592:	00000073          	ecall
 ret
 596:	8082                	ret

0000000000000598 <open>:
.global open
open:
 li a7, SYS_open
 598:	48bd                	li	a7,15
 ecall
 59a:	00000073          	ecall
 ret
 59e:	8082                	ret

00000000000005a0 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 5a0:	48c5                	li	a7,17
 ecall
 5a2:	00000073          	ecall
 ret
 5a6:	8082                	ret

00000000000005a8 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 5a8:	48c9                	li	a7,18
 ecall
 5aa:	00000073          	ecall
 ret
 5ae:	8082                	ret

00000000000005b0 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 5b0:	48a1                	li	a7,8
 ecall
 5b2:	00000073          	ecall
 ret
 5b6:	8082                	ret

00000000000005b8 <link>:
.global link
link:
 li a7, SYS_link
 5b8:	48cd                	li	a7,19
 ecall
 5ba:	00000073          	ecall
 ret
 5be:	8082                	ret

00000000000005c0 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 5c0:	48d1                	li	a7,20
 ecall
 5c2:	00000073          	ecall
 ret
 5c6:	8082                	ret

00000000000005c8 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 5c8:	48a5                	li	a7,9
 ecall
 5ca:	00000073          	ecall
 ret
 5ce:	8082                	ret

00000000000005d0 <dup>:
.global dup
dup:
 li a7, SYS_dup
 5d0:	48a9                	li	a7,10
 ecall
 5d2:	00000073          	ecall
 ret
 5d6:	8082                	ret

00000000000005d8 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 5d8:	48ad                	li	a7,11
 ecall
 5da:	00000073          	ecall
 ret
 5de:	8082                	ret

00000000000005e0 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 5e0:	48b1                	li	a7,12
 ecall
 5e2:	00000073          	ecall
 ret
 5e6:	8082                	ret

00000000000005e8 <pause>:
.global pause
pause:
 li a7, SYS_pause
 5e8:	48b5                	li	a7,13
 ecall
 5ea:	00000073          	ecall
 ret
 5ee:	8082                	ret

00000000000005f0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 5f0:	48b9                	li	a7,14
 ecall
 5f2:	00000073          	ecall
 ret
 5f6:	8082                	ret

00000000000005f8 <getprocinfo>:
.global getprocinfo
getprocinfo:
 li a7, SYS_getprocinfo
 5f8:	48d9                	li	a7,22
 ecall
 5fa:	00000073          	ecall
 ret
 5fe:	8082                	ret

0000000000000600 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 600:	1101                	addi	sp,sp,-32
 602:	ec06                	sd	ra,24(sp)
 604:	e822                	sd	s0,16(sp)
 606:	1000                	addi	s0,sp,32
 608:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 60c:	4605                	li	a2,1
 60e:	fef40593          	addi	a1,s0,-17
 612:	f67ff0ef          	jal	ra,578 <write>
}
 616:	60e2                	ld	ra,24(sp)
 618:	6442                	ld	s0,16(sp)
 61a:	6105                	addi	sp,sp,32
 61c:	8082                	ret

000000000000061e <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 61e:	715d                	addi	sp,sp,-80
 620:	e486                	sd	ra,72(sp)
 622:	e0a2                	sd	s0,64(sp)
 624:	fc26                	sd	s1,56(sp)
 626:	f84a                	sd	s2,48(sp)
 628:	f44e                	sd	s3,40(sp)
 62a:	0880                	addi	s0,sp,80
 62c:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 62e:	c299                	beqz	a3,634 <printint+0x16>
 630:	0805c163          	bltz	a1,6b2 <printint+0x94>
  neg = 0;
 634:	4881                	li	a7,0
 636:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 63a:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 63c:	00001517          	auipc	a0,0x1
 640:	8e450513          	addi	a0,a0,-1820 # f20 <digits>
 644:	883e                	mv	a6,a5
 646:	2785                	addiw	a5,a5,1
 648:	02c5f733          	remu	a4,a1,a2
 64c:	972a                	add	a4,a4,a0
 64e:	00074703          	lbu	a4,0(a4)
 652:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 656:	872e                	mv	a4,a1
 658:	02c5d5b3          	divu	a1,a1,a2
 65c:	0685                	addi	a3,a3,1
 65e:	fec773e3          	bgeu	a4,a2,644 <printint+0x26>
  if(neg)
 662:	00088b63          	beqz	a7,678 <printint+0x5a>
    buf[i++] = '-';
 666:	fd078793          	addi	a5,a5,-48
 66a:	97a2                	add	a5,a5,s0
 66c:	02d00713          	li	a4,45
 670:	fee78423          	sb	a4,-24(a5)
 674:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 678:	02f05663          	blez	a5,6a4 <printint+0x86>
 67c:	fb840713          	addi	a4,s0,-72
 680:	00f704b3          	add	s1,a4,a5
 684:	fff70993          	addi	s3,a4,-1
 688:	99be                	add	s3,s3,a5
 68a:	37fd                	addiw	a5,a5,-1
 68c:	1782                	slli	a5,a5,0x20
 68e:	9381                	srli	a5,a5,0x20
 690:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 694:	fff4c583          	lbu	a1,-1(s1)
 698:	854a                	mv	a0,s2
 69a:	f67ff0ef          	jal	ra,600 <putc>
  while(--i >= 0)
 69e:	14fd                	addi	s1,s1,-1
 6a0:	ff349ae3          	bne	s1,s3,694 <printint+0x76>
}
 6a4:	60a6                	ld	ra,72(sp)
 6a6:	6406                	ld	s0,64(sp)
 6a8:	74e2                	ld	s1,56(sp)
 6aa:	7942                	ld	s2,48(sp)
 6ac:	79a2                	ld	s3,40(sp)
 6ae:	6161                	addi	sp,sp,80
 6b0:	8082                	ret
    x = -xx;
 6b2:	40b005b3          	neg	a1,a1
    neg = 1;
 6b6:	4885                	li	a7,1
    x = -xx;
 6b8:	bfbd                	j	636 <printint+0x18>

00000000000006ba <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 6ba:	7119                	addi	sp,sp,-128
 6bc:	fc86                	sd	ra,120(sp)
 6be:	f8a2                	sd	s0,112(sp)
 6c0:	f4a6                	sd	s1,104(sp)
 6c2:	f0ca                	sd	s2,96(sp)
 6c4:	ecce                	sd	s3,88(sp)
 6c6:	e8d2                	sd	s4,80(sp)
 6c8:	e4d6                	sd	s5,72(sp)
 6ca:	e0da                	sd	s6,64(sp)
 6cc:	fc5e                	sd	s7,56(sp)
 6ce:	f862                	sd	s8,48(sp)
 6d0:	f466                	sd	s9,40(sp)
 6d2:	f06a                	sd	s10,32(sp)
 6d4:	ec6e                	sd	s11,24(sp)
 6d6:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6d8:	0005c903          	lbu	s2,0(a1)
 6dc:	24090c63          	beqz	s2,934 <vprintf+0x27a>
 6e0:	8b2a                	mv	s6,a0
 6e2:	8a2e                	mv	s4,a1
 6e4:	8bb2                	mv	s7,a2
  state = 0;
 6e6:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6e8:	4481                	li	s1,0
 6ea:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6ec:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6f0:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 6f4:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 6f8:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6fc:	00001c97          	auipc	s9,0x1
 700:	824c8c93          	addi	s9,s9,-2012 # f20 <digits>
 704:	a005                	j	724 <vprintf+0x6a>
        putc(fd, c0);
 706:	85ca                	mv	a1,s2
 708:	855a                	mv	a0,s6
 70a:	ef7ff0ef          	jal	ra,600 <putc>
 70e:	a019                	j	714 <vprintf+0x5a>
    } else if(state == '%'){
 710:	03598263          	beq	s3,s5,734 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 714:	2485                	addiw	s1,s1,1
 716:	8726                	mv	a4,s1
 718:	009a07b3          	add	a5,s4,s1
 71c:	0007c903          	lbu	s2,0(a5)
 720:	20090a63          	beqz	s2,934 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 724:	0009079b          	sext.w	a5,s2
    if(state == 0){
 728:	fe0994e3          	bnez	s3,710 <vprintf+0x56>
      if(c0 == '%'){
 72c:	fd579de3          	bne	a5,s5,706 <vprintf+0x4c>
        state = '%';
 730:	89be                	mv	s3,a5
 732:	b7cd                	j	714 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 734:	c3c1                	beqz	a5,7b4 <vprintf+0xfa>
 736:	00ea06b3          	add	a3,s4,a4
 73a:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 73e:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 740:	c681                	beqz	a3,748 <vprintf+0x8e>
 742:	9752                	add	a4,a4,s4
 744:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 748:	03878e63          	beq	a5,s8,784 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 74c:	05a78863          	beq	a5,s10,79c <vprintf+0xe2>
      } else if(c0 == 'u'){
 750:	0db78b63          	beq	a5,s11,826 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 754:	07800713          	li	a4,120
 758:	10e78d63          	beq	a5,a4,872 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 75c:	07000713          	li	a4,112
 760:	14e78263          	beq	a5,a4,8a4 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 764:	06300713          	li	a4,99
 768:	16e78f63          	beq	a5,a4,8e6 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 76c:	07300713          	li	a4,115
 770:	18e78563          	beq	a5,a4,8fa <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 774:	05579063          	bne	a5,s5,7b4 <vprintf+0xfa>
        putc(fd, '%');
 778:	85d6                	mv	a1,s5
 77a:	855a                	mv	a0,s6
 77c:	e85ff0ef          	jal	ra,600 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 780:	4981                	li	s3,0
 782:	bf49                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 784:	008b8913          	addi	s2,s7,8
 788:	4685                	li	a3,1
 78a:	4629                	li	a2,10
 78c:	000ba583          	lw	a1,0(s7)
 790:	855a                	mv	a0,s6
 792:	e8dff0ef          	jal	ra,61e <printint>
 796:	8bca                	mv	s7,s2
      state = 0;
 798:	4981                	li	s3,0
 79a:	bfad                	j	714 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 79c:	03868663          	beq	a3,s8,7c8 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7a0:	05a68163          	beq	a3,s10,7e2 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 7a4:	09b68d63          	beq	a3,s11,83e <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7a8:	03a68f63          	beq	a3,s10,7e6 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 7ac:	07800793          	li	a5,120
 7b0:	0cf68d63          	beq	a3,a5,88a <vprintf+0x1d0>
        putc(fd, '%');
 7b4:	85d6                	mv	a1,s5
 7b6:	855a                	mv	a0,s6
 7b8:	e49ff0ef          	jal	ra,600 <putc>
        putc(fd, c0);
 7bc:	85ca                	mv	a1,s2
 7be:	855a                	mv	a0,s6
 7c0:	e41ff0ef          	jal	ra,600 <putc>
      state = 0;
 7c4:	4981                	li	s3,0
 7c6:	b7b9                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 7c8:	008b8913          	addi	s2,s7,8
 7cc:	4685                	li	a3,1
 7ce:	4629                	li	a2,10
 7d0:	000bb583          	ld	a1,0(s7)
 7d4:	855a                	mv	a0,s6
 7d6:	e49ff0ef          	jal	ra,61e <printint>
        i += 1;
 7da:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 7dc:	8bca                	mv	s7,s2
      state = 0;
 7de:	4981                	li	s3,0
        i += 1;
 7e0:	bf15                	j	714 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7e2:	03860563          	beq	a2,s8,80c <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7e6:	07b60963          	beq	a2,s11,858 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 7ea:	07800793          	li	a5,120
 7ee:	fcf613e3          	bne	a2,a5,7b4 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7f2:	008b8913          	addi	s2,s7,8
 7f6:	4681                	li	a3,0
 7f8:	4641                	li	a2,16
 7fa:	000bb583          	ld	a1,0(s7)
 7fe:	855a                	mv	a0,s6
 800:	e1fff0ef          	jal	ra,61e <printint>
        i += 2;
 804:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 806:	8bca                	mv	s7,s2
      state = 0;
 808:	4981                	li	s3,0
        i += 2;
 80a:	b729                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 80c:	008b8913          	addi	s2,s7,8
 810:	4685                	li	a3,1
 812:	4629                	li	a2,10
 814:	000bb583          	ld	a1,0(s7)
 818:	855a                	mv	a0,s6
 81a:	e05ff0ef          	jal	ra,61e <printint>
        i += 2;
 81e:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 820:	8bca                	mv	s7,s2
      state = 0;
 822:	4981                	li	s3,0
        i += 2;
 824:	bdc5                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 826:	008b8913          	addi	s2,s7,8
 82a:	4681                	li	a3,0
 82c:	4629                	li	a2,10
 82e:	000be583          	lwu	a1,0(s7)
 832:	855a                	mv	a0,s6
 834:	debff0ef          	jal	ra,61e <printint>
 838:	8bca                	mv	s7,s2
      state = 0;
 83a:	4981                	li	s3,0
 83c:	bde1                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 83e:	008b8913          	addi	s2,s7,8
 842:	4681                	li	a3,0
 844:	4629                	li	a2,10
 846:	000bb583          	ld	a1,0(s7)
 84a:	855a                	mv	a0,s6
 84c:	dd3ff0ef          	jal	ra,61e <printint>
        i += 1;
 850:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 852:	8bca                	mv	s7,s2
      state = 0;
 854:	4981                	li	s3,0
        i += 1;
 856:	bd7d                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 858:	008b8913          	addi	s2,s7,8
 85c:	4681                	li	a3,0
 85e:	4629                	li	a2,10
 860:	000bb583          	ld	a1,0(s7)
 864:	855a                	mv	a0,s6
 866:	db9ff0ef          	jal	ra,61e <printint>
        i += 2;
 86a:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 86c:	8bca                	mv	s7,s2
      state = 0;
 86e:	4981                	li	s3,0
        i += 2;
 870:	b555                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 872:	008b8913          	addi	s2,s7,8
 876:	4681                	li	a3,0
 878:	4641                	li	a2,16
 87a:	000be583          	lwu	a1,0(s7)
 87e:	855a                	mv	a0,s6
 880:	d9fff0ef          	jal	ra,61e <printint>
 884:	8bca                	mv	s7,s2
      state = 0;
 886:	4981                	li	s3,0
 888:	b571                	j	714 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 88a:	008b8913          	addi	s2,s7,8
 88e:	4681                	li	a3,0
 890:	4641                	li	a2,16
 892:	000bb583          	ld	a1,0(s7)
 896:	855a                	mv	a0,s6
 898:	d87ff0ef          	jal	ra,61e <printint>
        i += 1;
 89c:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 89e:	8bca                	mv	s7,s2
      state = 0;
 8a0:	4981                	li	s3,0
        i += 1;
 8a2:	bd8d                	j	714 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 8a4:	008b8793          	addi	a5,s7,8
 8a8:	f8f43423          	sd	a5,-120(s0)
 8ac:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 8b0:	03000593          	li	a1,48
 8b4:	855a                	mv	a0,s6
 8b6:	d4bff0ef          	jal	ra,600 <putc>
  putc(fd, 'x');
 8ba:	07800593          	li	a1,120
 8be:	855a                	mv	a0,s6
 8c0:	d41ff0ef          	jal	ra,600 <putc>
 8c4:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 8c6:	03c9d793          	srli	a5,s3,0x3c
 8ca:	97e6                	add	a5,a5,s9
 8cc:	0007c583          	lbu	a1,0(a5)
 8d0:	855a                	mv	a0,s6
 8d2:	d2fff0ef          	jal	ra,600 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 8d6:	0992                	slli	s3,s3,0x4
 8d8:	397d                	addiw	s2,s2,-1
 8da:	fe0916e3          	bnez	s2,8c6 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 8de:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 8e2:	4981                	li	s3,0
 8e4:	bd05                	j	714 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 8e6:	008b8913          	addi	s2,s7,8
 8ea:	000bc583          	lbu	a1,0(s7)
 8ee:	855a                	mv	a0,s6
 8f0:	d11ff0ef          	jal	ra,600 <putc>
 8f4:	8bca                	mv	s7,s2
      state = 0;
 8f6:	4981                	li	s3,0
 8f8:	bd31                	j	714 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 8fa:	008b8993          	addi	s3,s7,8
 8fe:	000bb903          	ld	s2,0(s7)
 902:	00090f63          	beqz	s2,920 <vprintf+0x266>
        for(; *s; s++)
 906:	00094583          	lbu	a1,0(s2)
 90a:	c195                	beqz	a1,92e <vprintf+0x274>
          putc(fd, *s);
 90c:	855a                	mv	a0,s6
 90e:	cf3ff0ef          	jal	ra,600 <putc>
        for(; *s; s++)
 912:	0905                	addi	s2,s2,1
 914:	00094583          	lbu	a1,0(s2)
 918:	f9f5                	bnez	a1,90c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 91a:	8bce                	mv	s7,s3
      state = 0;
 91c:	4981                	li	s3,0
 91e:	bbdd                	j	714 <vprintf+0x5a>
          s = "(null)";
 920:	00000917          	auipc	s2,0x0
 924:	5f890913          	addi	s2,s2,1528 # f18 <malloc+0x4e8>
        for(; *s; s++)
 928:	02800593          	li	a1,40
 92c:	b7c5                	j	90c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 92e:	8bce                	mv	s7,s3
      state = 0;
 930:	4981                	li	s3,0
 932:	b3cd                	j	714 <vprintf+0x5a>
    }
  }
}
 934:	70e6                	ld	ra,120(sp)
 936:	7446                	ld	s0,112(sp)
 938:	74a6                	ld	s1,104(sp)
 93a:	7906                	ld	s2,96(sp)
 93c:	69e6                	ld	s3,88(sp)
 93e:	6a46                	ld	s4,80(sp)
 940:	6aa6                	ld	s5,72(sp)
 942:	6b06                	ld	s6,64(sp)
 944:	7be2                	ld	s7,56(sp)
 946:	7c42                	ld	s8,48(sp)
 948:	7ca2                	ld	s9,40(sp)
 94a:	7d02                	ld	s10,32(sp)
 94c:	6de2                	ld	s11,24(sp)
 94e:	6109                	addi	sp,sp,128
 950:	8082                	ret

0000000000000952 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 952:	715d                	addi	sp,sp,-80
 954:	ec06                	sd	ra,24(sp)
 956:	e822                	sd	s0,16(sp)
 958:	1000                	addi	s0,sp,32
 95a:	e010                	sd	a2,0(s0)
 95c:	e414                	sd	a3,8(s0)
 95e:	e818                	sd	a4,16(s0)
 960:	ec1c                	sd	a5,24(s0)
 962:	03043023          	sd	a6,32(s0)
 966:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 96a:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 96e:	8622                	mv	a2,s0
 970:	d4bff0ef          	jal	ra,6ba <vprintf>
}
 974:	60e2                	ld	ra,24(sp)
 976:	6442                	ld	s0,16(sp)
 978:	6161                	addi	sp,sp,80
 97a:	8082                	ret

000000000000097c <printf>:

void
printf(const char *fmt, ...)
{
 97c:	711d                	addi	sp,sp,-96
 97e:	ec06                	sd	ra,24(sp)
 980:	e822                	sd	s0,16(sp)
 982:	1000                	addi	s0,sp,32
 984:	e40c                	sd	a1,8(s0)
 986:	e810                	sd	a2,16(s0)
 988:	ec14                	sd	a3,24(s0)
 98a:	f018                	sd	a4,32(s0)
 98c:	f41c                	sd	a5,40(s0)
 98e:	03043823          	sd	a6,48(s0)
 992:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 996:	00840613          	addi	a2,s0,8
 99a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 99e:	85aa                	mv	a1,a0
 9a0:	4505                	li	a0,1
 9a2:	d19ff0ef          	jal	ra,6ba <vprintf>
}
 9a6:	60e2                	ld	ra,24(sp)
 9a8:	6442                	ld	s0,16(sp)
 9aa:	6125                	addi	sp,sp,96
 9ac:	8082                	ret

00000000000009ae <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 9ae:	1141                	addi	sp,sp,-16
 9b0:	e422                	sd	s0,8(sp)
 9b2:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 9b4:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9b8:	00000797          	auipc	a5,0x0
 9bc:	6487b783          	ld	a5,1608(a5) # 1000 <freep>
 9c0:	a02d                	j	9ea <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 9c2:	4618                	lw	a4,8(a2)
 9c4:	9f2d                	addw	a4,a4,a1
 9c6:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 9ca:	6398                	ld	a4,0(a5)
 9cc:	6310                	ld	a2,0(a4)
 9ce:	a83d                	j	a0c <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 9d0:	ff852703          	lw	a4,-8(a0)
 9d4:	9f31                	addw	a4,a4,a2
 9d6:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 9d8:	ff053683          	ld	a3,-16(a0)
 9dc:	a091                	j	a20 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9de:	6398                	ld	a4,0(a5)
 9e0:	00e7e463          	bltu	a5,a4,9e8 <free+0x3a>
 9e4:	00e6ea63          	bltu	a3,a4,9f8 <free+0x4a>
{
 9e8:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9ea:	fed7fae3          	bgeu	a5,a3,9de <free+0x30>
 9ee:	6398                	ld	a4,0(a5)
 9f0:	00e6e463          	bltu	a3,a4,9f8 <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9f4:	fee7eae3          	bltu	a5,a4,9e8 <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 9f8:	ff852583          	lw	a1,-8(a0)
 9fc:	6390                	ld	a2,0(a5)
 9fe:	02059813          	slli	a6,a1,0x20
 a02:	01c85713          	srli	a4,a6,0x1c
 a06:	9736                	add	a4,a4,a3
 a08:	fae60de3          	beq	a2,a4,9c2 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 a0c:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 a10:	4790                	lw	a2,8(a5)
 a12:	02061593          	slli	a1,a2,0x20
 a16:	01c5d713          	srli	a4,a1,0x1c
 a1a:	973e                	add	a4,a4,a5
 a1c:	fae68ae3          	beq	a3,a4,9d0 <free+0x22>
    p->s.ptr = bp->s.ptr;
 a20:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 a22:	00000717          	auipc	a4,0x0
 a26:	5cf73f23          	sd	a5,1502(a4) # 1000 <freep>
}
 a2a:	6422                	ld	s0,8(sp)
 a2c:	0141                	addi	sp,sp,16
 a2e:	8082                	ret

0000000000000a30 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a30:	7139                	addi	sp,sp,-64
 a32:	fc06                	sd	ra,56(sp)
 a34:	f822                	sd	s0,48(sp)
 a36:	f426                	sd	s1,40(sp)
 a38:	f04a                	sd	s2,32(sp)
 a3a:	ec4e                	sd	s3,24(sp)
 a3c:	e852                	sd	s4,16(sp)
 a3e:	e456                	sd	s5,8(sp)
 a40:	e05a                	sd	s6,0(sp)
 a42:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a44:	02051493          	slli	s1,a0,0x20
 a48:	9081                	srli	s1,s1,0x20
 a4a:	04bd                	addi	s1,s1,15
 a4c:	8091                	srli	s1,s1,0x4
 a4e:	0014899b          	addiw	s3,s1,1
 a52:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 a54:	00000517          	auipc	a0,0x0
 a58:	5ac53503          	ld	a0,1452(a0) # 1000 <freep>
 a5c:	c515                	beqz	a0,a88 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a5e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a60:	4798                	lw	a4,8(a5)
 a62:	02977f63          	bgeu	a4,s1,aa0 <malloc+0x70>
 a66:	8a4e                	mv	s4,s3
 a68:	0009871b          	sext.w	a4,s3
 a6c:	6685                	lui	a3,0x1
 a6e:	00d77363          	bgeu	a4,a3,a74 <malloc+0x44>
 a72:	6a05                	lui	s4,0x1
 a74:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a78:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a7c:	00000917          	auipc	s2,0x0
 a80:	58490913          	addi	s2,s2,1412 # 1000 <freep>
  if(p == SBRK_ERROR)
 a84:	5afd                	li	s5,-1
 a86:	a885                	j	af6 <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 a88:	00000797          	auipc	a5,0x0
 a8c:	58878793          	addi	a5,a5,1416 # 1010 <base>
 a90:	00000717          	auipc	a4,0x0
 a94:	56f73823          	sd	a5,1392(a4) # 1000 <freep>
 a98:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a9a:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a9e:	b7e1                	j	a66 <malloc+0x36>
      if(p->s.size == nunits)
 aa0:	02e48c63          	beq	s1,a4,ad8 <malloc+0xa8>
        p->s.size -= nunits;
 aa4:	4137073b          	subw	a4,a4,s3
 aa8:	c798                	sw	a4,8(a5)
        p += p->s.size;
 aaa:	02071693          	slli	a3,a4,0x20
 aae:	01c6d713          	srli	a4,a3,0x1c
 ab2:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 ab4:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 ab8:	00000717          	auipc	a4,0x0
 abc:	54a73423          	sd	a0,1352(a4) # 1000 <freep>
      return (void*)(p + 1);
 ac0:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 ac4:	70e2                	ld	ra,56(sp)
 ac6:	7442                	ld	s0,48(sp)
 ac8:	74a2                	ld	s1,40(sp)
 aca:	7902                	ld	s2,32(sp)
 acc:	69e2                	ld	s3,24(sp)
 ace:	6a42                	ld	s4,16(sp)
 ad0:	6aa2                	ld	s5,8(sp)
 ad2:	6b02                	ld	s6,0(sp)
 ad4:	6121                	addi	sp,sp,64
 ad6:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 ad8:	6398                	ld	a4,0(a5)
 ada:	e118                	sd	a4,0(a0)
 adc:	bff1                	j	ab8 <malloc+0x88>
  hp->s.size = nu;
 ade:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 ae2:	0541                	addi	a0,a0,16
 ae4:	ecbff0ef          	jal	ra,9ae <free>
  return freep;
 ae8:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 aec:	dd61                	beqz	a0,ac4 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 aee:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 af0:	4798                	lw	a4,8(a5)
 af2:	fa9777e3          	bgeu	a4,s1,aa0 <malloc+0x70>
    if(p == freep)
 af6:	00093703          	ld	a4,0(s2)
 afa:	853e                	mv	a0,a5
 afc:	fef719e3          	bne	a4,a5,aee <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 b00:	8552                	mv	a0,s4
 b02:	a23ff0ef          	jal	ra,524 <sbrk>
  if(p == SBRK_ERROR)
 b06:	fd551ce3          	bne	a0,s5,ade <malloc+0xae>
        return 0;
 b0a:	4501                	li	a0,0
 b0c:	bf65                	j	ac4 <malloc+0x94>
