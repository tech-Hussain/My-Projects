
user/_io_bound:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main(int argc, char *argv[]) {
   0:	7175                	addi	sp,sp,-144
   2:	e506                	sd	ra,136(sp)
   4:	e122                	sd	s0,128(sp)
   6:	fca6                	sd	s1,120(sp)
   8:	f8ca                	sd	s2,112(sp)
   a:	f4ce                	sd	s3,104(sp)
   c:	f0d2                	sd	s4,96(sp)
   e:	ecd6                	sd	s5,88(sp)
  10:	e8da                	sd	s6,80(sp)
  12:	e4de                	sd	s7,72(sp)
  14:	0900                	addi	s0,sp,144
    struct procinfo info;
    int pid = getpid();
  16:	542000ef          	jal	ra,558 <getpid>
  1a:	8aaa                	mv	s5,a0
    
    printf("=====================================\n");
  1c:	00001517          	auipc	a0,0x1
  20:	a7450513          	addi	a0,a0,-1420 # a90 <malloc+0xe0>
  24:	0d9000ef          	jal	ra,8fc <printf>
    printf("     I/O-BOUND PROCESS TEST\n");
  28:	00001517          	auipc	a0,0x1
  2c:	a9050513          	addi	a0,a0,-1392 # ab8 <malloc+0x108>
  30:	0cd000ef          	jal	ra,8fc <printf>
    printf("     Scheduler: MLFQ\n");
  34:	00001517          	auipc	a0,0x1
  38:	aa450513          	addi	a0,a0,-1372 # ad8 <malloc+0x128>
  3c:	0c1000ef          	jal	ra,8fc <printf>
    printf("=====================================\n\n");
  40:	00001517          	auipc	a0,0x1
  44:	ab050513          	addi	a0,a0,-1360 # af0 <malloc+0x140>
  48:	0b5000ef          	jal	ra,8fc <printf>
    
    getprocinfo(pid, &info);
  4c:	f7840593          	addi	a1,s0,-136
  50:	8556                	mv	a0,s5
  52:	526000ef          	jal	ra,578 <getprocinfo>
    printf("Initial State:\n");
  56:	00001517          	auipc	a0,0x1
  5a:	ac250513          	addi	a0,a0,-1342 # b18 <malloc+0x168>
  5e:	09f000ef          	jal	ra,8fc <printf>
    printf("  PID: %d\n", info.pid);
  62:	f7842583          	lw	a1,-136(s0)
  66:	00001517          	auipc	a0,0x1
  6a:	ac250513          	addi	a0,a0,-1342 # b28 <malloc+0x178>
  6e:	08f000ef          	jal	ra,8fc <printf>
    printf("  Priority: %d (MLFQ starts HIGH)\n", info.priority);
  72:	f7c42583          	lw	a1,-132(s0)
  76:	00001517          	auipc	a0,0x1
  7a:	ac250513          	addi	a0,a0,-1342 # b38 <malloc+0x188>
  7e:	07f000ef          	jal	ra,8fc <printf>
    printf("  Start Time: %lu ticks\n", info.start_time);
  82:	f9043583          	ld	a1,-112(s0)
  86:	00001517          	auipc	a0,0x1
  8a:	ada50513          	addi	a0,a0,-1318 # b60 <malloc+0x1b0>
  8e:	06f000ef          	jal	ra,8fc <printf>
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
  92:	f8042583          	lw	a1,-128(s0)
  96:	00001517          	auipc	a0,0x1
  9a:	aea50513          	addi	a0,a0,-1302 # b80 <malloc+0x1d0>
  9e:	05f000ef          	jal	ra,8fc <printf>
    printf("  Schedule Count: %d\n\n", info.sched_count);
  a2:	f8442583          	lw	a1,-124(s0)
  a6:	00001517          	auipc	a0,0x1
  aa:	af250513          	addi	a0,a0,-1294 # b98 <malloc+0x1e8>
  ae:	04f000ef          	jal	ra,8fc <printf>

    printf("Starting I/O operations...\n");
  b2:	00001517          	auipc	a0,0x1
  b6:	afe50513          	addi	a0,a0,-1282 # bb0 <malloc+0x200>
  ba:	043000ef          	jal	ra,8fc <printf>

    // Open or create a small file for simulated I/O
    int fd = open("io_test.txt", O_CREATE | O_WRONLY);
  be:	20100593          	li	a1,513
  c2:	00001517          	auipc	a0,0x1
  c6:	b0e50513          	addi	a0,a0,-1266 # bd0 <malloc+0x220>
  ca:	44e000ef          	jal	ra,518 <open>
    if (fd < 0) {
  ce:	00054f63          	bltz	a0,ec <main+0xec>
  d2:	892a                	mv	s2,a0
  d4:	4481                	li	s1,0

        // Simulated I/O write (small, frequent)
        write(fd, &data, sizeof(data));
    	
        // Occasional debug output every 10 iterations
        if (i % 10 == 0) {
  d6:	4a29                	li	s4,10
            printf("\n[Iteration %d] ", i);
  d8:	00001b97          	auipc	s7,0x1
  dc:	b30b8b93          	addi	s7,s7,-1232 # c08 <malloc+0x258>
            getprocinfo(pid, &info);
            printf("Priority: %d (MLFQ: should stay HIGH), CPU: %d, Wait: %lu, Sched: %d\n",
  e0:	00001b17          	auipc	s6,0x1
  e4:	b40b0b13          	addi	s6,s6,-1216 # c20 <malloc+0x270>
    for (int i = 0; i < 30; i++) {
  e8:	49f9                	li	s3,30
  ea:	a829                	j	104 <main+0x104>
        printf("Error: could not open io_test.txt\n");
  ec:	00001517          	auipc	a0,0x1
  f0:	af450513          	addi	a0,a0,-1292 # be0 <malloc+0x230>
  f4:	009000ef          	jal	ra,8fc <printf>
        exit(1);
  f8:	4505                	li	a0,1
  fa:	3de000ef          	jal	ra,4d8 <exit>
    for (int i = 0; i < 30; i++) {
  fe:	2485                	addiw	s1,s1,1
 100:	05348563          	beq	s1,s3,14a <main+0x14a>
        int data = i * i + 7;
 104:	029487bb          	mulw	a5,s1,s1
 108:	279d                	addiw	a5,a5,7
 10a:	f6f42a23          	sw	a5,-140(s0)
        write(fd, &data, sizeof(data));
 10e:	4611                	li	a2,4
 110:	f7440593          	addi	a1,s0,-140
 114:	854a                	mv	a0,s2
 116:	3e2000ef          	jal	ra,4f8 <write>
        if (i % 10 == 0) {
 11a:	0344e7bb          	remw	a5,s1,s4
 11e:	f3e5                	bnez	a5,fe <main+0xfe>
            printf("\n[Iteration %d] ", i);
 120:	85a6                	mv	a1,s1
 122:	855e                	mv	a0,s7
 124:	7d8000ef          	jal	ra,8fc <printf>
            getprocinfo(pid, &info);
 128:	f7840593          	addi	a1,s0,-136
 12c:	8556                	mv	a0,s5
 12e:	44a000ef          	jal	ra,578 <getprocinfo>
            printf("Priority: %d (MLFQ: should stay HIGH), CPU: %d, Wait: %lu, Sched: %d\n",
 132:	f8442703          	lw	a4,-124(s0)
 136:	fa843683          	ld	a3,-88(s0)
 13a:	f8042603          	lw	a2,-128(s0)
 13e:	f7c42583          	lw	a1,-132(s0)
 142:	855a                	mv	a0,s6
 144:	7b8000ef          	jal	ra,8fc <printf>
 148:	bf5d                	j	fe <main+0xfe>
                   info.priority, info.cpu_ticks, info.total_wait, info.sched_count);
        }
    }

    close(fd);
 14a:	854a                	mv	a0,s2
 14c:	3b4000ef          	jal	ra,500 <close>

    printf("\nI/O operations complete.\n");
 150:	00001517          	auipc	a0,0x1
 154:	b1850513          	addi	a0,a0,-1256 # c68 <malloc+0x2b8>
 158:	7a4000ef          	jal	ra,8fc <printf>

    getprocinfo(pid, &info);
 15c:	f7840593          	addi	a1,s0,-136
 160:	8556                	mv	a0,s5
 162:	416000ef          	jal	ra,578 <getprocinfo>
    printf("\n=====================================\n");
 166:	00001517          	auipc	a0,0x1
 16a:	b2250513          	addi	a0,a0,-1246 # c88 <malloc+0x2d8>
 16e:	78e000ef          	jal	ra,8fc <printf>
    printf("FINAL RESULTS (MLFQ):\n");
 172:	00001517          	auipc	a0,0x1
 176:	b3e50513          	addi	a0,a0,-1218 # cb0 <malloc+0x300>
 17a:	782000ef          	jal	ra,8fc <printf>
    printf("  Priority: %d (0=HIGH, 1=MED, 2=LOW)\n", info.priority);
 17e:	f7c42583          	lw	a1,-132(s0)
 182:	00001517          	auipc	a0,0x1
 186:	b4650513          	addi	a0,a0,-1210 # cc8 <malloc+0x318>
 18a:	772000ef          	jal	ra,8fc <printf>
    printf("  Turnaround Time: %lu ticks\n", info.end_time - info.start_time);
 18e:	f9843583          	ld	a1,-104(s0)
 192:	f9043783          	ld	a5,-112(s0)
 196:	8d9d                	sub	a1,a1,a5
 198:	00001517          	auipc	a0,0x1
 19c:	b5850513          	addi	a0,a0,-1192 # cf0 <malloc+0x340>
 1a0:	75c000ef          	jal	ra,8fc <printf>
    printf("  Response Time: %lu ticks\n", info.first_run - info.start_time);
 1a4:	fa043583          	ld	a1,-96(s0)
 1a8:	f9043783          	ld	a5,-112(s0)
 1ac:	8d9d                	sub	a1,a1,a5
 1ae:	00001517          	auipc	a0,0x1
 1b2:	b6250513          	addi	a0,a0,-1182 # d10 <malloc+0x360>
 1b6:	746000ef          	jal	ra,8fc <printf>
    printf("  Wait Time: %lu ticks\n", info.total_wait);
 1ba:	fa843583          	ld	a1,-88(s0)
 1be:	00001517          	auipc	a0,0x1
 1c2:	b7250513          	addi	a0,a0,-1166 # d30 <malloc+0x380>
 1c6:	736000ef          	jal	ra,8fc <printf>
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
 1ca:	f8042583          	lw	a1,-128(s0)
 1ce:	00001517          	auipc	a0,0x1
 1d2:	9b250513          	addi	a0,a0,-1614 # b80 <malloc+0x1d0>
 1d6:	726000ef          	jal	ra,8fc <printf>
    printf("  Schedule Count: %d\n", info.sched_count);
 1da:	f8442583          	lw	a1,-124(s0)
 1de:	00001517          	auipc	a0,0x1
 1e2:	b6a50513          	addi	a0,a0,-1174 # d48 <malloc+0x398>
 1e6:	716000ef          	jal	ra,8fc <printf>
    printf("  Timeslice Used: %d/%d\n", info.timeslice_used,
 1ea:	f8842583          	lw	a1,-120(s0)
           info.priority == 0 ? 4 : (info.priority == 1 ? 8 : 16));
 1ee:	f7c42783          	lw	a5,-132(s0)
    printf("  Timeslice Used: %d/%d\n", info.timeslice_used,
 1f2:	4611                	li	a2,4
 1f4:	c789                	beqz	a5,1fe <main+0x1fe>
           info.priority == 0 ? 4 : (info.priority == 1 ? 8 : 16));
 1f6:	4705                	li	a4,1
 1f8:	04e78463          	beq	a5,a4,240 <main+0x240>
 1fc:	4641                	li	a2,16
    printf("  Timeslice Used: %d/%d\n", info.timeslice_used,
 1fe:	00001517          	auipc	a0,0x1
 202:	b6250513          	addi	a0,a0,-1182 # d60 <malloc+0x3b0>
 206:	6f6000ef          	jal	ra,8fc <printf>
    printf("\nNOTE: In MLFQ, I/O-bound stays at HIGH priority\n");
 20a:	00001517          	auipc	a0,0x1
 20e:	b7650513          	addi	a0,a0,-1162 # d80 <malloc+0x3d0>
 212:	6ea000ef          	jal	ra,8fc <printf>
    printf("      Gets better response time than CPU-bound\n");
 216:	00001517          	auipc	a0,0x1
 21a:	ba250513          	addi	a0,a0,-1118 # db8 <malloc+0x408>
 21e:	6de000ef          	jal	ra,8fc <printf>
    printf("      Compare with RR where all are equal\n");
 222:	00001517          	auipc	a0,0x1
 226:	bc650513          	addi	a0,a0,-1082 # de8 <malloc+0x438>
 22a:	6d2000ef          	jal	ra,8fc <printf>
    printf("=====================================\n");
 22e:	00001517          	auipc	a0,0x1
 232:	86250513          	addi	a0,a0,-1950 # a90 <malloc+0xe0>
 236:	6c6000ef          	jal	ra,8fc <printf>

    exit(0);
 23a:	4501                	li	a0,0
 23c:	29c000ef          	jal	ra,4d8 <exit>
           info.priority == 0 ? 4 : (info.priority == 1 ? 8 : 16));
 240:	4621                	li	a2,8
 242:	bf75                	j	1fe <main+0x1fe>

0000000000000244 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 244:	1141                	addi	sp,sp,-16
 246:	e406                	sd	ra,8(sp)
 248:	e022                	sd	s0,0(sp)
 24a:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 24c:	db5ff0ef          	jal	ra,0 <main>
  exit(r);
 250:	288000ef          	jal	ra,4d8 <exit>

0000000000000254 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 254:	1141                	addi	sp,sp,-16
 256:	e422                	sd	s0,8(sp)
 258:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 25a:	87aa                	mv	a5,a0
 25c:	0585                	addi	a1,a1,1
 25e:	0785                	addi	a5,a5,1
 260:	fff5c703          	lbu	a4,-1(a1)
 264:	fee78fa3          	sb	a4,-1(a5)
 268:	fb75                	bnez	a4,25c <strcpy+0x8>
    ;
  return os;
}
 26a:	6422                	ld	s0,8(sp)
 26c:	0141                	addi	sp,sp,16
 26e:	8082                	ret

0000000000000270 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 270:	1141                	addi	sp,sp,-16
 272:	e422                	sd	s0,8(sp)
 274:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 276:	00054783          	lbu	a5,0(a0)
 27a:	cb91                	beqz	a5,28e <strcmp+0x1e>
 27c:	0005c703          	lbu	a4,0(a1)
 280:	00f71763          	bne	a4,a5,28e <strcmp+0x1e>
    p++, q++;
 284:	0505                	addi	a0,a0,1
 286:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 288:	00054783          	lbu	a5,0(a0)
 28c:	fbe5                	bnez	a5,27c <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 28e:	0005c503          	lbu	a0,0(a1)
}
 292:	40a7853b          	subw	a0,a5,a0
 296:	6422                	ld	s0,8(sp)
 298:	0141                	addi	sp,sp,16
 29a:	8082                	ret

000000000000029c <strlen>:

uint
strlen(const char *s)
{
 29c:	1141                	addi	sp,sp,-16
 29e:	e422                	sd	s0,8(sp)
 2a0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2a2:	00054783          	lbu	a5,0(a0)
 2a6:	cf91                	beqz	a5,2c2 <strlen+0x26>
 2a8:	0505                	addi	a0,a0,1
 2aa:	87aa                	mv	a5,a0
 2ac:	4685                	li	a3,1
 2ae:	9e89                	subw	a3,a3,a0
 2b0:	00f6853b          	addw	a0,a3,a5
 2b4:	0785                	addi	a5,a5,1
 2b6:	fff7c703          	lbu	a4,-1(a5)
 2ba:	fb7d                	bnez	a4,2b0 <strlen+0x14>
    ;
  return n;
}
 2bc:	6422                	ld	s0,8(sp)
 2be:	0141                	addi	sp,sp,16
 2c0:	8082                	ret
  for(n = 0; s[n]; n++)
 2c2:	4501                	li	a0,0
 2c4:	bfe5                	j	2bc <strlen+0x20>

00000000000002c6 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2c6:	1141                	addi	sp,sp,-16
 2c8:	e422                	sd	s0,8(sp)
 2ca:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2cc:	ca19                	beqz	a2,2e2 <memset+0x1c>
 2ce:	87aa                	mv	a5,a0
 2d0:	1602                	slli	a2,a2,0x20
 2d2:	9201                	srli	a2,a2,0x20
 2d4:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2d8:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2dc:	0785                	addi	a5,a5,1
 2de:	fee79de3          	bne	a5,a4,2d8 <memset+0x12>
  }
  return dst;
}
 2e2:	6422                	ld	s0,8(sp)
 2e4:	0141                	addi	sp,sp,16
 2e6:	8082                	ret

00000000000002e8 <strchr>:

char*
strchr(const char *s, char c)
{
 2e8:	1141                	addi	sp,sp,-16
 2ea:	e422                	sd	s0,8(sp)
 2ec:	0800                	addi	s0,sp,16
  for(; *s; s++)
 2ee:	00054783          	lbu	a5,0(a0)
 2f2:	cb99                	beqz	a5,308 <strchr+0x20>
    if(*s == c)
 2f4:	00f58763          	beq	a1,a5,302 <strchr+0x1a>
  for(; *s; s++)
 2f8:	0505                	addi	a0,a0,1
 2fa:	00054783          	lbu	a5,0(a0)
 2fe:	fbfd                	bnez	a5,2f4 <strchr+0xc>
      return (char*)s;
  return 0;
 300:	4501                	li	a0,0
}
 302:	6422                	ld	s0,8(sp)
 304:	0141                	addi	sp,sp,16
 306:	8082                	ret
  return 0;
 308:	4501                	li	a0,0
 30a:	bfe5                	j	302 <strchr+0x1a>

000000000000030c <gets>:

char*
gets(char *buf, int max)
{
 30c:	711d                	addi	sp,sp,-96
 30e:	ec86                	sd	ra,88(sp)
 310:	e8a2                	sd	s0,80(sp)
 312:	e4a6                	sd	s1,72(sp)
 314:	e0ca                	sd	s2,64(sp)
 316:	fc4e                	sd	s3,56(sp)
 318:	f852                	sd	s4,48(sp)
 31a:	f456                	sd	s5,40(sp)
 31c:	f05a                	sd	s6,32(sp)
 31e:	ec5e                	sd	s7,24(sp)
 320:	1080                	addi	s0,sp,96
 322:	8baa                	mv	s7,a0
 324:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 326:	892a                	mv	s2,a0
 328:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 32a:	4aa9                	li	s5,10
 32c:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 32e:	89a6                	mv	s3,s1
 330:	2485                	addiw	s1,s1,1
 332:	0344d663          	bge	s1,s4,35e <gets+0x52>
    cc = read(0, &c, 1);
 336:	4605                	li	a2,1
 338:	faf40593          	addi	a1,s0,-81
 33c:	4501                	li	a0,0
 33e:	1b2000ef          	jal	ra,4f0 <read>
    if(cc < 1)
 342:	00a05e63          	blez	a0,35e <gets+0x52>
    buf[i++] = c;
 346:	faf44783          	lbu	a5,-81(s0)
 34a:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 34e:	01578763          	beq	a5,s5,35c <gets+0x50>
 352:	0905                	addi	s2,s2,1
 354:	fd679de3          	bne	a5,s6,32e <gets+0x22>
  for(i=0; i+1 < max; ){
 358:	89a6                	mv	s3,s1
 35a:	a011                	j	35e <gets+0x52>
 35c:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 35e:	99de                	add	s3,s3,s7
 360:	00098023          	sb	zero,0(s3)
  return buf;
}
 364:	855e                	mv	a0,s7
 366:	60e6                	ld	ra,88(sp)
 368:	6446                	ld	s0,80(sp)
 36a:	64a6                	ld	s1,72(sp)
 36c:	6906                	ld	s2,64(sp)
 36e:	79e2                	ld	s3,56(sp)
 370:	7a42                	ld	s4,48(sp)
 372:	7aa2                	ld	s5,40(sp)
 374:	7b02                	ld	s6,32(sp)
 376:	6be2                	ld	s7,24(sp)
 378:	6125                	addi	sp,sp,96
 37a:	8082                	ret

000000000000037c <stat>:

int
stat(const char *n, struct stat *st)
{
 37c:	1101                	addi	sp,sp,-32
 37e:	ec06                	sd	ra,24(sp)
 380:	e822                	sd	s0,16(sp)
 382:	e426                	sd	s1,8(sp)
 384:	e04a                	sd	s2,0(sp)
 386:	1000                	addi	s0,sp,32
 388:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 38a:	4581                	li	a1,0
 38c:	18c000ef          	jal	ra,518 <open>
  if(fd < 0)
 390:	02054163          	bltz	a0,3b2 <stat+0x36>
 394:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 396:	85ca                	mv	a1,s2
 398:	198000ef          	jal	ra,530 <fstat>
 39c:	892a                	mv	s2,a0
  close(fd);
 39e:	8526                	mv	a0,s1
 3a0:	160000ef          	jal	ra,500 <close>
  return r;
}
 3a4:	854a                	mv	a0,s2
 3a6:	60e2                	ld	ra,24(sp)
 3a8:	6442                	ld	s0,16(sp)
 3aa:	64a2                	ld	s1,8(sp)
 3ac:	6902                	ld	s2,0(sp)
 3ae:	6105                	addi	sp,sp,32
 3b0:	8082                	ret
    return -1;
 3b2:	597d                	li	s2,-1
 3b4:	bfc5                	j	3a4 <stat+0x28>

00000000000003b6 <atoi>:

int
atoi(const char *s)
{
 3b6:	1141                	addi	sp,sp,-16
 3b8:	e422                	sd	s0,8(sp)
 3ba:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3bc:	00054683          	lbu	a3,0(a0)
 3c0:	fd06879b          	addiw	a5,a3,-48
 3c4:	0ff7f793          	zext.b	a5,a5
 3c8:	4625                	li	a2,9
 3ca:	02f66863          	bltu	a2,a5,3fa <atoi+0x44>
 3ce:	872a                	mv	a4,a0
  n = 0;
 3d0:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 3d2:	0705                	addi	a4,a4,1
 3d4:	0025179b          	slliw	a5,a0,0x2
 3d8:	9fa9                	addw	a5,a5,a0
 3da:	0017979b          	slliw	a5,a5,0x1
 3de:	9fb5                	addw	a5,a5,a3
 3e0:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 3e4:	00074683          	lbu	a3,0(a4)
 3e8:	fd06879b          	addiw	a5,a3,-48
 3ec:	0ff7f793          	zext.b	a5,a5
 3f0:	fef671e3          	bgeu	a2,a5,3d2 <atoi+0x1c>
  return n;
}
 3f4:	6422                	ld	s0,8(sp)
 3f6:	0141                	addi	sp,sp,16
 3f8:	8082                	ret
  n = 0;
 3fa:	4501                	li	a0,0
 3fc:	bfe5                	j	3f4 <atoi+0x3e>

00000000000003fe <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3fe:	1141                	addi	sp,sp,-16
 400:	e422                	sd	s0,8(sp)
 402:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 404:	02b57463          	bgeu	a0,a1,42c <memmove+0x2e>
    while(n-- > 0)
 408:	00c05f63          	blez	a2,426 <memmove+0x28>
 40c:	1602                	slli	a2,a2,0x20
 40e:	9201                	srli	a2,a2,0x20
 410:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 414:	872a                	mv	a4,a0
      *dst++ = *src++;
 416:	0585                	addi	a1,a1,1
 418:	0705                	addi	a4,a4,1
 41a:	fff5c683          	lbu	a3,-1(a1)
 41e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 422:	fee79ae3          	bne	a5,a4,416 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 426:	6422                	ld	s0,8(sp)
 428:	0141                	addi	sp,sp,16
 42a:	8082                	ret
    dst += n;
 42c:	00c50733          	add	a4,a0,a2
    src += n;
 430:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 432:	fec05ae3          	blez	a2,426 <memmove+0x28>
 436:	fff6079b          	addiw	a5,a2,-1
 43a:	1782                	slli	a5,a5,0x20
 43c:	9381                	srli	a5,a5,0x20
 43e:	fff7c793          	not	a5,a5
 442:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 444:	15fd                	addi	a1,a1,-1
 446:	177d                	addi	a4,a4,-1
 448:	0005c683          	lbu	a3,0(a1)
 44c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 450:	fee79ae3          	bne	a5,a4,444 <memmove+0x46>
 454:	bfc9                	j	426 <memmove+0x28>

0000000000000456 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 456:	1141                	addi	sp,sp,-16
 458:	e422                	sd	s0,8(sp)
 45a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 45c:	ca05                	beqz	a2,48c <memcmp+0x36>
 45e:	fff6069b          	addiw	a3,a2,-1
 462:	1682                	slli	a3,a3,0x20
 464:	9281                	srli	a3,a3,0x20
 466:	0685                	addi	a3,a3,1
 468:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 46a:	00054783          	lbu	a5,0(a0)
 46e:	0005c703          	lbu	a4,0(a1)
 472:	00e79863          	bne	a5,a4,482 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 476:	0505                	addi	a0,a0,1
    p2++;
 478:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 47a:	fed518e3          	bne	a0,a3,46a <memcmp+0x14>
  }
  return 0;
 47e:	4501                	li	a0,0
 480:	a019                	j	486 <memcmp+0x30>
      return *p1 - *p2;
 482:	40e7853b          	subw	a0,a5,a4
}
 486:	6422                	ld	s0,8(sp)
 488:	0141                	addi	sp,sp,16
 48a:	8082                	ret
  return 0;
 48c:	4501                	li	a0,0
 48e:	bfe5                	j	486 <memcmp+0x30>

0000000000000490 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 490:	1141                	addi	sp,sp,-16
 492:	e406                	sd	ra,8(sp)
 494:	e022                	sd	s0,0(sp)
 496:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 498:	f67ff0ef          	jal	ra,3fe <memmove>
}
 49c:	60a2                	ld	ra,8(sp)
 49e:	6402                	ld	s0,0(sp)
 4a0:	0141                	addi	sp,sp,16
 4a2:	8082                	ret

00000000000004a4 <sbrk>:

char *
sbrk(int n) {
 4a4:	1141                	addi	sp,sp,-16
 4a6:	e406                	sd	ra,8(sp)
 4a8:	e022                	sd	s0,0(sp)
 4aa:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 4ac:	4585                	li	a1,1
 4ae:	0b2000ef          	jal	ra,560 <sys_sbrk>
}
 4b2:	60a2                	ld	ra,8(sp)
 4b4:	6402                	ld	s0,0(sp)
 4b6:	0141                	addi	sp,sp,16
 4b8:	8082                	ret

00000000000004ba <sbrklazy>:

char *
sbrklazy(int n) {
 4ba:	1141                	addi	sp,sp,-16
 4bc:	e406                	sd	ra,8(sp)
 4be:	e022                	sd	s0,0(sp)
 4c0:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 4c2:	4589                	li	a1,2
 4c4:	09c000ef          	jal	ra,560 <sys_sbrk>
}
 4c8:	60a2                	ld	ra,8(sp)
 4ca:	6402                	ld	s0,0(sp)
 4cc:	0141                	addi	sp,sp,16
 4ce:	8082                	ret

00000000000004d0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4d0:	4885                	li	a7,1
 ecall
 4d2:	00000073          	ecall
 ret
 4d6:	8082                	ret

00000000000004d8 <exit>:
.global exit
exit:
 li a7, SYS_exit
 4d8:	4889                	li	a7,2
 ecall
 4da:	00000073          	ecall
 ret
 4de:	8082                	ret

00000000000004e0 <wait>:
.global wait
wait:
 li a7, SYS_wait
 4e0:	488d                	li	a7,3
 ecall
 4e2:	00000073          	ecall
 ret
 4e6:	8082                	ret

00000000000004e8 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4e8:	4891                	li	a7,4
 ecall
 4ea:	00000073          	ecall
 ret
 4ee:	8082                	ret

00000000000004f0 <read>:
.global read
read:
 li a7, SYS_read
 4f0:	4895                	li	a7,5
 ecall
 4f2:	00000073          	ecall
 ret
 4f6:	8082                	ret

00000000000004f8 <write>:
.global write
write:
 li a7, SYS_write
 4f8:	48c1                	li	a7,16
 ecall
 4fa:	00000073          	ecall
 ret
 4fe:	8082                	ret

0000000000000500 <close>:
.global close
close:
 li a7, SYS_close
 500:	48d5                	li	a7,21
 ecall
 502:	00000073          	ecall
 ret
 506:	8082                	ret

0000000000000508 <kill>:
.global kill
kill:
 li a7, SYS_kill
 508:	4899                	li	a7,6
 ecall
 50a:	00000073          	ecall
 ret
 50e:	8082                	ret

0000000000000510 <exec>:
.global exec
exec:
 li a7, SYS_exec
 510:	489d                	li	a7,7
 ecall
 512:	00000073          	ecall
 ret
 516:	8082                	ret

0000000000000518 <open>:
.global open
open:
 li a7, SYS_open
 518:	48bd                	li	a7,15
 ecall
 51a:	00000073          	ecall
 ret
 51e:	8082                	ret

0000000000000520 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 520:	48c5                	li	a7,17
 ecall
 522:	00000073          	ecall
 ret
 526:	8082                	ret

0000000000000528 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 528:	48c9                	li	a7,18
 ecall
 52a:	00000073          	ecall
 ret
 52e:	8082                	ret

0000000000000530 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 530:	48a1                	li	a7,8
 ecall
 532:	00000073          	ecall
 ret
 536:	8082                	ret

0000000000000538 <link>:
.global link
link:
 li a7, SYS_link
 538:	48cd                	li	a7,19
 ecall
 53a:	00000073          	ecall
 ret
 53e:	8082                	ret

0000000000000540 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 540:	48d1                	li	a7,20
 ecall
 542:	00000073          	ecall
 ret
 546:	8082                	ret

0000000000000548 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 548:	48a5                	li	a7,9
 ecall
 54a:	00000073          	ecall
 ret
 54e:	8082                	ret

0000000000000550 <dup>:
.global dup
dup:
 li a7, SYS_dup
 550:	48a9                	li	a7,10
 ecall
 552:	00000073          	ecall
 ret
 556:	8082                	ret

0000000000000558 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 558:	48ad                	li	a7,11
 ecall
 55a:	00000073          	ecall
 ret
 55e:	8082                	ret

0000000000000560 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 560:	48b1                	li	a7,12
 ecall
 562:	00000073          	ecall
 ret
 566:	8082                	ret

0000000000000568 <pause>:
.global pause
pause:
 li a7, SYS_pause
 568:	48b5                	li	a7,13
 ecall
 56a:	00000073          	ecall
 ret
 56e:	8082                	ret

0000000000000570 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 570:	48b9                	li	a7,14
 ecall
 572:	00000073          	ecall
 ret
 576:	8082                	ret

0000000000000578 <getprocinfo>:
.global getprocinfo
getprocinfo:
 li a7, SYS_getprocinfo
 578:	48d9                	li	a7,22
 ecall
 57a:	00000073          	ecall
 ret
 57e:	8082                	ret

0000000000000580 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 580:	1101                	addi	sp,sp,-32
 582:	ec06                	sd	ra,24(sp)
 584:	e822                	sd	s0,16(sp)
 586:	1000                	addi	s0,sp,32
 588:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 58c:	4605                	li	a2,1
 58e:	fef40593          	addi	a1,s0,-17
 592:	f67ff0ef          	jal	ra,4f8 <write>
}
 596:	60e2                	ld	ra,24(sp)
 598:	6442                	ld	s0,16(sp)
 59a:	6105                	addi	sp,sp,32
 59c:	8082                	ret

000000000000059e <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 59e:	715d                	addi	sp,sp,-80
 5a0:	e486                	sd	ra,72(sp)
 5a2:	e0a2                	sd	s0,64(sp)
 5a4:	fc26                	sd	s1,56(sp)
 5a6:	f84a                	sd	s2,48(sp)
 5a8:	f44e                	sd	s3,40(sp)
 5aa:	0880                	addi	s0,sp,80
 5ac:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 5ae:	c299                	beqz	a3,5b4 <printint+0x16>
 5b0:	0805c163          	bltz	a1,632 <printint+0x94>
  neg = 0;
 5b4:	4881                	li	a7,0
 5b6:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 5ba:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 5bc:	00001517          	auipc	a0,0x1
 5c0:	86450513          	addi	a0,a0,-1948 # e20 <digits>
 5c4:	883e                	mv	a6,a5
 5c6:	2785                	addiw	a5,a5,1
 5c8:	02c5f733          	remu	a4,a1,a2
 5cc:	972a                	add	a4,a4,a0
 5ce:	00074703          	lbu	a4,0(a4)
 5d2:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 5d6:	872e                	mv	a4,a1
 5d8:	02c5d5b3          	divu	a1,a1,a2
 5dc:	0685                	addi	a3,a3,1
 5de:	fec773e3          	bgeu	a4,a2,5c4 <printint+0x26>
  if(neg)
 5e2:	00088b63          	beqz	a7,5f8 <printint+0x5a>
    buf[i++] = '-';
 5e6:	fd078793          	addi	a5,a5,-48
 5ea:	97a2                	add	a5,a5,s0
 5ec:	02d00713          	li	a4,45
 5f0:	fee78423          	sb	a4,-24(a5)
 5f4:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 5f8:	02f05663          	blez	a5,624 <printint+0x86>
 5fc:	fb840713          	addi	a4,s0,-72
 600:	00f704b3          	add	s1,a4,a5
 604:	fff70993          	addi	s3,a4,-1
 608:	99be                	add	s3,s3,a5
 60a:	37fd                	addiw	a5,a5,-1
 60c:	1782                	slli	a5,a5,0x20
 60e:	9381                	srli	a5,a5,0x20
 610:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 614:	fff4c583          	lbu	a1,-1(s1)
 618:	854a                	mv	a0,s2
 61a:	f67ff0ef          	jal	ra,580 <putc>
  while(--i >= 0)
 61e:	14fd                	addi	s1,s1,-1
 620:	ff349ae3          	bne	s1,s3,614 <printint+0x76>
}
 624:	60a6                	ld	ra,72(sp)
 626:	6406                	ld	s0,64(sp)
 628:	74e2                	ld	s1,56(sp)
 62a:	7942                	ld	s2,48(sp)
 62c:	79a2                	ld	s3,40(sp)
 62e:	6161                	addi	sp,sp,80
 630:	8082                	ret
    x = -xx;
 632:	40b005b3          	neg	a1,a1
    neg = 1;
 636:	4885                	li	a7,1
    x = -xx;
 638:	bfbd                	j	5b6 <printint+0x18>

000000000000063a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 63a:	7119                	addi	sp,sp,-128
 63c:	fc86                	sd	ra,120(sp)
 63e:	f8a2                	sd	s0,112(sp)
 640:	f4a6                	sd	s1,104(sp)
 642:	f0ca                	sd	s2,96(sp)
 644:	ecce                	sd	s3,88(sp)
 646:	e8d2                	sd	s4,80(sp)
 648:	e4d6                	sd	s5,72(sp)
 64a:	e0da                	sd	s6,64(sp)
 64c:	fc5e                	sd	s7,56(sp)
 64e:	f862                	sd	s8,48(sp)
 650:	f466                	sd	s9,40(sp)
 652:	f06a                	sd	s10,32(sp)
 654:	ec6e                	sd	s11,24(sp)
 656:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 658:	0005c903          	lbu	s2,0(a1)
 65c:	24090c63          	beqz	s2,8b4 <vprintf+0x27a>
 660:	8b2a                	mv	s6,a0
 662:	8a2e                	mv	s4,a1
 664:	8bb2                	mv	s7,a2
  state = 0;
 666:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 668:	4481                	li	s1,0
 66a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 66c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 670:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 674:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 678:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 67c:	00000c97          	auipc	s9,0x0
 680:	7a4c8c93          	addi	s9,s9,1956 # e20 <digits>
 684:	a005                	j	6a4 <vprintf+0x6a>
        putc(fd, c0);
 686:	85ca                	mv	a1,s2
 688:	855a                	mv	a0,s6
 68a:	ef7ff0ef          	jal	ra,580 <putc>
 68e:	a019                	j	694 <vprintf+0x5a>
    } else if(state == '%'){
 690:	03598263          	beq	s3,s5,6b4 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 694:	2485                	addiw	s1,s1,1
 696:	8726                	mv	a4,s1
 698:	009a07b3          	add	a5,s4,s1
 69c:	0007c903          	lbu	s2,0(a5)
 6a0:	20090a63          	beqz	s2,8b4 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 6a4:	0009079b          	sext.w	a5,s2
    if(state == 0){
 6a8:	fe0994e3          	bnez	s3,690 <vprintf+0x56>
      if(c0 == '%'){
 6ac:	fd579de3          	bne	a5,s5,686 <vprintf+0x4c>
        state = '%';
 6b0:	89be                	mv	s3,a5
 6b2:	b7cd                	j	694 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 6b4:	c3c1                	beqz	a5,734 <vprintf+0xfa>
 6b6:	00ea06b3          	add	a3,s4,a4
 6ba:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 6be:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 6c0:	c681                	beqz	a3,6c8 <vprintf+0x8e>
 6c2:	9752                	add	a4,a4,s4
 6c4:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 6c8:	03878e63          	beq	a5,s8,704 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 6cc:	05a78863          	beq	a5,s10,71c <vprintf+0xe2>
      } else if(c0 == 'u'){
 6d0:	0db78b63          	beq	a5,s11,7a6 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 6d4:	07800713          	li	a4,120
 6d8:	10e78d63          	beq	a5,a4,7f2 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 6dc:	07000713          	li	a4,112
 6e0:	14e78263          	beq	a5,a4,824 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 6e4:	06300713          	li	a4,99
 6e8:	16e78f63          	beq	a5,a4,866 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 6ec:	07300713          	li	a4,115
 6f0:	18e78563          	beq	a5,a4,87a <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 6f4:	05579063          	bne	a5,s5,734 <vprintf+0xfa>
        putc(fd, '%');
 6f8:	85d6                	mv	a1,s5
 6fa:	855a                	mv	a0,s6
 6fc:	e85ff0ef          	jal	ra,580 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 700:	4981                	li	s3,0
 702:	bf49                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 704:	008b8913          	addi	s2,s7,8
 708:	4685                	li	a3,1
 70a:	4629                	li	a2,10
 70c:	000ba583          	lw	a1,0(s7)
 710:	855a                	mv	a0,s6
 712:	e8dff0ef          	jal	ra,59e <printint>
 716:	8bca                	mv	s7,s2
      state = 0;
 718:	4981                	li	s3,0
 71a:	bfad                	j	694 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 71c:	03868663          	beq	a3,s8,748 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 720:	05a68163          	beq	a3,s10,762 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 724:	09b68d63          	beq	a3,s11,7be <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 728:	03a68f63          	beq	a3,s10,766 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 72c:	07800793          	li	a5,120
 730:	0cf68d63          	beq	a3,a5,80a <vprintf+0x1d0>
        putc(fd, '%');
 734:	85d6                	mv	a1,s5
 736:	855a                	mv	a0,s6
 738:	e49ff0ef          	jal	ra,580 <putc>
        putc(fd, c0);
 73c:	85ca                	mv	a1,s2
 73e:	855a                	mv	a0,s6
 740:	e41ff0ef          	jal	ra,580 <putc>
      state = 0;
 744:	4981                	li	s3,0
 746:	b7b9                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 748:	008b8913          	addi	s2,s7,8
 74c:	4685                	li	a3,1
 74e:	4629                	li	a2,10
 750:	000bb583          	ld	a1,0(s7)
 754:	855a                	mv	a0,s6
 756:	e49ff0ef          	jal	ra,59e <printint>
        i += 1;
 75a:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 75c:	8bca                	mv	s7,s2
      state = 0;
 75e:	4981                	li	s3,0
        i += 1;
 760:	bf15                	j	694 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 762:	03860563          	beq	a2,s8,78c <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 766:	07b60963          	beq	a2,s11,7d8 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 76a:	07800793          	li	a5,120
 76e:	fcf613e3          	bne	a2,a5,734 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 772:	008b8913          	addi	s2,s7,8
 776:	4681                	li	a3,0
 778:	4641                	li	a2,16
 77a:	000bb583          	ld	a1,0(s7)
 77e:	855a                	mv	a0,s6
 780:	e1fff0ef          	jal	ra,59e <printint>
        i += 2;
 784:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 786:	8bca                	mv	s7,s2
      state = 0;
 788:	4981                	li	s3,0
        i += 2;
 78a:	b729                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 78c:	008b8913          	addi	s2,s7,8
 790:	4685                	li	a3,1
 792:	4629                	li	a2,10
 794:	000bb583          	ld	a1,0(s7)
 798:	855a                	mv	a0,s6
 79a:	e05ff0ef          	jal	ra,59e <printint>
        i += 2;
 79e:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 7a0:	8bca                	mv	s7,s2
      state = 0;
 7a2:	4981                	li	s3,0
        i += 2;
 7a4:	bdc5                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 7a6:	008b8913          	addi	s2,s7,8
 7aa:	4681                	li	a3,0
 7ac:	4629                	li	a2,10
 7ae:	000be583          	lwu	a1,0(s7)
 7b2:	855a                	mv	a0,s6
 7b4:	debff0ef          	jal	ra,59e <printint>
 7b8:	8bca                	mv	s7,s2
      state = 0;
 7ba:	4981                	li	s3,0
 7bc:	bde1                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7be:	008b8913          	addi	s2,s7,8
 7c2:	4681                	li	a3,0
 7c4:	4629                	li	a2,10
 7c6:	000bb583          	ld	a1,0(s7)
 7ca:	855a                	mv	a0,s6
 7cc:	dd3ff0ef          	jal	ra,59e <printint>
        i += 1;
 7d0:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7d2:	8bca                	mv	s7,s2
      state = 0;
 7d4:	4981                	li	s3,0
        i += 1;
 7d6:	bd7d                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7d8:	008b8913          	addi	s2,s7,8
 7dc:	4681                	li	a3,0
 7de:	4629                	li	a2,10
 7e0:	000bb583          	ld	a1,0(s7)
 7e4:	855a                	mv	a0,s6
 7e6:	db9ff0ef          	jal	ra,59e <printint>
        i += 2;
 7ea:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ec:	8bca                	mv	s7,s2
      state = 0;
 7ee:	4981                	li	s3,0
        i += 2;
 7f0:	b555                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 7f2:	008b8913          	addi	s2,s7,8
 7f6:	4681                	li	a3,0
 7f8:	4641                	li	a2,16
 7fa:	000be583          	lwu	a1,0(s7)
 7fe:	855a                	mv	a0,s6
 800:	d9fff0ef          	jal	ra,59e <printint>
 804:	8bca                	mv	s7,s2
      state = 0;
 806:	4981                	li	s3,0
 808:	b571                	j	694 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 80a:	008b8913          	addi	s2,s7,8
 80e:	4681                	li	a3,0
 810:	4641                	li	a2,16
 812:	000bb583          	ld	a1,0(s7)
 816:	855a                	mv	a0,s6
 818:	d87ff0ef          	jal	ra,59e <printint>
        i += 1;
 81c:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 81e:	8bca                	mv	s7,s2
      state = 0;
 820:	4981                	li	s3,0
        i += 1;
 822:	bd8d                	j	694 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 824:	008b8793          	addi	a5,s7,8
 828:	f8f43423          	sd	a5,-120(s0)
 82c:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 830:	03000593          	li	a1,48
 834:	855a                	mv	a0,s6
 836:	d4bff0ef          	jal	ra,580 <putc>
  putc(fd, 'x');
 83a:	07800593          	li	a1,120
 83e:	855a                	mv	a0,s6
 840:	d41ff0ef          	jal	ra,580 <putc>
 844:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 846:	03c9d793          	srli	a5,s3,0x3c
 84a:	97e6                	add	a5,a5,s9
 84c:	0007c583          	lbu	a1,0(a5)
 850:	855a                	mv	a0,s6
 852:	d2fff0ef          	jal	ra,580 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 856:	0992                	slli	s3,s3,0x4
 858:	397d                	addiw	s2,s2,-1
 85a:	fe0916e3          	bnez	s2,846 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 85e:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 862:	4981                	li	s3,0
 864:	bd05                	j	694 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 866:	008b8913          	addi	s2,s7,8
 86a:	000bc583          	lbu	a1,0(s7)
 86e:	855a                	mv	a0,s6
 870:	d11ff0ef          	jal	ra,580 <putc>
 874:	8bca                	mv	s7,s2
      state = 0;
 876:	4981                	li	s3,0
 878:	bd31                	j	694 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 87a:	008b8993          	addi	s3,s7,8
 87e:	000bb903          	ld	s2,0(s7)
 882:	00090f63          	beqz	s2,8a0 <vprintf+0x266>
        for(; *s; s++)
 886:	00094583          	lbu	a1,0(s2)
 88a:	c195                	beqz	a1,8ae <vprintf+0x274>
          putc(fd, *s);
 88c:	855a                	mv	a0,s6
 88e:	cf3ff0ef          	jal	ra,580 <putc>
        for(; *s; s++)
 892:	0905                	addi	s2,s2,1
 894:	00094583          	lbu	a1,0(s2)
 898:	f9f5                	bnez	a1,88c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 89a:	8bce                	mv	s7,s3
      state = 0;
 89c:	4981                	li	s3,0
 89e:	bbdd                	j	694 <vprintf+0x5a>
          s = "(null)";
 8a0:	00000917          	auipc	s2,0x0
 8a4:	57890913          	addi	s2,s2,1400 # e18 <malloc+0x468>
        for(; *s; s++)
 8a8:	02800593          	li	a1,40
 8ac:	b7c5                	j	88c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8ae:	8bce                	mv	s7,s3
      state = 0;
 8b0:	4981                	li	s3,0
 8b2:	b3cd                	j	694 <vprintf+0x5a>
    }
  }
}
 8b4:	70e6                	ld	ra,120(sp)
 8b6:	7446                	ld	s0,112(sp)
 8b8:	74a6                	ld	s1,104(sp)
 8ba:	7906                	ld	s2,96(sp)
 8bc:	69e6                	ld	s3,88(sp)
 8be:	6a46                	ld	s4,80(sp)
 8c0:	6aa6                	ld	s5,72(sp)
 8c2:	6b06                	ld	s6,64(sp)
 8c4:	7be2                	ld	s7,56(sp)
 8c6:	7c42                	ld	s8,48(sp)
 8c8:	7ca2                	ld	s9,40(sp)
 8ca:	7d02                	ld	s10,32(sp)
 8cc:	6de2                	ld	s11,24(sp)
 8ce:	6109                	addi	sp,sp,128
 8d0:	8082                	ret

00000000000008d2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 8d2:	715d                	addi	sp,sp,-80
 8d4:	ec06                	sd	ra,24(sp)
 8d6:	e822                	sd	s0,16(sp)
 8d8:	1000                	addi	s0,sp,32
 8da:	e010                	sd	a2,0(s0)
 8dc:	e414                	sd	a3,8(s0)
 8de:	e818                	sd	a4,16(s0)
 8e0:	ec1c                	sd	a5,24(s0)
 8e2:	03043023          	sd	a6,32(s0)
 8e6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 8ea:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 8ee:	8622                	mv	a2,s0
 8f0:	d4bff0ef          	jal	ra,63a <vprintf>
}
 8f4:	60e2                	ld	ra,24(sp)
 8f6:	6442                	ld	s0,16(sp)
 8f8:	6161                	addi	sp,sp,80
 8fa:	8082                	ret

00000000000008fc <printf>:

void
printf(const char *fmt, ...)
{
 8fc:	711d                	addi	sp,sp,-96
 8fe:	ec06                	sd	ra,24(sp)
 900:	e822                	sd	s0,16(sp)
 902:	1000                	addi	s0,sp,32
 904:	e40c                	sd	a1,8(s0)
 906:	e810                	sd	a2,16(s0)
 908:	ec14                	sd	a3,24(s0)
 90a:	f018                	sd	a4,32(s0)
 90c:	f41c                	sd	a5,40(s0)
 90e:	03043823          	sd	a6,48(s0)
 912:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 916:	00840613          	addi	a2,s0,8
 91a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 91e:	85aa                	mv	a1,a0
 920:	4505                	li	a0,1
 922:	d19ff0ef          	jal	ra,63a <vprintf>
}
 926:	60e2                	ld	ra,24(sp)
 928:	6442                	ld	s0,16(sp)
 92a:	6125                	addi	sp,sp,96
 92c:	8082                	ret

000000000000092e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 92e:	1141                	addi	sp,sp,-16
 930:	e422                	sd	s0,8(sp)
 932:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 934:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 938:	00000797          	auipc	a5,0x0
 93c:	6c87b783          	ld	a5,1736(a5) # 1000 <freep>
 940:	a02d                	j	96a <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 942:	4618                	lw	a4,8(a2)
 944:	9f2d                	addw	a4,a4,a1
 946:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 94a:	6398                	ld	a4,0(a5)
 94c:	6310                	ld	a2,0(a4)
 94e:	a83d                	j	98c <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 950:	ff852703          	lw	a4,-8(a0)
 954:	9f31                	addw	a4,a4,a2
 956:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 958:	ff053683          	ld	a3,-16(a0)
 95c:	a091                	j	9a0 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 95e:	6398                	ld	a4,0(a5)
 960:	00e7e463          	bltu	a5,a4,968 <free+0x3a>
 964:	00e6ea63          	bltu	a3,a4,978 <free+0x4a>
{
 968:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 96a:	fed7fae3          	bgeu	a5,a3,95e <free+0x30>
 96e:	6398                	ld	a4,0(a5)
 970:	00e6e463          	bltu	a3,a4,978 <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 974:	fee7eae3          	bltu	a5,a4,968 <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 978:	ff852583          	lw	a1,-8(a0)
 97c:	6390                	ld	a2,0(a5)
 97e:	02059813          	slli	a6,a1,0x20
 982:	01c85713          	srli	a4,a6,0x1c
 986:	9736                	add	a4,a4,a3
 988:	fae60de3          	beq	a2,a4,942 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 98c:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 990:	4790                	lw	a2,8(a5)
 992:	02061593          	slli	a1,a2,0x20
 996:	01c5d713          	srli	a4,a1,0x1c
 99a:	973e                	add	a4,a4,a5
 99c:	fae68ae3          	beq	a3,a4,950 <free+0x22>
    p->s.ptr = bp->s.ptr;
 9a0:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 9a2:	00000717          	auipc	a4,0x0
 9a6:	64f73f23          	sd	a5,1630(a4) # 1000 <freep>
}
 9aa:	6422                	ld	s0,8(sp)
 9ac:	0141                	addi	sp,sp,16
 9ae:	8082                	ret

00000000000009b0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 9b0:	7139                	addi	sp,sp,-64
 9b2:	fc06                	sd	ra,56(sp)
 9b4:	f822                	sd	s0,48(sp)
 9b6:	f426                	sd	s1,40(sp)
 9b8:	f04a                	sd	s2,32(sp)
 9ba:	ec4e                	sd	s3,24(sp)
 9bc:	e852                	sd	s4,16(sp)
 9be:	e456                	sd	s5,8(sp)
 9c0:	e05a                	sd	s6,0(sp)
 9c2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 9c4:	02051493          	slli	s1,a0,0x20
 9c8:	9081                	srli	s1,s1,0x20
 9ca:	04bd                	addi	s1,s1,15
 9cc:	8091                	srli	s1,s1,0x4
 9ce:	0014899b          	addiw	s3,s1,1
 9d2:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 9d4:	00000517          	auipc	a0,0x0
 9d8:	62c53503          	ld	a0,1580(a0) # 1000 <freep>
 9dc:	c515                	beqz	a0,a08 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9de:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9e0:	4798                	lw	a4,8(a5)
 9e2:	02977f63          	bgeu	a4,s1,a20 <malloc+0x70>
 9e6:	8a4e                	mv	s4,s3
 9e8:	0009871b          	sext.w	a4,s3
 9ec:	6685                	lui	a3,0x1
 9ee:	00d77363          	bgeu	a4,a3,9f4 <malloc+0x44>
 9f2:	6a05                	lui	s4,0x1
 9f4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9f8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 9fc:	00000917          	auipc	s2,0x0
 a00:	60490913          	addi	s2,s2,1540 # 1000 <freep>
  if(p == SBRK_ERROR)
 a04:	5afd                	li	s5,-1
 a06:	a885                	j	a76 <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 a08:	00000797          	auipc	a5,0x0
 a0c:	60878793          	addi	a5,a5,1544 # 1010 <base>
 a10:	00000717          	auipc	a4,0x0
 a14:	5ef73823          	sd	a5,1520(a4) # 1000 <freep>
 a18:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a1a:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a1e:	b7e1                	j	9e6 <malloc+0x36>
      if(p->s.size == nunits)
 a20:	02e48c63          	beq	s1,a4,a58 <malloc+0xa8>
        p->s.size -= nunits;
 a24:	4137073b          	subw	a4,a4,s3
 a28:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a2a:	02071693          	slli	a3,a4,0x20
 a2e:	01c6d713          	srli	a4,a3,0x1c
 a32:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a34:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a38:	00000717          	auipc	a4,0x0
 a3c:	5ca73423          	sd	a0,1480(a4) # 1000 <freep>
      return (void*)(p + 1);
 a40:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 a44:	70e2                	ld	ra,56(sp)
 a46:	7442                	ld	s0,48(sp)
 a48:	74a2                	ld	s1,40(sp)
 a4a:	7902                	ld	s2,32(sp)
 a4c:	69e2                	ld	s3,24(sp)
 a4e:	6a42                	ld	s4,16(sp)
 a50:	6aa2                	ld	s5,8(sp)
 a52:	6b02                	ld	s6,0(sp)
 a54:	6121                	addi	sp,sp,64
 a56:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 a58:	6398                	ld	a4,0(a5)
 a5a:	e118                	sd	a4,0(a0)
 a5c:	bff1                	j	a38 <malloc+0x88>
  hp->s.size = nu;
 a5e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a62:	0541                	addi	a0,a0,16
 a64:	ecbff0ef          	jal	ra,92e <free>
  return freep;
 a68:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 a6c:	dd61                	beqz	a0,a44 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a6e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a70:	4798                	lw	a4,8(a5)
 a72:	fa9777e3          	bgeu	a4,s1,a20 <malloc+0x70>
    if(p == freep)
 a76:	00093703          	ld	a4,0(s2)
 a7a:	853e                	mv	a0,a5
 a7c:	fef719e3          	bne	a4,a5,a6e <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 a80:	8552                	mv	a0,s4
 a82:	a23ff0ef          	jal	ra,4a4 <sbrk>
  if(p == SBRK_ERROR)
 a86:	fd551ce3          	bne	a0,s5,a5e <malloc+0xae>
        return 0;
 a8a:	4501                	li	a0,0
 a8c:	bf65                	j	a44 <malloc+0x94>
