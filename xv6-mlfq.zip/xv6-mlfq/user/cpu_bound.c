#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// CPU-intensive workload simulation


void cpu_intensive_work(long limit) {
    long count = 0;

    for (long num = 2; num <= limit; num++) {
        int is_prime = 1;
        for (long i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                is_prime = 0;
                break;
            }
        }

        if (is_prime)
            count++;
    }

    printf("Number of primes up to %ld = %ld\n", limit, count);
}



int main(int argc, char *argv[]) {
    struct procinfo info;
    int pid = getpid();
    
    printf("=====================================\n");
    printf("     CPU-BOUND PROCESS TEST\n");
    printf("     Scheduler: MLFQ\n");
    printf("=====================================\n\n");
    
    getprocinfo(pid, &info);
    printf("Initial State:\n");
    printf("  PID: %d\n", info.pid);
    printf("  Priority: %d (MLFQ starts HIGH)\n", info.priority);
    printf("  Start Time: %lu ticks\n\n", info.start_time);

    // PHASE 1 - First CPU burst (expected demotion to MEDIUM)
    printf("PHASE 1 - Heavy CPU burst...\n");
    cpu_intensive_work(700000);  // Increased iterations
    getprocinfo(pid, &info);
    printf("  After Phase 1: Priority=%d, CPU=%d, Wait=%lu, Sched=%d\n\n",
           info.priority, info.cpu_ticks, info.total_wait, info.sched_count);

    // PHASE 2 - Second CPU burst (expected demotion to LOW)
    printf("PHASE 2 - Continued CPU burst...\n");
    cpu_intensive_work(1200000);
    getprocinfo(pid, &info);
    printf("  After Phase 2: Priority=%d, CPU=%d, Wait=%lu, Sched=%d\n\n",
           info.priority, info.cpu_ticks, info.total_wait, info.sched_count);

    // PHASE 3 - Final CPU burst (should stay LOW)
    printf("PHASE 3 - Final CPU burst...\n");
    cpu_intensive_work(1600000);
    getprocinfo(pid, &info);

    printf("=====================================\n");
    printf("FINAL RESULTS (MLFQ):\n");
    printf("  Priority: %d (0=HIGH, 1=MED, 2=LOW)\n", info.priority);
    printf("  Turnaround Time: %lu ticks\n", info.end_time - info.start_time);
    printf("  Response Time: %lu ticks\n", info.first_run - info.start_time);
    printf("  Wait Time: %lu ticks\n", info.total_wait);
    printf("  CPU Ticks: %d\n", info.cpu_ticks);
    printf("  Schedule Count: %d\n", info.sched_count);
    printf("  Timeslice Used: %d/%d\n", info.timeslice_used,
           info.priority == 0 ? 4 : (info.priority == 1 ? 8 : 16));
    printf("\nNOTE: CPU-bound processes drop to lower priority levels in MLFQ.\n");
    printf("      Compare this with RR where priority remains fixed.\n");
    printf("=====================================\n");

    exit(0);
}

