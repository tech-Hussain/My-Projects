user/benchcmp.o: user/benchcmp.c kernel/types.h kernel/stat.h user/user.h
