
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	98813103          	ld	sp,-1656(sp) # 80007988 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04a000ef          	jal	ra,80000060 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	0x14d,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdcb17>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	d6078793          	addi	a5,a5,-672 # 80000de0 <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a2:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	ra,8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	7159                	addi	sp,sp,-112
    800000d2:	f486                	sd	ra,104(sp)
    800000d4:	f0a2                	sd	s0,96(sp)
    800000d6:	eca6                	sd	s1,88(sp)
    800000d8:	e8ca                	sd	s2,80(sp)
    800000da:	e4ce                	sd	s3,72(sp)
    800000dc:	e0d2                	sd	s4,64(sp)
    800000de:	fc56                	sd	s5,56(sp)
    800000e0:	f85a                	sd	s6,48(sp)
    800000e2:	f45e                	sd	s7,40(sp)
    800000e4:	f062                	sd	s8,32(sp)
    800000e6:	1880                	addi	s0,sp,112
  char buf[32];
  int i = 0;

  while(i < n){
    800000e8:	04c05463          	blez	a2,80000130 <consolewrite+0x60>
    800000ec:	8a2a                	mv	s4,a0
    800000ee:	8aae                	mv	s5,a1
    800000f0:	89b2                	mv	s3,a2
  int i = 0;
    800000f2:	4901                	li	s2,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000f4:	4bfd                	li	s7,31
    int nn = sizeof(buf);
    800000f6:	02000c13          	li	s8,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    800000fa:	5b7d                	li	s6,-1
    800000fc:	a025                	j	80000124 <consolewrite+0x54>
    800000fe:	86a6                	mv	a3,s1
    80000100:	01590633          	add	a2,s2,s5
    80000104:	85d2                	mv	a1,s4
    80000106:	f9040513          	addi	a0,s0,-112
    8000010a:	2c6020ef          	jal	ra,800023d0 <either_copyin>
    8000010e:	03650263          	beq	a0,s6,80000132 <consolewrite+0x62>
      break;
    uartwrite(buf, nn);
    80000112:	85a6                	mv	a1,s1
    80000114:	f9040513          	addi	a0,s0,-112
    80000118:	71c000ef          	jal	ra,80000834 <uartwrite>
    i += nn;
    8000011c:	0124893b          	addw	s2,s1,s2
  while(i < n){
    80000120:	01395963          	bge	s2,s3,80000132 <consolewrite+0x62>
    if(nn > n - i)
    80000124:	412984bb          	subw	s1,s3,s2
    80000128:	fc9bdbe3          	bge	s7,s1,800000fe <consolewrite+0x2e>
    int nn = sizeof(buf);
    8000012c:	84e2                	mv	s1,s8
    8000012e:	bfc1                	j	800000fe <consolewrite+0x2e>
  int i = 0;
    80000130:	4901                	li	s2,0
  }

  return i;
}
    80000132:	854a                	mv	a0,s2
    80000134:	70a6                	ld	ra,104(sp)
    80000136:	7406                	ld	s0,96(sp)
    80000138:	64e6                	ld	s1,88(sp)
    8000013a:	6946                	ld	s2,80(sp)
    8000013c:	69a6                	ld	s3,72(sp)
    8000013e:	6a06                	ld	s4,64(sp)
    80000140:	7ae2                	ld	s5,56(sp)
    80000142:	7b42                	ld	s6,48(sp)
    80000144:	7ba2                	ld	s7,40(sp)
    80000146:	7c02                	ld	s8,32(sp)
    80000148:	6165                	addi	sp,sp,112
    8000014a:	8082                	ret

000000008000014c <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000014c:	7159                	addi	sp,sp,-112
    8000014e:	f486                	sd	ra,104(sp)
    80000150:	f0a2                	sd	s0,96(sp)
    80000152:	eca6                	sd	s1,88(sp)
    80000154:	e8ca                	sd	s2,80(sp)
    80000156:	e4ce                	sd	s3,72(sp)
    80000158:	e0d2                	sd	s4,64(sp)
    8000015a:	fc56                	sd	s5,56(sp)
    8000015c:	f85a                	sd	s6,48(sp)
    8000015e:	f45e                	sd	s7,40(sp)
    80000160:	f062                	sd	s8,32(sp)
    80000162:	ec66                	sd	s9,24(sp)
    80000164:	e86a                	sd	s10,16(sp)
    80000166:	1880                	addi	s0,sp,112
    80000168:	8aaa                	mv	s5,a0
    8000016a:	8a2e                	mv	s4,a1
    8000016c:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    8000016e:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80000172:	00010517          	auipc	a0,0x10
    80000176:	86e50513          	addi	a0,a0,-1938 # 8000f9e0 <cons>
    8000017a:	1f1000ef          	jal	ra,80000b6a <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000017e:	00010497          	auipc	s1,0x10
    80000182:	86248493          	addi	s1,s1,-1950 # 8000f9e0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000186:	00010917          	auipc	s2,0x10
    8000018a:	8f290913          	addi	s2,s2,-1806 # 8000fa78 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    8000018e:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000190:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    80000192:	4ca9                	li	s9,10
  while(n > 0){
    80000194:	07305363          	blez	s3,800001fa <consoleread+0xae>
    while(cons.r == cons.w){
    80000198:	0984a783          	lw	a5,152(s1)
    8000019c:	09c4a703          	lw	a4,156(s1)
    800001a0:	02f71163          	bne	a4,a5,800001c2 <consoleread+0x76>
      if(killed(myproc())){
    800001a4:	722010ef          	jal	ra,800018c6 <myproc>
    800001a8:	0ba020ef          	jal	ra,80002262 <killed>
    800001ac:	e125                	bnez	a0,8000020c <consoleread+0xc0>
      sleep(&cons.r, &cons.lock);
    800001ae:	85a6                	mv	a1,s1
    800001b0:	854a                	mv	a0,s2
    800001b2:	66d010ef          	jal	ra,8000201e <sleep>
    while(cons.r == cons.w){
    800001b6:	0984a783          	lw	a5,152(s1)
    800001ba:	09c4a703          	lw	a4,156(s1)
    800001be:	fef703e3          	beq	a4,a5,800001a4 <consoleread+0x58>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001c2:	0017871b          	addiw	a4,a5,1
    800001c6:	08e4ac23          	sw	a4,152(s1)
    800001ca:	07f7f713          	andi	a4,a5,127
    800001ce:	9726                	add	a4,a4,s1
    800001d0:	01874703          	lbu	a4,24(a4)
    800001d4:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    800001d8:	057d0f63          	beq	s10,s7,80000236 <consoleread+0xea>
    cbuf = c;
    800001dc:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001e0:	4685                	li	a3,1
    800001e2:	f9f40613          	addi	a2,s0,-97
    800001e6:	85d2                	mv	a1,s4
    800001e8:	8556                	mv	a0,s5
    800001ea:	19c020ef          	jal	ra,80002386 <either_copyout>
    800001ee:	01850663          	beq	a0,s8,800001fa <consoleread+0xae>
    dst++;
    800001f2:	0a05                	addi	s4,s4,1
    --n;
    800001f4:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    800001f6:	f99d1fe3          	bne	s10,s9,80000194 <consoleread+0x48>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    800001fa:	0000f517          	auipc	a0,0xf
    800001fe:	7e650513          	addi	a0,a0,2022 # 8000f9e0 <cons>
    80000202:	201000ef          	jal	ra,80000c02 <release>

  return target - n;
    80000206:	413b053b          	subw	a0,s6,s3
    8000020a:	a801                	j	8000021a <consoleread+0xce>
        release(&cons.lock);
    8000020c:	0000f517          	auipc	a0,0xf
    80000210:	7d450513          	addi	a0,a0,2004 # 8000f9e0 <cons>
    80000214:	1ef000ef          	jal	ra,80000c02 <release>
        return -1;
    80000218:	557d                	li	a0,-1
}
    8000021a:	70a6                	ld	ra,104(sp)
    8000021c:	7406                	ld	s0,96(sp)
    8000021e:	64e6                	ld	s1,88(sp)
    80000220:	6946                	ld	s2,80(sp)
    80000222:	69a6                	ld	s3,72(sp)
    80000224:	6a06                	ld	s4,64(sp)
    80000226:	7ae2                	ld	s5,56(sp)
    80000228:	7b42                	ld	s6,48(sp)
    8000022a:	7ba2                	ld	s7,40(sp)
    8000022c:	7c02                	ld	s8,32(sp)
    8000022e:	6ce2                	ld	s9,24(sp)
    80000230:	6d42                	ld	s10,16(sp)
    80000232:	6165                	addi	sp,sp,112
    80000234:	8082                	ret
      if(n < target){
    80000236:	0009871b          	sext.w	a4,s3
    8000023a:	fd6770e3          	bgeu	a4,s6,800001fa <consoleread+0xae>
        cons.r--;
    8000023e:	00010717          	auipc	a4,0x10
    80000242:	82f72d23          	sw	a5,-1990(a4) # 8000fa78 <cons+0x98>
    80000246:	bf55                	j	800001fa <consoleread+0xae>

0000000080000248 <consputc>:
{
    80000248:	1141                	addi	sp,sp,-16
    8000024a:	e406                	sd	ra,8(sp)
    8000024c:	e022                	sd	s0,0(sp)
    8000024e:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000250:	10000793          	li	a5,256
    80000254:	00f50863          	beq	a0,a5,80000264 <consputc+0x1c>
    uartputc_sync(c);
    80000258:	67c000ef          	jal	ra,800008d4 <uartputc_sync>
}
    8000025c:	60a2                	ld	ra,8(sp)
    8000025e:	6402                	ld	s0,0(sp)
    80000260:	0141                	addi	sp,sp,16
    80000262:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000264:	4521                	li	a0,8
    80000266:	66e000ef          	jal	ra,800008d4 <uartputc_sync>
    8000026a:	02000513          	li	a0,32
    8000026e:	666000ef          	jal	ra,800008d4 <uartputc_sync>
    80000272:	4521                	li	a0,8
    80000274:	660000ef          	jal	ra,800008d4 <uartputc_sync>
    80000278:	b7d5                	j	8000025c <consputc+0x14>

000000008000027a <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    8000027a:	1101                	addi	sp,sp,-32
    8000027c:	ec06                	sd	ra,24(sp)
    8000027e:	e822                	sd	s0,16(sp)
    80000280:	e426                	sd	s1,8(sp)
    80000282:	e04a                	sd	s2,0(sp)
    80000284:	1000                	addi	s0,sp,32
    80000286:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80000288:	0000f517          	auipc	a0,0xf
    8000028c:	75850513          	addi	a0,a0,1880 # 8000f9e0 <cons>
    80000290:	0db000ef          	jal	ra,80000b6a <acquire>

  switch(c){
    80000294:	47d5                	li	a5,21
    80000296:	0af48063          	beq	s1,a5,80000336 <consoleintr+0xbc>
    8000029a:	0297c663          	blt	a5,s1,800002c6 <consoleintr+0x4c>
    8000029e:	47a1                	li	a5,8
    800002a0:	0cf48f63          	beq	s1,a5,8000037e <consoleintr+0x104>
    800002a4:	47c1                	li	a5,16
    800002a6:	10f49063          	bne	s1,a5,800003a6 <consoleintr+0x12c>
  case C('P'):  // Print process list.
    procdump();
    800002aa:	170020ef          	jal	ra,8000241a <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002ae:	0000f517          	auipc	a0,0xf
    800002b2:	73250513          	addi	a0,a0,1842 # 8000f9e0 <cons>
    800002b6:	14d000ef          	jal	ra,80000c02 <release>
}
    800002ba:	60e2                	ld	ra,24(sp)
    800002bc:	6442                	ld	s0,16(sp)
    800002be:	64a2                	ld	s1,8(sp)
    800002c0:	6902                	ld	s2,0(sp)
    800002c2:	6105                	addi	sp,sp,32
    800002c4:	8082                	ret
  switch(c){
    800002c6:	07f00793          	li	a5,127
    800002ca:	0af48a63          	beq	s1,a5,8000037e <consoleintr+0x104>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002ce:	0000f717          	auipc	a4,0xf
    800002d2:	71270713          	addi	a4,a4,1810 # 8000f9e0 <cons>
    800002d6:	0a072783          	lw	a5,160(a4)
    800002da:	09872703          	lw	a4,152(a4)
    800002de:	9f99                	subw	a5,a5,a4
    800002e0:	07f00713          	li	a4,127
    800002e4:	fcf765e3          	bltu	a4,a5,800002ae <consoleintr+0x34>
      c = (c == '\r') ? '\n' : c;
    800002e8:	47b5                	li	a5,13
    800002ea:	0cf48163          	beq	s1,a5,800003ac <consoleintr+0x132>
      consputc(c);
    800002ee:	8526                	mv	a0,s1
    800002f0:	f59ff0ef          	jal	ra,80000248 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002f4:	0000f797          	auipc	a5,0xf
    800002f8:	6ec78793          	addi	a5,a5,1772 # 8000f9e0 <cons>
    800002fc:	0a07a683          	lw	a3,160(a5)
    80000300:	0016871b          	addiw	a4,a3,1
    80000304:	0007061b          	sext.w	a2,a4
    80000308:	0ae7a023          	sw	a4,160(a5)
    8000030c:	07f6f693          	andi	a3,a3,127
    80000310:	97b6                	add	a5,a5,a3
    80000312:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000316:	47a9                	li	a5,10
    80000318:	0af48f63          	beq	s1,a5,800003d6 <consoleintr+0x15c>
    8000031c:	4791                	li	a5,4
    8000031e:	0af48c63          	beq	s1,a5,800003d6 <consoleintr+0x15c>
    80000322:	0000f797          	auipc	a5,0xf
    80000326:	7567a783          	lw	a5,1878(a5) # 8000fa78 <cons+0x98>
    8000032a:	9f1d                	subw	a4,a4,a5
    8000032c:	08000793          	li	a5,128
    80000330:	f6f71fe3          	bne	a4,a5,800002ae <consoleintr+0x34>
    80000334:	a04d                	j	800003d6 <consoleintr+0x15c>
    while(cons.e != cons.w &&
    80000336:	0000f717          	auipc	a4,0xf
    8000033a:	6aa70713          	addi	a4,a4,1706 # 8000f9e0 <cons>
    8000033e:	0a072783          	lw	a5,160(a4)
    80000342:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000346:	0000f497          	auipc	s1,0xf
    8000034a:	69a48493          	addi	s1,s1,1690 # 8000f9e0 <cons>
    while(cons.e != cons.w &&
    8000034e:	4929                	li	s2,10
    80000350:	f4f70fe3          	beq	a4,a5,800002ae <consoleintr+0x34>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000354:	37fd                	addiw	a5,a5,-1
    80000356:	07f7f713          	andi	a4,a5,127
    8000035a:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000035c:	01874703          	lbu	a4,24(a4)
    80000360:	f52707e3          	beq	a4,s2,800002ae <consoleintr+0x34>
      cons.e--;
    80000364:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000368:	10000513          	li	a0,256
    8000036c:	eddff0ef          	jal	ra,80000248 <consputc>
    while(cons.e != cons.w &&
    80000370:	0a04a783          	lw	a5,160(s1)
    80000374:	09c4a703          	lw	a4,156(s1)
    80000378:	fcf71ee3          	bne	a4,a5,80000354 <consoleintr+0xda>
    8000037c:	bf0d                	j	800002ae <consoleintr+0x34>
    if(cons.e != cons.w){
    8000037e:	0000f717          	auipc	a4,0xf
    80000382:	66270713          	addi	a4,a4,1634 # 8000f9e0 <cons>
    80000386:	0a072783          	lw	a5,160(a4)
    8000038a:	09c72703          	lw	a4,156(a4)
    8000038e:	f2f700e3          	beq	a4,a5,800002ae <consoleintr+0x34>
      cons.e--;
    80000392:	37fd                	addiw	a5,a5,-1
    80000394:	0000f717          	auipc	a4,0xf
    80000398:	6ef72623          	sw	a5,1772(a4) # 8000fa80 <cons+0xa0>
      consputc(BACKSPACE);
    8000039c:	10000513          	li	a0,256
    800003a0:	ea9ff0ef          	jal	ra,80000248 <consputc>
    800003a4:	b729                	j	800002ae <consoleintr+0x34>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003a6:	f00484e3          	beqz	s1,800002ae <consoleintr+0x34>
    800003aa:	b715                	j	800002ce <consoleintr+0x54>
      consputc(c);
    800003ac:	4529                	li	a0,10
    800003ae:	e9bff0ef          	jal	ra,80000248 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003b2:	0000f797          	auipc	a5,0xf
    800003b6:	62e78793          	addi	a5,a5,1582 # 8000f9e0 <cons>
    800003ba:	0a07a703          	lw	a4,160(a5)
    800003be:	0017069b          	addiw	a3,a4,1
    800003c2:	0006861b          	sext.w	a2,a3
    800003c6:	0ad7a023          	sw	a3,160(a5)
    800003ca:	07f77713          	andi	a4,a4,127
    800003ce:	97ba                	add	a5,a5,a4
    800003d0:	4729                	li	a4,10
    800003d2:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003d6:	0000f797          	auipc	a5,0xf
    800003da:	6ac7a323          	sw	a2,1702(a5) # 8000fa7c <cons+0x9c>
        wakeup(&cons.r);
    800003de:	0000f517          	auipc	a0,0xf
    800003e2:	69a50513          	addi	a0,a0,1690 # 8000fa78 <cons+0x98>
    800003e6:	485010ef          	jal	ra,8000206a <wakeup>
    800003ea:	b5d1                	j	800002ae <consoleintr+0x34>

00000000800003ec <consoleinit>:

void
consoleinit(void)
{
    800003ec:	1141                	addi	sp,sp,-16
    800003ee:	e406                	sd	ra,8(sp)
    800003f0:	e022                	sd	s0,0(sp)
    800003f2:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800003f4:	00007597          	auipc	a1,0x7
    800003f8:	c1c58593          	addi	a1,a1,-996 # 80007010 <etext+0x10>
    800003fc:	0000f517          	auipc	a0,0xf
    80000400:	5e450513          	addi	a0,a0,1508 # 8000f9e0 <cons>
    80000404:	6e6000ef          	jal	ra,80000aea <initlock>

  uartinit();
    80000408:	3e0000ef          	jal	ra,800007e8 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    8000040c:	00020797          	auipc	a5,0x20
    80000410:	74478793          	addi	a5,a5,1860 # 80020b50 <devsw>
    80000414:	00000717          	auipc	a4,0x0
    80000418:	d3870713          	addi	a4,a4,-712 # 8000014c <consoleread>
    8000041c:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000041e:	00000717          	auipc	a4,0x0
    80000422:	cb270713          	addi	a4,a4,-846 # 800000d0 <consolewrite>
    80000426:	ef98                	sd	a4,24(a5)
}
    80000428:	60a2                	ld	ra,8(sp)
    8000042a:	6402                	ld	s0,0(sp)
    8000042c:	0141                	addi	sp,sp,16
    8000042e:	8082                	ret

0000000080000430 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000430:	7139                	addi	sp,sp,-64
    80000432:	fc06                	sd	ra,56(sp)
    80000434:	f822                	sd	s0,48(sp)
    80000436:	f426                	sd	s1,40(sp)
    80000438:	f04a                	sd	s2,32(sp)
    8000043a:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000043c:	c219                	beqz	a2,80000442 <printint+0x12>
    8000043e:	06054e63          	bltz	a0,800004ba <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000442:	4881                	li	a7,0
    80000444:	fc840693          	addi	a3,s0,-56

  i = 0;
    80000448:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000044a:	00007617          	auipc	a2,0x7
    8000044e:	bee60613          	addi	a2,a2,-1042 # 80007038 <digits>
    80000452:	883e                	mv	a6,a5
    80000454:	2785                	addiw	a5,a5,1
    80000456:	02b57733          	remu	a4,a0,a1
    8000045a:	9732                	add	a4,a4,a2
    8000045c:	00074703          	lbu	a4,0(a4)
    80000460:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000464:	872a                	mv	a4,a0
    80000466:	02b55533          	divu	a0,a0,a1
    8000046a:	0685                	addi	a3,a3,1
    8000046c:	feb773e3          	bgeu	a4,a1,80000452 <printint+0x22>

  if(sign)
    80000470:	00088a63          	beqz	a7,80000484 <printint+0x54>
    buf[i++] = '-';
    80000474:	1781                	addi	a5,a5,-32
    80000476:	97a2                	add	a5,a5,s0
    80000478:	02d00713          	li	a4,45
    8000047c:	fee78423          	sb	a4,-24(a5)
    80000480:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    80000484:	02f05563          	blez	a5,800004ae <printint+0x7e>
    80000488:	fc840713          	addi	a4,s0,-56
    8000048c:	00f704b3          	add	s1,a4,a5
    80000490:	fff70913          	addi	s2,a4,-1
    80000494:	993e                	add	s2,s2,a5
    80000496:	37fd                	addiw	a5,a5,-1
    80000498:	1782                	slli	a5,a5,0x20
    8000049a:	9381                	srli	a5,a5,0x20
    8000049c:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004a0:	fff4c503          	lbu	a0,-1(s1)
    800004a4:	da5ff0ef          	jal	ra,80000248 <consputc>
  while(--i >= 0)
    800004a8:	14fd                	addi	s1,s1,-1
    800004aa:	ff249be3          	bne	s1,s2,800004a0 <printint+0x70>
}
    800004ae:	70e2                	ld	ra,56(sp)
    800004b0:	7442                	ld	s0,48(sp)
    800004b2:	74a2                	ld	s1,40(sp)
    800004b4:	7902                	ld	s2,32(sp)
    800004b6:	6121                	addi	sp,sp,64
    800004b8:	8082                	ret
    x = -xx;
    800004ba:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004be:	4885                	li	a7,1
    x = -xx;
    800004c0:	b751                	j	80000444 <printint+0x14>

00000000800004c2 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004c2:	7131                	addi	sp,sp,-192
    800004c4:	fc86                	sd	ra,120(sp)
    800004c6:	f8a2                	sd	s0,112(sp)
    800004c8:	f4a6                	sd	s1,104(sp)
    800004ca:	f0ca                	sd	s2,96(sp)
    800004cc:	ecce                	sd	s3,88(sp)
    800004ce:	e8d2                	sd	s4,80(sp)
    800004d0:	e4d6                	sd	s5,72(sp)
    800004d2:	e0da                	sd	s6,64(sp)
    800004d4:	fc5e                	sd	s7,56(sp)
    800004d6:	f862                	sd	s8,48(sp)
    800004d8:	f466                	sd	s9,40(sp)
    800004da:	f06a                	sd	s10,32(sp)
    800004dc:	ec6e                	sd	s11,24(sp)
    800004de:	0100                	addi	s0,sp,128
    800004e0:	8a2a                	mv	s4,a0
    800004e2:	e40c                	sd	a1,8(s0)
    800004e4:	e810                	sd	a2,16(s0)
    800004e6:	ec14                	sd	a3,24(s0)
    800004e8:	f018                	sd	a4,32(s0)
    800004ea:	f41c                	sd	a5,40(s0)
    800004ec:	03043823          	sd	a6,48(s0)
    800004f0:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    800004f4:	00007797          	auipc	a5,0x7
    800004f8:	4b07a783          	lw	a5,1200(a5) # 800079a4 <panicking>
    800004fc:	cb9d                	beqz	a5,80000532 <printf+0x70>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800004fe:	00840793          	addi	a5,s0,8
    80000502:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000506:	000a4503          	lbu	a0,0(s4)
    8000050a:	24050363          	beqz	a0,80000750 <printf+0x28e>
    8000050e:	4981                	li	s3,0
    if(cx != '%'){
    80000510:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    80000514:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    80000518:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000051c:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000520:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000524:	07000d93          	li	s11,112
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000528:	00007b97          	auipc	s7,0x7
    8000052c:	b10b8b93          	addi	s7,s7,-1264 # 80007038 <digits>
    80000530:	a01d                	j	80000556 <printf+0x94>
    acquire(&pr.lock);
    80000532:	0000f517          	auipc	a0,0xf
    80000536:	55650513          	addi	a0,a0,1366 # 8000fa88 <pr>
    8000053a:	630000ef          	jal	ra,80000b6a <acquire>
    8000053e:	b7c1                	j	800004fe <printf+0x3c>
      consputc(cx);
    80000540:	d09ff0ef          	jal	ra,80000248 <consputc>
      continue;
    80000544:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000546:	0014899b          	addiw	s3,s1,1
    8000054a:	013a07b3          	add	a5,s4,s3
    8000054e:	0007c503          	lbu	a0,0(a5)
    80000552:	1e050f63          	beqz	a0,80000750 <printf+0x28e>
    if(cx != '%'){
    80000556:	ff5515e3          	bne	a0,s5,80000540 <printf+0x7e>
    i++;
    8000055a:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000055e:	009a07b3          	add	a5,s4,s1
    80000562:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000566:	1e090563          	beqz	s2,80000750 <printf+0x28e>
    8000056a:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000056e:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    80000570:	c789                	beqz	a5,8000057a <printf+0xb8>
    80000572:	009a0733          	add	a4,s4,s1
    80000576:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    8000057a:	03690863          	beq	s2,s6,800005aa <printf+0xe8>
    } else if(c0 == 'l' && c1 == 'd'){
    8000057e:	05890263          	beq	s2,s8,800005c2 <printf+0x100>
    } else if(c0 == 'u'){
    80000582:	0d990163          	beq	s2,s9,80000644 <printf+0x182>
    } else if(c0 == 'x'){
    80000586:	11a90863          	beq	s2,s10,80000696 <printf+0x1d4>
    } else if(c0 == 'p'){
    8000058a:	15b90163          	beq	s2,s11,800006cc <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    8000058e:	06300793          	li	a5,99
    80000592:	16f90963          	beq	s2,a5,80000704 <printf+0x242>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    80000596:	07300793          	li	a5,115
    8000059a:	16f90f63          	beq	s2,a5,80000718 <printf+0x256>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    8000059e:	03591c63          	bne	s2,s5,800005d6 <printf+0x114>
      consputc('%');
    800005a2:	8556                	mv	a0,s5
    800005a4:	ca5ff0ef          	jal	ra,80000248 <consputc>
    800005a8:	bf79                	j	80000546 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    800005aa:	f8843783          	ld	a5,-120(s0)
    800005ae:	00878713          	addi	a4,a5,8
    800005b2:	f8e43423          	sd	a4,-120(s0)
    800005b6:	4605                	li	a2,1
    800005b8:	45a9                	li	a1,10
    800005ba:	4388                	lw	a0,0(a5)
    800005bc:	e75ff0ef          	jal	ra,80000430 <printint>
    800005c0:	b759                	j	80000546 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'd'){
    800005c2:	03678163          	beq	a5,s6,800005e4 <printf+0x122>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005c6:	03878d63          	beq	a5,s8,80000600 <printf+0x13e>
    } else if(c0 == 'l' && c1 == 'u'){
    800005ca:	09978a63          	beq	a5,s9,8000065e <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800005ce:	03878b63          	beq	a5,s8,80000604 <printf+0x142>
    } else if(c0 == 'l' && c1 == 'x'){
    800005d2:	0da78f63          	beq	a5,s10,800006b0 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    800005d6:	8556                	mv	a0,s5
    800005d8:	c71ff0ef          	jal	ra,80000248 <consputc>
      consputc(c0);
    800005dc:	854a                	mv	a0,s2
    800005de:	c6bff0ef          	jal	ra,80000248 <consputc>
    800005e2:	b795                	j	80000546 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    800005e4:	f8843783          	ld	a5,-120(s0)
    800005e8:	00878713          	addi	a4,a5,8
    800005ec:	f8e43423          	sd	a4,-120(s0)
    800005f0:	4605                	li	a2,1
    800005f2:	45a9                	li	a1,10
    800005f4:	6388                	ld	a0,0(a5)
    800005f6:	e3bff0ef          	jal	ra,80000430 <printint>
      i += 1;
    800005fa:	0029849b          	addiw	s1,s3,2
    800005fe:	b7a1                	j	80000546 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80000600:	03668463          	beq	a3,s6,80000628 <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000604:	07968b63          	beq	a3,s9,8000067a <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80000608:	fda697e3          	bne	a3,s10,800005d6 <printf+0x114>
      printint(va_arg(ap, uint64), 16, 0);
    8000060c:	f8843783          	ld	a5,-120(s0)
    80000610:	00878713          	addi	a4,a5,8
    80000614:	f8e43423          	sd	a4,-120(s0)
    80000618:	4601                	li	a2,0
    8000061a:	45c1                	li	a1,16
    8000061c:	6388                	ld	a0,0(a5)
    8000061e:	e13ff0ef          	jal	ra,80000430 <printint>
      i += 2;
    80000622:	0039849b          	addiw	s1,s3,3
    80000626:	b705                	j	80000546 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    80000628:	f8843783          	ld	a5,-120(s0)
    8000062c:	00878713          	addi	a4,a5,8
    80000630:	f8e43423          	sd	a4,-120(s0)
    80000634:	4605                	li	a2,1
    80000636:	45a9                	li	a1,10
    80000638:	6388                	ld	a0,0(a5)
    8000063a:	df7ff0ef          	jal	ra,80000430 <printint>
      i += 2;
    8000063e:	0039849b          	addiw	s1,s3,3
    80000642:	b711                	j	80000546 <printf+0x84>
      printint(va_arg(ap, uint32), 10, 0);
    80000644:	f8843783          	ld	a5,-120(s0)
    80000648:	00878713          	addi	a4,a5,8
    8000064c:	f8e43423          	sd	a4,-120(s0)
    80000650:	4601                	li	a2,0
    80000652:	45a9                	li	a1,10
    80000654:	0007e503          	lwu	a0,0(a5)
    80000658:	dd9ff0ef          	jal	ra,80000430 <printint>
    8000065c:	b5ed                	j	80000546 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    8000065e:	f8843783          	ld	a5,-120(s0)
    80000662:	00878713          	addi	a4,a5,8
    80000666:	f8e43423          	sd	a4,-120(s0)
    8000066a:	4601                	li	a2,0
    8000066c:	45a9                	li	a1,10
    8000066e:	6388                	ld	a0,0(a5)
    80000670:	dc1ff0ef          	jal	ra,80000430 <printint>
      i += 1;
    80000674:	0029849b          	addiw	s1,s3,2
    80000678:	b5f9                	j	80000546 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    8000067a:	f8843783          	ld	a5,-120(s0)
    8000067e:	00878713          	addi	a4,a5,8
    80000682:	f8e43423          	sd	a4,-120(s0)
    80000686:	4601                	li	a2,0
    80000688:	45a9                	li	a1,10
    8000068a:	6388                	ld	a0,0(a5)
    8000068c:	da5ff0ef          	jal	ra,80000430 <printint>
      i += 2;
    80000690:	0039849b          	addiw	s1,s3,3
    80000694:	bd4d                	j	80000546 <printf+0x84>
      printint(va_arg(ap, uint32), 16, 0);
    80000696:	f8843783          	ld	a5,-120(s0)
    8000069a:	00878713          	addi	a4,a5,8
    8000069e:	f8e43423          	sd	a4,-120(s0)
    800006a2:	4601                	li	a2,0
    800006a4:	45c1                	li	a1,16
    800006a6:	0007e503          	lwu	a0,0(a5)
    800006aa:	d87ff0ef          	jal	ra,80000430 <printint>
    800006ae:	bd61                	j	80000546 <printf+0x84>
      printint(va_arg(ap, uint64), 16, 0);
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	4601                	li	a2,0
    800006be:	45c1                	li	a1,16
    800006c0:	6388                	ld	a0,0(a5)
    800006c2:	d6fff0ef          	jal	ra,80000430 <printint>
      i += 1;
    800006c6:	0029849b          	addiw	s1,s3,2
    800006ca:	bdb5                	j	80000546 <printf+0x84>
      printptr(va_arg(ap, uint64));
    800006cc:	f8843783          	ld	a5,-120(s0)
    800006d0:	00878713          	addi	a4,a5,8
    800006d4:	f8e43423          	sd	a4,-120(s0)
    800006d8:	0007b983          	ld	s3,0(a5)
  consputc('0');
    800006dc:	03000513          	li	a0,48
    800006e0:	b69ff0ef          	jal	ra,80000248 <consputc>
  consputc('x');
    800006e4:	856a                	mv	a0,s10
    800006e6:	b63ff0ef          	jal	ra,80000248 <consputc>
    800006ea:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006ec:	03c9d793          	srli	a5,s3,0x3c
    800006f0:	97de                	add	a5,a5,s7
    800006f2:	0007c503          	lbu	a0,0(a5)
    800006f6:	b53ff0ef          	jal	ra,80000248 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006fa:	0992                	slli	s3,s3,0x4
    800006fc:	397d                	addiw	s2,s2,-1
    800006fe:	fe0917e3          	bnez	s2,800006ec <printf+0x22a>
    80000702:	b591                	j	80000546 <printf+0x84>
      consputc(va_arg(ap, uint));
    80000704:	f8843783          	ld	a5,-120(s0)
    80000708:	00878713          	addi	a4,a5,8
    8000070c:	f8e43423          	sd	a4,-120(s0)
    80000710:	4388                	lw	a0,0(a5)
    80000712:	b37ff0ef          	jal	ra,80000248 <consputc>
    80000716:	bd05                	j	80000546 <printf+0x84>
      if((s = va_arg(ap, char*)) == 0)
    80000718:	f8843783          	ld	a5,-120(s0)
    8000071c:	00878713          	addi	a4,a5,8
    80000720:	f8e43423          	sd	a4,-120(s0)
    80000724:	0007b903          	ld	s2,0(a5)
    80000728:	00090d63          	beqz	s2,80000742 <printf+0x280>
      for(; *s; s++)
    8000072c:	00094503          	lbu	a0,0(s2)
    80000730:	e0050be3          	beqz	a0,80000546 <printf+0x84>
        consputc(*s);
    80000734:	b15ff0ef          	jal	ra,80000248 <consputc>
      for(; *s; s++)
    80000738:	0905                	addi	s2,s2,1
    8000073a:	00094503          	lbu	a0,0(s2)
    8000073e:	f97d                	bnez	a0,80000734 <printf+0x272>
    80000740:	b519                	j	80000546 <printf+0x84>
        s = "(null)";
    80000742:	00007917          	auipc	s2,0x7
    80000746:	8d690913          	addi	s2,s2,-1834 # 80007018 <etext+0x18>
      for(; *s; s++)
    8000074a:	02800513          	li	a0,40
    8000074e:	b7dd                	j	80000734 <printf+0x272>
    }

  }
  va_end(ap);

  if(panicking == 0)
    80000750:	00007797          	auipc	a5,0x7
    80000754:	2547a783          	lw	a5,596(a5) # 800079a4 <panicking>
    80000758:	c38d                	beqz	a5,8000077a <printf+0x2b8>
    release(&pr.lock);

  return 0;
}
    8000075a:	4501                	li	a0,0
    8000075c:	70e6                	ld	ra,120(sp)
    8000075e:	7446                	ld	s0,112(sp)
    80000760:	74a6                	ld	s1,104(sp)
    80000762:	7906                	ld	s2,96(sp)
    80000764:	69e6                	ld	s3,88(sp)
    80000766:	6a46                	ld	s4,80(sp)
    80000768:	6aa6                	ld	s5,72(sp)
    8000076a:	6b06                	ld	s6,64(sp)
    8000076c:	7be2                	ld	s7,56(sp)
    8000076e:	7c42                	ld	s8,48(sp)
    80000770:	7ca2                	ld	s9,40(sp)
    80000772:	7d02                	ld	s10,32(sp)
    80000774:	6de2                	ld	s11,24(sp)
    80000776:	6129                	addi	sp,sp,192
    80000778:	8082                	ret
    release(&pr.lock);
    8000077a:	0000f517          	auipc	a0,0xf
    8000077e:	30e50513          	addi	a0,a0,782 # 8000fa88 <pr>
    80000782:	480000ef          	jal	ra,80000c02 <release>
  return 0;
    80000786:	bfd1                	j	8000075a <printf+0x298>

0000000080000788 <panic>:

void
panic(char *s)
{
    80000788:	1101                	addi	sp,sp,-32
    8000078a:	ec06                	sd	ra,24(sp)
    8000078c:	e822                	sd	s0,16(sp)
    8000078e:	e426                	sd	s1,8(sp)
    80000790:	e04a                	sd	s2,0(sp)
    80000792:	1000                	addi	s0,sp,32
    80000794:	84aa                	mv	s1,a0
  panicking = 1;
    80000796:	4905                	li	s2,1
    80000798:	00007797          	auipc	a5,0x7
    8000079c:	2127a623          	sw	s2,524(a5) # 800079a4 <panicking>
  printf("panic: ");
    800007a0:	00007517          	auipc	a0,0x7
    800007a4:	88050513          	addi	a0,a0,-1920 # 80007020 <etext+0x20>
    800007a8:	d1bff0ef          	jal	ra,800004c2 <printf>
  printf("%s\n", s);
    800007ac:	85a6                	mv	a1,s1
    800007ae:	00007517          	auipc	a0,0x7
    800007b2:	87a50513          	addi	a0,a0,-1926 # 80007028 <etext+0x28>
    800007b6:	d0dff0ef          	jal	ra,800004c2 <printf>
  panicked = 1; // freeze uart output from other CPUs
    800007ba:	00007797          	auipc	a5,0x7
    800007be:	1f27a323          	sw	s2,486(a5) # 800079a0 <panicked>
  for(;;)
    800007c2:	a001                	j	800007c2 <panic+0x3a>

00000000800007c4 <printfinit>:
    ;
}

void
printfinit(void)
{
    800007c4:	1141                	addi	sp,sp,-16
    800007c6:	e406                	sd	ra,8(sp)
    800007c8:	e022                	sd	s0,0(sp)
    800007ca:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    800007cc:	00007597          	auipc	a1,0x7
    800007d0:	86458593          	addi	a1,a1,-1948 # 80007030 <etext+0x30>
    800007d4:	0000f517          	auipc	a0,0xf
    800007d8:	2b450513          	addi	a0,a0,692 # 8000fa88 <pr>
    800007dc:	30e000ef          	jal	ra,80000aea <initlock>
}
    800007e0:	60a2                	ld	ra,8(sp)
    800007e2:	6402                	ld	s0,0(sp)
    800007e4:	0141                	addi	sp,sp,16
    800007e6:	8082                	ret

00000000800007e8 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    800007e8:	1141                	addi	sp,sp,-16
    800007ea:	e406                	sd	ra,8(sp)
    800007ec:	e022                	sd	s0,0(sp)
    800007ee:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007f0:	100007b7          	lui	a5,0x10000
    800007f4:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007f8:	f8000713          	li	a4,-128
    800007fc:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000800:	470d                	li	a4,3
    80000802:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000806:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000080a:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000080e:	469d                	li	a3,7
    80000810:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000814:	00e780a3          	sb	a4,1(a5)

  initlock(&tx_lock, "uart");
    80000818:	00007597          	auipc	a1,0x7
    8000081c:	83858593          	addi	a1,a1,-1992 # 80007050 <digits+0x18>
    80000820:	0000f517          	auipc	a0,0xf
    80000824:	28050513          	addi	a0,a0,640 # 8000faa0 <tx_lock>
    80000828:	2c2000ef          	jal	ra,80000aea <initlock>
}
    8000082c:	60a2                	ld	ra,8(sp)
    8000082e:	6402                	ld	s0,0(sp)
    80000830:	0141                	addi	sp,sp,16
    80000832:	8082                	ret

0000000080000834 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    80000834:	715d                	addi	sp,sp,-80
    80000836:	e486                	sd	ra,72(sp)
    80000838:	e0a2                	sd	s0,64(sp)
    8000083a:	fc26                	sd	s1,56(sp)
    8000083c:	f84a                	sd	s2,48(sp)
    8000083e:	f44e                	sd	s3,40(sp)
    80000840:	f052                	sd	s4,32(sp)
    80000842:	ec56                	sd	s5,24(sp)
    80000844:	e85a                	sd	s6,16(sp)
    80000846:	e45e                	sd	s7,8(sp)
    80000848:	0880                	addi	s0,sp,80
    8000084a:	84aa                	mv	s1,a0
    8000084c:	892e                	mv	s2,a1
  acquire(&tx_lock);
    8000084e:	0000f517          	auipc	a0,0xf
    80000852:	25250513          	addi	a0,a0,594 # 8000faa0 <tx_lock>
    80000856:	314000ef          	jal	ra,80000b6a <acquire>

  int i = 0;
  while(i < n){ 
    8000085a:	05205c63          	blez	s2,800008b2 <uartwrite+0x7e>
    8000085e:	8a26                	mv	s4,s1
    80000860:	0485                	addi	s1,s1,1
    80000862:	fff9079b          	addiw	a5,s2,-1
    80000866:	1782                	slli	a5,a5,0x20
    80000868:	9381                	srli	a5,a5,0x20
    8000086a:	00f48ab3          	add	s5,s1,a5
    while(tx_busy != 0){
    8000086e:	00007497          	auipc	s1,0x7
    80000872:	13e48493          	addi	s1,s1,318 # 800079ac <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    80000876:	0000f997          	auipc	s3,0xf
    8000087a:	22a98993          	addi	s3,s3,554 # 8000faa0 <tx_lock>
    8000087e:	00007917          	auipc	s2,0x7
    80000882:	12a90913          	addi	s2,s2,298 # 800079a8 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    80000886:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    8000088a:	4b05                	li	s6,1
    8000088c:	a005                	j	800008ac <uartwrite+0x78>
      sleep(&tx_chan, &tx_lock);
    8000088e:	85ce                	mv	a1,s3
    80000890:	854a                	mv	a0,s2
    80000892:	78c010ef          	jal	ra,8000201e <sleep>
    while(tx_busy != 0){
    80000896:	409c                	lw	a5,0(s1)
    80000898:	fbfd                	bnez	a5,8000088e <uartwrite+0x5a>
    WriteReg(THR, buf[i]);
    8000089a:	000a4783          	lbu	a5,0(s4)
    8000089e:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    800008a2:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    800008a6:	0a05                	addi	s4,s4,1
    800008a8:	015a0563          	beq	s4,s5,800008b2 <uartwrite+0x7e>
    while(tx_busy != 0){
    800008ac:	409c                	lw	a5,0(s1)
    800008ae:	f3e5                	bnez	a5,8000088e <uartwrite+0x5a>
    800008b0:	b7ed                	j	8000089a <uartwrite+0x66>
  }

  release(&tx_lock);
    800008b2:	0000f517          	auipc	a0,0xf
    800008b6:	1ee50513          	addi	a0,a0,494 # 8000faa0 <tx_lock>
    800008ba:	348000ef          	jal	ra,80000c02 <release>
}
    800008be:	60a6                	ld	ra,72(sp)
    800008c0:	6406                	ld	s0,64(sp)
    800008c2:	74e2                	ld	s1,56(sp)
    800008c4:	7942                	ld	s2,48(sp)
    800008c6:	79a2                	ld	s3,40(sp)
    800008c8:	7a02                	ld	s4,32(sp)
    800008ca:	6ae2                	ld	s5,24(sp)
    800008cc:	6b42                	ld	s6,16(sp)
    800008ce:	6ba2                	ld	s7,8(sp)
    800008d0:	6161                	addi	sp,sp,80
    800008d2:	8082                	ret

00000000800008d4 <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800008d4:	1101                	addi	sp,sp,-32
    800008d6:	ec06                	sd	ra,24(sp)
    800008d8:	e822                	sd	s0,16(sp)
    800008da:	e426                	sd	s1,8(sp)
    800008dc:	1000                	addi	s0,sp,32
    800008de:	84aa                	mv	s1,a0
  if(panicking == 0)
    800008e0:	00007797          	auipc	a5,0x7
    800008e4:	0c47a783          	lw	a5,196(a5) # 800079a4 <panicking>
    800008e8:	cb89                	beqz	a5,800008fa <uartputc_sync+0x26>
    push_off();

  if(panicked){
    800008ea:	00007797          	auipc	a5,0x7
    800008ee:	0b67a783          	lw	a5,182(a5) # 800079a0 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008f2:	10000737          	lui	a4,0x10000
  if(panicked){
    800008f6:	c789                	beqz	a5,80000900 <uartputc_sync+0x2c>
    for(;;)
    800008f8:	a001                	j	800008f8 <uartputc_sync+0x24>
    push_off();
    800008fa:	230000ef          	jal	ra,80000b2a <push_off>
    800008fe:	b7f5                	j	800008ea <uartputc_sync+0x16>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000900:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80000904:	0207f793          	andi	a5,a5,32
    80000908:	dfe5                	beqz	a5,80000900 <uartputc_sync+0x2c>
    ;
  WriteReg(THR, c);
    8000090a:	0ff4f513          	zext.b	a0,s1
    8000090e:	100007b7          	lui	a5,0x10000
    80000912:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    80000916:	00007797          	auipc	a5,0x7
    8000091a:	08e7a783          	lw	a5,142(a5) # 800079a4 <panicking>
    8000091e:	c791                	beqz	a5,8000092a <uartputc_sync+0x56>
    pop_off();
}
    80000920:	60e2                	ld	ra,24(sp)
    80000922:	6442                	ld	s0,16(sp)
    80000924:	64a2                	ld	s1,8(sp)
    80000926:	6105                	addi	sp,sp,32
    80000928:	8082                	ret
    pop_off();
    8000092a:	284000ef          	jal	ra,80000bae <pop_off>
}
    8000092e:	bfcd                	j	80000920 <uartputc_sync+0x4c>

0000000080000930 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000930:	1141                	addi	sp,sp,-16
    80000932:	e422                	sd	s0,8(sp)
    80000934:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    80000936:	100007b7          	lui	a5,0x10000
    8000093a:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    8000093e:	8b85                	andi	a5,a5,1
    80000940:	cb81                	beqz	a5,80000950 <uartgetc+0x20>
    // input data is ready.
    return ReadReg(RHR);
    80000942:	100007b7          	lui	a5,0x10000
    80000946:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    8000094a:	6422                	ld	s0,8(sp)
    8000094c:	0141                	addi	sp,sp,16
    8000094e:	8082                	ret
    return -1;
    80000950:	557d                	li	a0,-1
    80000952:	bfe5                	j	8000094a <uartgetc+0x1a>

0000000080000954 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000954:	1101                	addi	sp,sp,-32
    80000956:	ec06                	sd	ra,24(sp)
    80000958:	e822                	sd	s0,16(sp)
    8000095a:	e426                	sd	s1,8(sp)
    8000095c:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    8000095e:	100004b7          	lui	s1,0x10000
    80000962:	0024c783          	lbu	a5,2(s1) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000966:	0000f517          	auipc	a0,0xf
    8000096a:	13a50513          	addi	a0,a0,314 # 8000faa0 <tx_lock>
    8000096e:	1fc000ef          	jal	ra,80000b6a <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    80000972:	0054c783          	lbu	a5,5(s1)
    80000976:	0207f793          	andi	a5,a5,32
    8000097a:	eb89                	bnez	a5,8000098c <uartintr+0x38>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    8000097c:	0000f517          	auipc	a0,0xf
    80000980:	12450513          	addi	a0,a0,292 # 8000faa0 <tx_lock>
    80000984:	27e000ef          	jal	ra,80000c02 <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000988:	54fd                	li	s1,-1
    8000098a:	a831                	j	800009a6 <uartintr+0x52>
    tx_busy = 0;
    8000098c:	00007797          	auipc	a5,0x7
    80000990:	0207a023          	sw	zero,32(a5) # 800079ac <tx_busy>
    wakeup(&tx_chan);
    80000994:	00007517          	auipc	a0,0x7
    80000998:	01450513          	addi	a0,a0,20 # 800079a8 <tx_chan>
    8000099c:	6ce010ef          	jal	ra,8000206a <wakeup>
    800009a0:	bff1                	j	8000097c <uartintr+0x28>
      break;
    consoleintr(c);
    800009a2:	8d9ff0ef          	jal	ra,8000027a <consoleintr>
    int c = uartgetc();
    800009a6:	f8bff0ef          	jal	ra,80000930 <uartgetc>
    if(c == -1)
    800009aa:	fe951ce3          	bne	a0,s1,800009a2 <uartintr+0x4e>
  }
}
    800009ae:	60e2                	ld	ra,24(sp)
    800009b0:	6442                	ld	s0,16(sp)
    800009b2:	64a2                	ld	s1,8(sp)
    800009b4:	6105                	addi	sp,sp,32
    800009b6:	8082                	ret

00000000800009b8 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009b8:	1101                	addi	sp,sp,-32
    800009ba:	ec06                	sd	ra,24(sp)
    800009bc:	e822                	sd	s0,16(sp)
    800009be:	e426                	sd	s1,8(sp)
    800009c0:	e04a                	sd	s2,0(sp)
    800009c2:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    800009c4:	03451793          	slli	a5,a0,0x34
    800009c8:	e7a9                	bnez	a5,80000a12 <kfree+0x5a>
    800009ca:	84aa                	mv	s1,a0
    800009cc:	00021797          	auipc	a5,0x21
    800009d0:	31c78793          	addi	a5,a5,796 # 80021ce8 <end>
    800009d4:	02f56f63          	bltu	a0,a5,80000a12 <kfree+0x5a>
    800009d8:	47c5                	li	a5,17
    800009da:	07ee                	slli	a5,a5,0x1b
    800009dc:	02f57b63          	bgeu	a0,a5,80000a12 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    800009e0:	6605                	lui	a2,0x1
    800009e2:	4585                	li	a1,1
    800009e4:	25a000ef          	jal	ra,80000c3e <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    800009e8:	0000f917          	auipc	s2,0xf
    800009ec:	0d090913          	addi	s2,s2,208 # 8000fab8 <kmem>
    800009f0:	854a                	mv	a0,s2
    800009f2:	178000ef          	jal	ra,80000b6a <acquire>
  r->next = kmem.freelist;
    800009f6:	01893783          	ld	a5,24(s2)
    800009fa:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    800009fc:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a00:	854a                	mv	a0,s2
    80000a02:	200000ef          	jal	ra,80000c02 <release>
}
    80000a06:	60e2                	ld	ra,24(sp)
    80000a08:	6442                	ld	s0,16(sp)
    80000a0a:	64a2                	ld	s1,8(sp)
    80000a0c:	6902                	ld	s2,0(sp)
    80000a0e:	6105                	addi	sp,sp,32
    80000a10:	8082                	ret
    panic("kfree");
    80000a12:	00006517          	auipc	a0,0x6
    80000a16:	64650513          	addi	a0,a0,1606 # 80007058 <digits+0x20>
    80000a1a:	d6fff0ef          	jal	ra,80000788 <panic>

0000000080000a1e <freerange>:
{
    80000a1e:	7179                	addi	sp,sp,-48
    80000a20:	f406                	sd	ra,40(sp)
    80000a22:	f022                	sd	s0,32(sp)
    80000a24:	ec26                	sd	s1,24(sp)
    80000a26:	e84a                	sd	s2,16(sp)
    80000a28:	e44e                	sd	s3,8(sp)
    80000a2a:	e052                	sd	s4,0(sp)
    80000a2c:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a2e:	6785                	lui	a5,0x1
    80000a30:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a34:	00e504b3          	add	s1,a0,a4
    80000a38:	777d                	lui	a4,0xfffff
    80000a3a:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a3c:	94be                	add	s1,s1,a5
    80000a3e:	0095ec63          	bltu	a1,s1,80000a56 <freerange+0x38>
    80000a42:	892e                	mv	s2,a1
    kfree(p);
    80000a44:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a46:	6985                	lui	s3,0x1
    kfree(p);
    80000a48:	01448533          	add	a0,s1,s4
    80000a4c:	f6dff0ef          	jal	ra,800009b8 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a50:	94ce                	add	s1,s1,s3
    80000a52:	fe997be3          	bgeu	s2,s1,80000a48 <freerange+0x2a>
}
    80000a56:	70a2                	ld	ra,40(sp)
    80000a58:	7402                	ld	s0,32(sp)
    80000a5a:	64e2                	ld	s1,24(sp)
    80000a5c:	6942                	ld	s2,16(sp)
    80000a5e:	69a2                	ld	s3,8(sp)
    80000a60:	6a02                	ld	s4,0(sp)
    80000a62:	6145                	addi	sp,sp,48
    80000a64:	8082                	ret

0000000080000a66 <kinit>:
{
    80000a66:	1141                	addi	sp,sp,-16
    80000a68:	e406                	sd	ra,8(sp)
    80000a6a:	e022                	sd	s0,0(sp)
    80000a6c:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000a6e:	00006597          	auipc	a1,0x6
    80000a72:	5f258593          	addi	a1,a1,1522 # 80007060 <digits+0x28>
    80000a76:	0000f517          	auipc	a0,0xf
    80000a7a:	04250513          	addi	a0,a0,66 # 8000fab8 <kmem>
    80000a7e:	06c000ef          	jal	ra,80000aea <initlock>
  freerange(end, (void*)PHYSTOP);
    80000a82:	45c5                	li	a1,17
    80000a84:	05ee                	slli	a1,a1,0x1b
    80000a86:	00021517          	auipc	a0,0x21
    80000a8a:	26250513          	addi	a0,a0,610 # 80021ce8 <end>
    80000a8e:	f91ff0ef          	jal	ra,80000a1e <freerange>
}
    80000a92:	60a2                	ld	ra,8(sp)
    80000a94:	6402                	ld	s0,0(sp)
    80000a96:	0141                	addi	sp,sp,16
    80000a98:	8082                	ret

0000000080000a9a <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000a9a:	1101                	addi	sp,sp,-32
    80000a9c:	ec06                	sd	ra,24(sp)
    80000a9e:	e822                	sd	s0,16(sp)
    80000aa0:	e426                	sd	s1,8(sp)
    80000aa2:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000aa4:	0000f497          	auipc	s1,0xf
    80000aa8:	01448493          	addi	s1,s1,20 # 8000fab8 <kmem>
    80000aac:	8526                	mv	a0,s1
    80000aae:	0bc000ef          	jal	ra,80000b6a <acquire>
  r = kmem.freelist;
    80000ab2:	6c84                	ld	s1,24(s1)
  if(r)
    80000ab4:	c485                	beqz	s1,80000adc <kalloc+0x42>
    kmem.freelist = r->next;
    80000ab6:	609c                	ld	a5,0(s1)
    80000ab8:	0000f517          	auipc	a0,0xf
    80000abc:	00050513          	mv	a0,a0
    80000ac0:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000ac2:	140000ef          	jal	ra,80000c02 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000ac6:	6605                	lui	a2,0x1
    80000ac8:	4595                	li	a1,5
    80000aca:	8526                	mv	a0,s1
    80000acc:	172000ef          	jal	ra,80000c3e <memset>
  return (void*)r;
}
    80000ad0:	8526                	mv	a0,s1
    80000ad2:	60e2                	ld	ra,24(sp)
    80000ad4:	6442                	ld	s0,16(sp)
    80000ad6:	64a2                	ld	s1,8(sp)
    80000ad8:	6105                	addi	sp,sp,32
    80000ada:	8082                	ret
  release(&kmem.lock);
    80000adc:	0000f517          	auipc	a0,0xf
    80000ae0:	fdc50513          	addi	a0,a0,-36 # 8000fab8 <kmem>
    80000ae4:	11e000ef          	jal	ra,80000c02 <release>
  if(r)
    80000ae8:	b7e5                	j	80000ad0 <kalloc+0x36>

0000000080000aea <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000aea:	1141                	addi	sp,sp,-16
    80000aec:	e422                	sd	s0,8(sp)
    80000aee:	0800                	addi	s0,sp,16
  lk->name = name;
    80000af0:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000af2:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000af6:	00053823          	sd	zero,16(a0)
}
    80000afa:	6422                	ld	s0,8(sp)
    80000afc:	0141                	addi	sp,sp,16
    80000afe:	8082                	ret

0000000080000b00 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b00:	411c                	lw	a5,0(a0)
    80000b02:	e399                	bnez	a5,80000b08 <holding+0x8>
    80000b04:	4501                	li	a0,0
  return r;
}
    80000b06:	8082                	ret
{
    80000b08:	1101                	addi	sp,sp,-32
    80000b0a:	ec06                	sd	ra,24(sp)
    80000b0c:	e822                	sd	s0,16(sp)
    80000b0e:	e426                	sd	s1,8(sp)
    80000b10:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b12:	6904                	ld	s1,16(a0)
    80000b14:	597000ef          	jal	ra,800018aa <mycpu>
    80000b18:	40a48533          	sub	a0,s1,a0
    80000b1c:	00153513          	seqz	a0,a0
}
    80000b20:	60e2                	ld	ra,24(sp)
    80000b22:	6442                	ld	s0,16(sp)
    80000b24:	64a2                	ld	s1,8(sp)
    80000b26:	6105                	addi	sp,sp,32
    80000b28:	8082                	ret

0000000080000b2a <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b2a:	1101                	addi	sp,sp,-32
    80000b2c:	ec06                	sd	ra,24(sp)
    80000b2e:	e822                	sd	s0,16(sp)
    80000b30:	e426                	sd	s1,8(sp)
    80000b32:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000b34:	100024f3          	csrr	s1,sstatus
    80000b38:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000b3c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000b3e:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000b42:	569000ef          	jal	ra,800018aa <mycpu>
    80000b46:	5d3c                	lw	a5,120(a0)
    80000b48:	cb99                	beqz	a5,80000b5e <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000b4a:	561000ef          	jal	ra,800018aa <mycpu>
    80000b4e:	5d3c                	lw	a5,120(a0)
    80000b50:	2785                	addiw	a5,a5,1
    80000b52:	dd3c                	sw	a5,120(a0)
}
    80000b54:	60e2                	ld	ra,24(sp)
    80000b56:	6442                	ld	s0,16(sp)
    80000b58:	64a2                	ld	s1,8(sp)
    80000b5a:	6105                	addi	sp,sp,32
    80000b5c:	8082                	ret
    mycpu()->intena = old;
    80000b5e:	54d000ef          	jal	ra,800018aa <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000b62:	8085                	srli	s1,s1,0x1
    80000b64:	8885                	andi	s1,s1,1
    80000b66:	dd64                	sw	s1,124(a0)
    80000b68:	b7cd                	j	80000b4a <push_off+0x20>

0000000080000b6a <acquire>:
{
    80000b6a:	1101                	addi	sp,sp,-32
    80000b6c:	ec06                	sd	ra,24(sp)
    80000b6e:	e822                	sd	s0,16(sp)
    80000b70:	e426                	sd	s1,8(sp)
    80000b72:	1000                	addi	s0,sp,32
    80000b74:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000b76:	fb5ff0ef          	jal	ra,80000b2a <push_off>
  if(holding(lk))
    80000b7a:	8526                	mv	a0,s1
    80000b7c:	f85ff0ef          	jal	ra,80000b00 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000b80:	4705                	li	a4,1
  if(holding(lk))
    80000b82:	e105                	bnez	a0,80000ba2 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000b84:	87ba                	mv	a5,a4
    80000b86:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000b8a:	2781                	sext.w	a5,a5
    80000b8c:	ffe5                	bnez	a5,80000b84 <acquire+0x1a>
  __sync_synchronize();
    80000b8e:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000b92:	519000ef          	jal	ra,800018aa <mycpu>
    80000b96:	e888                	sd	a0,16(s1)
}
    80000b98:	60e2                	ld	ra,24(sp)
    80000b9a:	6442                	ld	s0,16(sp)
    80000b9c:	64a2                	ld	s1,8(sp)
    80000b9e:	6105                	addi	sp,sp,32
    80000ba0:	8082                	ret
    panic("acquire");
    80000ba2:	00006517          	auipc	a0,0x6
    80000ba6:	4c650513          	addi	a0,a0,1222 # 80007068 <digits+0x30>
    80000baa:	bdfff0ef          	jal	ra,80000788 <panic>

0000000080000bae <pop_off>:

void
pop_off(void)
{
    80000bae:	1141                	addi	sp,sp,-16
    80000bb0:	e406                	sd	ra,8(sp)
    80000bb2:	e022                	sd	s0,0(sp)
    80000bb4:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000bb6:	4f5000ef          	jal	ra,800018aa <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bba:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000bbe:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000bc0:	e78d                	bnez	a5,80000bea <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000bc2:	5d3c                	lw	a5,120(a0)
    80000bc4:	02f05963          	blez	a5,80000bf6 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000bc8:	37fd                	addiw	a5,a5,-1
    80000bca:	0007871b          	sext.w	a4,a5
    80000bce:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000bd0:	eb09                	bnez	a4,80000be2 <pop_off+0x34>
    80000bd2:	5d7c                	lw	a5,124(a0)
    80000bd4:	c799                	beqz	a5,80000be2 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bd6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000bda:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000bde:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000be2:	60a2                	ld	ra,8(sp)
    80000be4:	6402                	ld	s0,0(sp)
    80000be6:	0141                	addi	sp,sp,16
    80000be8:	8082                	ret
    panic("pop_off - interruptible");
    80000bea:	00006517          	auipc	a0,0x6
    80000bee:	48650513          	addi	a0,a0,1158 # 80007070 <digits+0x38>
    80000bf2:	b97ff0ef          	jal	ra,80000788 <panic>
    panic("pop_off");
    80000bf6:	00006517          	auipc	a0,0x6
    80000bfa:	49250513          	addi	a0,a0,1170 # 80007088 <digits+0x50>
    80000bfe:	b8bff0ef          	jal	ra,80000788 <panic>

0000000080000c02 <release>:
{
    80000c02:	1101                	addi	sp,sp,-32
    80000c04:	ec06                	sd	ra,24(sp)
    80000c06:	e822                	sd	s0,16(sp)
    80000c08:	e426                	sd	s1,8(sp)
    80000c0a:	1000                	addi	s0,sp,32
    80000c0c:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c0e:	ef3ff0ef          	jal	ra,80000b00 <holding>
    80000c12:	c105                	beqz	a0,80000c32 <release+0x30>
  lk->cpu = 0;
    80000c14:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000c18:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000c1c:	0f50000f          	fence	iorw,ow
    80000c20:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000c24:	f8bff0ef          	jal	ra,80000bae <pop_off>
}
    80000c28:	60e2                	ld	ra,24(sp)
    80000c2a:	6442                	ld	s0,16(sp)
    80000c2c:	64a2                	ld	s1,8(sp)
    80000c2e:	6105                	addi	sp,sp,32
    80000c30:	8082                	ret
    panic("release");
    80000c32:	00006517          	auipc	a0,0x6
    80000c36:	45e50513          	addi	a0,a0,1118 # 80007090 <digits+0x58>
    80000c3a:	b4fff0ef          	jal	ra,80000788 <panic>

0000000080000c3e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000c3e:	1141                	addi	sp,sp,-16
    80000c40:	e422                	sd	s0,8(sp)
    80000c42:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000c44:	ca19                	beqz	a2,80000c5a <memset+0x1c>
    80000c46:	87aa                	mv	a5,a0
    80000c48:	1602                	slli	a2,a2,0x20
    80000c4a:	9201                	srli	a2,a2,0x20
    80000c4c:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000c50:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000c54:	0785                	addi	a5,a5,1
    80000c56:	fee79de3          	bne	a5,a4,80000c50 <memset+0x12>
  }
  return dst;
}
    80000c5a:	6422                	ld	s0,8(sp)
    80000c5c:	0141                	addi	sp,sp,16
    80000c5e:	8082                	ret

0000000080000c60 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000c60:	1141                	addi	sp,sp,-16
    80000c62:	e422                	sd	s0,8(sp)
    80000c64:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000c66:	ca05                	beqz	a2,80000c96 <memcmp+0x36>
    80000c68:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000c6c:	1682                	slli	a3,a3,0x20
    80000c6e:	9281                	srli	a3,a3,0x20
    80000c70:	0685                	addi	a3,a3,1
    80000c72:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000c74:	00054783          	lbu	a5,0(a0)
    80000c78:	0005c703          	lbu	a4,0(a1)
    80000c7c:	00e79863          	bne	a5,a4,80000c8c <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000c80:	0505                	addi	a0,a0,1
    80000c82:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000c84:	fed518e3          	bne	a0,a3,80000c74 <memcmp+0x14>
  }

  return 0;
    80000c88:	4501                	li	a0,0
    80000c8a:	a019                	j	80000c90 <memcmp+0x30>
      return *s1 - *s2;
    80000c8c:	40e7853b          	subw	a0,a5,a4
}
    80000c90:	6422                	ld	s0,8(sp)
    80000c92:	0141                	addi	sp,sp,16
    80000c94:	8082                	ret
  return 0;
    80000c96:	4501                	li	a0,0
    80000c98:	bfe5                	j	80000c90 <memcmp+0x30>

0000000080000c9a <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000c9a:	1141                	addi	sp,sp,-16
    80000c9c:	e422                	sd	s0,8(sp)
    80000c9e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000ca0:	c205                	beqz	a2,80000cc0 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000ca2:	02a5e263          	bltu	a1,a0,80000cc6 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000ca6:	1602                	slli	a2,a2,0x20
    80000ca8:	9201                	srli	a2,a2,0x20
    80000caa:	00c587b3          	add	a5,a1,a2
{
    80000cae:	872a                	mv	a4,a0
      *d++ = *s++;
    80000cb0:	0585                	addi	a1,a1,1
    80000cb2:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdd319>
    80000cb4:	fff5c683          	lbu	a3,-1(a1)
    80000cb8:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000cbc:	fef59ae3          	bne	a1,a5,80000cb0 <memmove+0x16>

  return dst;
}
    80000cc0:	6422                	ld	s0,8(sp)
    80000cc2:	0141                	addi	sp,sp,16
    80000cc4:	8082                	ret
  if(s < d && s + n > d){
    80000cc6:	02061693          	slli	a3,a2,0x20
    80000cca:	9281                	srli	a3,a3,0x20
    80000ccc:	00d58733          	add	a4,a1,a3
    80000cd0:	fce57be3          	bgeu	a0,a4,80000ca6 <memmove+0xc>
    d += n;
    80000cd4:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000cd6:	fff6079b          	addiw	a5,a2,-1
    80000cda:	1782                	slli	a5,a5,0x20
    80000cdc:	9381                	srli	a5,a5,0x20
    80000cde:	fff7c793          	not	a5,a5
    80000ce2:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000ce4:	177d                	addi	a4,a4,-1
    80000ce6:	16fd                	addi	a3,a3,-1
    80000ce8:	00074603          	lbu	a2,0(a4)
    80000cec:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000cf0:	fee79ae3          	bne	a5,a4,80000ce4 <memmove+0x4a>
    80000cf4:	b7f1                	j	80000cc0 <memmove+0x26>

0000000080000cf6 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000cf6:	1141                	addi	sp,sp,-16
    80000cf8:	e406                	sd	ra,8(sp)
    80000cfa:	e022                	sd	s0,0(sp)
    80000cfc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000cfe:	f9dff0ef          	jal	ra,80000c9a <memmove>
}
    80000d02:	60a2                	ld	ra,8(sp)
    80000d04:	6402                	ld	s0,0(sp)
    80000d06:	0141                	addi	sp,sp,16
    80000d08:	8082                	ret

0000000080000d0a <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d0a:	1141                	addi	sp,sp,-16
    80000d0c:	e422                	sd	s0,8(sp)
    80000d0e:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000d10:	ce11                	beqz	a2,80000d2c <strncmp+0x22>
    80000d12:	00054783          	lbu	a5,0(a0)
    80000d16:	cf89                	beqz	a5,80000d30 <strncmp+0x26>
    80000d18:	0005c703          	lbu	a4,0(a1)
    80000d1c:	00f71a63          	bne	a4,a5,80000d30 <strncmp+0x26>
    n--, p++, q++;
    80000d20:	367d                	addiw	a2,a2,-1
    80000d22:	0505                	addi	a0,a0,1
    80000d24:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000d26:	f675                	bnez	a2,80000d12 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000d28:	4501                	li	a0,0
    80000d2a:	a809                	j	80000d3c <strncmp+0x32>
    80000d2c:	4501                	li	a0,0
    80000d2e:	a039                	j	80000d3c <strncmp+0x32>
  if(n == 0)
    80000d30:	ca09                	beqz	a2,80000d42 <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000d32:	00054503          	lbu	a0,0(a0)
    80000d36:	0005c783          	lbu	a5,0(a1)
    80000d3a:	9d1d                	subw	a0,a0,a5
}
    80000d3c:	6422                	ld	s0,8(sp)
    80000d3e:	0141                	addi	sp,sp,16
    80000d40:	8082                	ret
    return 0;
    80000d42:	4501                	li	a0,0
    80000d44:	bfe5                	j	80000d3c <strncmp+0x32>

0000000080000d46 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000d46:	1141                	addi	sp,sp,-16
    80000d48:	e422                	sd	s0,8(sp)
    80000d4a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000d4c:	872a                	mv	a4,a0
    80000d4e:	8832                	mv	a6,a2
    80000d50:	367d                	addiw	a2,a2,-1
    80000d52:	01005963          	blez	a6,80000d64 <strncpy+0x1e>
    80000d56:	0705                	addi	a4,a4,1
    80000d58:	0005c783          	lbu	a5,0(a1)
    80000d5c:	fef70fa3          	sb	a5,-1(a4)
    80000d60:	0585                	addi	a1,a1,1
    80000d62:	f7f5                	bnez	a5,80000d4e <strncpy+0x8>
    ;
  while(n-- > 0)
    80000d64:	86ba                	mv	a3,a4
    80000d66:	00c05c63          	blez	a2,80000d7e <strncpy+0x38>
    *s++ = 0;
    80000d6a:	0685                	addi	a3,a3,1
    80000d6c:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000d70:	40d707bb          	subw	a5,a4,a3
    80000d74:	37fd                	addiw	a5,a5,-1
    80000d76:	010787bb          	addw	a5,a5,a6
    80000d7a:	fef048e3          	bgtz	a5,80000d6a <strncpy+0x24>
  return os;
}
    80000d7e:	6422                	ld	s0,8(sp)
    80000d80:	0141                	addi	sp,sp,16
    80000d82:	8082                	ret

0000000080000d84 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000d84:	1141                	addi	sp,sp,-16
    80000d86:	e422                	sd	s0,8(sp)
    80000d88:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000d8a:	02c05363          	blez	a2,80000db0 <safestrcpy+0x2c>
    80000d8e:	fff6069b          	addiw	a3,a2,-1
    80000d92:	1682                	slli	a3,a3,0x20
    80000d94:	9281                	srli	a3,a3,0x20
    80000d96:	96ae                	add	a3,a3,a1
    80000d98:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000d9a:	00d58963          	beq	a1,a3,80000dac <safestrcpy+0x28>
    80000d9e:	0585                	addi	a1,a1,1
    80000da0:	0785                	addi	a5,a5,1
    80000da2:	fff5c703          	lbu	a4,-1(a1)
    80000da6:	fee78fa3          	sb	a4,-1(a5)
    80000daa:	fb65                	bnez	a4,80000d9a <safestrcpy+0x16>
    ;
  *s = 0;
    80000dac:	00078023          	sb	zero,0(a5)
  return os;
}
    80000db0:	6422                	ld	s0,8(sp)
    80000db2:	0141                	addi	sp,sp,16
    80000db4:	8082                	ret

0000000080000db6 <strlen>:

int
strlen(const char *s)
{
    80000db6:	1141                	addi	sp,sp,-16
    80000db8:	e422                	sd	s0,8(sp)
    80000dba:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000dbc:	00054783          	lbu	a5,0(a0)
    80000dc0:	cf91                	beqz	a5,80000ddc <strlen+0x26>
    80000dc2:	0505                	addi	a0,a0,1
    80000dc4:	87aa                	mv	a5,a0
    80000dc6:	4685                	li	a3,1
    80000dc8:	9e89                	subw	a3,a3,a0
    80000dca:	00f6853b          	addw	a0,a3,a5
    80000dce:	0785                	addi	a5,a5,1
    80000dd0:	fff7c703          	lbu	a4,-1(a5)
    80000dd4:	fb7d                	bnez	a4,80000dca <strlen+0x14>
    ;
  return n;
}
    80000dd6:	6422                	ld	s0,8(sp)
    80000dd8:	0141                	addi	sp,sp,16
    80000dda:	8082                	ret
  for(n = 0; s[n]; n++)
    80000ddc:	4501                	li	a0,0
    80000dde:	bfe5                	j	80000dd6 <strlen+0x20>

0000000080000de0 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000de0:	1141                	addi	sp,sp,-16
    80000de2:	e406                	sd	ra,8(sp)
    80000de4:	e022                	sd	s0,0(sp)
    80000de6:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000de8:	2b3000ef          	jal	ra,8000189a <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000dec:	00007717          	auipc	a4,0x7
    80000df0:	bc470713          	addi	a4,a4,-1084 # 800079b0 <started>
  if(cpuid() == 0){
    80000df4:	c51d                	beqz	a0,80000e22 <main+0x42>
    while(started == 0)
    80000df6:	431c                	lw	a5,0(a4)
    80000df8:	2781                	sext.w	a5,a5
    80000dfa:	dff5                	beqz	a5,80000df6 <main+0x16>
      ;
    __sync_synchronize();
    80000dfc:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e00:	29b000ef          	jal	ra,8000189a <cpuid>
    80000e04:	85aa                	mv	a1,a0
    80000e06:	00006517          	auipc	a0,0x6
    80000e0a:	2aa50513          	addi	a0,a0,682 # 800070b0 <digits+0x78>
    80000e0e:	eb4ff0ef          	jal	ra,800004c2 <printf>
    kvminithart();    // turn on paging
    80000e12:	080000ef          	jal	ra,80000e92 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000e16:	003010ef          	jal	ra,80002618 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000e1a:	72a040ef          	jal	ra,80005544 <plicinithart>
  }

  scheduler();        
    80000e1e:	733000ef          	jal	ra,80001d50 <scheduler>
    consoleinit();
    80000e22:	dcaff0ef          	jal	ra,800003ec <consoleinit>
    printfinit();
    80000e26:	99fff0ef          	jal	ra,800007c4 <printfinit>
    printf("\n");
    80000e2a:	00006517          	auipc	a0,0x6
    80000e2e:	29650513          	addi	a0,a0,662 # 800070c0 <digits+0x88>
    80000e32:	e90ff0ef          	jal	ra,800004c2 <printf>
    printf("xv6 kernel is booting\n");
    80000e36:	00006517          	auipc	a0,0x6
    80000e3a:	26250513          	addi	a0,a0,610 # 80007098 <digits+0x60>
    80000e3e:	e84ff0ef          	jal	ra,800004c2 <printf>
    printf("\n");
    80000e42:	00006517          	auipc	a0,0x6
    80000e46:	27e50513          	addi	a0,a0,638 # 800070c0 <digits+0x88>
    80000e4a:	e78ff0ef          	jal	ra,800004c2 <printf>
    kinit();         // physical page allocator
    80000e4e:	c19ff0ef          	jal	ra,80000a66 <kinit>
    kvminit();       // create kernel page table
    80000e52:	2ca000ef          	jal	ra,8000111c <kvminit>
    kvminithart();   // turn on paging
    80000e56:	03c000ef          	jal	ra,80000e92 <kvminithart>
    procinit();      // process table
    80000e5a:	199000ef          	jal	ra,800017f2 <procinit>
    trapinit();      // trap vectors
    80000e5e:	796010ef          	jal	ra,800025f4 <trapinit>
    trapinithart();  // install kernel trap vector
    80000e62:	7b6010ef          	jal	ra,80002618 <trapinithart>
    plicinit();      // set up interrupt controller
    80000e66:	6c8040ef          	jal	ra,8000552e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000e6a:	6da040ef          	jal	ra,80005544 <plicinithart>
    binit();         // buffer cache
    80000e6e:	677010ef          	jal	ra,80002ce4 <binit>
    iinit();         // inode table
    80000e72:	3e6020ef          	jal	ra,80003258 <iinit>
    fileinit();      // file table
    80000e76:	2ce030ef          	jal	ra,80004144 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000e7a:	7ba040ef          	jal	ra,80005634 <virtio_disk_init>
    userinit();      // first user process
    80000e7e:	529000ef          	jal	ra,80001ba6 <userinit>
    __sync_synchronize();
    80000e82:	0ff0000f          	fence
    started = 1;
    80000e86:	4785                	li	a5,1
    80000e88:	00007717          	auipc	a4,0x7
    80000e8c:	b2f72423          	sw	a5,-1240(a4) # 800079b0 <started>
    80000e90:	b779                	j	80000e1e <main+0x3e>

0000000080000e92 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000e92:	1141                	addi	sp,sp,-16
    80000e94:	e422                	sd	s0,8(sp)
    80000e96:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000e98:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000e9c:	00007797          	auipc	a5,0x7
    80000ea0:	b1c7b783          	ld	a5,-1252(a5) # 800079b8 <kernel_pagetable>
    80000ea4:	83b1                	srli	a5,a5,0xc
    80000ea6:	577d                	li	a4,-1
    80000ea8:	177e                	slli	a4,a4,0x3f
    80000eaa:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000eac:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000eb0:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000eb4:	6422                	ld	s0,8(sp)
    80000eb6:	0141                	addi	sp,sp,16
    80000eb8:	8082                	ret

0000000080000eba <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000eba:	7139                	addi	sp,sp,-64
    80000ebc:	fc06                	sd	ra,56(sp)
    80000ebe:	f822                	sd	s0,48(sp)
    80000ec0:	f426                	sd	s1,40(sp)
    80000ec2:	f04a                	sd	s2,32(sp)
    80000ec4:	ec4e                	sd	s3,24(sp)
    80000ec6:	e852                	sd	s4,16(sp)
    80000ec8:	e456                	sd	s5,8(sp)
    80000eca:	e05a                	sd	s6,0(sp)
    80000ecc:	0080                	addi	s0,sp,64
    80000ece:	84aa                	mv	s1,a0
    80000ed0:	89ae                	mv	s3,a1
    80000ed2:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000ed4:	57fd                	li	a5,-1
    80000ed6:	83e9                	srli	a5,a5,0x1a
    80000ed8:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000eda:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000edc:	02b7fc63          	bgeu	a5,a1,80000f14 <walk+0x5a>
    panic("walk");
    80000ee0:	00006517          	auipc	a0,0x6
    80000ee4:	1e850513          	addi	a0,a0,488 # 800070c8 <digits+0x90>
    80000ee8:	8a1ff0ef          	jal	ra,80000788 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000eec:	060a8263          	beqz	s5,80000f50 <walk+0x96>
    80000ef0:	babff0ef          	jal	ra,80000a9a <kalloc>
    80000ef4:	84aa                	mv	s1,a0
    80000ef6:	c139                	beqz	a0,80000f3c <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000ef8:	6605                	lui	a2,0x1
    80000efa:	4581                	li	a1,0
    80000efc:	d43ff0ef          	jal	ra,80000c3e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f00:	00c4d793          	srli	a5,s1,0xc
    80000f04:	07aa                	slli	a5,a5,0xa
    80000f06:	0017e793          	ori	a5,a5,1
    80000f0a:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000f0e:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffdd30f>
    80000f10:	036a0063          	beq	s4,s6,80000f30 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f14:	0149d933          	srl	s2,s3,s4
    80000f18:	1ff97913          	andi	s2,s2,511
    80000f1c:	090e                	slli	s2,s2,0x3
    80000f1e:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000f20:	00093483          	ld	s1,0(s2)
    80000f24:	0014f793          	andi	a5,s1,1
    80000f28:	d3f1                	beqz	a5,80000eec <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f2a:	80a9                	srli	s1,s1,0xa
    80000f2c:	04b2                	slli	s1,s1,0xc
    80000f2e:	b7c5                	j	80000f0e <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f30:	00c9d513          	srli	a0,s3,0xc
    80000f34:	1ff57513          	andi	a0,a0,511
    80000f38:	050e                	slli	a0,a0,0x3
    80000f3a:	9526                	add	a0,a0,s1
}
    80000f3c:	70e2                	ld	ra,56(sp)
    80000f3e:	7442                	ld	s0,48(sp)
    80000f40:	74a2                	ld	s1,40(sp)
    80000f42:	7902                	ld	s2,32(sp)
    80000f44:	69e2                	ld	s3,24(sp)
    80000f46:	6a42                	ld	s4,16(sp)
    80000f48:	6aa2                	ld	s5,8(sp)
    80000f4a:	6b02                	ld	s6,0(sp)
    80000f4c:	6121                	addi	sp,sp,64
    80000f4e:	8082                	ret
        return 0;
    80000f50:	4501                	li	a0,0
    80000f52:	b7ed                	j	80000f3c <walk+0x82>

0000000080000f54 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000f54:	57fd                	li	a5,-1
    80000f56:	83e9                	srli	a5,a5,0x1a
    80000f58:	00b7f463          	bgeu	a5,a1,80000f60 <walkaddr+0xc>
    return 0;
    80000f5c:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000f5e:	8082                	ret
{
    80000f60:	1141                	addi	sp,sp,-16
    80000f62:	e406                	sd	ra,8(sp)
    80000f64:	e022                	sd	s0,0(sp)
    80000f66:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000f68:	4601                	li	a2,0
    80000f6a:	f51ff0ef          	jal	ra,80000eba <walk>
  if(pte == 0)
    80000f6e:	c105                	beqz	a0,80000f8e <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000f70:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000f72:	0117f693          	andi	a3,a5,17
    80000f76:	4745                	li	a4,17
    return 0;
    80000f78:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000f7a:	00e68663          	beq	a3,a4,80000f86 <walkaddr+0x32>
}
    80000f7e:	60a2                	ld	ra,8(sp)
    80000f80:	6402                	ld	s0,0(sp)
    80000f82:	0141                	addi	sp,sp,16
    80000f84:	8082                	ret
  pa = PTE2PA(*pte);
    80000f86:	83a9                	srli	a5,a5,0xa
    80000f88:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000f8c:	bfcd                	j	80000f7e <walkaddr+0x2a>
    return 0;
    80000f8e:	4501                	li	a0,0
    80000f90:	b7fd                	j	80000f7e <walkaddr+0x2a>

0000000080000f92 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000f92:	715d                	addi	sp,sp,-80
    80000f94:	e486                	sd	ra,72(sp)
    80000f96:	e0a2                	sd	s0,64(sp)
    80000f98:	fc26                	sd	s1,56(sp)
    80000f9a:	f84a                	sd	s2,48(sp)
    80000f9c:	f44e                	sd	s3,40(sp)
    80000f9e:	f052                	sd	s4,32(sp)
    80000fa0:	ec56                	sd	s5,24(sp)
    80000fa2:	e85a                	sd	s6,16(sp)
    80000fa4:	e45e                	sd	s7,8(sp)
    80000fa6:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80000fa8:	03459793          	slli	a5,a1,0x34
    80000fac:	e7a9                	bnez	a5,80000ff6 <mappages+0x64>
    80000fae:	8aaa                	mv	s5,a0
    80000fb0:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80000fb2:	03461793          	slli	a5,a2,0x34
    80000fb6:	e7b1                	bnez	a5,80001002 <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    80000fb8:	ca39                	beqz	a2,8000100e <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80000fba:	77fd                	lui	a5,0xfffff
    80000fbc:	963e                	add	a2,a2,a5
    80000fbe:	00b609b3          	add	s3,a2,a1
  a = va;
    80000fc2:	892e                	mv	s2,a1
    80000fc4:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80000fc8:	6b85                	lui	s7,0x1
    80000fca:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    80000fce:	4605                	li	a2,1
    80000fd0:	85ca                	mv	a1,s2
    80000fd2:	8556                	mv	a0,s5
    80000fd4:	ee7ff0ef          	jal	ra,80000eba <walk>
    80000fd8:	c539                	beqz	a0,80001026 <mappages+0x94>
    if(*pte & PTE_V)
    80000fda:	611c                	ld	a5,0(a0)
    80000fdc:	8b85                	andi	a5,a5,1
    80000fde:	ef95                	bnez	a5,8000101a <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000fe0:	80b1                	srli	s1,s1,0xc
    80000fe2:	04aa                	slli	s1,s1,0xa
    80000fe4:	0164e4b3          	or	s1,s1,s6
    80000fe8:	0014e493          	ori	s1,s1,1
    80000fec:	e104                	sd	s1,0(a0)
    if(a == last)
    80000fee:	05390863          	beq	s2,s3,8000103e <mappages+0xac>
    a += PGSIZE;
    80000ff2:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80000ff4:	bfd9                	j	80000fca <mappages+0x38>
    panic("mappages: va not aligned");
    80000ff6:	00006517          	auipc	a0,0x6
    80000ffa:	0da50513          	addi	a0,a0,218 # 800070d0 <digits+0x98>
    80000ffe:	f8aff0ef          	jal	ra,80000788 <panic>
    panic("mappages: size not aligned");
    80001002:	00006517          	auipc	a0,0x6
    80001006:	0ee50513          	addi	a0,a0,238 # 800070f0 <digits+0xb8>
    8000100a:	f7eff0ef          	jal	ra,80000788 <panic>
    panic("mappages: size");
    8000100e:	00006517          	auipc	a0,0x6
    80001012:	10250513          	addi	a0,a0,258 # 80007110 <digits+0xd8>
    80001016:	f72ff0ef          	jal	ra,80000788 <panic>
      panic("mappages: remap");
    8000101a:	00006517          	auipc	a0,0x6
    8000101e:	10650513          	addi	a0,a0,262 # 80007120 <digits+0xe8>
    80001022:	f66ff0ef          	jal	ra,80000788 <panic>
      return -1;
    80001026:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001028:	60a6                	ld	ra,72(sp)
    8000102a:	6406                	ld	s0,64(sp)
    8000102c:	74e2                	ld	s1,56(sp)
    8000102e:	7942                	ld	s2,48(sp)
    80001030:	79a2                	ld	s3,40(sp)
    80001032:	7a02                	ld	s4,32(sp)
    80001034:	6ae2                	ld	s5,24(sp)
    80001036:	6b42                	ld	s6,16(sp)
    80001038:	6ba2                	ld	s7,8(sp)
    8000103a:	6161                	addi	sp,sp,80
    8000103c:	8082                	ret
  return 0;
    8000103e:	4501                	li	a0,0
    80001040:	b7e5                	j	80001028 <mappages+0x96>

0000000080001042 <kvmmap>:
{
    80001042:	1141                	addi	sp,sp,-16
    80001044:	e406                	sd	ra,8(sp)
    80001046:	e022                	sd	s0,0(sp)
    80001048:	0800                	addi	s0,sp,16
    8000104a:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000104c:	86b2                	mv	a3,a2
    8000104e:	863e                	mv	a2,a5
    80001050:	f43ff0ef          	jal	ra,80000f92 <mappages>
    80001054:	e509                	bnez	a0,8000105e <kvmmap+0x1c>
}
    80001056:	60a2                	ld	ra,8(sp)
    80001058:	6402                	ld	s0,0(sp)
    8000105a:	0141                	addi	sp,sp,16
    8000105c:	8082                	ret
    panic("kvmmap");
    8000105e:	00006517          	auipc	a0,0x6
    80001062:	0d250513          	addi	a0,a0,210 # 80007130 <digits+0xf8>
    80001066:	f22ff0ef          	jal	ra,80000788 <panic>

000000008000106a <kvmmake>:
{
    8000106a:	1101                	addi	sp,sp,-32
    8000106c:	ec06                	sd	ra,24(sp)
    8000106e:	e822                	sd	s0,16(sp)
    80001070:	e426                	sd	s1,8(sp)
    80001072:	e04a                	sd	s2,0(sp)
    80001074:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001076:	a25ff0ef          	jal	ra,80000a9a <kalloc>
    8000107a:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000107c:	6605                	lui	a2,0x1
    8000107e:	4581                	li	a1,0
    80001080:	bbfff0ef          	jal	ra,80000c3e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001084:	4719                	li	a4,6
    80001086:	6685                	lui	a3,0x1
    80001088:	10000637          	lui	a2,0x10000
    8000108c:	100005b7          	lui	a1,0x10000
    80001090:	8526                	mv	a0,s1
    80001092:	fb1ff0ef          	jal	ra,80001042 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001096:	4719                	li	a4,6
    80001098:	6685                	lui	a3,0x1
    8000109a:	10001637          	lui	a2,0x10001
    8000109e:	100015b7          	lui	a1,0x10001
    800010a2:	8526                	mv	a0,s1
    800010a4:	f9fff0ef          	jal	ra,80001042 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800010a8:	4719                	li	a4,6
    800010aa:	040006b7          	lui	a3,0x4000
    800010ae:	0c000637          	lui	a2,0xc000
    800010b2:	0c0005b7          	lui	a1,0xc000
    800010b6:	8526                	mv	a0,s1
    800010b8:	f8bff0ef          	jal	ra,80001042 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800010bc:	00006917          	auipc	s2,0x6
    800010c0:	f4490913          	addi	s2,s2,-188 # 80007000 <etext>
    800010c4:	4729                	li	a4,10
    800010c6:	80006697          	auipc	a3,0x80006
    800010ca:	f3a68693          	addi	a3,a3,-198 # 7000 <_entry-0x7fff9000>
    800010ce:	4605                	li	a2,1
    800010d0:	067e                	slli	a2,a2,0x1f
    800010d2:	85b2                	mv	a1,a2
    800010d4:	8526                	mv	a0,s1
    800010d6:	f6dff0ef          	jal	ra,80001042 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800010da:	4719                	li	a4,6
    800010dc:	46c5                	li	a3,17
    800010de:	06ee                	slli	a3,a3,0x1b
    800010e0:	412686b3          	sub	a3,a3,s2
    800010e4:	864a                	mv	a2,s2
    800010e6:	85ca                	mv	a1,s2
    800010e8:	8526                	mv	a0,s1
    800010ea:	f59ff0ef          	jal	ra,80001042 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800010ee:	4729                	li	a4,10
    800010f0:	6685                	lui	a3,0x1
    800010f2:	00005617          	auipc	a2,0x5
    800010f6:	f0e60613          	addi	a2,a2,-242 # 80006000 <_trampoline>
    800010fa:	040005b7          	lui	a1,0x4000
    800010fe:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001100:	05b2                	slli	a1,a1,0xc
    80001102:	8526                	mv	a0,s1
    80001104:	f3fff0ef          	jal	ra,80001042 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001108:	8526                	mv	a0,s1
    8000110a:	65e000ef          	jal	ra,80001768 <proc_mapstacks>
}
    8000110e:	8526                	mv	a0,s1
    80001110:	60e2                	ld	ra,24(sp)
    80001112:	6442                	ld	s0,16(sp)
    80001114:	64a2                	ld	s1,8(sp)
    80001116:	6902                	ld	s2,0(sp)
    80001118:	6105                	addi	sp,sp,32
    8000111a:	8082                	ret

000000008000111c <kvminit>:
{
    8000111c:	1141                	addi	sp,sp,-16
    8000111e:	e406                	sd	ra,8(sp)
    80001120:	e022                	sd	s0,0(sp)
    80001122:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001124:	f47ff0ef          	jal	ra,8000106a <kvmmake>
    80001128:	00007797          	auipc	a5,0x7
    8000112c:	88a7b823          	sd	a0,-1904(a5) # 800079b8 <kernel_pagetable>
}
    80001130:	60a2                	ld	ra,8(sp)
    80001132:	6402                	ld	s0,0(sp)
    80001134:	0141                	addi	sp,sp,16
    80001136:	8082                	ret

0000000080001138 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001138:	1101                	addi	sp,sp,-32
    8000113a:	ec06                	sd	ra,24(sp)
    8000113c:	e822                	sd	s0,16(sp)
    8000113e:	e426                	sd	s1,8(sp)
    80001140:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001142:	959ff0ef          	jal	ra,80000a9a <kalloc>
    80001146:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001148:	c509                	beqz	a0,80001152 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000114a:	6605                	lui	a2,0x1
    8000114c:	4581                	li	a1,0
    8000114e:	af1ff0ef          	jal	ra,80000c3e <memset>
  return pagetable;
}
    80001152:	8526                	mv	a0,s1
    80001154:	60e2                	ld	ra,24(sp)
    80001156:	6442                	ld	s0,16(sp)
    80001158:	64a2                	ld	s1,8(sp)
    8000115a:	6105                	addi	sp,sp,32
    8000115c:	8082                	ret

000000008000115e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000115e:	7139                	addi	sp,sp,-64
    80001160:	fc06                	sd	ra,56(sp)
    80001162:	f822                	sd	s0,48(sp)
    80001164:	f426                	sd	s1,40(sp)
    80001166:	f04a                	sd	s2,32(sp)
    80001168:	ec4e                	sd	s3,24(sp)
    8000116a:	e852                	sd	s4,16(sp)
    8000116c:	e456                	sd	s5,8(sp)
    8000116e:	e05a                	sd	s6,0(sp)
    80001170:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001172:	03459793          	slli	a5,a1,0x34
    80001176:	e785                	bnez	a5,8000119e <uvmunmap+0x40>
    80001178:	8a2a                	mv	s4,a0
    8000117a:	892e                	mv	s2,a1
    8000117c:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000117e:	0632                	slli	a2,a2,0xc
    80001180:	00b609b3          	add	s3,a2,a1
    80001184:	6b05                	lui	s6,0x1
    80001186:	0335e763          	bltu	a1,s3,800011b4 <uvmunmap+0x56>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    8000118a:	70e2                	ld	ra,56(sp)
    8000118c:	7442                	ld	s0,48(sp)
    8000118e:	74a2                	ld	s1,40(sp)
    80001190:	7902                	ld	s2,32(sp)
    80001192:	69e2                	ld	s3,24(sp)
    80001194:	6a42                	ld	s4,16(sp)
    80001196:	6aa2                	ld	s5,8(sp)
    80001198:	6b02                	ld	s6,0(sp)
    8000119a:	6121                	addi	sp,sp,64
    8000119c:	8082                	ret
    panic("uvmunmap: not aligned");
    8000119e:	00006517          	auipc	a0,0x6
    800011a2:	f9a50513          	addi	a0,a0,-102 # 80007138 <digits+0x100>
    800011a6:	de2ff0ef          	jal	ra,80000788 <panic>
    *pte = 0;
    800011aa:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800011ae:	995a                	add	s2,s2,s6
    800011b0:	fd397de3          	bgeu	s2,s3,8000118a <uvmunmap+0x2c>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800011b4:	4601                	li	a2,0
    800011b6:	85ca                	mv	a1,s2
    800011b8:	8552                	mv	a0,s4
    800011ba:	d01ff0ef          	jal	ra,80000eba <walk>
    800011be:	84aa                	mv	s1,a0
    800011c0:	d57d                	beqz	a0,800011ae <uvmunmap+0x50>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    800011c2:	611c                	ld	a5,0(a0)
    800011c4:	0017f713          	andi	a4,a5,1
    800011c8:	d37d                	beqz	a4,800011ae <uvmunmap+0x50>
    if(do_free){
    800011ca:	fe0a80e3          	beqz	s5,800011aa <uvmunmap+0x4c>
      uint64 pa = PTE2PA(*pte);
    800011ce:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    800011d0:	00c79513          	slli	a0,a5,0xc
    800011d4:	fe4ff0ef          	jal	ra,800009b8 <kfree>
    800011d8:	bfc9                	j	800011aa <uvmunmap+0x4c>

00000000800011da <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800011da:	1101                	addi	sp,sp,-32
    800011dc:	ec06                	sd	ra,24(sp)
    800011de:	e822                	sd	s0,16(sp)
    800011e0:	e426                	sd	s1,8(sp)
    800011e2:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800011e4:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800011e6:	00b67d63          	bgeu	a2,a1,80001200 <uvmdealloc+0x26>
    800011ea:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800011ec:	6785                	lui	a5,0x1
    800011ee:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800011f0:	00f60733          	add	a4,a2,a5
    800011f4:	76fd                	lui	a3,0xfffff
    800011f6:	8f75                	and	a4,a4,a3
    800011f8:	97ae                	add	a5,a5,a1
    800011fa:	8ff5                	and	a5,a5,a3
    800011fc:	00f76863          	bltu	a4,a5,8000120c <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001200:	8526                	mv	a0,s1
    80001202:	60e2                	ld	ra,24(sp)
    80001204:	6442                	ld	s0,16(sp)
    80001206:	64a2                	ld	s1,8(sp)
    80001208:	6105                	addi	sp,sp,32
    8000120a:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000120c:	8f99                	sub	a5,a5,a4
    8000120e:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001210:	4685                	li	a3,1
    80001212:	0007861b          	sext.w	a2,a5
    80001216:	85ba                	mv	a1,a4
    80001218:	f47ff0ef          	jal	ra,8000115e <uvmunmap>
    8000121c:	b7d5                	j	80001200 <uvmdealloc+0x26>

000000008000121e <uvmalloc>:
  if(newsz < oldsz)
    8000121e:	08b66963          	bltu	a2,a1,800012b0 <uvmalloc+0x92>
{
    80001222:	7139                	addi	sp,sp,-64
    80001224:	fc06                	sd	ra,56(sp)
    80001226:	f822                	sd	s0,48(sp)
    80001228:	f426                	sd	s1,40(sp)
    8000122a:	f04a                	sd	s2,32(sp)
    8000122c:	ec4e                	sd	s3,24(sp)
    8000122e:	e852                	sd	s4,16(sp)
    80001230:	e456                	sd	s5,8(sp)
    80001232:	e05a                	sd	s6,0(sp)
    80001234:	0080                	addi	s0,sp,64
    80001236:	8aaa                	mv	s5,a0
    80001238:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000123a:	6785                	lui	a5,0x1
    8000123c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000123e:	95be                	add	a1,a1,a5
    80001240:	77fd                	lui	a5,0xfffff
    80001242:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001246:	06c9f763          	bgeu	s3,a2,800012b4 <uvmalloc+0x96>
    8000124a:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000124c:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001250:	84bff0ef          	jal	ra,80000a9a <kalloc>
    80001254:	84aa                	mv	s1,a0
    if(mem == 0){
    80001256:	c11d                	beqz	a0,8000127c <uvmalloc+0x5e>
    memset(mem, 0, PGSIZE);
    80001258:	6605                	lui	a2,0x1
    8000125a:	4581                	li	a1,0
    8000125c:	9e3ff0ef          	jal	ra,80000c3e <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001260:	875a                	mv	a4,s6
    80001262:	86a6                	mv	a3,s1
    80001264:	6605                	lui	a2,0x1
    80001266:	85ca                	mv	a1,s2
    80001268:	8556                	mv	a0,s5
    8000126a:	d29ff0ef          	jal	ra,80000f92 <mappages>
    8000126e:	e51d                	bnez	a0,8000129c <uvmalloc+0x7e>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001270:	6785                	lui	a5,0x1
    80001272:	993e                	add	s2,s2,a5
    80001274:	fd496ee3          	bltu	s2,s4,80001250 <uvmalloc+0x32>
  return newsz;
    80001278:	8552                	mv	a0,s4
    8000127a:	a039                	j	80001288 <uvmalloc+0x6a>
      uvmdealloc(pagetable, a, oldsz);
    8000127c:	864e                	mv	a2,s3
    8000127e:	85ca                	mv	a1,s2
    80001280:	8556                	mv	a0,s5
    80001282:	f59ff0ef          	jal	ra,800011da <uvmdealloc>
      return 0;
    80001286:	4501                	li	a0,0
}
    80001288:	70e2                	ld	ra,56(sp)
    8000128a:	7442                	ld	s0,48(sp)
    8000128c:	74a2                	ld	s1,40(sp)
    8000128e:	7902                	ld	s2,32(sp)
    80001290:	69e2                	ld	s3,24(sp)
    80001292:	6a42                	ld	s4,16(sp)
    80001294:	6aa2                	ld	s5,8(sp)
    80001296:	6b02                	ld	s6,0(sp)
    80001298:	6121                	addi	sp,sp,64
    8000129a:	8082                	ret
      kfree(mem);
    8000129c:	8526                	mv	a0,s1
    8000129e:	f1aff0ef          	jal	ra,800009b8 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800012a2:	864e                	mv	a2,s3
    800012a4:	85ca                	mv	a1,s2
    800012a6:	8556                	mv	a0,s5
    800012a8:	f33ff0ef          	jal	ra,800011da <uvmdealloc>
      return 0;
    800012ac:	4501                	li	a0,0
    800012ae:	bfe9                	j	80001288 <uvmalloc+0x6a>
    return oldsz;
    800012b0:	852e                	mv	a0,a1
}
    800012b2:	8082                	ret
  return newsz;
    800012b4:	8532                	mv	a0,a2
    800012b6:	bfc9                	j	80001288 <uvmalloc+0x6a>

00000000800012b8 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800012b8:	7179                	addi	sp,sp,-48
    800012ba:	f406                	sd	ra,40(sp)
    800012bc:	f022                	sd	s0,32(sp)
    800012be:	ec26                	sd	s1,24(sp)
    800012c0:	e84a                	sd	s2,16(sp)
    800012c2:	e44e                	sd	s3,8(sp)
    800012c4:	e052                	sd	s4,0(sp)
    800012c6:	1800                	addi	s0,sp,48
    800012c8:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800012ca:	84aa                	mv	s1,a0
    800012cc:	6905                	lui	s2,0x1
    800012ce:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800012d0:	4985                	li	s3,1
    800012d2:	a819                	j	800012e8 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800012d4:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800012d6:	00c79513          	slli	a0,a5,0xc
    800012da:	fdfff0ef          	jal	ra,800012b8 <freewalk>
      pagetable[i] = 0;
    800012de:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    800012e2:	04a1                	addi	s1,s1,8
    800012e4:	01248f63          	beq	s1,s2,80001302 <freewalk+0x4a>
    pte_t pte = pagetable[i];
    800012e8:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800012ea:	00f7f713          	andi	a4,a5,15
    800012ee:	ff3703e3          	beq	a4,s3,800012d4 <freewalk+0x1c>
    } else if(pte & PTE_V){
    800012f2:	8b85                	andi	a5,a5,1
    800012f4:	d7fd                	beqz	a5,800012e2 <freewalk+0x2a>
      panic("freewalk: leaf");
    800012f6:	00006517          	auipc	a0,0x6
    800012fa:	e5a50513          	addi	a0,a0,-422 # 80007150 <digits+0x118>
    800012fe:	c8aff0ef          	jal	ra,80000788 <panic>
    }
  }
  kfree((void*)pagetable);
    80001302:	8552                	mv	a0,s4
    80001304:	eb4ff0ef          	jal	ra,800009b8 <kfree>
}
    80001308:	70a2                	ld	ra,40(sp)
    8000130a:	7402                	ld	s0,32(sp)
    8000130c:	64e2                	ld	s1,24(sp)
    8000130e:	6942                	ld	s2,16(sp)
    80001310:	69a2                	ld	s3,8(sp)
    80001312:	6a02                	ld	s4,0(sp)
    80001314:	6145                	addi	sp,sp,48
    80001316:	8082                	ret

0000000080001318 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001318:	1101                	addi	sp,sp,-32
    8000131a:	ec06                	sd	ra,24(sp)
    8000131c:	e822                	sd	s0,16(sp)
    8000131e:	e426                	sd	s1,8(sp)
    80001320:	1000                	addi	s0,sp,32
    80001322:	84aa                	mv	s1,a0
  if(sz > 0)
    80001324:	e989                	bnez	a1,80001336 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001326:	8526                	mv	a0,s1
    80001328:	f91ff0ef          	jal	ra,800012b8 <freewalk>
}
    8000132c:	60e2                	ld	ra,24(sp)
    8000132e:	6442                	ld	s0,16(sp)
    80001330:	64a2                	ld	s1,8(sp)
    80001332:	6105                	addi	sp,sp,32
    80001334:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001336:	6785                	lui	a5,0x1
    80001338:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000133a:	95be                	add	a1,a1,a5
    8000133c:	4685                	li	a3,1
    8000133e:	00c5d613          	srli	a2,a1,0xc
    80001342:	4581                	li	a1,0
    80001344:	e1bff0ef          	jal	ra,8000115e <uvmunmap>
    80001348:	bff9                	j	80001326 <uvmfree+0xe>

000000008000134a <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    8000134a:	ce49                	beqz	a2,800013e4 <uvmcopy+0x9a>
{
    8000134c:	715d                	addi	sp,sp,-80
    8000134e:	e486                	sd	ra,72(sp)
    80001350:	e0a2                	sd	s0,64(sp)
    80001352:	fc26                	sd	s1,56(sp)
    80001354:	f84a                	sd	s2,48(sp)
    80001356:	f44e                	sd	s3,40(sp)
    80001358:	f052                	sd	s4,32(sp)
    8000135a:	ec56                	sd	s5,24(sp)
    8000135c:	e85a                	sd	s6,16(sp)
    8000135e:	e45e                	sd	s7,8(sp)
    80001360:	0880                	addi	s0,sp,80
    80001362:	8aaa                	mv	s5,a0
    80001364:	8b2e                	mv	s6,a1
    80001366:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001368:	4481                	li	s1,0
    8000136a:	a029                	j	80001374 <uvmcopy+0x2a>
    8000136c:	6785                	lui	a5,0x1
    8000136e:	94be                	add	s1,s1,a5
    80001370:	0544fe63          	bgeu	s1,s4,800013cc <uvmcopy+0x82>
    if((pte = walk(old, i, 0)) == 0)
    80001374:	4601                	li	a2,0
    80001376:	85a6                	mv	a1,s1
    80001378:	8556                	mv	a0,s5
    8000137a:	b41ff0ef          	jal	ra,80000eba <walk>
    8000137e:	d57d                	beqz	a0,8000136c <uvmcopy+0x22>
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
    80001380:	6118                	ld	a4,0(a0)
    80001382:	00177793          	andi	a5,a4,1
    80001386:	d3fd                	beqz	a5,8000136c <uvmcopy+0x22>
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    80001388:	00a75593          	srli	a1,a4,0xa
    8000138c:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80001390:	3ff77913          	andi	s2,a4,1023
    if((mem = kalloc()) == 0)
    80001394:	f06ff0ef          	jal	ra,80000a9a <kalloc>
    80001398:	89aa                	mv	s3,a0
    8000139a:	c105                	beqz	a0,800013ba <uvmcopy+0x70>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    8000139c:	6605                	lui	a2,0x1
    8000139e:	85de                	mv	a1,s7
    800013a0:	8fbff0ef          	jal	ra,80000c9a <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800013a4:	874a                	mv	a4,s2
    800013a6:	86ce                	mv	a3,s3
    800013a8:	6605                	lui	a2,0x1
    800013aa:	85a6                	mv	a1,s1
    800013ac:	855a                	mv	a0,s6
    800013ae:	be5ff0ef          	jal	ra,80000f92 <mappages>
    800013b2:	dd4d                	beqz	a0,8000136c <uvmcopy+0x22>
      kfree(mem);
    800013b4:	854e                	mv	a0,s3
    800013b6:	e02ff0ef          	jal	ra,800009b8 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800013ba:	4685                	li	a3,1
    800013bc:	00c4d613          	srli	a2,s1,0xc
    800013c0:	4581                	li	a1,0
    800013c2:	855a                	mv	a0,s6
    800013c4:	d9bff0ef          	jal	ra,8000115e <uvmunmap>
  return -1;
    800013c8:	557d                	li	a0,-1
    800013ca:	a011                	j	800013ce <uvmcopy+0x84>
  return 0;
    800013cc:	4501                	li	a0,0
}
    800013ce:	60a6                	ld	ra,72(sp)
    800013d0:	6406                	ld	s0,64(sp)
    800013d2:	74e2                	ld	s1,56(sp)
    800013d4:	7942                	ld	s2,48(sp)
    800013d6:	79a2                	ld	s3,40(sp)
    800013d8:	7a02                	ld	s4,32(sp)
    800013da:	6ae2                	ld	s5,24(sp)
    800013dc:	6b42                	ld	s6,16(sp)
    800013de:	6ba2                	ld	s7,8(sp)
    800013e0:	6161                	addi	sp,sp,80
    800013e2:	8082                	ret
  return 0;
    800013e4:	4501                	li	a0,0
}
    800013e6:	8082                	ret

00000000800013e8 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800013e8:	1141                	addi	sp,sp,-16
    800013ea:	e406                	sd	ra,8(sp)
    800013ec:	e022                	sd	s0,0(sp)
    800013ee:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800013f0:	4601                	li	a2,0
    800013f2:	ac9ff0ef          	jal	ra,80000eba <walk>
  if(pte == 0)
    800013f6:	c901                	beqz	a0,80001406 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800013f8:	611c                	ld	a5,0(a0)
    800013fa:	9bbd                	andi	a5,a5,-17
    800013fc:	e11c                	sd	a5,0(a0)
}
    800013fe:	60a2                	ld	ra,8(sp)
    80001400:	6402                	ld	s0,0(sp)
    80001402:	0141                	addi	sp,sp,16
    80001404:	8082                	ret
    panic("uvmclear");
    80001406:	00006517          	auipc	a0,0x6
    8000140a:	d5a50513          	addi	a0,a0,-678 # 80007160 <digits+0x128>
    8000140e:	b7aff0ef          	jal	ra,80000788 <panic>

0000000080001412 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001412:	c2cd                	beqz	a3,800014b4 <copyinstr+0xa2>
{
    80001414:	715d                	addi	sp,sp,-80
    80001416:	e486                	sd	ra,72(sp)
    80001418:	e0a2                	sd	s0,64(sp)
    8000141a:	fc26                	sd	s1,56(sp)
    8000141c:	f84a                	sd	s2,48(sp)
    8000141e:	f44e                	sd	s3,40(sp)
    80001420:	f052                	sd	s4,32(sp)
    80001422:	ec56                	sd	s5,24(sp)
    80001424:	e85a                	sd	s6,16(sp)
    80001426:	e45e                	sd	s7,8(sp)
    80001428:	0880                	addi	s0,sp,80
    8000142a:	8a2a                	mv	s4,a0
    8000142c:	8b2e                	mv	s6,a1
    8000142e:	8bb2                	mv	s7,a2
    80001430:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    80001432:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001434:	6985                	lui	s3,0x1
    80001436:	a02d                	j	80001460 <copyinstr+0x4e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80001438:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    8000143c:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    8000143e:	37fd                	addiw	a5,a5,-1
    80001440:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80001444:	60a6                	ld	ra,72(sp)
    80001446:	6406                	ld	s0,64(sp)
    80001448:	74e2                	ld	s1,56(sp)
    8000144a:	7942                	ld	s2,48(sp)
    8000144c:	79a2                	ld	s3,40(sp)
    8000144e:	7a02                	ld	s4,32(sp)
    80001450:	6ae2                	ld	s5,24(sp)
    80001452:	6b42                	ld	s6,16(sp)
    80001454:	6ba2                	ld	s7,8(sp)
    80001456:	6161                	addi	sp,sp,80
    80001458:	8082                	ret
    srcva = va0 + PGSIZE;
    8000145a:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    8000145e:	c4b9                	beqz	s1,800014ac <copyinstr+0x9a>
    va0 = PGROUNDDOWN(srcva);
    80001460:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    80001464:	85ca                	mv	a1,s2
    80001466:	8552                	mv	a0,s4
    80001468:	aedff0ef          	jal	ra,80000f54 <walkaddr>
    if(pa0 == 0)
    8000146c:	c131                	beqz	a0,800014b0 <copyinstr+0x9e>
    n = PGSIZE - (srcva - va0);
    8000146e:	417906b3          	sub	a3,s2,s7
    80001472:	96ce                	add	a3,a3,s3
    80001474:	00d4f363          	bgeu	s1,a3,8000147a <copyinstr+0x68>
    80001478:	86a6                	mv	a3,s1
    char *p = (char *) (pa0 + (srcva - va0));
    8000147a:	955e                	add	a0,a0,s7
    8000147c:	41250533          	sub	a0,a0,s2
    while(n > 0){
    80001480:	dee9                	beqz	a3,8000145a <copyinstr+0x48>
    80001482:	87da                	mv	a5,s6
      if(*p == '\0'){
    80001484:	41650633          	sub	a2,a0,s6
    80001488:	fff48593          	addi	a1,s1,-1
    8000148c:	95da                	add	a1,a1,s6
    while(n > 0){
    8000148e:	96da                	add	a3,a3,s6
      if(*p == '\0'){
    80001490:	00f60733          	add	a4,a2,a5
    80001494:	00074703          	lbu	a4,0(a4)
    80001498:	d345                	beqz	a4,80001438 <copyinstr+0x26>
        *dst = *p;
    8000149a:	00e78023          	sb	a4,0(a5)
      --max;
    8000149e:	40f584b3          	sub	s1,a1,a5
      dst++;
    800014a2:	0785                	addi	a5,a5,1
    while(n > 0){
    800014a4:	fed796e3          	bne	a5,a3,80001490 <copyinstr+0x7e>
      dst++;
    800014a8:	8b3e                	mv	s6,a5
    800014aa:	bf45                	j	8000145a <copyinstr+0x48>
    800014ac:	4781                	li	a5,0
    800014ae:	bf41                	j	8000143e <copyinstr+0x2c>
      return -1;
    800014b0:	557d                	li	a0,-1
    800014b2:	bf49                	j	80001444 <copyinstr+0x32>
  int got_null = 0;
    800014b4:	4781                	li	a5,0
  if(got_null){
    800014b6:	37fd                	addiw	a5,a5,-1
    800014b8:	0007851b          	sext.w	a0,a5
}
    800014bc:	8082                	ret

00000000800014be <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800014be:	1141                	addi	sp,sp,-16
    800014c0:	e406                	sd	ra,8(sp)
    800014c2:	e022                	sd	s0,0(sp)
    800014c4:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800014c6:	4601                	li	a2,0
    800014c8:	9f3ff0ef          	jal	ra,80000eba <walk>
  if (pte == 0) {
    800014cc:	c519                	beqz	a0,800014da <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    800014ce:	6108                	ld	a0,0(a0)
    return 0;
    800014d0:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800014d2:	60a2                	ld	ra,8(sp)
    800014d4:	6402                	ld	s0,0(sp)
    800014d6:	0141                	addi	sp,sp,16
    800014d8:	8082                	ret
    return 0;
    800014da:	4501                	li	a0,0
    800014dc:	bfdd                	j	800014d2 <ismapped+0x14>

00000000800014de <vmfault>:
{
    800014de:	7179                	addi	sp,sp,-48
    800014e0:	f406                	sd	ra,40(sp)
    800014e2:	f022                	sd	s0,32(sp)
    800014e4:	ec26                	sd	s1,24(sp)
    800014e6:	e84a                	sd	s2,16(sp)
    800014e8:	e44e                	sd	s3,8(sp)
    800014ea:	e052                	sd	s4,0(sp)
    800014ec:	1800                	addi	s0,sp,48
    800014ee:	89aa                	mv	s3,a0
    800014f0:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    800014f2:	3d4000ef          	jal	ra,800018c6 <myproc>
  if (va >= p->sz)
    800014f6:	653c                	ld	a5,72(a0)
    800014f8:	00f4ec63          	bltu	s1,a5,80001510 <vmfault+0x32>
    return 0;
    800014fc:	4981                	li	s3,0
}
    800014fe:	854e                	mv	a0,s3
    80001500:	70a2                	ld	ra,40(sp)
    80001502:	7402                	ld	s0,32(sp)
    80001504:	64e2                	ld	s1,24(sp)
    80001506:	6942                	ld	s2,16(sp)
    80001508:	69a2                	ld	s3,8(sp)
    8000150a:	6a02                	ld	s4,0(sp)
    8000150c:	6145                	addi	sp,sp,48
    8000150e:	8082                	ret
    80001510:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    80001512:	77fd                	lui	a5,0xfffff
    80001514:	8cfd                	and	s1,s1,a5
  if(ismapped(pagetable, va)) {
    80001516:	85a6                	mv	a1,s1
    80001518:	854e                	mv	a0,s3
    8000151a:	fa5ff0ef          	jal	ra,800014be <ismapped>
    return 0;
    8000151e:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    80001520:	fd79                	bnez	a0,800014fe <vmfault+0x20>
  mem = (uint64) kalloc();
    80001522:	d78ff0ef          	jal	ra,80000a9a <kalloc>
    80001526:	8a2a                	mv	s4,a0
  if(mem == 0)
    80001528:	d979                	beqz	a0,800014fe <vmfault+0x20>
  mem = (uint64) kalloc();
    8000152a:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    8000152c:	6605                	lui	a2,0x1
    8000152e:	4581                	li	a1,0
    80001530:	f0eff0ef          	jal	ra,80000c3e <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    80001534:	4759                	li	a4,22
    80001536:	86d2                	mv	a3,s4
    80001538:	6605                	lui	a2,0x1
    8000153a:	85a6                	mv	a1,s1
    8000153c:	05093503          	ld	a0,80(s2) # 1050 <_entry-0x7fffefb0>
    80001540:	a53ff0ef          	jal	ra,80000f92 <mappages>
    80001544:	dd4d                	beqz	a0,800014fe <vmfault+0x20>
    kfree((void *)mem);
    80001546:	8552                	mv	a0,s4
    80001548:	c70ff0ef          	jal	ra,800009b8 <kfree>
    return 0;
    8000154c:	4981                	li	s3,0
    8000154e:	bf45                	j	800014fe <vmfault+0x20>

0000000080001550 <copyout>:
  while(len > 0){
    80001550:	cec1                	beqz	a3,800015e8 <copyout+0x98>
{
    80001552:	711d                	addi	sp,sp,-96
    80001554:	ec86                	sd	ra,88(sp)
    80001556:	e8a2                	sd	s0,80(sp)
    80001558:	e4a6                	sd	s1,72(sp)
    8000155a:	e0ca                	sd	s2,64(sp)
    8000155c:	fc4e                	sd	s3,56(sp)
    8000155e:	f852                	sd	s4,48(sp)
    80001560:	f456                	sd	s5,40(sp)
    80001562:	f05a                	sd	s6,32(sp)
    80001564:	ec5e                	sd	s7,24(sp)
    80001566:	e862                	sd	s8,16(sp)
    80001568:	e466                	sd	s9,8(sp)
    8000156a:	e06a                	sd	s10,0(sp)
    8000156c:	1080                	addi	s0,sp,96
    8000156e:	8c2a                	mv	s8,a0
    80001570:	8b2e                	mv	s6,a1
    80001572:	8bb2                	mv	s7,a2
    80001574:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80001576:	74fd                	lui	s1,0xfffff
    80001578:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    8000157a:	57fd                	li	a5,-1
    8000157c:	83e9                	srli	a5,a5,0x1a
    8000157e:	0697e763          	bltu	a5,s1,800015ec <copyout+0x9c>
    80001582:	6d05                	lui	s10,0x1
    80001584:	8cbe                	mv	s9,a5
    80001586:	a015                	j	800015aa <copyout+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001588:	409b0533          	sub	a0,s6,s1
    8000158c:	0009861b          	sext.w	a2,s3
    80001590:	85de                	mv	a1,s7
    80001592:	954a                	add	a0,a0,s2
    80001594:	f06ff0ef          	jal	ra,80000c9a <memmove>
    len -= n;
    80001598:	413a0a33          	sub	s4,s4,s3
    src += n;
    8000159c:	9bce                	add	s7,s7,s3
  while(len > 0){
    8000159e:	040a0363          	beqz	s4,800015e4 <copyout+0x94>
    if(va0 >= MAXVA)
    800015a2:	055ce763          	bltu	s9,s5,800015f0 <copyout+0xa0>
    va0 = PGROUNDDOWN(dstva);
    800015a6:	84d6                	mv	s1,s5
    dstva = va0 + PGSIZE;
    800015a8:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    800015aa:	85a6                	mv	a1,s1
    800015ac:	8562                	mv	a0,s8
    800015ae:	9a7ff0ef          	jal	ra,80000f54 <walkaddr>
    800015b2:	892a                	mv	s2,a0
    if(pa0 == 0) {
    800015b4:	e901                	bnez	a0,800015c4 <copyout+0x74>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800015b6:	4601                	li	a2,0
    800015b8:	85a6                	mv	a1,s1
    800015ba:	8562                	mv	a0,s8
    800015bc:	f23ff0ef          	jal	ra,800014de <vmfault>
    800015c0:	892a                	mv	s2,a0
    800015c2:	c90d                	beqz	a0,800015f4 <copyout+0xa4>
    pte = walk(pagetable, va0, 0);
    800015c4:	4601                	li	a2,0
    800015c6:	85a6                	mv	a1,s1
    800015c8:	8562                	mv	a0,s8
    800015ca:	8f1ff0ef          	jal	ra,80000eba <walk>
    if((*pte & PTE_W) == 0)
    800015ce:	611c                	ld	a5,0(a0)
    800015d0:	8b91                	andi	a5,a5,4
    800015d2:	c39d                	beqz	a5,800015f8 <copyout+0xa8>
    n = PGSIZE - (dstva - va0);
    800015d4:	01a48ab3          	add	s5,s1,s10
    800015d8:	416a89b3          	sub	s3,s5,s6
    800015dc:	fb3a76e3          	bgeu	s4,s3,80001588 <copyout+0x38>
    800015e0:	89d2                	mv	s3,s4
    800015e2:	b75d                	j	80001588 <copyout+0x38>
  return 0;
    800015e4:	4501                	li	a0,0
    800015e6:	a811                	j	800015fa <copyout+0xaa>
    800015e8:	4501                	li	a0,0
}
    800015ea:	8082                	ret
      return -1;
    800015ec:	557d                	li	a0,-1
    800015ee:	a031                	j	800015fa <copyout+0xaa>
    800015f0:	557d                	li	a0,-1
    800015f2:	a021                	j	800015fa <copyout+0xaa>
        return -1;
    800015f4:	557d                	li	a0,-1
    800015f6:	a011                	j	800015fa <copyout+0xaa>
      return -1;
    800015f8:	557d                	li	a0,-1
}
    800015fa:	60e6                	ld	ra,88(sp)
    800015fc:	6446                	ld	s0,80(sp)
    800015fe:	64a6                	ld	s1,72(sp)
    80001600:	6906                	ld	s2,64(sp)
    80001602:	79e2                	ld	s3,56(sp)
    80001604:	7a42                	ld	s4,48(sp)
    80001606:	7aa2                	ld	s5,40(sp)
    80001608:	7b02                	ld	s6,32(sp)
    8000160a:	6be2                	ld	s7,24(sp)
    8000160c:	6c42                	ld	s8,16(sp)
    8000160e:	6ca2                	ld	s9,8(sp)
    80001610:	6d02                	ld	s10,0(sp)
    80001612:	6125                	addi	sp,sp,96
    80001614:	8082                	ret

0000000080001616 <copyin>:
  while(len > 0){
    80001616:	c6c9                	beqz	a3,800016a0 <copyin+0x8a>
{
    80001618:	715d                	addi	sp,sp,-80
    8000161a:	e486                	sd	ra,72(sp)
    8000161c:	e0a2                	sd	s0,64(sp)
    8000161e:	fc26                	sd	s1,56(sp)
    80001620:	f84a                	sd	s2,48(sp)
    80001622:	f44e                	sd	s3,40(sp)
    80001624:	f052                	sd	s4,32(sp)
    80001626:	ec56                	sd	s5,24(sp)
    80001628:	e85a                	sd	s6,16(sp)
    8000162a:	e45e                	sd	s7,8(sp)
    8000162c:	e062                	sd	s8,0(sp)
    8000162e:	0880                	addi	s0,sp,80
    80001630:	8baa                	mv	s7,a0
    80001632:	8aae                	mv	s5,a1
    80001634:	8932                	mv	s2,a2
    80001636:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    80001638:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    8000163a:	6b05                	lui	s6,0x1
    8000163c:	a035                	j	80001668 <copyin+0x52>
    8000163e:	412984b3          	sub	s1,s3,s2
    80001642:	94da                	add	s1,s1,s6
    80001644:	009a7363          	bgeu	s4,s1,8000164a <copyin+0x34>
    80001648:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000164a:	413905b3          	sub	a1,s2,s3
    8000164e:	0004861b          	sext.w	a2,s1
    80001652:	95aa                	add	a1,a1,a0
    80001654:	8556                	mv	a0,s5
    80001656:	e44ff0ef          	jal	ra,80000c9a <memmove>
    len -= n;
    8000165a:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000165e:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001660:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001664:	020a0163          	beqz	s4,80001686 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001668:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000166c:	85ce                	mv	a1,s3
    8000166e:	855e                	mv	a0,s7
    80001670:	8e5ff0ef          	jal	ra,80000f54 <walkaddr>
    if(pa0 == 0) {
    80001674:	f569                	bnez	a0,8000163e <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001676:	4601                	li	a2,0
    80001678:	85ce                	mv	a1,s3
    8000167a:	855e                	mv	a0,s7
    8000167c:	e63ff0ef          	jal	ra,800014de <vmfault>
    80001680:	fd5d                	bnez	a0,8000163e <copyin+0x28>
        return -1;
    80001682:	557d                	li	a0,-1
    80001684:	a011                	j	80001688 <copyin+0x72>
  return 0;
    80001686:	4501                	li	a0,0
}
    80001688:	60a6                	ld	ra,72(sp)
    8000168a:	6406                	ld	s0,64(sp)
    8000168c:	74e2                	ld	s1,56(sp)
    8000168e:	7942                	ld	s2,48(sp)
    80001690:	79a2                	ld	s3,40(sp)
    80001692:	7a02                	ld	s4,32(sp)
    80001694:	6ae2                	ld	s5,24(sp)
    80001696:	6b42                	ld	s6,16(sp)
    80001698:	6ba2                	ld	s7,8(sp)
    8000169a:	6c02                	ld	s8,0(sp)
    8000169c:	6161                	addi	sp,sp,80
    8000169e:	8082                	ret
  return 0;
    800016a0:	4501                	li	a0,0
}
    800016a2:	8082                	ret

00000000800016a4 <get_timeslice>:

// ============= NEW MLFQ HELPER FUNCTIONS - NEW CODE =============

// Get time slice for a given priority level
// Higher priority = shorter time slice for better responsiveness
int get_timeslice(int priority) {
    800016a4:	1141                	addi	sp,sp,-16
    800016a6:	e422                	sd	s0,8(sp)
    800016a8:	0800                	addi	s0,sp,16
  switch(priority) {
    800016aa:	4705                	li	a4,1
    800016ac:	00e50a63          	beq	a0,a4,800016c0 <get_timeslice+0x1c>
    800016b0:	87aa                	mv	a5,a0
    case MLFQ_HIGH:   return TIMESLICE_HIGH;    // 4 ticks - shortest time slice
    case MLFQ_MEDIUM: return TIMESLICE_MEDIUM;  // 8 ticks - medium time slice
    case MLFQ_LOW:    return TIMESLICE_LOW;     // 16 ticks - longest time slice
    default:          return TIMESLICE_LOW;     // Default to lowest priority
    800016b2:	4541                	li	a0,16
  switch(priority) {
    800016b4:	c781                	beqz	a5,800016bc <get_timeslice+0x18>
  }
}
    800016b6:	6422                	ld	s0,8(sp)
    800016b8:	0141                	addi	sp,sp,16
    800016ba:	8082                	ret
    case MLFQ_HIGH:   return TIMESLICE_HIGH;    // 4 ticks - shortest time slice
    800016bc:	4511                	li	a0,4
    800016be:	bfe5                	j	800016b6 <get_timeslice+0x12>
  switch(priority) {
    800016c0:	4521                	li	a0,8
    800016c2:	bfd5                	j	800016b6 <get_timeslice+0x12>

00000000800016c4 <init_mlfq_proc>:

// Initialize MLFQ fields for a new process
// All new processes start at highest priority for best responsiveness
void init_mlfq_proc(struct proc *p) {
    800016c4:	1101                	addi	sp,sp,-32
    800016c6:	ec06                	sd	ra,24(sp)
    800016c8:	e822                	sd	s0,16(sp)
    800016ca:	e426                	sd	s1,8(sp)
    800016cc:	1000                	addi	s0,sp,32
    800016ce:	84aa                	mv	s1,a0
  p->priority = MLFQ_HIGH;                       // Start at highest priority
    800016d0:	16052423          	sw	zero,360(a0)
  p->timeslice = get_timeslice(MLFQ_HIGH);      // Set time slice for high priority
    800016d4:	4501                	li	a0,0
    800016d6:	fcfff0ef          	jal	ra,800016a4 <get_timeslice>
    800016da:	16a4a623          	sw	a0,364(s1) # fffffffffffff16c <end+0xffffffff7ffdd484>
  p->timeslice_used = 0;                        // No time used yet
    800016de:	1604a823          	sw	zero,368(s1)
  p->cpu_ticks = 0;                             // No CPU time consumed
    800016e2:	1604aa23          	sw	zero,372(s1)
  p->sched_count = 0;                           // Not scheduled yet
    800016e6:	1604ac23          	sw	zero,376(s1)
  p->yielded_io = 0;                            // Not yielded for I/O
    800016ea:	1604ae23          	sw	zero,380(s1)
  
  // Initialize timing metrics
  p->start_time = ticks;                        // Record creation time
    800016ee:	00006797          	auipc	a5,0x6
    800016f2:	2e27e783          	lwu	a5,738(a5) # 800079d0 <ticks>
    800016f6:	18f4b023          	sd	a5,384(s1)
  p->end_time = 0;                              // Not finished yet
    800016fa:	1804b423          	sd	zero,392(s1)
  p->first_run = 0;                             // Not run yet
    800016fe:	1804b823          	sd	zero,400(s1)
  p->total_wait = 0;                            // No wait time yet
    80001702:	1804bc23          	sd	zero,408(s1)
  p->last_scheduled = ticks;                    // Initialize last scheduled time
    80001706:	1af4b023          	sd	a5,416(s1)
}
    8000170a:	60e2                	ld	ra,24(sp)
    8000170c:	6442                	ld	s0,16(sp)
    8000170e:	64a2                	ld	s1,8(sp)
    80001710:	6105                	addi	sp,sp,32
    80001712:	8082                	ret

0000000080001714 <boost_all_priorities>:

// Anti-starvation mechanism: boost all processes to highest priority
// This prevents lower-priority processes from being starved indefinitely
void
boost_all_priorities(void)
{
    80001714:	7179                	addi	sp,sp,-48
    80001716:	f406                	sd	ra,40(sp)
    80001718:	f022                	sd	s0,32(sp)
    8000171a:	ec26                	sd	s1,24(sp)
    8000171c:	e84a                	sd	s2,16(sp)
    8000171e:	e44e                	sd	s3,8(sp)
    80001720:	1800                	addi	s0,sp,48
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001722:	0000e497          	auipc	s1,0xe
    80001726:	7e648493          	addi	s1,s1,2022 # 8000ff08 <proc>
    // Don't acquire locks in interrupt context!
    // Just do the assignment - it's atomic
    if(p->state == RUNNABLE || p->state == RUNNING) {
    8000172a:	4985                	li	s3,1
  for(p = proc; p < &proc[NPROC]; p++) {
    8000172c:	00015917          	auipc	s2,0x15
    80001730:	1dc90913          	addi	s2,s2,476 # 80016908 <tickslock>
    80001734:	a029                	j	8000173e <boost_all_priorities+0x2a>
    80001736:	1a848493          	addi	s1,s1,424
    8000173a:	03248063          	beq	s1,s2,8000175a <boost_all_priorities+0x46>
    if(p->state == RUNNABLE || p->state == RUNNING) {
    8000173e:	4c9c                	lw	a5,24(s1)
    80001740:	37f5                	addiw	a5,a5,-3
    80001742:	fef9eae3          	bltu	s3,a5,80001736 <boost_all_priorities+0x22>
      p->priority = MLFQ_HIGH;
    80001746:	1604a423          	sw	zero,360(s1)
      p->timeslice = get_timeslice(MLFQ_HIGH);
    8000174a:	4501                	li	a0,0
    8000174c:	f59ff0ef          	jal	ra,800016a4 <get_timeslice>
    80001750:	16a4a623          	sw	a0,364(s1)
      p->timeslice_used = 0;
    80001754:	1604a823          	sw	zero,368(s1)
    80001758:	bff9                	j	80001736 <boost_all_priorities+0x22>
    }
  }
}
    8000175a:	70a2                	ld	ra,40(sp)
    8000175c:	7402                	ld	s0,32(sp)
    8000175e:	64e2                	ld	s1,24(sp)
    80001760:	6942                	ld	s2,16(sp)
    80001762:	69a2                	ld	s3,8(sp)
    80001764:	6145                	addi	sp,sp,48
    80001766:	8082                	ret

0000000080001768 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001768:	7139                	addi	sp,sp,-64
    8000176a:	fc06                	sd	ra,56(sp)
    8000176c:	f822                	sd	s0,48(sp)
    8000176e:	f426                	sd	s1,40(sp)
    80001770:	f04a                	sd	s2,32(sp)
    80001772:	ec4e                	sd	s3,24(sp)
    80001774:	e852                	sd	s4,16(sp)
    80001776:	e456                	sd	s5,8(sp)
    80001778:	e05a                	sd	s6,0(sp)
    8000177a:	0080                	addi	s0,sp,64
    8000177c:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    8000177e:	0000e497          	auipc	s1,0xe
    80001782:	78a48493          	addi	s1,s1,1930 # 8000ff08 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80001786:	8b26                	mv	s6,s1
    80001788:	00006a97          	auipc	s5,0x6
    8000178c:	878a8a93          	addi	s5,s5,-1928 # 80007000 <etext>
    80001790:	04000937          	lui	s2,0x4000
    80001794:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    80001796:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001798:	00015a17          	auipc	s4,0x15
    8000179c:	170a0a13          	addi	s4,s4,368 # 80016908 <tickslock>
    char *pa = kalloc();
    800017a0:	afaff0ef          	jal	ra,80000a9a <kalloc>
    800017a4:	862a                	mv	a2,a0
    if(pa == 0)
    800017a6:	c121                	beqz	a0,800017e6 <proc_mapstacks+0x7e>
    uint64 va = KSTACK((int) (p - proc));
    800017a8:	416485b3          	sub	a1,s1,s6
    800017ac:	858d                	srai	a1,a1,0x3
    800017ae:	000ab783          	ld	a5,0(s5)
    800017b2:	02f585b3          	mul	a1,a1,a5
    800017b6:	2585                	addiw	a1,a1,1
    800017b8:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017bc:	4719                	li	a4,6
    800017be:	6685                	lui	a3,0x1
    800017c0:	40b905b3          	sub	a1,s2,a1
    800017c4:	854e                	mv	a0,s3
    800017c6:	87dff0ef          	jal	ra,80001042 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ca:	1a848493          	addi	s1,s1,424
    800017ce:	fd4499e3          	bne	s1,s4,800017a0 <proc_mapstacks+0x38>
  }
}
    800017d2:	70e2                	ld	ra,56(sp)
    800017d4:	7442                	ld	s0,48(sp)
    800017d6:	74a2                	ld	s1,40(sp)
    800017d8:	7902                	ld	s2,32(sp)
    800017da:	69e2                	ld	s3,24(sp)
    800017dc:	6a42                	ld	s4,16(sp)
    800017de:	6aa2                	ld	s5,8(sp)
    800017e0:	6b02                	ld	s6,0(sp)
    800017e2:	6121                	addi	sp,sp,64
    800017e4:	8082                	ret
      panic("kalloc");
    800017e6:	00006517          	auipc	a0,0x6
    800017ea:	98a50513          	addi	a0,a0,-1654 # 80007170 <digits+0x138>
    800017ee:	f9bfe0ef          	jal	ra,80000788 <panic>

00000000800017f2 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017f2:	7139                	addi	sp,sp,-64
    800017f4:	fc06                	sd	ra,56(sp)
    800017f6:	f822                	sd	s0,48(sp)
    800017f8:	f426                	sd	s1,40(sp)
    800017fa:	f04a                	sd	s2,32(sp)
    800017fc:	ec4e                	sd	s3,24(sp)
    800017fe:	e852                	sd	s4,16(sp)
    80001800:	e456                	sd	s5,8(sp)
    80001802:	e05a                	sd	s6,0(sp)
    80001804:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001806:	00006597          	auipc	a1,0x6
    8000180a:	97258593          	addi	a1,a1,-1678 # 80007178 <digits+0x140>
    8000180e:	0000e517          	auipc	a0,0xe
    80001812:	2ca50513          	addi	a0,a0,714 # 8000fad8 <pid_lock>
    80001816:	ad4ff0ef          	jal	ra,80000aea <initlock>
  initlock(&wait_lock, "wait_lock");
    8000181a:	00006597          	auipc	a1,0x6
    8000181e:	96658593          	addi	a1,a1,-1690 # 80007180 <digits+0x148>
    80001822:	0000e517          	auipc	a0,0xe
    80001826:	2ce50513          	addi	a0,a0,718 # 8000faf0 <wait_lock>
    8000182a:	ac0ff0ef          	jal	ra,80000aea <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000182e:	0000e497          	auipc	s1,0xe
    80001832:	6da48493          	addi	s1,s1,1754 # 8000ff08 <proc>
      initlock(&p->lock, "proc");
    80001836:	00006b17          	auipc	s6,0x6
    8000183a:	95ab0b13          	addi	s6,s6,-1702 # 80007190 <digits+0x158>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    8000183e:	8aa6                	mv	s5,s1
    80001840:	00005a17          	auipc	s4,0x5
    80001844:	7c0a0a13          	addi	s4,s4,1984 # 80007000 <etext>
    80001848:	04000937          	lui	s2,0x4000
    8000184c:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    8000184e:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001850:	00015997          	auipc	s3,0x15
    80001854:	0b898993          	addi	s3,s3,184 # 80016908 <tickslock>
      initlock(&p->lock, "proc");
    80001858:	85da                	mv	a1,s6
    8000185a:	8526                	mv	a0,s1
    8000185c:	a8eff0ef          	jal	ra,80000aea <initlock>
      p->state = UNUSED;
    80001860:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001864:	415487b3          	sub	a5,s1,s5
    80001868:	878d                	srai	a5,a5,0x3
    8000186a:	000a3703          	ld	a4,0(s4)
    8000186e:	02e787b3          	mul	a5,a5,a4
    80001872:	2785                	addiw	a5,a5,1
    80001874:	00d7979b          	slliw	a5,a5,0xd
    80001878:	40f907b3          	sub	a5,s2,a5
    8000187c:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    8000187e:	1a848493          	addi	s1,s1,424
    80001882:	fd349be3          	bne	s1,s3,80001858 <procinit+0x66>
  }
}
    80001886:	70e2                	ld	ra,56(sp)
    80001888:	7442                	ld	s0,48(sp)
    8000188a:	74a2                	ld	s1,40(sp)
    8000188c:	7902                	ld	s2,32(sp)
    8000188e:	69e2                	ld	s3,24(sp)
    80001890:	6a42                	ld	s4,16(sp)
    80001892:	6aa2                	ld	s5,8(sp)
    80001894:	6b02                	ld	s6,0(sp)
    80001896:	6121                	addi	sp,sp,64
    80001898:	8082                	ret

000000008000189a <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    8000189a:	1141                	addi	sp,sp,-16
    8000189c:	e422                	sd	s0,8(sp)
    8000189e:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800018a0:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018a2:	2501                	sext.w	a0,a0
    800018a4:	6422                	ld	s0,8(sp)
    800018a6:	0141                	addi	sp,sp,16
    800018a8:	8082                	ret

00000000800018aa <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800018aa:	1141                	addi	sp,sp,-16
    800018ac:	e422                	sd	s0,8(sp)
    800018ae:	0800                	addi	s0,sp,16
    800018b0:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018b2:	2781                	sext.w	a5,a5
    800018b4:	079e                	slli	a5,a5,0x7
  return c;
}
    800018b6:	0000e517          	auipc	a0,0xe
    800018ba:	25250513          	addi	a0,a0,594 # 8000fb08 <cpus>
    800018be:	953e                	add	a0,a0,a5
    800018c0:	6422                	ld	s0,8(sp)
    800018c2:	0141                	addi	sp,sp,16
    800018c4:	8082                	ret

00000000800018c6 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    800018c6:	1101                	addi	sp,sp,-32
    800018c8:	ec06                	sd	ra,24(sp)
    800018ca:	e822                	sd	s0,16(sp)
    800018cc:	e426                	sd	s1,8(sp)
    800018ce:	1000                	addi	s0,sp,32
  push_off();
    800018d0:	a5aff0ef          	jal	ra,80000b2a <push_off>
    800018d4:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018d6:	2781                	sext.w	a5,a5
    800018d8:	079e                	slli	a5,a5,0x7
    800018da:	0000e717          	auipc	a4,0xe
    800018de:	1fe70713          	addi	a4,a4,510 # 8000fad8 <pid_lock>
    800018e2:	97ba                	add	a5,a5,a4
    800018e4:	7b84                	ld	s1,48(a5)
  pop_off();
    800018e6:	ac8ff0ef          	jal	ra,80000bae <pop_off>
  return p;
}
    800018ea:	8526                	mv	a0,s1
    800018ec:	60e2                	ld	ra,24(sp)
    800018ee:	6442                	ld	s0,16(sp)
    800018f0:	64a2                	ld	s1,8(sp)
    800018f2:	6105                	addi	sp,sp,32
    800018f4:	8082                	ret

00000000800018f6 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800018f6:	7179                	addi	sp,sp,-48
    800018f8:	f406                	sd	ra,40(sp)
    800018fa:	f022                	sd	s0,32(sp)
    800018fc:	ec26                	sd	s1,24(sp)
    800018fe:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001900:	fc7ff0ef          	jal	ra,800018c6 <myproc>
    80001904:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001906:	afcff0ef          	jal	ra,80000c02 <release>

  if (first) {
    8000190a:	00006797          	auipc	a5,0x6
    8000190e:	0667a783          	lw	a5,102(a5) # 80007970 <first.1>
    80001912:	cf8d                	beqz	a5,8000194c <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001914:	4505                	li	a0,1
    80001916:	5f5010ef          	jal	ra,8000370a <fsinit>

    first = 0;
    8000191a:	00006797          	auipc	a5,0x6
    8000191e:	0407ab23          	sw	zero,86(a5) # 80007970 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    80001922:	0ff0000f          	fence

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001926:	00006517          	auipc	a0,0x6
    8000192a:	87250513          	addi	a0,a0,-1934 # 80007198 <digits+0x160>
    8000192e:	fca43823          	sd	a0,-48(s0)
    80001932:	fc043c23          	sd	zero,-40(s0)
    80001936:	fd040593          	addi	a1,s0,-48
    8000193a:	67f020ef          	jal	ra,800047b8 <kexec>
    8000193e:	6cbc                	ld	a5,88(s1)
    80001940:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001942:	6cbc                	ld	a5,88(s1)
    80001944:	7bb8                	ld	a4,112(a5)
    80001946:	57fd                	li	a5,-1
    80001948:	02f70d63          	beq	a4,a5,80001982 <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    8000194c:	4e5000ef          	jal	ra,80002630 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001950:	68a8                	ld	a0,80(s1)
    80001952:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001954:	04000737          	lui	a4,0x4000
    80001958:	00004797          	auipc	a5,0x4
    8000195c:	74478793          	addi	a5,a5,1860 # 8000609c <userret>
    80001960:	00004697          	auipc	a3,0x4
    80001964:	6a068693          	addi	a3,a3,1696 # 80006000 <_trampoline>
    80001968:	8f95                	sub	a5,a5,a3
    8000196a:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000196c:	0732                	slli	a4,a4,0xc
    8000196e:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001970:	577d                	li	a4,-1
    80001972:	177e                	slli	a4,a4,0x3f
    80001974:	8d59                	or	a0,a0,a4
    80001976:	9782                	jalr	a5
}
    80001978:	70a2                	ld	ra,40(sp)
    8000197a:	7402                	ld	s0,32(sp)
    8000197c:	64e2                	ld	s1,24(sp)
    8000197e:	6145                	addi	sp,sp,48
    80001980:	8082                	ret
      panic("exec");
    80001982:	00006517          	auipc	a0,0x6
    80001986:	81e50513          	addi	a0,a0,-2018 # 800071a0 <digits+0x168>
    8000198a:	dfffe0ef          	jal	ra,80000788 <panic>

000000008000198e <allocpid>:
{
    8000198e:	1101                	addi	sp,sp,-32
    80001990:	ec06                	sd	ra,24(sp)
    80001992:	e822                	sd	s0,16(sp)
    80001994:	e426                	sd	s1,8(sp)
    80001996:	e04a                	sd	s2,0(sp)
    80001998:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    8000199a:	0000e917          	auipc	s2,0xe
    8000199e:	13e90913          	addi	s2,s2,318 # 8000fad8 <pid_lock>
    800019a2:	854a                	mv	a0,s2
    800019a4:	9c6ff0ef          	jal	ra,80000b6a <acquire>
  pid = nextpid;
    800019a8:	00006797          	auipc	a5,0x6
    800019ac:	fcc78793          	addi	a5,a5,-52 # 80007974 <nextpid>
    800019b0:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019b2:	0014871b          	addiw	a4,s1,1
    800019b6:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019b8:	854a                	mv	a0,s2
    800019ba:	a48ff0ef          	jal	ra,80000c02 <release>
}
    800019be:	8526                	mv	a0,s1
    800019c0:	60e2                	ld	ra,24(sp)
    800019c2:	6442                	ld	s0,16(sp)
    800019c4:	64a2                	ld	s1,8(sp)
    800019c6:	6902                	ld	s2,0(sp)
    800019c8:	6105                	addi	sp,sp,32
    800019ca:	8082                	ret

00000000800019cc <proc_pagetable>:
{
    800019cc:	1101                	addi	sp,sp,-32
    800019ce:	ec06                	sd	ra,24(sp)
    800019d0:	e822                	sd	s0,16(sp)
    800019d2:	e426                	sd	s1,8(sp)
    800019d4:	e04a                	sd	s2,0(sp)
    800019d6:	1000                	addi	s0,sp,32
    800019d8:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019da:	f5eff0ef          	jal	ra,80001138 <uvmcreate>
    800019de:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800019e0:	cd05                	beqz	a0,80001a18 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800019e2:	4729                	li	a4,10
    800019e4:	00004697          	auipc	a3,0x4
    800019e8:	61c68693          	addi	a3,a3,1564 # 80006000 <_trampoline>
    800019ec:	6605                	lui	a2,0x1
    800019ee:	040005b7          	lui	a1,0x4000
    800019f2:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019f4:	05b2                	slli	a1,a1,0xc
    800019f6:	d9cff0ef          	jal	ra,80000f92 <mappages>
    800019fa:	02054663          	bltz	a0,80001a26 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    800019fe:	4719                	li	a4,6
    80001a00:	05893683          	ld	a3,88(s2)
    80001a04:	6605                	lui	a2,0x1
    80001a06:	020005b7          	lui	a1,0x2000
    80001a0a:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a0c:	05b6                	slli	a1,a1,0xd
    80001a0e:	8526                	mv	a0,s1
    80001a10:	d82ff0ef          	jal	ra,80000f92 <mappages>
    80001a14:	00054f63          	bltz	a0,80001a32 <proc_pagetable+0x66>
}
    80001a18:	8526                	mv	a0,s1
    80001a1a:	60e2                	ld	ra,24(sp)
    80001a1c:	6442                	ld	s0,16(sp)
    80001a1e:	64a2                	ld	s1,8(sp)
    80001a20:	6902                	ld	s2,0(sp)
    80001a22:	6105                	addi	sp,sp,32
    80001a24:	8082                	ret
    uvmfree(pagetable, 0);
    80001a26:	4581                	li	a1,0
    80001a28:	8526                	mv	a0,s1
    80001a2a:	8efff0ef          	jal	ra,80001318 <uvmfree>
    return 0;
    80001a2e:	4481                	li	s1,0
    80001a30:	b7e5                	j	80001a18 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a32:	4681                	li	a3,0
    80001a34:	4605                	li	a2,1
    80001a36:	040005b7          	lui	a1,0x4000
    80001a3a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a3c:	05b2                	slli	a1,a1,0xc
    80001a3e:	8526                	mv	a0,s1
    80001a40:	f1eff0ef          	jal	ra,8000115e <uvmunmap>
    uvmfree(pagetable, 0);
    80001a44:	4581                	li	a1,0
    80001a46:	8526                	mv	a0,s1
    80001a48:	8d1ff0ef          	jal	ra,80001318 <uvmfree>
    return 0;
    80001a4c:	4481                	li	s1,0
    80001a4e:	b7e9                	j	80001a18 <proc_pagetable+0x4c>

0000000080001a50 <proc_freepagetable>:
{
    80001a50:	1101                	addi	sp,sp,-32
    80001a52:	ec06                	sd	ra,24(sp)
    80001a54:	e822                	sd	s0,16(sp)
    80001a56:	e426                	sd	s1,8(sp)
    80001a58:	e04a                	sd	s2,0(sp)
    80001a5a:	1000                	addi	s0,sp,32
    80001a5c:	84aa                	mv	s1,a0
    80001a5e:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a60:	4681                	li	a3,0
    80001a62:	4605                	li	a2,1
    80001a64:	040005b7          	lui	a1,0x4000
    80001a68:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a6a:	05b2                	slli	a1,a1,0xc
    80001a6c:	ef2ff0ef          	jal	ra,8000115e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a70:	4681                	li	a3,0
    80001a72:	4605                	li	a2,1
    80001a74:	020005b7          	lui	a1,0x2000
    80001a78:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a7a:	05b6                	slli	a1,a1,0xd
    80001a7c:	8526                	mv	a0,s1
    80001a7e:	ee0ff0ef          	jal	ra,8000115e <uvmunmap>
  uvmfree(pagetable, sz);
    80001a82:	85ca                	mv	a1,s2
    80001a84:	8526                	mv	a0,s1
    80001a86:	893ff0ef          	jal	ra,80001318 <uvmfree>
}
    80001a8a:	60e2                	ld	ra,24(sp)
    80001a8c:	6442                	ld	s0,16(sp)
    80001a8e:	64a2                	ld	s1,8(sp)
    80001a90:	6902                	ld	s2,0(sp)
    80001a92:	6105                	addi	sp,sp,32
    80001a94:	8082                	ret

0000000080001a96 <freeproc>:
{
    80001a96:	1101                	addi	sp,sp,-32
    80001a98:	ec06                	sd	ra,24(sp)
    80001a9a:	e822                	sd	s0,16(sp)
    80001a9c:	e426                	sd	s1,8(sp)
    80001a9e:	1000                	addi	s0,sp,32
    80001aa0:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001aa2:	6d28                	ld	a0,88(a0)
    80001aa4:	c119                	beqz	a0,80001aaa <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001aa6:	f13fe0ef          	jal	ra,800009b8 <kfree>
  p->trapframe = 0;
    80001aaa:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001aae:	68a8                	ld	a0,80(s1)
    80001ab0:	c501                	beqz	a0,80001ab8 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001ab2:	64ac                	ld	a1,72(s1)
    80001ab4:	f9dff0ef          	jal	ra,80001a50 <proc_freepagetable>
  p->pagetable = 0;
    80001ab8:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001abc:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001ac0:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001ac4:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001ac8:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001acc:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001ad0:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001ad4:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ad8:	0004ac23          	sw	zero,24(s1)
}
    80001adc:	60e2                	ld	ra,24(sp)
    80001ade:	6442                	ld	s0,16(sp)
    80001ae0:	64a2                	ld	s1,8(sp)
    80001ae2:	6105                	addi	sp,sp,32
    80001ae4:	8082                	ret

0000000080001ae6 <allocproc>:
{
    80001ae6:	1101                	addi	sp,sp,-32
    80001ae8:	ec06                	sd	ra,24(sp)
    80001aea:	e822                	sd	s0,16(sp)
    80001aec:	e426                	sd	s1,8(sp)
    80001aee:	e04a                	sd	s2,0(sp)
    80001af0:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001af2:	0000e497          	auipc	s1,0xe
    80001af6:	41648493          	addi	s1,s1,1046 # 8000ff08 <proc>
    80001afa:	00015917          	auipc	s2,0x15
    80001afe:	e0e90913          	addi	s2,s2,-498 # 80016908 <tickslock>
    acquire(&p->lock);
    80001b02:	8526                	mv	a0,s1
    80001b04:	866ff0ef          	jal	ra,80000b6a <acquire>
    if(p->state == UNUSED) {
    80001b08:	4c9c                	lw	a5,24(s1)
    80001b0a:	cb91                	beqz	a5,80001b1e <allocproc+0x38>
      release(&p->lock);
    80001b0c:	8526                	mv	a0,s1
    80001b0e:	8f4ff0ef          	jal	ra,80000c02 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b12:	1a848493          	addi	s1,s1,424
    80001b16:	ff2496e3          	bne	s1,s2,80001b02 <allocproc+0x1c>
  return 0;
    80001b1a:	4481                	li	s1,0
    80001b1c:	a8b1                	j	80001b78 <allocproc+0x92>
  p->pid = allocpid();
    80001b1e:	e71ff0ef          	jal	ra,8000198e <allocpid>
    80001b22:	892a                	mv	s2,a0
    80001b24:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b26:	4785                	li	a5,1
    80001b28:	cc9c                	sw	a5,24(s1)
  init_mlfq_proc(p); // Initialize MLFQ scheduling fields for new process
    80001b2a:	8526                	mv	a0,s1
    80001b2c:	b99ff0ef          	jal	ra,800016c4 <init_mlfq_proc>
  printf("init_mlfq_proc: pid=%d, timeslice=%d\n", p->pid, p->timeslice);
    80001b30:	16c4a603          	lw	a2,364(s1)
    80001b34:	85ca                	mv	a1,s2
    80001b36:	00005517          	auipc	a0,0x5
    80001b3a:	67250513          	addi	a0,a0,1650 # 800071a8 <digits+0x170>
    80001b3e:	985fe0ef          	jal	ra,800004c2 <printf>
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b42:	f59fe0ef          	jal	ra,80000a9a <kalloc>
    80001b46:	892a                	mv	s2,a0
    80001b48:	eca8                	sd	a0,88(s1)
    80001b4a:	cd15                	beqz	a0,80001b86 <allocproc+0xa0>
  p->pagetable = proc_pagetable(p);
    80001b4c:	8526                	mv	a0,s1
    80001b4e:	e7fff0ef          	jal	ra,800019cc <proc_pagetable>
    80001b52:	892a                	mv	s2,a0
    80001b54:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b56:	c121                	beqz	a0,80001b96 <allocproc+0xb0>
  memset(&p->context, 0, sizeof(p->context));
    80001b58:	07000613          	li	a2,112
    80001b5c:	4581                	li	a1,0
    80001b5e:	06048513          	addi	a0,s1,96
    80001b62:	8dcff0ef          	jal	ra,80000c3e <memset>
  p->context.ra = (uint64)forkret;
    80001b66:	00000797          	auipc	a5,0x0
    80001b6a:	d9078793          	addi	a5,a5,-624 # 800018f6 <forkret>
    80001b6e:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b70:	60bc                	ld	a5,64(s1)
    80001b72:	6705                	lui	a4,0x1
    80001b74:	97ba                	add	a5,a5,a4
    80001b76:	f4bc                	sd	a5,104(s1)
}
    80001b78:	8526                	mv	a0,s1
    80001b7a:	60e2                	ld	ra,24(sp)
    80001b7c:	6442                	ld	s0,16(sp)
    80001b7e:	64a2                	ld	s1,8(sp)
    80001b80:	6902                	ld	s2,0(sp)
    80001b82:	6105                	addi	sp,sp,32
    80001b84:	8082                	ret
    freeproc(p);
    80001b86:	8526                	mv	a0,s1
    80001b88:	f0fff0ef          	jal	ra,80001a96 <freeproc>
    release(&p->lock);
    80001b8c:	8526                	mv	a0,s1
    80001b8e:	874ff0ef          	jal	ra,80000c02 <release>
    return 0;
    80001b92:	84ca                	mv	s1,s2
    80001b94:	b7d5                	j	80001b78 <allocproc+0x92>
    freeproc(p);
    80001b96:	8526                	mv	a0,s1
    80001b98:	effff0ef          	jal	ra,80001a96 <freeproc>
    release(&p->lock);
    80001b9c:	8526                	mv	a0,s1
    80001b9e:	864ff0ef          	jal	ra,80000c02 <release>
    return 0;
    80001ba2:	84ca                	mv	s1,s2
    80001ba4:	bfd1                	j	80001b78 <allocproc+0x92>

0000000080001ba6 <userinit>:
{
    80001ba6:	1101                	addi	sp,sp,-32
    80001ba8:	ec06                	sd	ra,24(sp)
    80001baa:	e822                	sd	s0,16(sp)
    80001bac:	e426                	sd	s1,8(sp)
    80001bae:	1000                	addi	s0,sp,32
  p = allocproc();
    80001bb0:	f37ff0ef          	jal	ra,80001ae6 <allocproc>
    80001bb4:	84aa                	mv	s1,a0
  initproc = p;
    80001bb6:	00006797          	auipc	a5,0x6
    80001bba:	e0a7b923          	sd	a0,-494(a5) # 800079c8 <initproc>
  p->cwd = namei("/");
    80001bbe:	00005517          	auipc	a0,0x5
    80001bc2:	61250513          	addi	a0,a0,1554 # 800071d0 <digits+0x198>
    80001bc6:	048020ef          	jal	ra,80003c0e <namei>
    80001bca:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bce:	478d                	li	a5,3
    80001bd0:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bd2:	8526                	mv	a0,s1
    80001bd4:	82eff0ef          	jal	ra,80000c02 <release>
}
    80001bd8:	60e2                	ld	ra,24(sp)
    80001bda:	6442                	ld	s0,16(sp)
    80001bdc:	64a2                	ld	s1,8(sp)
    80001bde:	6105                	addi	sp,sp,32
    80001be0:	8082                	ret

0000000080001be2 <growproc>:
{
    80001be2:	1101                	addi	sp,sp,-32
    80001be4:	ec06                	sd	ra,24(sp)
    80001be6:	e822                	sd	s0,16(sp)
    80001be8:	e426                	sd	s1,8(sp)
    80001bea:	e04a                	sd	s2,0(sp)
    80001bec:	1000                	addi	s0,sp,32
    80001bee:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001bf0:	cd7ff0ef          	jal	ra,800018c6 <myproc>
    80001bf4:	892a                	mv	s2,a0
  sz = p->sz;
    80001bf6:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001bf8:	02905963          	blez	s1,80001c2a <growproc+0x48>
    if(sz + n > TRAPFRAME) {
    80001bfc:	00b48633          	add	a2,s1,a1
    80001c00:	020007b7          	lui	a5,0x2000
    80001c04:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c06:	07b6                	slli	a5,a5,0xd
    80001c08:	02c7ea63          	bltu	a5,a2,80001c3c <growproc+0x5a>
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c0c:	4691                	li	a3,4
    80001c0e:	6928                	ld	a0,80(a0)
    80001c10:	e0eff0ef          	jal	ra,8000121e <uvmalloc>
    80001c14:	85aa                	mv	a1,a0
    80001c16:	c50d                	beqz	a0,80001c40 <growproc+0x5e>
  p->sz = sz;
    80001c18:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c1c:	4501                	li	a0,0
}
    80001c1e:	60e2                	ld	ra,24(sp)
    80001c20:	6442                	ld	s0,16(sp)
    80001c22:	64a2                	ld	s1,8(sp)
    80001c24:	6902                	ld	s2,0(sp)
    80001c26:	6105                	addi	sp,sp,32
    80001c28:	8082                	ret
  } else if(n < 0){
    80001c2a:	fe04d7e3          	bgez	s1,80001c18 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c2e:	00b48633          	add	a2,s1,a1
    80001c32:	6928                	ld	a0,80(a0)
    80001c34:	da6ff0ef          	jal	ra,800011da <uvmdealloc>
    80001c38:	85aa                	mv	a1,a0
    80001c3a:	bff9                	j	80001c18 <growproc+0x36>
      return -1;
    80001c3c:	557d                	li	a0,-1
    80001c3e:	b7c5                	j	80001c1e <growproc+0x3c>
      return -1;
    80001c40:	557d                	li	a0,-1
    80001c42:	bff1                	j	80001c1e <growproc+0x3c>

0000000080001c44 <kfork>:
{
    80001c44:	7139                	addi	sp,sp,-64
    80001c46:	fc06                	sd	ra,56(sp)
    80001c48:	f822                	sd	s0,48(sp)
    80001c4a:	f426                	sd	s1,40(sp)
    80001c4c:	f04a                	sd	s2,32(sp)
    80001c4e:	ec4e                	sd	s3,24(sp)
    80001c50:	e852                	sd	s4,16(sp)
    80001c52:	e456                	sd	s5,8(sp)
    80001c54:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c56:	c71ff0ef          	jal	ra,800018c6 <myproc>
    80001c5a:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c5c:	e8bff0ef          	jal	ra,80001ae6 <allocproc>
    80001c60:	0e050663          	beqz	a0,80001d4c <kfork+0x108>
    80001c64:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c66:	048ab603          	ld	a2,72(s5)
    80001c6a:	692c                	ld	a1,80(a0)
    80001c6c:	050ab503          	ld	a0,80(s5)
    80001c70:	edaff0ef          	jal	ra,8000134a <uvmcopy>
    80001c74:	04054863          	bltz	a0,80001cc4 <kfork+0x80>
  np->sz = p->sz;
    80001c78:	048ab783          	ld	a5,72(s5)
    80001c7c:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c80:	058ab683          	ld	a3,88(s5)
    80001c84:	87b6                	mv	a5,a3
    80001c86:	058a3703          	ld	a4,88(s4)
    80001c8a:	12068693          	addi	a3,a3,288
    80001c8e:	0007b803          	ld	a6,0(a5)
    80001c92:	6788                	ld	a0,8(a5)
    80001c94:	6b8c                	ld	a1,16(a5)
    80001c96:	6f90                	ld	a2,24(a5)
    80001c98:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c9c:	e708                	sd	a0,8(a4)
    80001c9e:	eb0c                	sd	a1,16(a4)
    80001ca0:	ef10                	sd	a2,24(a4)
    80001ca2:	02078793          	addi	a5,a5,32
    80001ca6:	02070713          	addi	a4,a4,32
    80001caa:	fed792e3          	bne	a5,a3,80001c8e <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001cae:	058a3783          	ld	a5,88(s4)
    80001cb2:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001cb6:	0d0a8493          	addi	s1,s5,208
    80001cba:	0d0a0913          	addi	s2,s4,208
    80001cbe:	150a8993          	addi	s3,s5,336
    80001cc2:	a829                	j	80001cdc <kfork+0x98>
    freeproc(np);
    80001cc4:	8552                	mv	a0,s4
    80001cc6:	dd1ff0ef          	jal	ra,80001a96 <freeproc>
    release(&np->lock);
    80001cca:	8552                	mv	a0,s4
    80001ccc:	f37fe0ef          	jal	ra,80000c02 <release>
    return -1;
    80001cd0:	597d                	li	s2,-1
    80001cd2:	a09d                	j	80001d38 <kfork+0xf4>
  for(i = 0; i < NOFILE; i++)
    80001cd4:	04a1                	addi	s1,s1,8
    80001cd6:	0921                	addi	s2,s2,8
    80001cd8:	01348963          	beq	s1,s3,80001cea <kfork+0xa6>
    if(p->ofile[i])
    80001cdc:	6088                	ld	a0,0(s1)
    80001cde:	d97d                	beqz	a0,80001cd4 <kfork+0x90>
      np->ofile[i] = filedup(p->ofile[i]);
    80001ce0:	4e6020ef          	jal	ra,800041c6 <filedup>
    80001ce4:	00a93023          	sd	a0,0(s2)
    80001ce8:	b7f5                	j	80001cd4 <kfork+0x90>
  np->cwd = idup(p->cwd);
    80001cea:	150ab503          	ld	a0,336(s5)
    80001cee:	6f6010ef          	jal	ra,800033e4 <idup>
    80001cf2:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cf6:	4641                	li	a2,16
    80001cf8:	158a8593          	addi	a1,s5,344
    80001cfc:	158a0513          	addi	a0,s4,344
    80001d00:	884ff0ef          	jal	ra,80000d84 <safestrcpy>
  pid = np->pid;
    80001d04:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001d08:	8552                	mv	a0,s4
    80001d0a:	ef9fe0ef          	jal	ra,80000c02 <release>
  acquire(&wait_lock);
    80001d0e:	0000e497          	auipc	s1,0xe
    80001d12:	de248493          	addi	s1,s1,-542 # 8000faf0 <wait_lock>
    80001d16:	8526                	mv	a0,s1
    80001d18:	e53fe0ef          	jal	ra,80000b6a <acquire>
  np->parent = p;
    80001d1c:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d20:	8526                	mv	a0,s1
    80001d22:	ee1fe0ef          	jal	ra,80000c02 <release>
  acquire(&np->lock);
    80001d26:	8552                	mv	a0,s4
    80001d28:	e43fe0ef          	jal	ra,80000b6a <acquire>
  np->state = RUNNABLE;
    80001d2c:	478d                	li	a5,3
    80001d2e:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d32:	8552                	mv	a0,s4
    80001d34:	ecffe0ef          	jal	ra,80000c02 <release>
}
    80001d38:	854a                	mv	a0,s2
    80001d3a:	70e2                	ld	ra,56(sp)
    80001d3c:	7442                	ld	s0,48(sp)
    80001d3e:	74a2                	ld	s1,40(sp)
    80001d40:	7902                	ld	s2,32(sp)
    80001d42:	69e2                	ld	s3,24(sp)
    80001d44:	6a42                	ld	s4,16(sp)
    80001d46:	6aa2                	ld	s5,8(sp)
    80001d48:	6121                	addi	sp,sp,64
    80001d4a:	8082                	ret
    return -1;
    80001d4c:	597d                	li	s2,-1
    80001d4e:	b7ed                	j	80001d38 <kfork+0xf4>

0000000080001d50 <scheduler>:
{
    80001d50:	715d                	addi	sp,sp,-80
    80001d52:	e486                	sd	ra,72(sp)
    80001d54:	e0a2                	sd	s0,64(sp)
    80001d56:	fc26                	sd	s1,56(sp)
    80001d58:	f84a                	sd	s2,48(sp)
    80001d5a:	f44e                	sd	s3,40(sp)
    80001d5c:	f052                	sd	s4,32(sp)
    80001d5e:	ec56                	sd	s5,24(sp)
    80001d60:	e85a                	sd	s6,16(sp)
    80001d62:	e45e                	sd	s7,8(sp)
    80001d64:	0880                	addi	s0,sp,80
    80001d66:	8792                	mv	a5,tp
  int id = r_tp();
    80001d68:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d6a:	00779b93          	slli	s7,a5,0x7
    80001d6e:	0000e717          	auipc	a4,0xe
    80001d72:	d6a70713          	addi	a4,a4,-662 # 8000fad8 <pid_lock>
    80001d76:	975e                	add	a4,a4,s7
    80001d78:	02073823          	sd	zero,48(a4)
          swtch(&c->context, &p->context);
    80001d7c:	0000e717          	auipc	a4,0xe
    80001d80:	d9470713          	addi	a4,a4,-620 # 8000fb10 <cpus+0x8>
    80001d84:	9bba                	add	s7,s7,a4
      for(p = proc; p < &proc[NPROC]; p++) {
    80001d86:	00015997          	auipc	s3,0x15
    80001d8a:	b8298993          	addi	s3,s3,-1150 # 80016908 <tickslock>
          c->proc = p;
    80001d8e:	079e                	slli	a5,a5,0x7
    80001d90:	0000eb17          	auipc	s6,0xe
    80001d94:	d48b0b13          	addi	s6,s6,-696 # 8000fad8 <pid_lock>
    80001d98:	9b3e                	add	s6,s6,a5
            p->first_run = ticks;
    80001d9a:	00006a97          	auipc	s5,0x6
    80001d9e:	c36a8a93          	addi	s5,s5,-970 # 800079d0 <ticks>
    80001da2:	a859                	j	80001e38 <scheduler+0xe8>
        release(&p->lock);
    80001da4:	8526                	mv	a0,s1
    80001da6:	e5dfe0ef          	jal	ra,80000c02 <release>
      for(p = proc; p < &proc[NPROC]; p++) {
    80001daa:	1a848493          	addi	s1,s1,424
    80001dae:	09348063          	beq	s1,s3,80001e2e <scheduler+0xde>
        acquire(&p->lock);
    80001db2:	8526                	mv	a0,s1
    80001db4:	db7fe0ef          	jal	ra,80000b6a <acquire>
        if(p->state == RUNNABLE && p->priority == priority) {
    80001db8:	4c9c                	lw	a5,24(s1)
    80001dba:	ff2795e3          	bne	a5,s2,80001da4 <scheduler+0x54>
    80001dbe:	1684a783          	lw	a5,360(s1)
    80001dc2:	ff4791e3          	bne	a5,s4,80001da4 <scheduler+0x54>
          p->state = RUNNING;
    80001dc6:	4791                	li	a5,4
    80001dc8:	cc9c                	sw	a5,24(s1)
          c->proc = p;
    80001dca:	029b3823          	sd	s1,48(s6)
          p->sched_count++;
    80001dce:	1784a783          	lw	a5,376(s1)
    80001dd2:	2785                	addiw	a5,a5,1
    80001dd4:	16f4ac23          	sw	a5,376(s1)
          if(p->first_run == 0)
    80001dd8:	1904b783          	ld	a5,400(s1)
    80001ddc:	e789                	bnez	a5,80001de6 <scheduler+0x96>
            p->first_run = ticks;
    80001dde:	000ae783          	lwu	a5,0(s5)
    80001de2:	18f4b823          	sd	a5,400(s1)
          p->total_wait += (ticks - p->last_scheduled);
    80001de6:	000ae783          	lwu	a5,0(s5)
    80001dea:	1984b703          	ld	a4,408(s1)
    80001dee:	97ba                	add	a5,a5,a4
    80001df0:	1a04b703          	ld	a4,416(s1)
    80001df4:	8f99                	sub	a5,a5,a4
    80001df6:	18f4bc23          	sd	a5,408(s1)
          swtch(&c->context, &p->context);
    80001dfa:	06048593          	addi	a1,s1,96
    80001dfe:	855e                	mv	a0,s7
    80001e00:	78a000ef          	jal	ra,8000258a <swtch>
          p->last_scheduled = ticks;
    80001e04:	000ae783          	lwu	a5,0(s5)
    80001e08:	1af4b023          	sd	a5,416(s1)
          c->proc = 0;
    80001e0c:	020b3823          	sd	zero,48(s6)
          release(&p->lock);
    80001e10:	8526                	mv	a0,s1
    80001e12:	df1fe0ef          	jal	ra,80000c02 <release>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e16:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e1a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e1e:	10079073          	csrw	sstatus,a5
    for(int priority = MLFQ_HIGH; priority <= MLFQ_LOW; priority++) {
    80001e22:	4a01                	li	s4,0
      for(p = proc; p < &proc[NPROC]; p++) {
    80001e24:	0000e497          	auipc	s1,0xe
    80001e28:	0e448493          	addi	s1,s1,228 # 8000ff08 <proc>
    80001e2c:	b759                	j	80001db2 <scheduler+0x62>
    for(int priority = MLFQ_HIGH; priority <= MLFQ_LOW; priority++) {
    80001e2e:	2a05                	addiw	s4,s4,1
    80001e30:	ff2a1ae3          	bne	s4,s2,80001e24 <scheduler+0xd4>
      asm volatile("wfi");
    80001e34:	10500073          	wfi
        if(p->state == RUNNABLE && p->priority == priority) {
    80001e38:	490d                	li	s2,3
    80001e3a:	bff1                	j	80001e16 <scheduler+0xc6>

0000000080001e3c <sched>:
{
    80001e3c:	7179                	addi	sp,sp,-48
    80001e3e:	f406                	sd	ra,40(sp)
    80001e40:	f022                	sd	s0,32(sp)
    80001e42:	ec26                	sd	s1,24(sp)
    80001e44:	e84a                	sd	s2,16(sp)
    80001e46:	e44e                	sd	s3,8(sp)
    80001e48:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e4a:	a7dff0ef          	jal	ra,800018c6 <myproc>
    80001e4e:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e50:	cb1fe0ef          	jal	ra,80000b00 <holding>
    80001e54:	c92d                	beqz	a0,80001ec6 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e56:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e58:	2781                	sext.w	a5,a5
    80001e5a:	079e                	slli	a5,a5,0x7
    80001e5c:	0000e717          	auipc	a4,0xe
    80001e60:	c7c70713          	addi	a4,a4,-900 # 8000fad8 <pid_lock>
    80001e64:	97ba                	add	a5,a5,a4
    80001e66:	0a87a703          	lw	a4,168(a5)
    80001e6a:	4785                	li	a5,1
    80001e6c:	06f71363          	bne	a4,a5,80001ed2 <sched+0x96>
  if(p->state == RUNNING)
    80001e70:	4c98                	lw	a4,24(s1)
    80001e72:	4791                	li	a5,4
    80001e74:	06f70563          	beq	a4,a5,80001ede <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e78:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e7c:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e7e:	e7b5                	bnez	a5,80001eea <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e80:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e82:	0000e917          	auipc	s2,0xe
    80001e86:	c5690913          	addi	s2,s2,-938 # 8000fad8 <pid_lock>
    80001e8a:	2781                	sext.w	a5,a5
    80001e8c:	079e                	slli	a5,a5,0x7
    80001e8e:	97ca                	add	a5,a5,s2
    80001e90:	0ac7a983          	lw	s3,172(a5)
    80001e94:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e96:	2781                	sext.w	a5,a5
    80001e98:	079e                	slli	a5,a5,0x7
    80001e9a:	0000e597          	auipc	a1,0xe
    80001e9e:	c7658593          	addi	a1,a1,-906 # 8000fb10 <cpus+0x8>
    80001ea2:	95be                	add	a1,a1,a5
    80001ea4:	06048513          	addi	a0,s1,96
    80001ea8:	6e2000ef          	jal	ra,8000258a <swtch>
    80001eac:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001eae:	2781                	sext.w	a5,a5
    80001eb0:	079e                	slli	a5,a5,0x7
    80001eb2:	993e                	add	s2,s2,a5
    80001eb4:	0b392623          	sw	s3,172(s2)
}
    80001eb8:	70a2                	ld	ra,40(sp)
    80001eba:	7402                	ld	s0,32(sp)
    80001ebc:	64e2                	ld	s1,24(sp)
    80001ebe:	6942                	ld	s2,16(sp)
    80001ec0:	69a2                	ld	s3,8(sp)
    80001ec2:	6145                	addi	sp,sp,48
    80001ec4:	8082                	ret
    panic("sched p->lock");
    80001ec6:	00005517          	auipc	a0,0x5
    80001eca:	31250513          	addi	a0,a0,786 # 800071d8 <digits+0x1a0>
    80001ece:	8bbfe0ef          	jal	ra,80000788 <panic>
    panic("sched locks");
    80001ed2:	00005517          	auipc	a0,0x5
    80001ed6:	31650513          	addi	a0,a0,790 # 800071e8 <digits+0x1b0>
    80001eda:	8affe0ef          	jal	ra,80000788 <panic>
    panic("sched RUNNING");
    80001ede:	00005517          	auipc	a0,0x5
    80001ee2:	31a50513          	addi	a0,a0,794 # 800071f8 <digits+0x1c0>
    80001ee6:	8a3fe0ef          	jal	ra,80000788 <panic>
    panic("sched interruptible");
    80001eea:	00005517          	auipc	a0,0x5
    80001eee:	31e50513          	addi	a0,a0,798 # 80007208 <digits+0x1d0>
    80001ef2:	897fe0ef          	jal	ra,80000788 <panic>

0000000080001ef6 <yield>:
{
    80001ef6:	1101                	addi	sp,sp,-32
    80001ef8:	ec06                	sd	ra,24(sp)
    80001efa:	e822                	sd	s0,16(sp)
    80001efc:	e426                	sd	s1,8(sp)
    80001efe:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f00:	9c7ff0ef          	jal	ra,800018c6 <myproc>
    80001f04:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f06:	c65fe0ef          	jal	ra,80000b6a <acquire>
  if(p->state == RUNNING) {
    80001f0a:	4c98                	lw	a4,24(s1)
    80001f0c:	4791                	li	a5,4
    80001f0e:	00f70e63          	beq	a4,a5,80001f2a <yield+0x34>
  p->state = RUNNABLE;
    80001f12:	478d                	li	a5,3
    80001f14:	cc9c                	sw	a5,24(s1)
  sched();
    80001f16:	f27ff0ef          	jal	ra,80001e3c <sched>
  release(&p->lock);
    80001f1a:	8526                	mv	a0,s1
    80001f1c:	ce7fe0ef          	jal	ra,80000c02 <release>
}
    80001f20:	60e2                	ld	ra,24(sp)
    80001f22:	6442                	ld	s0,16(sp)
    80001f24:	64a2                	ld	s1,8(sp)
    80001f26:	6105                	addi	sp,sp,32
    80001f28:	8082                	ret
    p->yielded_io = 1;  // This is an I/O yield, preserve priority
    80001f2a:	4785                	li	a5,1
    80001f2c:	16f4ae23          	sw	a5,380(s1)
    80001f30:	b7cd                	j	80001f12 <yield+0x1c>

0000000080001f32 <mlfq_tick>:
{
    80001f32:	1101                	addi	sp,sp,-32
    80001f34:	ec06                	sd	ra,24(sp)
    80001f36:	e822                	sd	s0,16(sp)
    80001f38:	e426                	sd	s1,8(sp)
    80001f3a:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f3c:	98bff0ef          	jal	ra,800018c6 <myproc>
  if(p == 0 || p->state != RUNNING)
    80001f40:	c959                	beqz	a0,80001fd6 <mlfq_tick+0xa4>
    80001f42:	84aa                	mv	s1,a0
    80001f44:	4d18                	lw	a4,24(a0)
    80001f46:	4791                	li	a5,4
    80001f48:	08f71763          	bne	a4,a5,80001fd6 <mlfq_tick+0xa4>
  starvation_counter++;
    80001f4c:	00006717          	auipc	a4,0x6
    80001f50:	a7470713          	addi	a4,a4,-1420 # 800079c0 <starvation_counter>
    80001f54:	431c                	lw	a5,0(a4)
    80001f56:	2785                	addiw	a5,a5,1
    80001f58:	0007859b          	sext.w	a1,a5
    80001f5c:	c31c                	sw	a5,0(a4)
  if(starvation_counter >= STARVATION_THRESHOLD) {
    80001f5e:	06300793          	li	a5,99
    80001f62:	06b7cf63          	blt	a5,a1,80001fe0 <mlfq_tick+0xae>
  p->cpu_ticks++;
    80001f66:	1744a783          	lw	a5,372(s1)
    80001f6a:	2785                	addiw	a5,a5,1
    80001f6c:	16f4aa23          	sw	a5,372(s1)
  p->timeslice_used++;
    80001f70:	1704a683          	lw	a3,368(s1)
    80001f74:	2685                	addiw	a3,a3,1
    80001f76:	16d4a823          	sw	a3,368(s1)
  printf("[MLFQ DEBUG] Tick: PID=%d, Priority=%d, SliceUsed=%d/%d\n",
    80001f7a:	16c4a703          	lw	a4,364(s1)
    80001f7e:	2681                	sext.w	a3,a3
    80001f80:	1684a603          	lw	a2,360(s1)
    80001f84:	588c                	lw	a1,48(s1)
    80001f86:	00005517          	auipc	a0,0x5
    80001f8a:	2ea50513          	addi	a0,a0,746 # 80007270 <digits+0x238>
    80001f8e:	d34fe0ef          	jal	ra,800004c2 <printf>
  if(p->timeslice_used >= p->timeslice) {
    80001f92:	1704a703          	lw	a4,368(s1)
    80001f96:	16c4a783          	lw	a5,364(s1)
    80001f9a:	06f74f63          	blt	a4,a5,80002018 <mlfq_tick+0xe6>
    if(!p->yielded_io && p->priority < MLFQ_LOW) {
    80001f9e:	17c4a783          	lw	a5,380(s1)
    80001fa2:	e791                	bnez	a5,80001fae <mlfq_tick+0x7c>
    80001fa4:	1684a603          	lw	a2,360(s1)
    80001fa8:	4785                	li	a5,1
    80001faa:	04c7d863          	bge	a5,a2,80001ffa <mlfq_tick+0xc8>
    p->timeslice = get_timeslice(p->priority);
    80001fae:	1684a503          	lw	a0,360(s1)
    80001fb2:	ef2ff0ef          	jal	ra,800016a4 <get_timeslice>
    80001fb6:	862a                	mv	a2,a0
    80001fb8:	16a4a623          	sw	a0,364(s1)
    p->timeslice_used = 0;
    80001fbc:	1604a823          	sw	zero,368(s1)
    p->yielded_io = 0;  // ensure next tick not treated as I/O
    80001fc0:	1604ae23          	sw	zero,380(s1)
    printf("[MLFQ DEBUG] PID=%d preempted -> RUNNABLE. New timeslice=%d\n",
    80001fc4:	588c                	lw	a1,48(s1)
    80001fc6:	00005517          	auipc	a0,0x5
    80001fca:	33250513          	addi	a0,a0,818 # 800072f8 <digits+0x2c0>
    80001fce:	cf4fe0ef          	jal	ra,800004c2 <printf>
    yield(); // safe to call directly, yield() locks itself
    80001fd2:	f25ff0ef          	jal	ra,80001ef6 <yield>
}
    80001fd6:	60e2                	ld	ra,24(sp)
    80001fd8:	6442                	ld	s0,16(sp)
    80001fda:	64a2                	ld	s1,8(sp)
    80001fdc:	6105                	addi	sp,sp,32
    80001fde:	8082                	ret
    printf("[MLFQ DEBUG] Starvation threshold reached (%d ticks). Boosting all priorities.\n",
    80001fe0:	00005517          	auipc	a0,0x5
    80001fe4:	24050513          	addi	a0,a0,576 # 80007220 <digits+0x1e8>
    80001fe8:	cdafe0ef          	jal	ra,800004c2 <printf>
    boost_all_priorities();
    80001fec:	f28ff0ef          	jal	ra,80001714 <boost_all_priorities>
    starvation_counter = 0;
    80001ff0:	00006797          	auipc	a5,0x6
    80001ff4:	9c07a823          	sw	zero,-1584(a5) # 800079c0 <starvation_counter>
    80001ff8:	b7bd                	j	80001f66 <mlfq_tick+0x34>
      printf("[MLFQ DEBUG] PID=%d demoted from priority %d -> %d (used full slice)\n",
    80001ffa:	0016069b          	addiw	a3,a2,1 # 1001 <_entry-0x7fffefff>
    80001ffe:	588c                	lw	a1,48(s1)
    80002000:	00005517          	auipc	a0,0x5
    80002004:	2b050513          	addi	a0,a0,688 # 800072b0 <digits+0x278>
    80002008:	cbafe0ef          	jal	ra,800004c2 <printf>
      p->priority++;
    8000200c:	1684a783          	lw	a5,360(s1)
    80002010:	2785                	addiw	a5,a5,1
    80002012:	16f4a423          	sw	a5,360(s1)
    80002016:	bf61                	j	80001fae <mlfq_tick+0x7c>
    p->yielded_io = 0;
    80002018:	1604ae23          	sw	zero,380(s1)
    8000201c:	bf6d                	j	80001fd6 <mlfq_tick+0xa4>

000000008000201e <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    8000201e:	7179                	addi	sp,sp,-48
    80002020:	f406                	sd	ra,40(sp)
    80002022:	f022                	sd	s0,32(sp)
    80002024:	ec26                	sd	s1,24(sp)
    80002026:	e84a                	sd	s2,16(sp)
    80002028:	e44e                	sd	s3,8(sp)
    8000202a:	1800                	addi	s0,sp,48
    8000202c:	89aa                	mv	s3,a0
    8000202e:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002030:	897ff0ef          	jal	ra,800018c6 <myproc>
    80002034:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80002036:	b35fe0ef          	jal	ra,80000b6a <acquire>
  release(lk);
    8000203a:	854a                	mv	a0,s2
    8000203c:	bc7fe0ef          	jal	ra,80000c02 <release>

  // Go to sleep.
  p->chan = chan;
    80002040:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80002044:	4789                	li	a5,2
    80002046:	cc9c                	sw	a5,24(s1)

  sched();
    80002048:	df5ff0ef          	jal	ra,80001e3c <sched>

  // Tidy up.
  p->chan = 0;
    8000204c:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80002050:	8526                	mv	a0,s1
    80002052:	bb1fe0ef          	jal	ra,80000c02 <release>
  acquire(lk);
    80002056:	854a                	mv	a0,s2
    80002058:	b13fe0ef          	jal	ra,80000b6a <acquire>
}
    8000205c:	70a2                	ld	ra,40(sp)
    8000205e:	7402                	ld	s0,32(sp)
    80002060:	64e2                	ld	s1,24(sp)
    80002062:	6942                	ld	s2,16(sp)
    80002064:	69a2                	ld	s3,8(sp)
    80002066:	6145                	addi	sp,sp,48
    80002068:	8082                	ret

000000008000206a <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    8000206a:	7139                	addi	sp,sp,-64
    8000206c:	fc06                	sd	ra,56(sp)
    8000206e:	f822                	sd	s0,48(sp)
    80002070:	f426                	sd	s1,40(sp)
    80002072:	f04a                	sd	s2,32(sp)
    80002074:	ec4e                	sd	s3,24(sp)
    80002076:	e852                	sd	s4,16(sp)
    80002078:	e456                	sd	s5,8(sp)
    8000207a:	0080                	addi	s0,sp,64
    8000207c:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    8000207e:	0000e497          	auipc	s1,0xe
    80002082:	e8a48493          	addi	s1,s1,-374 # 8000ff08 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80002086:	4989                	li	s3,2
        p->state = RUNNABLE;
    80002088:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    8000208a:	00015917          	auipc	s2,0x15
    8000208e:	87e90913          	addi	s2,s2,-1922 # 80016908 <tickslock>
    80002092:	a801                	j	800020a2 <wakeup+0x38>
      }
      release(&p->lock);
    80002094:	8526                	mv	a0,s1
    80002096:	b6dfe0ef          	jal	ra,80000c02 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000209a:	1a848493          	addi	s1,s1,424
    8000209e:	03248263          	beq	s1,s2,800020c2 <wakeup+0x58>
    if(p != myproc()){
    800020a2:	825ff0ef          	jal	ra,800018c6 <myproc>
    800020a6:	fea48ae3          	beq	s1,a0,8000209a <wakeup+0x30>
      acquire(&p->lock);
    800020aa:	8526                	mv	a0,s1
    800020ac:	abffe0ef          	jal	ra,80000b6a <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800020b0:	4c9c                	lw	a5,24(s1)
    800020b2:	ff3791e3          	bne	a5,s3,80002094 <wakeup+0x2a>
    800020b6:	709c                	ld	a5,32(s1)
    800020b8:	fd479ee3          	bne	a5,s4,80002094 <wakeup+0x2a>
        p->state = RUNNABLE;
    800020bc:	0154ac23          	sw	s5,24(s1)
    800020c0:	bfd1                	j	80002094 <wakeup+0x2a>
    }
  }
}
    800020c2:	70e2                	ld	ra,56(sp)
    800020c4:	7442                	ld	s0,48(sp)
    800020c6:	74a2                	ld	s1,40(sp)
    800020c8:	7902                	ld	s2,32(sp)
    800020ca:	69e2                	ld	s3,24(sp)
    800020cc:	6a42                	ld	s4,16(sp)
    800020ce:	6aa2                	ld	s5,8(sp)
    800020d0:	6121                	addi	sp,sp,64
    800020d2:	8082                	ret

00000000800020d4 <reparent>:
{
    800020d4:	7179                	addi	sp,sp,-48
    800020d6:	f406                	sd	ra,40(sp)
    800020d8:	f022                	sd	s0,32(sp)
    800020da:	ec26                	sd	s1,24(sp)
    800020dc:	e84a                	sd	s2,16(sp)
    800020de:	e44e                	sd	s3,8(sp)
    800020e0:	e052                	sd	s4,0(sp)
    800020e2:	1800                	addi	s0,sp,48
    800020e4:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800020e6:	0000e497          	auipc	s1,0xe
    800020ea:	e2248493          	addi	s1,s1,-478 # 8000ff08 <proc>
      pp->parent = initproc;
    800020ee:	00006a17          	auipc	s4,0x6
    800020f2:	8daa0a13          	addi	s4,s4,-1830 # 800079c8 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800020f6:	00015997          	auipc	s3,0x15
    800020fa:	81298993          	addi	s3,s3,-2030 # 80016908 <tickslock>
    800020fe:	a029                	j	80002108 <reparent+0x34>
    80002100:	1a848493          	addi	s1,s1,424
    80002104:	01348b63          	beq	s1,s3,8000211a <reparent+0x46>
    if(pp->parent == p){
    80002108:	7c9c                	ld	a5,56(s1)
    8000210a:	ff279be3          	bne	a5,s2,80002100 <reparent+0x2c>
      pp->parent = initproc;
    8000210e:	000a3503          	ld	a0,0(s4)
    80002112:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002114:	f57ff0ef          	jal	ra,8000206a <wakeup>
    80002118:	b7e5                	j	80002100 <reparent+0x2c>
}
    8000211a:	70a2                	ld	ra,40(sp)
    8000211c:	7402                	ld	s0,32(sp)
    8000211e:	64e2                	ld	s1,24(sp)
    80002120:	6942                	ld	s2,16(sp)
    80002122:	69a2                	ld	s3,8(sp)
    80002124:	6a02                	ld	s4,0(sp)
    80002126:	6145                	addi	sp,sp,48
    80002128:	8082                	ret

000000008000212a <kexit>:
{
    8000212a:	7179                	addi	sp,sp,-48
    8000212c:	f406                	sd	ra,40(sp)
    8000212e:	f022                	sd	s0,32(sp)
    80002130:	ec26                	sd	s1,24(sp)
    80002132:	e84a                	sd	s2,16(sp)
    80002134:	e44e                	sd	s3,8(sp)
    80002136:	e052                	sd	s4,0(sp)
    80002138:	1800                	addi	s0,sp,48
    8000213a:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000213c:	f8aff0ef          	jal	ra,800018c6 <myproc>
    80002140:	89aa                	mv	s3,a0
  if(p == initproc)
    80002142:	00006797          	auipc	a5,0x6
    80002146:	8867b783          	ld	a5,-1914(a5) # 800079c8 <initproc>
    8000214a:	0d050493          	addi	s1,a0,208
    8000214e:	15050913          	addi	s2,a0,336
    80002152:	00a79f63          	bne	a5,a0,80002170 <kexit+0x46>
    panic("init exiting");
    80002156:	00005517          	auipc	a0,0x5
    8000215a:	1e250513          	addi	a0,a0,482 # 80007338 <digits+0x300>
    8000215e:	e2afe0ef          	jal	ra,80000788 <panic>
      fileclose(f);
    80002162:	0aa020ef          	jal	ra,8000420c <fileclose>
      p->ofile[fd] = 0;
    80002166:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    8000216a:	04a1                	addi	s1,s1,8
    8000216c:	01248563          	beq	s1,s2,80002176 <kexit+0x4c>
    if(p->ofile[fd]){
    80002170:	6088                	ld	a0,0(s1)
    80002172:	f965                	bnez	a0,80002162 <kexit+0x38>
    80002174:	bfdd                	j	8000216a <kexit+0x40>
  begin_op();
    80002176:	48d010ef          	jal	ra,80003e02 <begin_op>
  iput(p->cwd);
    8000217a:	1509b503          	ld	a0,336(s3)
    8000217e:	41a010ef          	jal	ra,80003598 <iput>
  end_op();
    80002182:	4ef010ef          	jal	ra,80003e70 <end_op>
  p->cwd = 0;
    80002186:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000218a:	0000e497          	auipc	s1,0xe
    8000218e:	96648493          	addi	s1,s1,-1690 # 8000faf0 <wait_lock>
    80002192:	8526                	mv	a0,s1
    80002194:	9d7fe0ef          	jal	ra,80000b6a <acquire>
  reparent(p);
    80002198:	854e                	mv	a0,s3
    8000219a:	f3bff0ef          	jal	ra,800020d4 <reparent>
  wakeup(p->parent);
    8000219e:	0389b503          	ld	a0,56(s3)
    800021a2:	ec9ff0ef          	jal	ra,8000206a <wakeup>
  acquire(&p->lock);
    800021a6:	854e                	mv	a0,s3
    800021a8:	9c3fe0ef          	jal	ra,80000b6a <acquire>
  p->xstate = status;
    800021ac:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800021b0:	4795                	li	a5,5
    800021b2:	00f9ac23          	sw	a5,24(s3)
  p->end_time = ticks;  // Record end time for performance metrics
    800021b6:	00006797          	auipc	a5,0x6
    800021ba:	81a7e783          	lwu	a5,-2022(a5) # 800079d0 <ticks>
    800021be:	18f9b423          	sd	a5,392(s3)
  release(&wait_lock);
    800021c2:	8526                	mv	a0,s1
    800021c4:	a3ffe0ef          	jal	ra,80000c02 <release>
  sched();
    800021c8:	c75ff0ef          	jal	ra,80001e3c <sched>
  panic("zombie exit");
    800021cc:	00005517          	auipc	a0,0x5
    800021d0:	17c50513          	addi	a0,a0,380 # 80007348 <digits+0x310>
    800021d4:	db4fe0ef          	jal	ra,80000788 <panic>

00000000800021d8 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800021d8:	7179                	addi	sp,sp,-48
    800021da:	f406                	sd	ra,40(sp)
    800021dc:	f022                	sd	s0,32(sp)
    800021de:	ec26                	sd	s1,24(sp)
    800021e0:	e84a                	sd	s2,16(sp)
    800021e2:	e44e                	sd	s3,8(sp)
    800021e4:	1800                	addi	s0,sp,48
    800021e6:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800021e8:	0000e497          	auipc	s1,0xe
    800021ec:	d2048493          	addi	s1,s1,-736 # 8000ff08 <proc>
    800021f0:	00014997          	auipc	s3,0x14
    800021f4:	71898993          	addi	s3,s3,1816 # 80016908 <tickslock>
    acquire(&p->lock);
    800021f8:	8526                	mv	a0,s1
    800021fa:	971fe0ef          	jal	ra,80000b6a <acquire>
    if(p->pid == pid){
    800021fe:	589c                	lw	a5,48(s1)
    80002200:	01278b63          	beq	a5,s2,80002216 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002204:	8526                	mv	a0,s1
    80002206:	9fdfe0ef          	jal	ra,80000c02 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000220a:	1a848493          	addi	s1,s1,424
    8000220e:	ff3495e3          	bne	s1,s3,800021f8 <kkill+0x20>
  }
  return -1;
    80002212:	557d                	li	a0,-1
    80002214:	a819                	j	8000222a <kkill+0x52>
      p->killed = 1;
    80002216:	4785                	li	a5,1
    80002218:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000221a:	4c98                	lw	a4,24(s1)
    8000221c:	4789                	li	a5,2
    8000221e:	00f70d63          	beq	a4,a5,80002238 <kkill+0x60>
      release(&p->lock);
    80002222:	8526                	mv	a0,s1
    80002224:	9dffe0ef          	jal	ra,80000c02 <release>
      return 0;
    80002228:	4501                	li	a0,0
}
    8000222a:	70a2                	ld	ra,40(sp)
    8000222c:	7402                	ld	s0,32(sp)
    8000222e:	64e2                	ld	s1,24(sp)
    80002230:	6942                	ld	s2,16(sp)
    80002232:	69a2                	ld	s3,8(sp)
    80002234:	6145                	addi	sp,sp,48
    80002236:	8082                	ret
        p->state = RUNNABLE;
    80002238:	478d                	li	a5,3
    8000223a:	cc9c                	sw	a5,24(s1)
    8000223c:	b7dd                	j	80002222 <kkill+0x4a>

000000008000223e <setkilled>:

void
setkilled(struct proc *p)
{
    8000223e:	1101                	addi	sp,sp,-32
    80002240:	ec06                	sd	ra,24(sp)
    80002242:	e822                	sd	s0,16(sp)
    80002244:	e426                	sd	s1,8(sp)
    80002246:	1000                	addi	s0,sp,32
    80002248:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000224a:	921fe0ef          	jal	ra,80000b6a <acquire>
  p->killed = 1;
    8000224e:	4785                	li	a5,1
    80002250:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002252:	8526                	mv	a0,s1
    80002254:	9affe0ef          	jal	ra,80000c02 <release>
}
    80002258:	60e2                	ld	ra,24(sp)
    8000225a:	6442                	ld	s0,16(sp)
    8000225c:	64a2                	ld	s1,8(sp)
    8000225e:	6105                	addi	sp,sp,32
    80002260:	8082                	ret

0000000080002262 <killed>:

int
killed(struct proc *p)
{
    80002262:	1101                	addi	sp,sp,-32
    80002264:	ec06                	sd	ra,24(sp)
    80002266:	e822                	sd	s0,16(sp)
    80002268:	e426                	sd	s1,8(sp)
    8000226a:	e04a                	sd	s2,0(sp)
    8000226c:	1000                	addi	s0,sp,32
    8000226e:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002270:	8fbfe0ef          	jal	ra,80000b6a <acquire>
  k = p->killed;
    80002274:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    80002278:	8526                	mv	a0,s1
    8000227a:	989fe0ef          	jal	ra,80000c02 <release>
  return k;
}
    8000227e:	854a                	mv	a0,s2
    80002280:	60e2                	ld	ra,24(sp)
    80002282:	6442                	ld	s0,16(sp)
    80002284:	64a2                	ld	s1,8(sp)
    80002286:	6902                	ld	s2,0(sp)
    80002288:	6105                	addi	sp,sp,32
    8000228a:	8082                	ret

000000008000228c <kwait>:
{
    8000228c:	715d                	addi	sp,sp,-80
    8000228e:	e486                	sd	ra,72(sp)
    80002290:	e0a2                	sd	s0,64(sp)
    80002292:	fc26                	sd	s1,56(sp)
    80002294:	f84a                	sd	s2,48(sp)
    80002296:	f44e                	sd	s3,40(sp)
    80002298:	f052                	sd	s4,32(sp)
    8000229a:	ec56                	sd	s5,24(sp)
    8000229c:	e85a                	sd	s6,16(sp)
    8000229e:	e45e                	sd	s7,8(sp)
    800022a0:	e062                	sd	s8,0(sp)
    800022a2:	0880                	addi	s0,sp,80
    800022a4:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800022a6:	e20ff0ef          	jal	ra,800018c6 <myproc>
    800022aa:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800022ac:	0000e517          	auipc	a0,0xe
    800022b0:	84450513          	addi	a0,a0,-1980 # 8000faf0 <wait_lock>
    800022b4:	8b7fe0ef          	jal	ra,80000b6a <acquire>
    havekids = 0;
    800022b8:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    800022ba:	4a15                	li	s4,5
        havekids = 1;
    800022bc:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022be:	00014997          	auipc	s3,0x14
    800022c2:	64a98993          	addi	s3,s3,1610 # 80016908 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800022c6:	0000ec17          	auipc	s8,0xe
    800022ca:	82ac0c13          	addi	s8,s8,-2006 # 8000faf0 <wait_lock>
    havekids = 0;
    800022ce:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022d0:	0000e497          	auipc	s1,0xe
    800022d4:	c3848493          	addi	s1,s1,-968 # 8000ff08 <proc>
    800022d8:	a899                	j	8000232e <kwait+0xa2>
          pid = pp->pid;
    800022da:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800022de:	000b0c63          	beqz	s6,800022f6 <kwait+0x6a>
    800022e2:	4691                	li	a3,4
    800022e4:	02c48613          	addi	a2,s1,44
    800022e8:	85da                	mv	a1,s6
    800022ea:	05093503          	ld	a0,80(s2)
    800022ee:	a62ff0ef          	jal	ra,80001550 <copyout>
    800022f2:	00054f63          	bltz	a0,80002310 <kwait+0x84>
          freeproc(pp);
    800022f6:	8526                	mv	a0,s1
    800022f8:	f9eff0ef          	jal	ra,80001a96 <freeproc>
          release(&pp->lock);
    800022fc:	8526                	mv	a0,s1
    800022fe:	905fe0ef          	jal	ra,80000c02 <release>
          release(&wait_lock);
    80002302:	0000d517          	auipc	a0,0xd
    80002306:	7ee50513          	addi	a0,a0,2030 # 8000faf0 <wait_lock>
    8000230a:	8f9fe0ef          	jal	ra,80000c02 <release>
          return pid;
    8000230e:	a891                	j	80002362 <kwait+0xd6>
            release(&pp->lock);
    80002310:	8526                	mv	a0,s1
    80002312:	8f1fe0ef          	jal	ra,80000c02 <release>
            release(&wait_lock);
    80002316:	0000d517          	auipc	a0,0xd
    8000231a:	7da50513          	addi	a0,a0,2010 # 8000faf0 <wait_lock>
    8000231e:	8e5fe0ef          	jal	ra,80000c02 <release>
            return -1;
    80002322:	59fd                	li	s3,-1
    80002324:	a83d                	j	80002362 <kwait+0xd6>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002326:	1a848493          	addi	s1,s1,424
    8000232a:	03348063          	beq	s1,s3,8000234a <kwait+0xbe>
      if(pp->parent == p){
    8000232e:	7c9c                	ld	a5,56(s1)
    80002330:	ff279be3          	bne	a5,s2,80002326 <kwait+0x9a>
        acquire(&pp->lock);
    80002334:	8526                	mv	a0,s1
    80002336:	835fe0ef          	jal	ra,80000b6a <acquire>
        if(pp->state == ZOMBIE){
    8000233a:	4c9c                	lw	a5,24(s1)
    8000233c:	f9478fe3          	beq	a5,s4,800022da <kwait+0x4e>
        release(&pp->lock);
    80002340:	8526                	mv	a0,s1
    80002342:	8c1fe0ef          	jal	ra,80000c02 <release>
        havekids = 1;
    80002346:	8756                	mv	a4,s5
    80002348:	bff9                	j	80002326 <kwait+0x9a>
    if(!havekids || killed(p)){
    8000234a:	c709                	beqz	a4,80002354 <kwait+0xc8>
    8000234c:	854a                	mv	a0,s2
    8000234e:	f15ff0ef          	jal	ra,80002262 <killed>
    80002352:	c50d                	beqz	a0,8000237c <kwait+0xf0>
      release(&wait_lock);
    80002354:	0000d517          	auipc	a0,0xd
    80002358:	79c50513          	addi	a0,a0,1948 # 8000faf0 <wait_lock>
    8000235c:	8a7fe0ef          	jal	ra,80000c02 <release>
      return -1;
    80002360:	59fd                	li	s3,-1
}
    80002362:	854e                	mv	a0,s3
    80002364:	60a6                	ld	ra,72(sp)
    80002366:	6406                	ld	s0,64(sp)
    80002368:	74e2                	ld	s1,56(sp)
    8000236a:	7942                	ld	s2,48(sp)
    8000236c:	79a2                	ld	s3,40(sp)
    8000236e:	7a02                	ld	s4,32(sp)
    80002370:	6ae2                	ld	s5,24(sp)
    80002372:	6b42                	ld	s6,16(sp)
    80002374:	6ba2                	ld	s7,8(sp)
    80002376:	6c02                	ld	s8,0(sp)
    80002378:	6161                	addi	sp,sp,80
    8000237a:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000237c:	85e2                	mv	a1,s8
    8000237e:	854a                	mv	a0,s2
    80002380:	c9fff0ef          	jal	ra,8000201e <sleep>
    havekids = 0;
    80002384:	b7a9                	j	800022ce <kwait+0x42>

0000000080002386 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002386:	7179                	addi	sp,sp,-48
    80002388:	f406                	sd	ra,40(sp)
    8000238a:	f022                	sd	s0,32(sp)
    8000238c:	ec26                	sd	s1,24(sp)
    8000238e:	e84a                	sd	s2,16(sp)
    80002390:	e44e                	sd	s3,8(sp)
    80002392:	e052                	sd	s4,0(sp)
    80002394:	1800                	addi	s0,sp,48
    80002396:	84aa                	mv	s1,a0
    80002398:	892e                	mv	s2,a1
    8000239a:	89b2                	mv	s3,a2
    8000239c:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000239e:	d28ff0ef          	jal	ra,800018c6 <myproc>
  if(user_dst){
    800023a2:	cc99                	beqz	s1,800023c0 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800023a4:	86d2                	mv	a3,s4
    800023a6:	864e                	mv	a2,s3
    800023a8:	85ca                	mv	a1,s2
    800023aa:	6928                	ld	a0,80(a0)
    800023ac:	9a4ff0ef          	jal	ra,80001550 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800023b0:	70a2                	ld	ra,40(sp)
    800023b2:	7402                	ld	s0,32(sp)
    800023b4:	64e2                	ld	s1,24(sp)
    800023b6:	6942                	ld	s2,16(sp)
    800023b8:	69a2                	ld	s3,8(sp)
    800023ba:	6a02                	ld	s4,0(sp)
    800023bc:	6145                	addi	sp,sp,48
    800023be:	8082                	ret
    memmove((char *)dst, src, len);
    800023c0:	000a061b          	sext.w	a2,s4
    800023c4:	85ce                	mv	a1,s3
    800023c6:	854a                	mv	a0,s2
    800023c8:	8d3fe0ef          	jal	ra,80000c9a <memmove>
    return 0;
    800023cc:	8526                	mv	a0,s1
    800023ce:	b7cd                	j	800023b0 <either_copyout+0x2a>

00000000800023d0 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800023d0:	7179                	addi	sp,sp,-48
    800023d2:	f406                	sd	ra,40(sp)
    800023d4:	f022                	sd	s0,32(sp)
    800023d6:	ec26                	sd	s1,24(sp)
    800023d8:	e84a                	sd	s2,16(sp)
    800023da:	e44e                	sd	s3,8(sp)
    800023dc:	e052                	sd	s4,0(sp)
    800023de:	1800                	addi	s0,sp,48
    800023e0:	892a                	mv	s2,a0
    800023e2:	84ae                	mv	s1,a1
    800023e4:	89b2                	mv	s3,a2
    800023e6:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800023e8:	cdeff0ef          	jal	ra,800018c6 <myproc>
  if(user_src){
    800023ec:	cc99                	beqz	s1,8000240a <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800023ee:	86d2                	mv	a3,s4
    800023f0:	864e                	mv	a2,s3
    800023f2:	85ca                	mv	a1,s2
    800023f4:	6928                	ld	a0,80(a0)
    800023f6:	a20ff0ef          	jal	ra,80001616 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800023fa:	70a2                	ld	ra,40(sp)
    800023fc:	7402                	ld	s0,32(sp)
    800023fe:	64e2                	ld	s1,24(sp)
    80002400:	6942                	ld	s2,16(sp)
    80002402:	69a2                	ld	s3,8(sp)
    80002404:	6a02                	ld	s4,0(sp)
    80002406:	6145                	addi	sp,sp,48
    80002408:	8082                	ret
    memmove(dst, (char*)src, len);
    8000240a:	000a061b          	sext.w	a2,s4
    8000240e:	85ce                	mv	a1,s3
    80002410:	854a                	mv	a0,s2
    80002412:	889fe0ef          	jal	ra,80000c9a <memmove>
    return 0;
    80002416:	8526                	mv	a0,s1
    80002418:	b7cd                	j	800023fa <either_copyin+0x2a>

000000008000241a <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000241a:	715d                	addi	sp,sp,-80
    8000241c:	e486                	sd	ra,72(sp)
    8000241e:	e0a2                	sd	s0,64(sp)
    80002420:	fc26                	sd	s1,56(sp)
    80002422:	f84a                	sd	s2,48(sp)
    80002424:	f44e                	sd	s3,40(sp)
    80002426:	f052                	sd	s4,32(sp)
    80002428:	ec56                	sd	s5,24(sp)
    8000242a:	e85a                	sd	s6,16(sp)
    8000242c:	e45e                	sd	s7,8(sp)
    8000242e:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80002430:	00005517          	auipc	a0,0x5
    80002434:	c9050513          	addi	a0,a0,-880 # 800070c0 <digits+0x88>
    80002438:	88afe0ef          	jal	ra,800004c2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000243c:	0000e497          	auipc	s1,0xe
    80002440:	c2448493          	addi	s1,s1,-988 # 80010060 <proc+0x158>
    80002444:	00014917          	auipc	s2,0x14
    80002448:	61c90913          	addi	s2,s2,1564 # 80016a60 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000244c:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000244e:	00005997          	auipc	s3,0x5
    80002452:	f0a98993          	addi	s3,s3,-246 # 80007358 <digits+0x320>
    printf("%d %s %s", p->pid, state, p->name);
    80002456:	00005a97          	auipc	s5,0x5
    8000245a:	f0aa8a93          	addi	s5,s5,-246 # 80007360 <digits+0x328>
    printf("\n");
    8000245e:	00005a17          	auipc	s4,0x5
    80002462:	c62a0a13          	addi	s4,s4,-926 # 800070c0 <digits+0x88>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002466:	00005b97          	auipc	s7,0x5
    8000246a:	f3ab8b93          	addi	s7,s7,-198 # 800073a0 <states.0>
    8000246e:	a829                	j	80002488 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002470:	ed86a583          	lw	a1,-296(a3)
    80002474:	8556                	mv	a0,s5
    80002476:	84cfe0ef          	jal	ra,800004c2 <printf>
    printf("\n");
    8000247a:	8552                	mv	a0,s4
    8000247c:	846fe0ef          	jal	ra,800004c2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002480:	1a848493          	addi	s1,s1,424
    80002484:	03248263          	beq	s1,s2,800024a8 <procdump+0x8e>
    if(p->state == UNUSED)
    80002488:	86a6                	mv	a3,s1
    8000248a:	ec04a783          	lw	a5,-320(s1)
    8000248e:	dbed                	beqz	a5,80002480 <procdump+0x66>
      state = "???";
    80002490:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002492:	fcfb6fe3          	bltu	s6,a5,80002470 <procdump+0x56>
    80002496:	02079713          	slli	a4,a5,0x20
    8000249a:	01d75793          	srli	a5,a4,0x1d
    8000249e:	97de                	add	a5,a5,s7
    800024a0:	6390                	ld	a2,0(a5)
    800024a2:	f679                	bnez	a2,80002470 <procdump+0x56>
      state = "???";
    800024a4:	864e                	mv	a2,s3
    800024a6:	b7e9                	j	80002470 <procdump+0x56>
  }
}
    800024a8:	60a6                	ld	ra,72(sp)
    800024aa:	6406                	ld	s0,64(sp)
    800024ac:	74e2                	ld	s1,56(sp)
    800024ae:	7942                	ld	s2,48(sp)
    800024b0:	79a2                	ld	s3,40(sp)
    800024b2:	7a02                	ld	s4,32(sp)
    800024b4:	6ae2                	ld	s5,24(sp)
    800024b6:	6b42                	ld	s6,16(sp)
    800024b8:	6ba2                	ld	s7,8(sp)
    800024ba:	6161                	addi	sp,sp,80
    800024bc:	8082                	ret

00000000800024be <getprocinfo>:
// ============= NEW SYSTEM CALL: getprocinfo =============
// Returns performance information for a specific process
// This system call allows user programs to get detailed performance metrics
int
getprocinfo(int pid, uint64 addr)
{
    800024be:	7119                	addi	sp,sp,-128
    800024c0:	fc86                	sd	ra,120(sp)
    800024c2:	f8a2                	sd	s0,112(sp)
    800024c4:	f4a6                	sd	s1,104(sp)
    800024c6:	f0ca                	sd	s2,96(sp)
    800024c8:	ecce                	sd	s3,88(sp)
    800024ca:	e8d2                	sd	s4,80(sp)
    800024cc:	e4d6                	sd	s5,72(sp)
    800024ce:	0100                	addi	s0,sp,128
    800024d0:	892a                	mv	s2,a0
    800024d2:	8aae                	mv	s5,a1
  struct proc *p;                    // Pointer to iterate through process table
  struct proc *current = myproc();   // Current calling process
    800024d4:	bf2ff0ef          	jal	ra,800018c6 <myproc>
    800024d8:	8a2a                	mv	s4,a0
  struct procinfo info;             // Structure to hold process information
  
  // Search for process with matching PID in the process table
  for(p = proc; p < &proc[NPROC]; p++){
    800024da:	0000e497          	auipc	s1,0xe
    800024de:	a2e48493          	addi	s1,s1,-1490 # 8000ff08 <proc>
    800024e2:	00014997          	auipc	s3,0x14
    800024e6:	42698993          	addi	s3,s3,1062 # 80016908 <tickslock>
    800024ea:	a801                	j	800024fa <getprocinfo+0x3c>
      }
      
      return 0;                      // Success - information copied successfully
    }
    
    release(&p->lock);               // Release lock if this wasn't the right process
    800024ec:	8526                	mv	a0,s1
    800024ee:	f14fe0ef          	jal	ra,80000c02 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800024f2:	1a848493          	addi	s1,s1,424
    800024f6:	09348863          	beq	s1,s3,80002586 <getprocinfo+0xc8>
    acquire(&p->lock);               // Acquire lock to safely read process data
    800024fa:	8526                	mv	a0,s1
    800024fc:	e6efe0ef          	jal	ra,80000b6a <acquire>
    if(p->pid == pid && p->state != UNUSED) {
    80002500:	589c                	lw	a5,48(s1)
    80002502:	ff2795e3          	bne	a5,s2,800024ec <getprocinfo+0x2e>
    80002506:	4c98                	lw	a4,24(s1)
    80002508:	d375                	beqz	a4,800024ec <getprocinfo+0x2e>
      info.pid = p->pid;             // Process ID
    8000250a:	f8f42423          	sw	a5,-120(s0)
      info.priority = p->priority;   // Current priority level (0=high, 2=low)
    8000250e:	1684a783          	lw	a5,360(s1)
    80002512:	f8f42623          	sw	a5,-116(s0)
      info.cpu_ticks = p->cpu_ticks; // Total CPU ticks consumed by process
    80002516:	1744a783          	lw	a5,372(s1)
    8000251a:	f8f42823          	sw	a5,-112(s0)
      info.sched_count = p->sched_count;     // Number of times process was scheduled
    8000251e:	1784a783          	lw	a5,376(s1)
    80002522:	f8f42a23          	sw	a5,-108(s0)
      info.timeslice_used = p->timeslice_used; // Ticks used in current time slice
    80002526:	1704a783          	lw	a5,368(s1)
    8000252a:	f8f42c23          	sw	a5,-104(s0)
      info.start_time = p->start_time;
    8000252e:	1804b783          	ld	a5,384(s1)
    80002532:	faf43023          	sd	a5,-96(s0)
      info.end_time = (p->end_time > 0) ? p->end_time : ticks;          // When process finished (0 if running)
    80002536:	1884b783          	ld	a5,392(s1)
    8000253a:	e789                	bnez	a5,80002544 <getprocinfo+0x86>
    8000253c:	00005797          	auipc	a5,0x5
    80002540:	4947e783          	lwu	a5,1172(a5) # 800079d0 <ticks>
    80002544:	faf43423          	sd	a5,-88(s0)
      info.first_run = p->first_run;         // When process was first scheduled
    80002548:	1904b783          	ld	a5,400(s1)
    8000254c:	faf43823          	sd	a5,-80(s0)
      info.total_wait = p->total_wait;       // Total accumulated wait time
    80002550:	1984b783          	ld	a5,408(s1)
    80002554:	faf43c23          	sd	a5,-72(s0)
      release(&p->lock);             // Release lock before copying to user space
    80002558:	8526                	mv	a0,s1
    8000255a:	ea8fe0ef          	jal	ra,80000c02 <release>
      if(copyout(current->pagetable, addr, (char *)&info, sizeof(info)) < 0) {
    8000255e:	03800693          	li	a3,56
    80002562:	f8840613          	addi	a2,s0,-120
    80002566:	85d6                	mv	a1,s5
    80002568:	050a3503          	ld	a0,80(s4)
    8000256c:	fe5fe0ef          	jal	ra,80001550 <copyout>
    80002570:	41f5551b          	sraiw	a0,a0,0x1f
  }
  
  return -1;                         // Process not found with given PID
}
    80002574:	70e6                	ld	ra,120(sp)
    80002576:	7446                	ld	s0,112(sp)
    80002578:	74a6                	ld	s1,104(sp)
    8000257a:	7906                	ld	s2,96(sp)
    8000257c:	69e6                	ld	s3,88(sp)
    8000257e:	6a46                	ld	s4,80(sp)
    80002580:	6aa6                	ld	s5,72(sp)
    80002582:	6109                	addi	sp,sp,128
    80002584:	8082                	ret
  return -1;                         // Process not found with given PID
    80002586:	557d                	li	a0,-1
    80002588:	b7f5                	j	80002574 <getprocinfo+0xb6>

000000008000258a <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    8000258a:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    8000258e:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002592:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002594:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002596:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    8000259a:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    8000259e:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800025a2:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800025a6:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800025aa:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800025ae:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800025b2:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800025b6:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800025ba:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800025be:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800025c2:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800025c6:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800025c8:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    800025ca:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    800025ce:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    800025d2:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800025d6:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800025da:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800025de:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800025e2:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800025e6:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800025ea:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800025ee:	0685bd83          	ld	s11,104(a1)
        
        ret
    800025f2:	8082                	ret

00000000800025f4 <trapinit>:
/* MLFQ tick handler prototype (implemented in proc.c) */
void mlfq_tick(void);

void
trapinit(void)
{
    800025f4:	1141                	addi	sp,sp,-16
    800025f6:	e406                	sd	ra,8(sp)
    800025f8:	e022                	sd	s0,0(sp)
    800025fa:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800025fc:	00005597          	auipc	a1,0x5
    80002600:	dd458593          	addi	a1,a1,-556 # 800073d0 <states.0+0x30>
    80002604:	00014517          	auipc	a0,0x14
    80002608:	30450513          	addi	a0,a0,772 # 80016908 <tickslock>
    8000260c:	cdefe0ef          	jal	ra,80000aea <initlock>
}
    80002610:	60a2                	ld	ra,8(sp)
    80002612:	6402                	ld	s0,0(sp)
    80002614:	0141                	addi	sp,sp,16
    80002616:	8082                	ret

0000000080002618 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002618:	1141                	addi	sp,sp,-16
    8000261a:	e422                	sd	s0,8(sp)
    8000261c:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000261e:	00003797          	auipc	a5,0x3
    80002622:	eb278793          	addi	a5,a5,-334 # 800054d0 <kernelvec>
    80002626:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000262a:	6422                	ld	s0,8(sp)
    8000262c:	0141                	addi	sp,sp,16
    8000262e:	8082                	ret

0000000080002630 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002630:	1141                	addi	sp,sp,-16
    80002632:	e406                	sd	ra,8(sp)
    80002634:	e022                	sd	s0,0(sp)
    80002636:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002638:	a8eff0ef          	jal	ra,800018c6 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000263c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002640:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002642:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002646:	04000737          	lui	a4,0x4000
    8000264a:	00004797          	auipc	a5,0x4
    8000264e:	9b678793          	addi	a5,a5,-1610 # 80006000 <_trampoline>
    80002652:	00004697          	auipc	a3,0x4
    80002656:	9ae68693          	addi	a3,a3,-1618 # 80006000 <_trampoline>
    8000265a:	8f95                	sub	a5,a5,a3
    8000265c:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000265e:	0732                	slli	a4,a4,0xc
    80002660:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002662:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002666:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002668:	18002773          	csrr	a4,satp
    8000266c:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000266e:	6d38                	ld	a4,88(a0)
    80002670:	613c                	ld	a5,64(a0)
    80002672:	6685                	lui	a3,0x1
    80002674:	97b6                	add	a5,a5,a3
    80002676:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002678:	6d3c                	ld	a5,88(a0)
    8000267a:	00000717          	auipc	a4,0x0
    8000267e:	0f470713          	addi	a4,a4,244 # 8000276e <usertrap>
    80002682:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002684:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002686:	8712                	mv	a4,tp
    80002688:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000268a:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000268e:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002692:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002696:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000269a:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000269c:	6f9c                	ld	a5,24(a5)
    8000269e:	14179073          	csrw	sepc,a5
}
    800026a2:	60a2                	ld	ra,8(sp)
    800026a4:	6402                	ld	s0,0(sp)
    800026a6:	0141                	addi	sp,sp,16
    800026a8:	8082                	ret

00000000800026aa <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800026aa:	1101                	addi	sp,sp,-32
    800026ac:	ec06                	sd	ra,24(sp)
    800026ae:	e822                	sd	s0,16(sp)
    800026b0:	e426                	sd	s1,8(sp)
    800026b2:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    800026b4:	9e6ff0ef          	jal	ra,8000189a <cpuid>
    800026b8:	cd19                	beqz	a0,800026d6 <clockintr+0x2c>
  asm volatile("csrr %0, time" : "=r" (x) );
    800026ba:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800026be:	000f4737          	lui	a4,0xf4
    800026c2:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800026c6:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800026c8:	14d79073          	csrw	0x14d,a5
}
    800026cc:	60e2                	ld	ra,24(sp)
    800026ce:	6442                	ld	s0,16(sp)
    800026d0:	64a2                	ld	s1,8(sp)
    800026d2:	6105                	addi	sp,sp,32
    800026d4:	8082                	ret
    acquire(&tickslock);
    800026d6:	00014497          	auipc	s1,0x14
    800026da:	23248493          	addi	s1,s1,562 # 80016908 <tickslock>
    800026de:	8526                	mv	a0,s1
    800026e0:	c8afe0ef          	jal	ra,80000b6a <acquire>
    ticks++;
    800026e4:	00005517          	auipc	a0,0x5
    800026e8:	2ec50513          	addi	a0,a0,748 # 800079d0 <ticks>
    800026ec:	411c                	lw	a5,0(a0)
    800026ee:	2785                	addiw	a5,a5,1
    800026f0:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800026f2:	979ff0ef          	jal	ra,8000206a <wakeup>
    release(&tickslock);
    800026f6:	8526                	mv	a0,s1
    800026f8:	d0afe0ef          	jal	ra,80000c02 <release>
    800026fc:	bf7d                	j	800026ba <clockintr+0x10>

00000000800026fe <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800026fe:	1101                	addi	sp,sp,-32
    80002700:	ec06                	sd	ra,24(sp)
    80002702:	e822                	sd	s0,16(sp)
    80002704:	e426                	sd	s1,8(sp)
    80002706:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002708:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    8000270c:	57fd                	li	a5,-1
    8000270e:	17fe                	slli	a5,a5,0x3f
    80002710:	07a5                	addi	a5,a5,9
    80002712:	00f70d63          	beq	a4,a5,8000272c <devintr+0x2e>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002716:	57fd                	li	a5,-1
    80002718:	17fe                	slli	a5,a5,0x3f
    8000271a:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000271c:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    8000271e:	04f70463          	beq	a4,a5,80002766 <devintr+0x68>
  }
}
    80002722:	60e2                	ld	ra,24(sp)
    80002724:	6442                	ld	s0,16(sp)
    80002726:	64a2                	ld	s1,8(sp)
    80002728:	6105                	addi	sp,sp,32
    8000272a:	8082                	ret
    int irq = plic_claim();
    8000272c:	64d020ef          	jal	ra,80005578 <plic_claim>
    80002730:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002732:	47a9                	li	a5,10
    80002734:	02f50363          	beq	a0,a5,8000275a <devintr+0x5c>
    } else if(irq == VIRTIO0_IRQ){
    80002738:	4785                	li	a5,1
    8000273a:	02f50363          	beq	a0,a5,80002760 <devintr+0x62>
    return 1;
    8000273e:	4505                	li	a0,1
    } else if(irq){
    80002740:	d0ed                	beqz	s1,80002722 <devintr+0x24>
      printf("unexpected interrupt irq=%d\n", irq);
    80002742:	85a6                	mv	a1,s1
    80002744:	00005517          	auipc	a0,0x5
    80002748:	c9450513          	addi	a0,a0,-876 # 800073d8 <states.0+0x38>
    8000274c:	d77fd0ef          	jal	ra,800004c2 <printf>
      plic_complete(irq);
    80002750:	8526                	mv	a0,s1
    80002752:	647020ef          	jal	ra,80005598 <plic_complete>
    return 1;
    80002756:	4505                	li	a0,1
    80002758:	b7e9                	j	80002722 <devintr+0x24>
      uartintr();
    8000275a:	9fafe0ef          	jal	ra,80000954 <uartintr>
    8000275e:	bfcd                	j	80002750 <devintr+0x52>
      virtio_disk_intr();
    80002760:	2a4030ef          	jal	ra,80005a04 <virtio_disk_intr>
    80002764:	b7f5                	j	80002750 <devintr+0x52>
    clockintr();
    80002766:	f45ff0ef          	jal	ra,800026aa <clockintr>
    return 2;
    8000276a:	4509                	li	a0,2
    8000276c:	bf5d                	j	80002722 <devintr+0x24>

000000008000276e <usertrap>:
{
    8000276e:	1101                	addi	sp,sp,-32
    80002770:	ec06                	sd	ra,24(sp)
    80002772:	e822                	sd	s0,16(sp)
    80002774:	e426                	sd	s1,8(sp)
    80002776:	e04a                	sd	s2,0(sp)
    80002778:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000277a:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    8000277e:	1007f793          	andi	a5,a5,256
    80002782:	eba5                	bnez	a5,800027f2 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002784:	00003797          	auipc	a5,0x3
    80002788:	d4c78793          	addi	a5,a5,-692 # 800054d0 <kernelvec>
    8000278c:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002790:	936ff0ef          	jal	ra,800018c6 <myproc>
    80002794:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002796:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002798:	14102773          	csrr	a4,sepc
    8000279c:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000279e:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800027a2:	47a1                	li	a5,8
    800027a4:	04f70d63          	beq	a4,a5,800027fe <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    800027a8:	f57ff0ef          	jal	ra,800026fe <devintr>
    800027ac:	892a                	mv	s2,a0
    800027ae:	e945                	bnez	a0,8000285e <usertrap+0xf0>
    800027b0:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800027b4:	47bd                	li	a5,15
    800027b6:	08f70863          	beq	a4,a5,80002846 <usertrap+0xd8>
    800027ba:	14202773          	csrr	a4,scause
    800027be:	47b5                	li	a5,13
    800027c0:	08f70363          	beq	a4,a5,80002846 <usertrap+0xd8>
    800027c4:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800027c8:	5890                	lw	a2,48(s1)
    800027ca:	00005517          	auipc	a0,0x5
    800027ce:	c4e50513          	addi	a0,a0,-946 # 80007418 <states.0+0x78>
    800027d2:	cf1fd0ef          	jal	ra,800004c2 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800027d6:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800027da:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800027de:	00005517          	auipc	a0,0x5
    800027e2:	c6a50513          	addi	a0,a0,-918 # 80007448 <states.0+0xa8>
    800027e6:	cddfd0ef          	jal	ra,800004c2 <printf>
    setkilled(p);
    800027ea:	8526                	mv	a0,s1
    800027ec:	a53ff0ef          	jal	ra,8000223e <setkilled>
    800027f0:	a035                	j	8000281c <usertrap+0xae>
    panic("usertrap: not from user mode");
    800027f2:	00005517          	auipc	a0,0x5
    800027f6:	c0650513          	addi	a0,a0,-1018 # 800073f8 <states.0+0x58>
    800027fa:	f8ffd0ef          	jal	ra,80000788 <panic>
    if(killed(p))
    800027fe:	a65ff0ef          	jal	ra,80002262 <killed>
    80002802:	ed15                	bnez	a0,8000283e <usertrap+0xd0>
    p->trapframe->epc += 4;
    80002804:	6cb8                	ld	a4,88(s1)
    80002806:	6f1c                	ld	a5,24(a4)
    80002808:	0791                	addi	a5,a5,4
    8000280a:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000280c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002810:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002814:	10079073          	csrw	sstatus,a5
    syscall();
    80002818:	254000ef          	jal	ra,80002a6c <syscall>
  if(killed(p))
    8000281c:	8526                	mv	a0,s1
    8000281e:	a45ff0ef          	jal	ra,80002262 <killed>
    80002822:	e139                	bnez	a0,80002868 <usertrap+0xfa>
  prepare_return();
    80002824:	e0dff0ef          	jal	ra,80002630 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002828:	68a8                	ld	a0,80(s1)
    8000282a:	8131                	srli	a0,a0,0xc
    8000282c:	57fd                	li	a5,-1
    8000282e:	17fe                	slli	a5,a5,0x3f
    80002830:	8d5d                	or	a0,a0,a5
}
    80002832:	60e2                	ld	ra,24(sp)
    80002834:	6442                	ld	s0,16(sp)
    80002836:	64a2                	ld	s1,8(sp)
    80002838:	6902                	ld	s2,0(sp)
    8000283a:	6105                	addi	sp,sp,32
    8000283c:	8082                	ret
      kexit(-1);
    8000283e:	557d                	li	a0,-1
    80002840:	8ebff0ef          	jal	ra,8000212a <kexit>
    80002844:	b7c1                	j	80002804 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002846:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000284a:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    8000284e:	164d                	addi	a2,a2,-13
    80002850:	00163613          	seqz	a2,a2
    80002854:	68a8                	ld	a0,80(s1)
    80002856:	c89fe0ef          	jal	ra,800014de <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    8000285a:	f169                	bnez	a0,8000281c <usertrap+0xae>
    8000285c:	b7a5                	j	800027c4 <usertrap+0x56>
  if(killed(p))
    8000285e:	8526                	mv	a0,s1
    80002860:	a03ff0ef          	jal	ra,80002262 <killed>
    80002864:	c511                	beqz	a0,80002870 <usertrap+0x102>
    80002866:	a011                	j	8000286a <usertrap+0xfc>
    80002868:	4901                	li	s2,0
    kexit(-1);
    8000286a:	557d                	li	a0,-1
    8000286c:	8bfff0ef          	jal	ra,8000212a <kexit>
  if(which_dev == 2) {
    80002870:	4789                	li	a5,2
    80002872:	faf919e3          	bne	s2,a5,80002824 <usertrap+0xb6>
    mlfq_tick();
    80002876:	ebcff0ef          	jal	ra,80001f32 <mlfq_tick>
    if(p->timeslice_used == 0)  // preempt only when slice expired
    8000287a:	1704a783          	lw	a5,368(s1)
    8000287e:	f3dd                	bnez	a5,80002824 <usertrap+0xb6>
        yield();
    80002880:	e76ff0ef          	jal	ra,80001ef6 <yield>
    80002884:	b745                	j	80002824 <usertrap+0xb6>

0000000080002886 <kerneltrap>:
{
    80002886:	7179                	addi	sp,sp,-48
    80002888:	f406                	sd	ra,40(sp)
    8000288a:	f022                	sd	s0,32(sp)
    8000288c:	ec26                	sd	s1,24(sp)
    8000288e:	e84a                	sd	s2,16(sp)
    80002890:	e44e                	sd	s3,8(sp)
    80002892:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002894:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002898:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000289c:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    800028a0:	1004f793          	andi	a5,s1,256
    800028a4:	c795                	beqz	a5,800028d0 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028a6:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800028aa:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800028ac:	eb85                	bnez	a5,800028dc <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    800028ae:	e51ff0ef          	jal	ra,800026fe <devintr>
    800028b2:	c91d                	beqz	a0,800028e8 <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0) {
    800028b4:	4789                	li	a5,2
    800028b6:	04f50a63          	beq	a0,a5,8000290a <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800028ba:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800028be:	10049073          	csrw	sstatus,s1
}
    800028c2:	70a2                	ld	ra,40(sp)
    800028c4:	7402                	ld	s0,32(sp)
    800028c6:	64e2                	ld	s1,24(sp)
    800028c8:	6942                	ld	s2,16(sp)
    800028ca:	69a2                	ld	s3,8(sp)
    800028cc:	6145                	addi	sp,sp,48
    800028ce:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800028d0:	00005517          	auipc	a0,0x5
    800028d4:	ba050513          	addi	a0,a0,-1120 # 80007470 <states.0+0xd0>
    800028d8:	eb1fd0ef          	jal	ra,80000788 <panic>
    panic("kerneltrap: interrupts enabled");
    800028dc:	00005517          	auipc	a0,0x5
    800028e0:	bbc50513          	addi	a0,a0,-1092 # 80007498 <states.0+0xf8>
    800028e4:	ea5fd0ef          	jal	ra,80000788 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800028e8:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800028ec:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800028f0:	85ce                	mv	a1,s3
    800028f2:	00005517          	auipc	a0,0x5
    800028f6:	bc650513          	addi	a0,a0,-1082 # 800074b8 <states.0+0x118>
    800028fa:	bc9fd0ef          	jal	ra,800004c2 <printf>
    panic("kerneltrap");
    800028fe:	00005517          	auipc	a0,0x5
    80002902:	be250513          	addi	a0,a0,-1054 # 800074e0 <states.0+0x140>
    80002906:	e83fd0ef          	jal	ra,80000788 <panic>
  if(which_dev == 2 && myproc() != 0) {
    8000290a:	fbdfe0ef          	jal	ra,800018c6 <myproc>
    8000290e:	d555                	beqz	a0,800028ba <kerneltrap+0x34>
    mlfq_tick();
    80002910:	e22ff0ef          	jal	ra,80001f32 <mlfq_tick>
    yield();
    80002914:	de2ff0ef          	jal	ra,80001ef6 <yield>
    80002918:	b74d                	j	800028ba <kerneltrap+0x34>

000000008000291a <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    8000291a:	1101                	addi	sp,sp,-32
    8000291c:	ec06                	sd	ra,24(sp)
    8000291e:	e822                	sd	s0,16(sp)
    80002920:	e426                	sd	s1,8(sp)
    80002922:	1000                	addi	s0,sp,32
    80002924:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002926:	fa1fe0ef          	jal	ra,800018c6 <myproc>
  switch (n) {
    8000292a:	4795                	li	a5,5
    8000292c:	0497e163          	bltu	a5,s1,8000296e <argraw+0x54>
    80002930:	048a                	slli	s1,s1,0x2
    80002932:	00005717          	auipc	a4,0x5
    80002936:	be670713          	addi	a4,a4,-1050 # 80007518 <states.0+0x178>
    8000293a:	94ba                	add	s1,s1,a4
    8000293c:	409c                	lw	a5,0(s1)
    8000293e:	97ba                	add	a5,a5,a4
    80002940:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002942:	6d3c                	ld	a5,88(a0)
    80002944:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002946:	60e2                	ld	ra,24(sp)
    80002948:	6442                	ld	s0,16(sp)
    8000294a:	64a2                	ld	s1,8(sp)
    8000294c:	6105                	addi	sp,sp,32
    8000294e:	8082                	ret
    return p->trapframe->a1;
    80002950:	6d3c                	ld	a5,88(a0)
    80002952:	7fa8                	ld	a0,120(a5)
    80002954:	bfcd                	j	80002946 <argraw+0x2c>
    return p->trapframe->a2;
    80002956:	6d3c                	ld	a5,88(a0)
    80002958:	63c8                	ld	a0,128(a5)
    8000295a:	b7f5                	j	80002946 <argraw+0x2c>
    return p->trapframe->a3;
    8000295c:	6d3c                	ld	a5,88(a0)
    8000295e:	67c8                	ld	a0,136(a5)
    80002960:	b7dd                	j	80002946 <argraw+0x2c>
    return p->trapframe->a4;
    80002962:	6d3c                	ld	a5,88(a0)
    80002964:	6bc8                	ld	a0,144(a5)
    80002966:	b7c5                	j	80002946 <argraw+0x2c>
    return p->trapframe->a5;
    80002968:	6d3c                	ld	a5,88(a0)
    8000296a:	6fc8                	ld	a0,152(a5)
    8000296c:	bfe9                	j	80002946 <argraw+0x2c>
  panic("argraw");
    8000296e:	00005517          	auipc	a0,0x5
    80002972:	b8250513          	addi	a0,a0,-1150 # 800074f0 <states.0+0x150>
    80002976:	e13fd0ef          	jal	ra,80000788 <panic>

000000008000297a <fetchaddr>:
{
    8000297a:	1101                	addi	sp,sp,-32
    8000297c:	ec06                	sd	ra,24(sp)
    8000297e:	e822                	sd	s0,16(sp)
    80002980:	e426                	sd	s1,8(sp)
    80002982:	e04a                	sd	s2,0(sp)
    80002984:	1000                	addi	s0,sp,32
    80002986:	84aa                	mv	s1,a0
    80002988:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000298a:	f3dfe0ef          	jal	ra,800018c6 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    8000298e:	653c                	ld	a5,72(a0)
    80002990:	02f4f663          	bgeu	s1,a5,800029bc <fetchaddr+0x42>
    80002994:	00848713          	addi	a4,s1,8
    80002998:	02e7e463          	bltu	a5,a4,800029c0 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000299c:	46a1                	li	a3,8
    8000299e:	8626                	mv	a2,s1
    800029a0:	85ca                	mv	a1,s2
    800029a2:	6928                	ld	a0,80(a0)
    800029a4:	c73fe0ef          	jal	ra,80001616 <copyin>
    800029a8:	00a03533          	snez	a0,a0
    800029ac:	40a00533          	neg	a0,a0
}
    800029b0:	60e2                	ld	ra,24(sp)
    800029b2:	6442                	ld	s0,16(sp)
    800029b4:	64a2                	ld	s1,8(sp)
    800029b6:	6902                	ld	s2,0(sp)
    800029b8:	6105                	addi	sp,sp,32
    800029ba:	8082                	ret
    return -1;
    800029bc:	557d                	li	a0,-1
    800029be:	bfcd                	j	800029b0 <fetchaddr+0x36>
    800029c0:	557d                	li	a0,-1
    800029c2:	b7fd                	j	800029b0 <fetchaddr+0x36>

00000000800029c4 <fetchstr>:
{
    800029c4:	7179                	addi	sp,sp,-48
    800029c6:	f406                	sd	ra,40(sp)
    800029c8:	f022                	sd	s0,32(sp)
    800029ca:	ec26                	sd	s1,24(sp)
    800029cc:	e84a                	sd	s2,16(sp)
    800029ce:	e44e                	sd	s3,8(sp)
    800029d0:	1800                	addi	s0,sp,48
    800029d2:	892a                	mv	s2,a0
    800029d4:	84ae                	mv	s1,a1
    800029d6:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    800029d8:	eeffe0ef          	jal	ra,800018c6 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    800029dc:	86ce                	mv	a3,s3
    800029de:	864a                	mv	a2,s2
    800029e0:	85a6                	mv	a1,s1
    800029e2:	6928                	ld	a0,80(a0)
    800029e4:	a2ffe0ef          	jal	ra,80001412 <copyinstr>
    800029e8:	00054c63          	bltz	a0,80002a00 <fetchstr+0x3c>
  return strlen(buf);
    800029ec:	8526                	mv	a0,s1
    800029ee:	bc8fe0ef          	jal	ra,80000db6 <strlen>
}
    800029f2:	70a2                	ld	ra,40(sp)
    800029f4:	7402                	ld	s0,32(sp)
    800029f6:	64e2                	ld	s1,24(sp)
    800029f8:	6942                	ld	s2,16(sp)
    800029fa:	69a2                	ld	s3,8(sp)
    800029fc:	6145                	addi	sp,sp,48
    800029fe:	8082                	ret
    return -1;
    80002a00:	557d                	li	a0,-1
    80002a02:	bfc5                	j	800029f2 <fetchstr+0x2e>

0000000080002a04 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002a04:	1101                	addi	sp,sp,-32
    80002a06:	ec06                	sd	ra,24(sp)
    80002a08:	e822                	sd	s0,16(sp)
    80002a0a:	e426                	sd	s1,8(sp)
    80002a0c:	1000                	addi	s0,sp,32
    80002a0e:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a10:	f0bff0ef          	jal	ra,8000291a <argraw>
    80002a14:	c088                	sw	a0,0(s1)
}
    80002a16:	60e2                	ld	ra,24(sp)
    80002a18:	6442                	ld	s0,16(sp)
    80002a1a:	64a2                	ld	s1,8(sp)
    80002a1c:	6105                	addi	sp,sp,32
    80002a1e:	8082                	ret

0000000080002a20 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002a20:	1101                	addi	sp,sp,-32
    80002a22:	ec06                	sd	ra,24(sp)
    80002a24:	e822                	sd	s0,16(sp)
    80002a26:	e426                	sd	s1,8(sp)
    80002a28:	1000                	addi	s0,sp,32
    80002a2a:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a2c:	eefff0ef          	jal	ra,8000291a <argraw>
    80002a30:	e088                	sd	a0,0(s1)
}
    80002a32:	60e2                	ld	ra,24(sp)
    80002a34:	6442                	ld	s0,16(sp)
    80002a36:	64a2                	ld	s1,8(sp)
    80002a38:	6105                	addi	sp,sp,32
    80002a3a:	8082                	ret

0000000080002a3c <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002a3c:	7179                	addi	sp,sp,-48
    80002a3e:	f406                	sd	ra,40(sp)
    80002a40:	f022                	sd	s0,32(sp)
    80002a42:	ec26                	sd	s1,24(sp)
    80002a44:	e84a                	sd	s2,16(sp)
    80002a46:	1800                	addi	s0,sp,48
    80002a48:	84ae                	mv	s1,a1
    80002a4a:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002a4c:	fd840593          	addi	a1,s0,-40
    80002a50:	fd1ff0ef          	jal	ra,80002a20 <argaddr>
  return fetchstr(addr, buf, max);
    80002a54:	864a                	mv	a2,s2
    80002a56:	85a6                	mv	a1,s1
    80002a58:	fd843503          	ld	a0,-40(s0)
    80002a5c:	f69ff0ef          	jal	ra,800029c4 <fetchstr>
}
    80002a60:	70a2                	ld	ra,40(sp)
    80002a62:	7402                	ld	s0,32(sp)
    80002a64:	64e2                	ld	s1,24(sp)
    80002a66:	6942                	ld	s2,16(sp)
    80002a68:	6145                	addi	sp,sp,48
    80002a6a:	8082                	ret

0000000080002a6c <syscall>:
// ============= END OF NEW ENTRY =============
};

void
syscall(void)
{
    80002a6c:	1101                	addi	sp,sp,-32
    80002a6e:	ec06                	sd	ra,24(sp)
    80002a70:	e822                	sd	s0,16(sp)
    80002a72:	e426                	sd	s1,8(sp)
    80002a74:	e04a                	sd	s2,0(sp)
    80002a76:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002a78:	e4ffe0ef          	jal	ra,800018c6 <myproc>
    80002a7c:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002a7e:	05853903          	ld	s2,88(a0)
    80002a82:	0a893783          	ld	a5,168(s2)
    80002a86:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002a8a:	37fd                	addiw	a5,a5,-1
    80002a8c:	4755                	li	a4,21
    80002a8e:	00f76f63          	bltu	a4,a5,80002aac <syscall+0x40>
    80002a92:	00369713          	slli	a4,a3,0x3
    80002a96:	00005797          	auipc	a5,0x5
    80002a9a:	a9a78793          	addi	a5,a5,-1382 # 80007530 <syscalls>
    80002a9e:	97ba                	add	a5,a5,a4
    80002aa0:	639c                	ld	a5,0(a5)
    80002aa2:	c789                	beqz	a5,80002aac <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002aa4:	9782                	jalr	a5
    80002aa6:	06a93823          	sd	a0,112(s2)
    80002aaa:	a829                	j	80002ac4 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002aac:	15848613          	addi	a2,s1,344
    80002ab0:	588c                	lw	a1,48(s1)
    80002ab2:	00005517          	auipc	a0,0x5
    80002ab6:	a4650513          	addi	a0,a0,-1466 # 800074f8 <states.0+0x158>
    80002aba:	a09fd0ef          	jal	ra,800004c2 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002abe:	6cbc                	ld	a5,88(s1)
    80002ac0:	577d                	li	a4,-1
    80002ac2:	fbb8                	sd	a4,112(a5)
  }
}
    80002ac4:	60e2                	ld	ra,24(sp)
    80002ac6:	6442                	ld	s0,16(sp)
    80002ac8:	64a2                	ld	s1,8(sp)
    80002aca:	6902                	ld	s2,0(sp)
    80002acc:	6105                	addi	sp,sp,32
    80002ace:	8082                	ret

0000000080002ad0 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002ad0:	1101                	addi	sp,sp,-32
    80002ad2:	ec06                	sd	ra,24(sp)
    80002ad4:	e822                	sd	s0,16(sp)
    80002ad6:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002ad8:	fec40593          	addi	a1,s0,-20
    80002adc:	4501                	li	a0,0
    80002ade:	f27ff0ef          	jal	ra,80002a04 <argint>
  kexit(n);
    80002ae2:	fec42503          	lw	a0,-20(s0)
    80002ae6:	e44ff0ef          	jal	ra,8000212a <kexit>
  return 0;  // not reached
}
    80002aea:	4501                	li	a0,0
    80002aec:	60e2                	ld	ra,24(sp)
    80002aee:	6442                	ld	s0,16(sp)
    80002af0:	6105                	addi	sp,sp,32
    80002af2:	8082                	ret

0000000080002af4 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002af4:	1141                	addi	sp,sp,-16
    80002af6:	e406                	sd	ra,8(sp)
    80002af8:	e022                	sd	s0,0(sp)
    80002afa:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002afc:	dcbfe0ef          	jal	ra,800018c6 <myproc>
}
    80002b00:	5908                	lw	a0,48(a0)
    80002b02:	60a2                	ld	ra,8(sp)
    80002b04:	6402                	ld	s0,0(sp)
    80002b06:	0141                	addi	sp,sp,16
    80002b08:	8082                	ret

0000000080002b0a <sys_fork>:

uint64
sys_fork(void)
{
    80002b0a:	1141                	addi	sp,sp,-16
    80002b0c:	e406                	sd	ra,8(sp)
    80002b0e:	e022                	sd	s0,0(sp)
    80002b10:	0800                	addi	s0,sp,16
  return kfork();
    80002b12:	932ff0ef          	jal	ra,80001c44 <kfork>
}
    80002b16:	60a2                	ld	ra,8(sp)
    80002b18:	6402                	ld	s0,0(sp)
    80002b1a:	0141                	addi	sp,sp,16
    80002b1c:	8082                	ret

0000000080002b1e <sys_wait>:

uint64
sys_wait(void)
{
    80002b1e:	1101                	addi	sp,sp,-32
    80002b20:	ec06                	sd	ra,24(sp)
    80002b22:	e822                	sd	s0,16(sp)
    80002b24:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002b26:	fe840593          	addi	a1,s0,-24
    80002b2a:	4501                	li	a0,0
    80002b2c:	ef5ff0ef          	jal	ra,80002a20 <argaddr>
  return kwait(p);
    80002b30:	fe843503          	ld	a0,-24(s0)
    80002b34:	f58ff0ef          	jal	ra,8000228c <kwait>
}
    80002b38:	60e2                	ld	ra,24(sp)
    80002b3a:	6442                	ld	s0,16(sp)
    80002b3c:	6105                	addi	sp,sp,32
    80002b3e:	8082                	ret

0000000080002b40 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002b40:	7179                	addi	sp,sp,-48
    80002b42:	f406                	sd	ra,40(sp)
    80002b44:	f022                	sd	s0,32(sp)
    80002b46:	ec26                	sd	s1,24(sp)
    80002b48:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002b4a:	fd840593          	addi	a1,s0,-40
    80002b4e:	4501                	li	a0,0
    80002b50:	eb5ff0ef          	jal	ra,80002a04 <argint>
  argint(1, &t);
    80002b54:	fdc40593          	addi	a1,s0,-36
    80002b58:	4505                	li	a0,1
    80002b5a:	eabff0ef          	jal	ra,80002a04 <argint>
  addr = myproc()->sz;
    80002b5e:	d69fe0ef          	jal	ra,800018c6 <myproc>
    80002b62:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002b64:	fdc42703          	lw	a4,-36(s0)
    80002b68:	4785                	li	a5,1
    80002b6a:	02f70763          	beq	a4,a5,80002b98 <sys_sbrk+0x58>
    80002b6e:	fd842783          	lw	a5,-40(s0)
    80002b72:	0207c363          	bltz	a5,80002b98 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002b76:	97a6                	add	a5,a5,s1
    80002b78:	0297ee63          	bltu	a5,s1,80002bb4 <sys_sbrk+0x74>
      return -1;
    if(addr + n > TRAPFRAME)
    80002b7c:	02000737          	lui	a4,0x2000
    80002b80:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002b82:	0736                	slli	a4,a4,0xd
    80002b84:	02f76a63          	bltu	a4,a5,80002bb8 <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002b88:	d3ffe0ef          	jal	ra,800018c6 <myproc>
    80002b8c:	fd842703          	lw	a4,-40(s0)
    80002b90:	653c                	ld	a5,72(a0)
    80002b92:	97ba                	add	a5,a5,a4
    80002b94:	e53c                	sd	a5,72(a0)
    80002b96:	a039                	j	80002ba4 <sys_sbrk+0x64>
    if(growproc(n) < 0) {
    80002b98:	fd842503          	lw	a0,-40(s0)
    80002b9c:	846ff0ef          	jal	ra,80001be2 <growproc>
    80002ba0:	00054863          	bltz	a0,80002bb0 <sys_sbrk+0x70>
  }
  return addr;
}
    80002ba4:	8526                	mv	a0,s1
    80002ba6:	70a2                	ld	ra,40(sp)
    80002ba8:	7402                	ld	s0,32(sp)
    80002baa:	64e2                	ld	s1,24(sp)
    80002bac:	6145                	addi	sp,sp,48
    80002bae:	8082                	ret
      return -1;
    80002bb0:	54fd                	li	s1,-1
    80002bb2:	bfcd                	j	80002ba4 <sys_sbrk+0x64>
      return -1;
    80002bb4:	54fd                	li	s1,-1
    80002bb6:	b7fd                	j	80002ba4 <sys_sbrk+0x64>
      return -1;
    80002bb8:	54fd                	li	s1,-1
    80002bba:	b7ed                	j	80002ba4 <sys_sbrk+0x64>

0000000080002bbc <sys_pause>:

uint64
sys_pause(void)
{
    80002bbc:	7139                	addi	sp,sp,-64
    80002bbe:	fc06                	sd	ra,56(sp)
    80002bc0:	f822                	sd	s0,48(sp)
    80002bc2:	f426                	sd	s1,40(sp)
    80002bc4:	f04a                	sd	s2,32(sp)
    80002bc6:	ec4e                	sd	s3,24(sp)
    80002bc8:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002bca:	fcc40593          	addi	a1,s0,-52
    80002bce:	4501                	li	a0,0
    80002bd0:	e35ff0ef          	jal	ra,80002a04 <argint>
  if(n < 0)
    80002bd4:	fcc42783          	lw	a5,-52(s0)
    80002bd8:	0607c563          	bltz	a5,80002c42 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002bdc:	00014517          	auipc	a0,0x14
    80002be0:	d2c50513          	addi	a0,a0,-724 # 80016908 <tickslock>
    80002be4:	f87fd0ef          	jal	ra,80000b6a <acquire>
  ticks0 = ticks;
    80002be8:	00005917          	auipc	s2,0x5
    80002bec:	de892903          	lw	s2,-536(s2) # 800079d0 <ticks>
  while(ticks - ticks0 < n){
    80002bf0:	fcc42783          	lw	a5,-52(s0)
    80002bf4:	cb8d                	beqz	a5,80002c26 <sys_pause+0x6a>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002bf6:	00014997          	auipc	s3,0x14
    80002bfa:	d1298993          	addi	s3,s3,-750 # 80016908 <tickslock>
    80002bfe:	00005497          	auipc	s1,0x5
    80002c02:	dd248493          	addi	s1,s1,-558 # 800079d0 <ticks>
    if(killed(myproc())){
    80002c06:	cc1fe0ef          	jal	ra,800018c6 <myproc>
    80002c0a:	e58ff0ef          	jal	ra,80002262 <killed>
    80002c0e:	ed0d                	bnez	a0,80002c48 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002c10:	85ce                	mv	a1,s3
    80002c12:	8526                	mv	a0,s1
    80002c14:	c0aff0ef          	jal	ra,8000201e <sleep>
  while(ticks - ticks0 < n){
    80002c18:	409c                	lw	a5,0(s1)
    80002c1a:	412787bb          	subw	a5,a5,s2
    80002c1e:	fcc42703          	lw	a4,-52(s0)
    80002c22:	fee7e2e3          	bltu	a5,a4,80002c06 <sys_pause+0x4a>
  }
  release(&tickslock);
    80002c26:	00014517          	auipc	a0,0x14
    80002c2a:	ce250513          	addi	a0,a0,-798 # 80016908 <tickslock>
    80002c2e:	fd5fd0ef          	jal	ra,80000c02 <release>
  return 0;
    80002c32:	4501                	li	a0,0
}
    80002c34:	70e2                	ld	ra,56(sp)
    80002c36:	7442                	ld	s0,48(sp)
    80002c38:	74a2                	ld	s1,40(sp)
    80002c3a:	7902                	ld	s2,32(sp)
    80002c3c:	69e2                	ld	s3,24(sp)
    80002c3e:	6121                	addi	sp,sp,64
    80002c40:	8082                	ret
    n = 0;
    80002c42:	fc042623          	sw	zero,-52(s0)
    80002c46:	bf59                	j	80002bdc <sys_pause+0x20>
      release(&tickslock);
    80002c48:	00014517          	auipc	a0,0x14
    80002c4c:	cc050513          	addi	a0,a0,-832 # 80016908 <tickslock>
    80002c50:	fb3fd0ef          	jal	ra,80000c02 <release>
      return -1;
    80002c54:	557d                	li	a0,-1
    80002c56:	bff9                	j	80002c34 <sys_pause+0x78>

0000000080002c58 <sys_kill>:

uint64
sys_kill(void)
{
    80002c58:	1101                	addi	sp,sp,-32
    80002c5a:	ec06                	sd	ra,24(sp)
    80002c5c:	e822                	sd	s0,16(sp)
    80002c5e:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002c60:	fec40593          	addi	a1,s0,-20
    80002c64:	4501                	li	a0,0
    80002c66:	d9fff0ef          	jal	ra,80002a04 <argint>
  return kkill(pid);
    80002c6a:	fec42503          	lw	a0,-20(s0)
    80002c6e:	d6aff0ef          	jal	ra,800021d8 <kkill>
}
    80002c72:	60e2                	ld	ra,24(sp)
    80002c74:	6442                	ld	s0,16(sp)
    80002c76:	6105                	addi	sp,sp,32
    80002c78:	8082                	ret

0000000080002c7a <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002c7a:	1101                	addi	sp,sp,-32
    80002c7c:	ec06                	sd	ra,24(sp)
    80002c7e:	e822                	sd	s0,16(sp)
    80002c80:	e426                	sd	s1,8(sp)
    80002c82:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002c84:	00014517          	auipc	a0,0x14
    80002c88:	c8450513          	addi	a0,a0,-892 # 80016908 <tickslock>
    80002c8c:	edffd0ef          	jal	ra,80000b6a <acquire>
  xticks = ticks;
    80002c90:	00005497          	auipc	s1,0x5
    80002c94:	d404a483          	lw	s1,-704(s1) # 800079d0 <ticks>
  release(&tickslock);
    80002c98:	00014517          	auipc	a0,0x14
    80002c9c:	c7050513          	addi	a0,a0,-912 # 80016908 <tickslock>
    80002ca0:	f63fd0ef          	jal	ra,80000c02 <release>
  return xticks;
}
    80002ca4:	02049513          	slli	a0,s1,0x20
    80002ca8:	9101                	srli	a0,a0,0x20
    80002caa:	60e2                	ld	ra,24(sp)
    80002cac:	6442                	ld	s0,16(sp)
    80002cae:	64a2                	ld	s1,8(sp)
    80002cb0:	6105                	addi	sp,sp,32
    80002cb2:	8082                	ret

0000000080002cb4 <sys_getprocinfo>:

uint64
sys_getprocinfo(void)
{
    80002cb4:	1101                	addi	sp,sp,-32
    80002cb6:	ec06                	sd	ra,24(sp)
    80002cb8:	e822                	sd	s0,16(sp)
    80002cba:	1000                	addi	s0,sp,32
  int pid;
  uint64 addr;
  
  argint(0, &pid);
    80002cbc:	fec40593          	addi	a1,s0,-20
    80002cc0:	4501                	li	a0,0
    80002cc2:	d43ff0ef          	jal	ra,80002a04 <argint>
  argaddr(1, &addr);
    80002cc6:	fe040593          	addi	a1,s0,-32
    80002cca:	4505                	li	a0,1
    80002ccc:	d55ff0ef          	jal	ra,80002a20 <argaddr>
  
  return getprocinfo(pid, addr);
    80002cd0:	fe043583          	ld	a1,-32(s0)
    80002cd4:	fec42503          	lw	a0,-20(s0)
    80002cd8:	fe6ff0ef          	jal	ra,800024be <getprocinfo>
}
    80002cdc:	60e2                	ld	ra,24(sp)
    80002cde:	6442                	ld	s0,16(sp)
    80002ce0:	6105                	addi	sp,sp,32
    80002ce2:	8082                	ret

0000000080002ce4 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002ce4:	7179                	addi	sp,sp,-48
    80002ce6:	f406                	sd	ra,40(sp)
    80002ce8:	f022                	sd	s0,32(sp)
    80002cea:	ec26                	sd	s1,24(sp)
    80002cec:	e84a                	sd	s2,16(sp)
    80002cee:	e44e                	sd	s3,8(sp)
    80002cf0:	e052                	sd	s4,0(sp)
    80002cf2:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002cf4:	00005597          	auipc	a1,0x5
    80002cf8:	8f458593          	addi	a1,a1,-1804 # 800075e8 <syscalls+0xb8>
    80002cfc:	00014517          	auipc	a0,0x14
    80002d00:	c2450513          	addi	a0,a0,-988 # 80016920 <bcache>
    80002d04:	de7fd0ef          	jal	ra,80000aea <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002d08:	0001c797          	auipc	a5,0x1c
    80002d0c:	c1878793          	addi	a5,a5,-1000 # 8001e920 <bcache+0x8000>
    80002d10:	0001c717          	auipc	a4,0x1c
    80002d14:	e7870713          	addi	a4,a4,-392 # 8001eb88 <bcache+0x8268>
    80002d18:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002d1c:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002d20:	00014497          	auipc	s1,0x14
    80002d24:	c1848493          	addi	s1,s1,-1000 # 80016938 <bcache+0x18>
    b->next = bcache.head.next;
    80002d28:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002d2a:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002d2c:	00005a17          	auipc	s4,0x5
    80002d30:	8c4a0a13          	addi	s4,s4,-1852 # 800075f0 <syscalls+0xc0>
    b->next = bcache.head.next;
    80002d34:	2b893783          	ld	a5,696(s2)
    80002d38:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002d3a:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002d3e:	85d2                	mv	a1,s4
    80002d40:	01048513          	addi	a0,s1,16
    80002d44:	302010ef          	jal	ra,80004046 <initsleeplock>
    bcache.head.next->prev = b;
    80002d48:	2b893783          	ld	a5,696(s2)
    80002d4c:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002d4e:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002d52:	45848493          	addi	s1,s1,1112
    80002d56:	fd349fe3          	bne	s1,s3,80002d34 <binit+0x50>
  }
}
    80002d5a:	70a2                	ld	ra,40(sp)
    80002d5c:	7402                	ld	s0,32(sp)
    80002d5e:	64e2                	ld	s1,24(sp)
    80002d60:	6942                	ld	s2,16(sp)
    80002d62:	69a2                	ld	s3,8(sp)
    80002d64:	6a02                	ld	s4,0(sp)
    80002d66:	6145                	addi	sp,sp,48
    80002d68:	8082                	ret

0000000080002d6a <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002d6a:	7179                	addi	sp,sp,-48
    80002d6c:	f406                	sd	ra,40(sp)
    80002d6e:	f022                	sd	s0,32(sp)
    80002d70:	ec26                	sd	s1,24(sp)
    80002d72:	e84a                	sd	s2,16(sp)
    80002d74:	e44e                	sd	s3,8(sp)
    80002d76:	1800                	addi	s0,sp,48
    80002d78:	892a                	mv	s2,a0
    80002d7a:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002d7c:	00014517          	auipc	a0,0x14
    80002d80:	ba450513          	addi	a0,a0,-1116 # 80016920 <bcache>
    80002d84:	de7fd0ef          	jal	ra,80000b6a <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002d88:	0001c497          	auipc	s1,0x1c
    80002d8c:	e504b483          	ld	s1,-432(s1) # 8001ebd8 <bcache+0x82b8>
    80002d90:	0001c797          	auipc	a5,0x1c
    80002d94:	df878793          	addi	a5,a5,-520 # 8001eb88 <bcache+0x8268>
    80002d98:	02f48b63          	beq	s1,a5,80002dce <bread+0x64>
    80002d9c:	873e                	mv	a4,a5
    80002d9e:	a021                	j	80002da6 <bread+0x3c>
    80002da0:	68a4                	ld	s1,80(s1)
    80002da2:	02e48663          	beq	s1,a4,80002dce <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002da6:	449c                	lw	a5,8(s1)
    80002da8:	ff279ce3          	bne	a5,s2,80002da0 <bread+0x36>
    80002dac:	44dc                	lw	a5,12(s1)
    80002dae:	ff3799e3          	bne	a5,s3,80002da0 <bread+0x36>
      b->refcnt++;
    80002db2:	40bc                	lw	a5,64(s1)
    80002db4:	2785                	addiw	a5,a5,1
    80002db6:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002db8:	00014517          	auipc	a0,0x14
    80002dbc:	b6850513          	addi	a0,a0,-1176 # 80016920 <bcache>
    80002dc0:	e43fd0ef          	jal	ra,80000c02 <release>
      acquiresleep(&b->lock);
    80002dc4:	01048513          	addi	a0,s1,16
    80002dc8:	2b4010ef          	jal	ra,8000407c <acquiresleep>
      return b;
    80002dcc:	a889                	j	80002e1e <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002dce:	0001c497          	auipc	s1,0x1c
    80002dd2:	e024b483          	ld	s1,-510(s1) # 8001ebd0 <bcache+0x82b0>
    80002dd6:	0001c797          	auipc	a5,0x1c
    80002dda:	db278793          	addi	a5,a5,-590 # 8001eb88 <bcache+0x8268>
    80002dde:	00f48863          	beq	s1,a5,80002dee <bread+0x84>
    80002de2:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002de4:	40bc                	lw	a5,64(s1)
    80002de6:	cb91                	beqz	a5,80002dfa <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002de8:	64a4                	ld	s1,72(s1)
    80002dea:	fee49de3          	bne	s1,a4,80002de4 <bread+0x7a>
  panic("bget: no buffers");
    80002dee:	00005517          	auipc	a0,0x5
    80002df2:	80a50513          	addi	a0,a0,-2038 # 800075f8 <syscalls+0xc8>
    80002df6:	993fd0ef          	jal	ra,80000788 <panic>
      b->dev = dev;
    80002dfa:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002dfe:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002e02:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002e06:	4785                	li	a5,1
    80002e08:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e0a:	00014517          	auipc	a0,0x14
    80002e0e:	b1650513          	addi	a0,a0,-1258 # 80016920 <bcache>
    80002e12:	df1fd0ef          	jal	ra,80000c02 <release>
      acquiresleep(&b->lock);
    80002e16:	01048513          	addi	a0,s1,16
    80002e1a:	262010ef          	jal	ra,8000407c <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002e1e:	409c                	lw	a5,0(s1)
    80002e20:	cb89                	beqz	a5,80002e32 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002e22:	8526                	mv	a0,s1
    80002e24:	70a2                	ld	ra,40(sp)
    80002e26:	7402                	ld	s0,32(sp)
    80002e28:	64e2                	ld	s1,24(sp)
    80002e2a:	6942                	ld	s2,16(sp)
    80002e2c:	69a2                	ld	s3,8(sp)
    80002e2e:	6145                	addi	sp,sp,48
    80002e30:	8082                	ret
    virtio_disk_rw(b, 0);
    80002e32:	4581                	li	a1,0
    80002e34:	8526                	mv	a0,s1
    80002e36:	1b5020ef          	jal	ra,800057ea <virtio_disk_rw>
    b->valid = 1;
    80002e3a:	4785                	li	a5,1
    80002e3c:	c09c                	sw	a5,0(s1)
  return b;
    80002e3e:	b7d5                	j	80002e22 <bread+0xb8>

0000000080002e40 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002e40:	1101                	addi	sp,sp,-32
    80002e42:	ec06                	sd	ra,24(sp)
    80002e44:	e822                	sd	s0,16(sp)
    80002e46:	e426                	sd	s1,8(sp)
    80002e48:	1000                	addi	s0,sp,32
    80002e4a:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002e4c:	0541                	addi	a0,a0,16
    80002e4e:	2ac010ef          	jal	ra,800040fa <holdingsleep>
    80002e52:	c911                	beqz	a0,80002e66 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002e54:	4585                	li	a1,1
    80002e56:	8526                	mv	a0,s1
    80002e58:	193020ef          	jal	ra,800057ea <virtio_disk_rw>
}
    80002e5c:	60e2                	ld	ra,24(sp)
    80002e5e:	6442                	ld	s0,16(sp)
    80002e60:	64a2                	ld	s1,8(sp)
    80002e62:	6105                	addi	sp,sp,32
    80002e64:	8082                	ret
    panic("bwrite");
    80002e66:	00004517          	auipc	a0,0x4
    80002e6a:	7aa50513          	addi	a0,a0,1962 # 80007610 <syscalls+0xe0>
    80002e6e:	91bfd0ef          	jal	ra,80000788 <panic>

0000000080002e72 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002e72:	1101                	addi	sp,sp,-32
    80002e74:	ec06                	sd	ra,24(sp)
    80002e76:	e822                	sd	s0,16(sp)
    80002e78:	e426                	sd	s1,8(sp)
    80002e7a:	e04a                	sd	s2,0(sp)
    80002e7c:	1000                	addi	s0,sp,32
    80002e7e:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002e80:	01050913          	addi	s2,a0,16
    80002e84:	854a                	mv	a0,s2
    80002e86:	274010ef          	jal	ra,800040fa <holdingsleep>
    80002e8a:	c13d                	beqz	a0,80002ef0 <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
    80002e8c:	854a                	mv	a0,s2
    80002e8e:	234010ef          	jal	ra,800040c2 <releasesleep>

  acquire(&bcache.lock);
    80002e92:	00014517          	auipc	a0,0x14
    80002e96:	a8e50513          	addi	a0,a0,-1394 # 80016920 <bcache>
    80002e9a:	cd1fd0ef          	jal	ra,80000b6a <acquire>
  b->refcnt--;
    80002e9e:	40bc                	lw	a5,64(s1)
    80002ea0:	37fd                	addiw	a5,a5,-1
    80002ea2:	0007871b          	sext.w	a4,a5
    80002ea6:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002ea8:	eb05                	bnez	a4,80002ed8 <brelse+0x66>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002eaa:	68bc                	ld	a5,80(s1)
    80002eac:	64b8                	ld	a4,72(s1)
    80002eae:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    80002eb0:	64bc                	ld	a5,72(s1)
    80002eb2:	68b8                	ld	a4,80(s1)
    80002eb4:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002eb6:	0001c797          	auipc	a5,0x1c
    80002eba:	a6a78793          	addi	a5,a5,-1430 # 8001e920 <bcache+0x8000>
    80002ebe:	2b87b703          	ld	a4,696(a5)
    80002ec2:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002ec4:	0001c717          	auipc	a4,0x1c
    80002ec8:	cc470713          	addi	a4,a4,-828 # 8001eb88 <bcache+0x8268>
    80002ecc:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002ece:	2b87b703          	ld	a4,696(a5)
    80002ed2:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002ed4:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002ed8:	00014517          	auipc	a0,0x14
    80002edc:	a4850513          	addi	a0,a0,-1464 # 80016920 <bcache>
    80002ee0:	d23fd0ef          	jal	ra,80000c02 <release>
}
    80002ee4:	60e2                	ld	ra,24(sp)
    80002ee6:	6442                	ld	s0,16(sp)
    80002ee8:	64a2                	ld	s1,8(sp)
    80002eea:	6902                	ld	s2,0(sp)
    80002eec:	6105                	addi	sp,sp,32
    80002eee:	8082                	ret
    panic("brelse");
    80002ef0:	00004517          	auipc	a0,0x4
    80002ef4:	72850513          	addi	a0,a0,1832 # 80007618 <syscalls+0xe8>
    80002ef8:	891fd0ef          	jal	ra,80000788 <panic>

0000000080002efc <bpin>:

void
bpin(struct buf *b) {
    80002efc:	1101                	addi	sp,sp,-32
    80002efe:	ec06                	sd	ra,24(sp)
    80002f00:	e822                	sd	s0,16(sp)
    80002f02:	e426                	sd	s1,8(sp)
    80002f04:	1000                	addi	s0,sp,32
    80002f06:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002f08:	00014517          	auipc	a0,0x14
    80002f0c:	a1850513          	addi	a0,a0,-1512 # 80016920 <bcache>
    80002f10:	c5bfd0ef          	jal	ra,80000b6a <acquire>
  b->refcnt++;
    80002f14:	40bc                	lw	a5,64(s1)
    80002f16:	2785                	addiw	a5,a5,1
    80002f18:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002f1a:	00014517          	auipc	a0,0x14
    80002f1e:	a0650513          	addi	a0,a0,-1530 # 80016920 <bcache>
    80002f22:	ce1fd0ef          	jal	ra,80000c02 <release>
}
    80002f26:	60e2                	ld	ra,24(sp)
    80002f28:	6442                	ld	s0,16(sp)
    80002f2a:	64a2                	ld	s1,8(sp)
    80002f2c:	6105                	addi	sp,sp,32
    80002f2e:	8082                	ret

0000000080002f30 <bunpin>:

void
bunpin(struct buf *b) {
    80002f30:	1101                	addi	sp,sp,-32
    80002f32:	ec06                	sd	ra,24(sp)
    80002f34:	e822                	sd	s0,16(sp)
    80002f36:	e426                	sd	s1,8(sp)
    80002f38:	1000                	addi	s0,sp,32
    80002f3a:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002f3c:	00014517          	auipc	a0,0x14
    80002f40:	9e450513          	addi	a0,a0,-1564 # 80016920 <bcache>
    80002f44:	c27fd0ef          	jal	ra,80000b6a <acquire>
  b->refcnt--;
    80002f48:	40bc                	lw	a5,64(s1)
    80002f4a:	37fd                	addiw	a5,a5,-1
    80002f4c:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002f4e:	00014517          	auipc	a0,0x14
    80002f52:	9d250513          	addi	a0,a0,-1582 # 80016920 <bcache>
    80002f56:	cadfd0ef          	jal	ra,80000c02 <release>
}
    80002f5a:	60e2                	ld	ra,24(sp)
    80002f5c:	6442                	ld	s0,16(sp)
    80002f5e:	64a2                	ld	s1,8(sp)
    80002f60:	6105                	addi	sp,sp,32
    80002f62:	8082                	ret

0000000080002f64 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002f64:	1101                	addi	sp,sp,-32
    80002f66:	ec06                	sd	ra,24(sp)
    80002f68:	e822                	sd	s0,16(sp)
    80002f6a:	e426                	sd	s1,8(sp)
    80002f6c:	e04a                	sd	s2,0(sp)
    80002f6e:	1000                	addi	s0,sp,32
    80002f70:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002f72:	00d5d59b          	srliw	a1,a1,0xd
    80002f76:	0001c797          	auipc	a5,0x1c
    80002f7a:	0867a783          	lw	a5,134(a5) # 8001effc <sb+0x1c>
    80002f7e:	9dbd                	addw	a1,a1,a5
    80002f80:	debff0ef          	jal	ra,80002d6a <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002f84:	0074f713          	andi	a4,s1,7
    80002f88:	4785                	li	a5,1
    80002f8a:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    80002f8e:	14ce                	slli	s1,s1,0x33
    80002f90:	90d9                	srli	s1,s1,0x36
    80002f92:	00950733          	add	a4,a0,s1
    80002f96:	05874703          	lbu	a4,88(a4)
    80002f9a:	00e7f6b3          	and	a3,a5,a4
    80002f9e:	c29d                	beqz	a3,80002fc4 <bfree+0x60>
    80002fa0:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002fa2:	94aa                	add	s1,s1,a0
    80002fa4:	fff7c793          	not	a5,a5
    80002fa8:	8f7d                	and	a4,a4,a5
    80002faa:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002fae:	7d7000ef          	jal	ra,80003f84 <log_write>
  brelse(bp);
    80002fb2:	854a                	mv	a0,s2
    80002fb4:	ebfff0ef          	jal	ra,80002e72 <brelse>
}
    80002fb8:	60e2                	ld	ra,24(sp)
    80002fba:	6442                	ld	s0,16(sp)
    80002fbc:	64a2                	ld	s1,8(sp)
    80002fbe:	6902                	ld	s2,0(sp)
    80002fc0:	6105                	addi	sp,sp,32
    80002fc2:	8082                	ret
    panic("freeing free block");
    80002fc4:	00004517          	auipc	a0,0x4
    80002fc8:	65c50513          	addi	a0,a0,1628 # 80007620 <syscalls+0xf0>
    80002fcc:	fbcfd0ef          	jal	ra,80000788 <panic>

0000000080002fd0 <balloc>:
{
    80002fd0:	711d                	addi	sp,sp,-96
    80002fd2:	ec86                	sd	ra,88(sp)
    80002fd4:	e8a2                	sd	s0,80(sp)
    80002fd6:	e4a6                	sd	s1,72(sp)
    80002fd8:	e0ca                	sd	s2,64(sp)
    80002fda:	fc4e                	sd	s3,56(sp)
    80002fdc:	f852                	sd	s4,48(sp)
    80002fde:	f456                	sd	s5,40(sp)
    80002fe0:	f05a                	sd	s6,32(sp)
    80002fe2:	ec5e                	sd	s7,24(sp)
    80002fe4:	e862                	sd	s8,16(sp)
    80002fe6:	e466                	sd	s9,8(sp)
    80002fe8:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80002fea:	0001c797          	auipc	a5,0x1c
    80002fee:	ffa7a783          	lw	a5,-6(a5) # 8001efe4 <sb+0x4>
    80002ff2:	cff1                	beqz	a5,800030ce <balloc+0xfe>
    80002ff4:	8baa                	mv	s7,a0
    80002ff6:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002ff8:	0001cb17          	auipc	s6,0x1c
    80002ffc:	fe8b0b13          	addi	s6,s6,-24 # 8001efe0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003000:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80003002:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003004:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003006:	6c89                	lui	s9,0x2
    80003008:	a0b5                	j	80003074 <balloc+0xa4>
        bp->data[bi/8] |= m;  // Mark block in use.
    8000300a:	97ca                	add	a5,a5,s2
    8000300c:	8e55                	or	a2,a2,a3
    8000300e:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80003012:	854a                	mv	a0,s2
    80003014:	771000ef          	jal	ra,80003f84 <log_write>
        brelse(bp);
    80003018:	854a                	mv	a0,s2
    8000301a:	e59ff0ef          	jal	ra,80002e72 <brelse>
  bp = bread(dev, bno);
    8000301e:	85a6                	mv	a1,s1
    80003020:	855e                	mv	a0,s7
    80003022:	d49ff0ef          	jal	ra,80002d6a <bread>
    80003026:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80003028:	40000613          	li	a2,1024
    8000302c:	4581                	li	a1,0
    8000302e:	05850513          	addi	a0,a0,88
    80003032:	c0dfd0ef          	jal	ra,80000c3e <memset>
  log_write(bp);
    80003036:	854a                	mv	a0,s2
    80003038:	74d000ef          	jal	ra,80003f84 <log_write>
  brelse(bp);
    8000303c:	854a                	mv	a0,s2
    8000303e:	e35ff0ef          	jal	ra,80002e72 <brelse>
}
    80003042:	8526                	mv	a0,s1
    80003044:	60e6                	ld	ra,88(sp)
    80003046:	6446                	ld	s0,80(sp)
    80003048:	64a6                	ld	s1,72(sp)
    8000304a:	6906                	ld	s2,64(sp)
    8000304c:	79e2                	ld	s3,56(sp)
    8000304e:	7a42                	ld	s4,48(sp)
    80003050:	7aa2                	ld	s5,40(sp)
    80003052:	7b02                	ld	s6,32(sp)
    80003054:	6be2                	ld	s7,24(sp)
    80003056:	6c42                	ld	s8,16(sp)
    80003058:	6ca2                	ld	s9,8(sp)
    8000305a:	6125                	addi	sp,sp,96
    8000305c:	8082                	ret
    brelse(bp);
    8000305e:	854a                	mv	a0,s2
    80003060:	e13ff0ef          	jal	ra,80002e72 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80003064:	015c87bb          	addw	a5,s9,s5
    80003068:	00078a9b          	sext.w	s5,a5
    8000306c:	004b2703          	lw	a4,4(s6)
    80003070:	04eaff63          	bgeu	s5,a4,800030ce <balloc+0xfe>
    bp = bread(dev, BBLOCK(b, sb));
    80003074:	41fad79b          	sraiw	a5,s5,0x1f
    80003078:	0137d79b          	srliw	a5,a5,0x13
    8000307c:	015787bb          	addw	a5,a5,s5
    80003080:	40d7d79b          	sraiw	a5,a5,0xd
    80003084:	01cb2583          	lw	a1,28(s6)
    80003088:	9dbd                	addw	a1,a1,a5
    8000308a:	855e                	mv	a0,s7
    8000308c:	cdfff0ef          	jal	ra,80002d6a <bread>
    80003090:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003092:	004b2503          	lw	a0,4(s6)
    80003096:	000a849b          	sext.w	s1,s5
    8000309a:	8762                	mv	a4,s8
    8000309c:	fca4f1e3          	bgeu	s1,a0,8000305e <balloc+0x8e>
      m = 1 << (bi % 8);
    800030a0:	00777693          	andi	a3,a4,7
    800030a4:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800030a8:	41f7579b          	sraiw	a5,a4,0x1f
    800030ac:	01d7d79b          	srliw	a5,a5,0x1d
    800030b0:	9fb9                	addw	a5,a5,a4
    800030b2:	4037d79b          	sraiw	a5,a5,0x3
    800030b6:	00f90633          	add	a2,s2,a5
    800030ba:	05864603          	lbu	a2,88(a2)
    800030be:	00c6f5b3          	and	a1,a3,a2
    800030c2:	d5a1                	beqz	a1,8000300a <balloc+0x3a>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800030c4:	2705                	addiw	a4,a4,1
    800030c6:	2485                	addiw	s1,s1,1
    800030c8:	fd471ae3          	bne	a4,s4,8000309c <balloc+0xcc>
    800030cc:	bf49                	j	8000305e <balloc+0x8e>
  printf("balloc: out of blocks\n");
    800030ce:	00004517          	auipc	a0,0x4
    800030d2:	56a50513          	addi	a0,a0,1386 # 80007638 <syscalls+0x108>
    800030d6:	becfd0ef          	jal	ra,800004c2 <printf>
  return 0;
    800030da:	4481                	li	s1,0
    800030dc:	b79d                	j	80003042 <balloc+0x72>

00000000800030de <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800030de:	7179                	addi	sp,sp,-48
    800030e0:	f406                	sd	ra,40(sp)
    800030e2:	f022                	sd	s0,32(sp)
    800030e4:	ec26                	sd	s1,24(sp)
    800030e6:	e84a                	sd	s2,16(sp)
    800030e8:	e44e                	sd	s3,8(sp)
    800030ea:	e052                	sd	s4,0(sp)
    800030ec:	1800                	addi	s0,sp,48
    800030ee:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800030f0:	47ad                	li	a5,11
    800030f2:	02b7e663          	bltu	a5,a1,8000311e <bmap+0x40>
    if((addr = ip->addrs[bn]) == 0){
    800030f6:	02059793          	slli	a5,a1,0x20
    800030fa:	01e7d593          	srli	a1,a5,0x1e
    800030fe:	00b504b3          	add	s1,a0,a1
    80003102:	0504a903          	lw	s2,80(s1)
    80003106:	06091663          	bnez	s2,80003172 <bmap+0x94>
      addr = balloc(ip->dev);
    8000310a:	4108                	lw	a0,0(a0)
    8000310c:	ec5ff0ef          	jal	ra,80002fd0 <balloc>
    80003110:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003114:	04090f63          	beqz	s2,80003172 <bmap+0x94>
        return 0;
      ip->addrs[bn] = addr;
    80003118:	0524a823          	sw	s2,80(s1)
    8000311c:	a899                	j	80003172 <bmap+0x94>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000311e:	ff45849b          	addiw	s1,a1,-12
    80003122:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80003126:	0ff00793          	li	a5,255
    8000312a:	06e7eb63          	bltu	a5,a4,800031a0 <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000312e:	08052903          	lw	s2,128(a0)
    80003132:	00091b63          	bnez	s2,80003148 <bmap+0x6a>
      addr = balloc(ip->dev);
    80003136:	4108                	lw	a0,0(a0)
    80003138:	e99ff0ef          	jal	ra,80002fd0 <balloc>
    8000313c:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003140:	02090963          	beqz	s2,80003172 <bmap+0x94>
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003144:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80003148:	85ca                	mv	a1,s2
    8000314a:	0009a503          	lw	a0,0(s3)
    8000314e:	c1dff0ef          	jal	ra,80002d6a <bread>
    80003152:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003154:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80003158:	02049713          	slli	a4,s1,0x20
    8000315c:	01e75593          	srli	a1,a4,0x1e
    80003160:	00b784b3          	add	s1,a5,a1
    80003164:	0004a903          	lw	s2,0(s1)
    80003168:	00090e63          	beqz	s2,80003184 <bmap+0xa6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000316c:	8552                	mv	a0,s4
    8000316e:	d05ff0ef          	jal	ra,80002e72 <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    80003172:	854a                	mv	a0,s2
    80003174:	70a2                	ld	ra,40(sp)
    80003176:	7402                	ld	s0,32(sp)
    80003178:	64e2                	ld	s1,24(sp)
    8000317a:	6942                	ld	s2,16(sp)
    8000317c:	69a2                	ld	s3,8(sp)
    8000317e:	6a02                	ld	s4,0(sp)
    80003180:	6145                	addi	sp,sp,48
    80003182:	8082                	ret
      addr = balloc(ip->dev);
    80003184:	0009a503          	lw	a0,0(s3)
    80003188:	e49ff0ef          	jal	ra,80002fd0 <balloc>
    8000318c:	0005091b          	sext.w	s2,a0
      if(addr){
    80003190:	fc090ee3          	beqz	s2,8000316c <bmap+0x8e>
        a[bn] = addr;
    80003194:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80003198:	8552                	mv	a0,s4
    8000319a:	5eb000ef          	jal	ra,80003f84 <log_write>
    8000319e:	b7f9                	j	8000316c <bmap+0x8e>
  panic("bmap: out of range");
    800031a0:	00004517          	auipc	a0,0x4
    800031a4:	4b050513          	addi	a0,a0,1200 # 80007650 <syscalls+0x120>
    800031a8:	de0fd0ef          	jal	ra,80000788 <panic>

00000000800031ac <iget>:
{
    800031ac:	7179                	addi	sp,sp,-48
    800031ae:	f406                	sd	ra,40(sp)
    800031b0:	f022                	sd	s0,32(sp)
    800031b2:	ec26                	sd	s1,24(sp)
    800031b4:	e84a                	sd	s2,16(sp)
    800031b6:	e44e                	sd	s3,8(sp)
    800031b8:	e052                	sd	s4,0(sp)
    800031ba:	1800                	addi	s0,sp,48
    800031bc:	89aa                	mv	s3,a0
    800031be:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800031c0:	0001c517          	auipc	a0,0x1c
    800031c4:	e4050513          	addi	a0,a0,-448 # 8001f000 <itable>
    800031c8:	9a3fd0ef          	jal	ra,80000b6a <acquire>
  empty = 0;
    800031cc:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800031ce:	0001c497          	auipc	s1,0x1c
    800031d2:	e4a48493          	addi	s1,s1,-438 # 8001f018 <itable+0x18>
    800031d6:	0001e697          	auipc	a3,0x1e
    800031da:	8d268693          	addi	a3,a3,-1838 # 80020aa8 <log>
    800031de:	a039                	j	800031ec <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800031e0:	02090963          	beqz	s2,80003212 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800031e4:	08848493          	addi	s1,s1,136
    800031e8:	02d48863          	beq	s1,a3,80003218 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800031ec:	449c                	lw	a5,8(s1)
    800031ee:	fef059e3          	blez	a5,800031e0 <iget+0x34>
    800031f2:	4098                	lw	a4,0(s1)
    800031f4:	ff3716e3          	bne	a4,s3,800031e0 <iget+0x34>
    800031f8:	40d8                	lw	a4,4(s1)
    800031fa:	ff4713e3          	bne	a4,s4,800031e0 <iget+0x34>
      ip->ref++;
    800031fe:	2785                	addiw	a5,a5,1
    80003200:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003202:	0001c517          	auipc	a0,0x1c
    80003206:	dfe50513          	addi	a0,a0,-514 # 8001f000 <itable>
    8000320a:	9f9fd0ef          	jal	ra,80000c02 <release>
      return ip;
    8000320e:	8926                	mv	s2,s1
    80003210:	a02d                	j	8000323a <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003212:	fbe9                	bnez	a5,800031e4 <iget+0x38>
    80003214:	8926                	mv	s2,s1
    80003216:	b7f9                	j	800031e4 <iget+0x38>
  if(empty == 0)
    80003218:	02090a63          	beqz	s2,8000324c <iget+0xa0>
  ip->dev = dev;
    8000321c:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003220:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003224:	4785                	li	a5,1
    80003226:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000322a:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000322e:	0001c517          	auipc	a0,0x1c
    80003232:	dd250513          	addi	a0,a0,-558 # 8001f000 <itable>
    80003236:	9cdfd0ef          	jal	ra,80000c02 <release>
}
    8000323a:	854a                	mv	a0,s2
    8000323c:	70a2                	ld	ra,40(sp)
    8000323e:	7402                	ld	s0,32(sp)
    80003240:	64e2                	ld	s1,24(sp)
    80003242:	6942                	ld	s2,16(sp)
    80003244:	69a2                	ld	s3,8(sp)
    80003246:	6a02                	ld	s4,0(sp)
    80003248:	6145                	addi	sp,sp,48
    8000324a:	8082                	ret
    panic("iget: no inodes");
    8000324c:	00004517          	auipc	a0,0x4
    80003250:	41c50513          	addi	a0,a0,1052 # 80007668 <syscalls+0x138>
    80003254:	d34fd0ef          	jal	ra,80000788 <panic>

0000000080003258 <iinit>:
{
    80003258:	7179                	addi	sp,sp,-48
    8000325a:	f406                	sd	ra,40(sp)
    8000325c:	f022                	sd	s0,32(sp)
    8000325e:	ec26                	sd	s1,24(sp)
    80003260:	e84a                	sd	s2,16(sp)
    80003262:	e44e                	sd	s3,8(sp)
    80003264:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003266:	00004597          	auipc	a1,0x4
    8000326a:	41258593          	addi	a1,a1,1042 # 80007678 <syscalls+0x148>
    8000326e:	0001c517          	auipc	a0,0x1c
    80003272:	d9250513          	addi	a0,a0,-622 # 8001f000 <itable>
    80003276:	875fd0ef          	jal	ra,80000aea <initlock>
  for(i = 0; i < NINODE; i++) {
    8000327a:	0001c497          	auipc	s1,0x1c
    8000327e:	dae48493          	addi	s1,s1,-594 # 8001f028 <itable+0x28>
    80003282:	0001e997          	auipc	s3,0x1e
    80003286:	83698993          	addi	s3,s3,-1994 # 80020ab8 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000328a:	00004917          	auipc	s2,0x4
    8000328e:	3f690913          	addi	s2,s2,1014 # 80007680 <syscalls+0x150>
    80003292:	85ca                	mv	a1,s2
    80003294:	8526                	mv	a0,s1
    80003296:	5b1000ef          	jal	ra,80004046 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    8000329a:	08848493          	addi	s1,s1,136
    8000329e:	ff349ae3          	bne	s1,s3,80003292 <iinit+0x3a>
}
    800032a2:	70a2                	ld	ra,40(sp)
    800032a4:	7402                	ld	s0,32(sp)
    800032a6:	64e2                	ld	s1,24(sp)
    800032a8:	6942                	ld	s2,16(sp)
    800032aa:	69a2                	ld	s3,8(sp)
    800032ac:	6145                	addi	sp,sp,48
    800032ae:	8082                	ret

00000000800032b0 <ialloc>:
{
    800032b0:	715d                	addi	sp,sp,-80
    800032b2:	e486                	sd	ra,72(sp)
    800032b4:	e0a2                	sd	s0,64(sp)
    800032b6:	fc26                	sd	s1,56(sp)
    800032b8:	f84a                	sd	s2,48(sp)
    800032ba:	f44e                	sd	s3,40(sp)
    800032bc:	f052                	sd	s4,32(sp)
    800032be:	ec56                	sd	s5,24(sp)
    800032c0:	e85a                	sd	s6,16(sp)
    800032c2:	e45e                	sd	s7,8(sp)
    800032c4:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    800032c6:	0001c717          	auipc	a4,0x1c
    800032ca:	d2672703          	lw	a4,-730(a4) # 8001efec <sb+0xc>
    800032ce:	4785                	li	a5,1
    800032d0:	04e7f663          	bgeu	a5,a4,8000331c <ialloc+0x6c>
    800032d4:	8aaa                	mv	s5,a0
    800032d6:	8bae                	mv	s7,a1
    800032d8:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    800032da:	0001ca17          	auipc	s4,0x1c
    800032de:	d06a0a13          	addi	s4,s4,-762 # 8001efe0 <sb>
    800032e2:	00048b1b          	sext.w	s6,s1
    800032e6:	0044d593          	srli	a1,s1,0x4
    800032ea:	018a2783          	lw	a5,24(s4)
    800032ee:	9dbd                	addw	a1,a1,a5
    800032f0:	8556                	mv	a0,s5
    800032f2:	a79ff0ef          	jal	ra,80002d6a <bread>
    800032f6:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800032f8:	05850993          	addi	s3,a0,88
    800032fc:	00f4f793          	andi	a5,s1,15
    80003300:	079a                	slli	a5,a5,0x6
    80003302:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80003304:	00099783          	lh	a5,0(s3)
    80003308:	cf85                	beqz	a5,80003340 <ialloc+0x90>
    brelse(bp);
    8000330a:	b69ff0ef          	jal	ra,80002e72 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000330e:	0485                	addi	s1,s1,1
    80003310:	00ca2703          	lw	a4,12(s4)
    80003314:	0004879b          	sext.w	a5,s1
    80003318:	fce7e5e3          	bltu	a5,a4,800032e2 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    8000331c:	00004517          	auipc	a0,0x4
    80003320:	36c50513          	addi	a0,a0,876 # 80007688 <syscalls+0x158>
    80003324:	99efd0ef          	jal	ra,800004c2 <printf>
  return 0;
    80003328:	4501                	li	a0,0
}
    8000332a:	60a6                	ld	ra,72(sp)
    8000332c:	6406                	ld	s0,64(sp)
    8000332e:	74e2                	ld	s1,56(sp)
    80003330:	7942                	ld	s2,48(sp)
    80003332:	79a2                	ld	s3,40(sp)
    80003334:	7a02                	ld	s4,32(sp)
    80003336:	6ae2                	ld	s5,24(sp)
    80003338:	6b42                	ld	s6,16(sp)
    8000333a:	6ba2                	ld	s7,8(sp)
    8000333c:	6161                	addi	sp,sp,80
    8000333e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003340:	04000613          	li	a2,64
    80003344:	4581                	li	a1,0
    80003346:	854e                	mv	a0,s3
    80003348:	8f7fd0ef          	jal	ra,80000c3e <memset>
      dip->type = type;
    8000334c:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003350:	854a                	mv	a0,s2
    80003352:	433000ef          	jal	ra,80003f84 <log_write>
      brelse(bp);
    80003356:	854a                	mv	a0,s2
    80003358:	b1bff0ef          	jal	ra,80002e72 <brelse>
      return iget(dev, inum);
    8000335c:	85da                	mv	a1,s6
    8000335e:	8556                	mv	a0,s5
    80003360:	e4dff0ef          	jal	ra,800031ac <iget>
    80003364:	b7d9                	j	8000332a <ialloc+0x7a>

0000000080003366 <iupdate>:
{
    80003366:	1101                	addi	sp,sp,-32
    80003368:	ec06                	sd	ra,24(sp)
    8000336a:	e822                	sd	s0,16(sp)
    8000336c:	e426                	sd	s1,8(sp)
    8000336e:	e04a                	sd	s2,0(sp)
    80003370:	1000                	addi	s0,sp,32
    80003372:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003374:	415c                	lw	a5,4(a0)
    80003376:	0047d79b          	srliw	a5,a5,0x4
    8000337a:	0001c597          	auipc	a1,0x1c
    8000337e:	c7e5a583          	lw	a1,-898(a1) # 8001eff8 <sb+0x18>
    80003382:	9dbd                	addw	a1,a1,a5
    80003384:	4108                	lw	a0,0(a0)
    80003386:	9e5ff0ef          	jal	ra,80002d6a <bread>
    8000338a:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000338c:	05850793          	addi	a5,a0,88
    80003390:	40d8                	lw	a4,4(s1)
    80003392:	8b3d                	andi	a4,a4,15
    80003394:	071a                	slli	a4,a4,0x6
    80003396:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003398:	04449703          	lh	a4,68(s1)
    8000339c:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800033a0:	04649703          	lh	a4,70(s1)
    800033a4:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800033a8:	04849703          	lh	a4,72(s1)
    800033ac:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800033b0:	04a49703          	lh	a4,74(s1)
    800033b4:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800033b8:	44f8                	lw	a4,76(s1)
    800033ba:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800033bc:	03400613          	li	a2,52
    800033c0:	05048593          	addi	a1,s1,80
    800033c4:	00c78513          	addi	a0,a5,12
    800033c8:	8d3fd0ef          	jal	ra,80000c9a <memmove>
  log_write(bp);
    800033cc:	854a                	mv	a0,s2
    800033ce:	3b7000ef          	jal	ra,80003f84 <log_write>
  brelse(bp);
    800033d2:	854a                	mv	a0,s2
    800033d4:	a9fff0ef          	jal	ra,80002e72 <brelse>
}
    800033d8:	60e2                	ld	ra,24(sp)
    800033da:	6442                	ld	s0,16(sp)
    800033dc:	64a2                	ld	s1,8(sp)
    800033de:	6902                	ld	s2,0(sp)
    800033e0:	6105                	addi	sp,sp,32
    800033e2:	8082                	ret

00000000800033e4 <idup>:
{
    800033e4:	1101                	addi	sp,sp,-32
    800033e6:	ec06                	sd	ra,24(sp)
    800033e8:	e822                	sd	s0,16(sp)
    800033ea:	e426                	sd	s1,8(sp)
    800033ec:	1000                	addi	s0,sp,32
    800033ee:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800033f0:	0001c517          	auipc	a0,0x1c
    800033f4:	c1050513          	addi	a0,a0,-1008 # 8001f000 <itable>
    800033f8:	f72fd0ef          	jal	ra,80000b6a <acquire>
  ip->ref++;
    800033fc:	449c                	lw	a5,8(s1)
    800033fe:	2785                	addiw	a5,a5,1
    80003400:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003402:	0001c517          	auipc	a0,0x1c
    80003406:	bfe50513          	addi	a0,a0,-1026 # 8001f000 <itable>
    8000340a:	ff8fd0ef          	jal	ra,80000c02 <release>
}
    8000340e:	8526                	mv	a0,s1
    80003410:	60e2                	ld	ra,24(sp)
    80003412:	6442                	ld	s0,16(sp)
    80003414:	64a2                	ld	s1,8(sp)
    80003416:	6105                	addi	sp,sp,32
    80003418:	8082                	ret

000000008000341a <ilock>:
{
    8000341a:	1101                	addi	sp,sp,-32
    8000341c:	ec06                	sd	ra,24(sp)
    8000341e:	e822                	sd	s0,16(sp)
    80003420:	e426                	sd	s1,8(sp)
    80003422:	e04a                	sd	s2,0(sp)
    80003424:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003426:	c105                	beqz	a0,80003446 <ilock+0x2c>
    80003428:	84aa                	mv	s1,a0
    8000342a:	451c                	lw	a5,8(a0)
    8000342c:	00f05d63          	blez	a5,80003446 <ilock+0x2c>
  acquiresleep(&ip->lock);
    80003430:	0541                	addi	a0,a0,16
    80003432:	44b000ef          	jal	ra,8000407c <acquiresleep>
  if(ip->valid == 0){
    80003436:	40bc                	lw	a5,64(s1)
    80003438:	cf89                	beqz	a5,80003452 <ilock+0x38>
}
    8000343a:	60e2                	ld	ra,24(sp)
    8000343c:	6442                	ld	s0,16(sp)
    8000343e:	64a2                	ld	s1,8(sp)
    80003440:	6902                	ld	s2,0(sp)
    80003442:	6105                	addi	sp,sp,32
    80003444:	8082                	ret
    panic("ilock");
    80003446:	00004517          	auipc	a0,0x4
    8000344a:	25a50513          	addi	a0,a0,602 # 800076a0 <syscalls+0x170>
    8000344e:	b3afd0ef          	jal	ra,80000788 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003452:	40dc                	lw	a5,4(s1)
    80003454:	0047d79b          	srliw	a5,a5,0x4
    80003458:	0001c597          	auipc	a1,0x1c
    8000345c:	ba05a583          	lw	a1,-1120(a1) # 8001eff8 <sb+0x18>
    80003460:	9dbd                	addw	a1,a1,a5
    80003462:	4088                	lw	a0,0(s1)
    80003464:	907ff0ef          	jal	ra,80002d6a <bread>
    80003468:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000346a:	05850593          	addi	a1,a0,88
    8000346e:	40dc                	lw	a5,4(s1)
    80003470:	8bbd                	andi	a5,a5,15
    80003472:	079a                	slli	a5,a5,0x6
    80003474:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003476:	00059783          	lh	a5,0(a1)
    8000347a:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000347e:	00259783          	lh	a5,2(a1)
    80003482:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003486:	00459783          	lh	a5,4(a1)
    8000348a:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000348e:	00659783          	lh	a5,6(a1)
    80003492:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003496:	459c                	lw	a5,8(a1)
    80003498:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000349a:	03400613          	li	a2,52
    8000349e:	05b1                	addi	a1,a1,12
    800034a0:	05048513          	addi	a0,s1,80
    800034a4:	ff6fd0ef          	jal	ra,80000c9a <memmove>
    brelse(bp);
    800034a8:	854a                	mv	a0,s2
    800034aa:	9c9ff0ef          	jal	ra,80002e72 <brelse>
    ip->valid = 1;
    800034ae:	4785                	li	a5,1
    800034b0:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800034b2:	04449783          	lh	a5,68(s1)
    800034b6:	f3d1                	bnez	a5,8000343a <ilock+0x20>
      panic("ilock: no type");
    800034b8:	00004517          	auipc	a0,0x4
    800034bc:	1f050513          	addi	a0,a0,496 # 800076a8 <syscalls+0x178>
    800034c0:	ac8fd0ef          	jal	ra,80000788 <panic>

00000000800034c4 <iunlock>:
{
    800034c4:	1101                	addi	sp,sp,-32
    800034c6:	ec06                	sd	ra,24(sp)
    800034c8:	e822                	sd	s0,16(sp)
    800034ca:	e426                	sd	s1,8(sp)
    800034cc:	e04a                	sd	s2,0(sp)
    800034ce:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800034d0:	c505                	beqz	a0,800034f8 <iunlock+0x34>
    800034d2:	84aa                	mv	s1,a0
    800034d4:	01050913          	addi	s2,a0,16
    800034d8:	854a                	mv	a0,s2
    800034da:	421000ef          	jal	ra,800040fa <holdingsleep>
    800034de:	cd09                	beqz	a0,800034f8 <iunlock+0x34>
    800034e0:	449c                	lw	a5,8(s1)
    800034e2:	00f05b63          	blez	a5,800034f8 <iunlock+0x34>
  releasesleep(&ip->lock);
    800034e6:	854a                	mv	a0,s2
    800034e8:	3db000ef          	jal	ra,800040c2 <releasesleep>
}
    800034ec:	60e2                	ld	ra,24(sp)
    800034ee:	6442                	ld	s0,16(sp)
    800034f0:	64a2                	ld	s1,8(sp)
    800034f2:	6902                	ld	s2,0(sp)
    800034f4:	6105                	addi	sp,sp,32
    800034f6:	8082                	ret
    panic("iunlock");
    800034f8:	00004517          	auipc	a0,0x4
    800034fc:	1c050513          	addi	a0,a0,448 # 800076b8 <syscalls+0x188>
    80003500:	a88fd0ef          	jal	ra,80000788 <panic>

0000000080003504 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003504:	7179                	addi	sp,sp,-48
    80003506:	f406                	sd	ra,40(sp)
    80003508:	f022                	sd	s0,32(sp)
    8000350a:	ec26                	sd	s1,24(sp)
    8000350c:	e84a                	sd	s2,16(sp)
    8000350e:	e44e                	sd	s3,8(sp)
    80003510:	e052                	sd	s4,0(sp)
    80003512:	1800                	addi	s0,sp,48
    80003514:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003516:	05050493          	addi	s1,a0,80
    8000351a:	08050913          	addi	s2,a0,128
    8000351e:	a021                	j	80003526 <itrunc+0x22>
    80003520:	0491                	addi	s1,s1,4
    80003522:	01248b63          	beq	s1,s2,80003538 <itrunc+0x34>
    if(ip->addrs[i]){
    80003526:	408c                	lw	a1,0(s1)
    80003528:	dde5                	beqz	a1,80003520 <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    8000352a:	0009a503          	lw	a0,0(s3)
    8000352e:	a37ff0ef          	jal	ra,80002f64 <bfree>
      ip->addrs[i] = 0;
    80003532:	0004a023          	sw	zero,0(s1)
    80003536:	b7ed                	j	80003520 <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003538:	0809a583          	lw	a1,128(s3)
    8000353c:	ed91                	bnez	a1,80003558 <itrunc+0x54>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000353e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003542:	854e                	mv	a0,s3
    80003544:	e23ff0ef          	jal	ra,80003366 <iupdate>
}
    80003548:	70a2                	ld	ra,40(sp)
    8000354a:	7402                	ld	s0,32(sp)
    8000354c:	64e2                	ld	s1,24(sp)
    8000354e:	6942                	ld	s2,16(sp)
    80003550:	69a2                	ld	s3,8(sp)
    80003552:	6a02                	ld	s4,0(sp)
    80003554:	6145                	addi	sp,sp,48
    80003556:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003558:	0009a503          	lw	a0,0(s3)
    8000355c:	80fff0ef          	jal	ra,80002d6a <bread>
    80003560:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003562:	05850493          	addi	s1,a0,88
    80003566:	45850913          	addi	s2,a0,1112
    8000356a:	a021                	j	80003572 <itrunc+0x6e>
    8000356c:	0491                	addi	s1,s1,4
    8000356e:	01248963          	beq	s1,s2,80003580 <itrunc+0x7c>
      if(a[j])
    80003572:	408c                	lw	a1,0(s1)
    80003574:	dde5                	beqz	a1,8000356c <itrunc+0x68>
        bfree(ip->dev, a[j]);
    80003576:	0009a503          	lw	a0,0(s3)
    8000357a:	9ebff0ef          	jal	ra,80002f64 <bfree>
    8000357e:	b7fd                	j	8000356c <itrunc+0x68>
    brelse(bp);
    80003580:	8552                	mv	a0,s4
    80003582:	8f1ff0ef          	jal	ra,80002e72 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003586:	0809a583          	lw	a1,128(s3)
    8000358a:	0009a503          	lw	a0,0(s3)
    8000358e:	9d7ff0ef          	jal	ra,80002f64 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003592:	0809a023          	sw	zero,128(s3)
    80003596:	b765                	j	8000353e <itrunc+0x3a>

0000000080003598 <iput>:
{
    80003598:	1101                	addi	sp,sp,-32
    8000359a:	ec06                	sd	ra,24(sp)
    8000359c:	e822                	sd	s0,16(sp)
    8000359e:	e426                	sd	s1,8(sp)
    800035a0:	e04a                	sd	s2,0(sp)
    800035a2:	1000                	addi	s0,sp,32
    800035a4:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800035a6:	0001c517          	auipc	a0,0x1c
    800035aa:	a5a50513          	addi	a0,a0,-1446 # 8001f000 <itable>
    800035ae:	dbcfd0ef          	jal	ra,80000b6a <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800035b2:	4498                	lw	a4,8(s1)
    800035b4:	4785                	li	a5,1
    800035b6:	02f70163          	beq	a4,a5,800035d8 <iput+0x40>
  ip->ref--;
    800035ba:	449c                	lw	a5,8(s1)
    800035bc:	37fd                	addiw	a5,a5,-1
    800035be:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800035c0:	0001c517          	auipc	a0,0x1c
    800035c4:	a4050513          	addi	a0,a0,-1472 # 8001f000 <itable>
    800035c8:	e3afd0ef          	jal	ra,80000c02 <release>
}
    800035cc:	60e2                	ld	ra,24(sp)
    800035ce:	6442                	ld	s0,16(sp)
    800035d0:	64a2                	ld	s1,8(sp)
    800035d2:	6902                	ld	s2,0(sp)
    800035d4:	6105                	addi	sp,sp,32
    800035d6:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800035d8:	40bc                	lw	a5,64(s1)
    800035da:	d3e5                	beqz	a5,800035ba <iput+0x22>
    800035dc:	04a49783          	lh	a5,74(s1)
    800035e0:	ffe9                	bnez	a5,800035ba <iput+0x22>
    acquiresleep(&ip->lock);
    800035e2:	01048913          	addi	s2,s1,16
    800035e6:	854a                	mv	a0,s2
    800035e8:	295000ef          	jal	ra,8000407c <acquiresleep>
    release(&itable.lock);
    800035ec:	0001c517          	auipc	a0,0x1c
    800035f0:	a1450513          	addi	a0,a0,-1516 # 8001f000 <itable>
    800035f4:	e0efd0ef          	jal	ra,80000c02 <release>
    itrunc(ip);
    800035f8:	8526                	mv	a0,s1
    800035fa:	f0bff0ef          	jal	ra,80003504 <itrunc>
    ip->type = 0;
    800035fe:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003602:	8526                	mv	a0,s1
    80003604:	d63ff0ef          	jal	ra,80003366 <iupdate>
    ip->valid = 0;
    80003608:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000360c:	854a                	mv	a0,s2
    8000360e:	2b5000ef          	jal	ra,800040c2 <releasesleep>
    acquire(&itable.lock);
    80003612:	0001c517          	auipc	a0,0x1c
    80003616:	9ee50513          	addi	a0,a0,-1554 # 8001f000 <itable>
    8000361a:	d50fd0ef          	jal	ra,80000b6a <acquire>
    8000361e:	bf71                	j	800035ba <iput+0x22>

0000000080003620 <iunlockput>:
{
    80003620:	1101                	addi	sp,sp,-32
    80003622:	ec06                	sd	ra,24(sp)
    80003624:	e822                	sd	s0,16(sp)
    80003626:	e426                	sd	s1,8(sp)
    80003628:	1000                	addi	s0,sp,32
    8000362a:	84aa                	mv	s1,a0
  iunlock(ip);
    8000362c:	e99ff0ef          	jal	ra,800034c4 <iunlock>
  iput(ip);
    80003630:	8526                	mv	a0,s1
    80003632:	f67ff0ef          	jal	ra,80003598 <iput>
}
    80003636:	60e2                	ld	ra,24(sp)
    80003638:	6442                	ld	s0,16(sp)
    8000363a:	64a2                	ld	s1,8(sp)
    8000363c:	6105                	addi	sp,sp,32
    8000363e:	8082                	ret

0000000080003640 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003640:	0001c717          	auipc	a4,0x1c
    80003644:	9ac72703          	lw	a4,-1620(a4) # 8001efec <sb+0xc>
    80003648:	4785                	li	a5,1
    8000364a:	0ae7ff63          	bgeu	a5,a4,80003708 <ireclaim+0xc8>
{
    8000364e:	7139                	addi	sp,sp,-64
    80003650:	fc06                	sd	ra,56(sp)
    80003652:	f822                	sd	s0,48(sp)
    80003654:	f426                	sd	s1,40(sp)
    80003656:	f04a                	sd	s2,32(sp)
    80003658:	ec4e                	sd	s3,24(sp)
    8000365a:	e852                	sd	s4,16(sp)
    8000365c:	e456                	sd	s5,8(sp)
    8000365e:	e05a                	sd	s6,0(sp)
    80003660:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003662:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003664:	00050a1b          	sext.w	s4,a0
    80003668:	0001ca97          	auipc	s5,0x1c
    8000366c:	978a8a93          	addi	s5,s5,-1672 # 8001efe0 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    80003670:	00004b17          	auipc	s6,0x4
    80003674:	050b0b13          	addi	s6,s6,80 # 800076c0 <syscalls+0x190>
    80003678:	a099                	j	800036be <ireclaim+0x7e>
    8000367a:	85ce                	mv	a1,s3
    8000367c:	855a                	mv	a0,s6
    8000367e:	e45fc0ef          	jal	ra,800004c2 <printf>
      ip = iget(dev, inum);
    80003682:	85ce                	mv	a1,s3
    80003684:	8552                	mv	a0,s4
    80003686:	b27ff0ef          	jal	ra,800031ac <iget>
    8000368a:	89aa                	mv	s3,a0
    brelse(bp);
    8000368c:	854a                	mv	a0,s2
    8000368e:	fe4ff0ef          	jal	ra,80002e72 <brelse>
    if (ip) {
    80003692:	00098f63          	beqz	s3,800036b0 <ireclaim+0x70>
      begin_op();
    80003696:	76c000ef          	jal	ra,80003e02 <begin_op>
      ilock(ip);
    8000369a:	854e                	mv	a0,s3
    8000369c:	d7fff0ef          	jal	ra,8000341a <ilock>
      iunlock(ip);
    800036a0:	854e                	mv	a0,s3
    800036a2:	e23ff0ef          	jal	ra,800034c4 <iunlock>
      iput(ip);
    800036a6:	854e                	mv	a0,s3
    800036a8:	ef1ff0ef          	jal	ra,80003598 <iput>
      end_op();
    800036ac:	7c4000ef          	jal	ra,80003e70 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800036b0:	0485                	addi	s1,s1,1
    800036b2:	00caa703          	lw	a4,12(s5)
    800036b6:	0004879b          	sext.w	a5,s1
    800036ba:	02e7fd63          	bgeu	a5,a4,800036f4 <ireclaim+0xb4>
    800036be:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800036c2:	0044d593          	srli	a1,s1,0x4
    800036c6:	018aa783          	lw	a5,24(s5)
    800036ca:	9dbd                	addw	a1,a1,a5
    800036cc:	8552                	mv	a0,s4
    800036ce:	e9cff0ef          	jal	ra,80002d6a <bread>
    800036d2:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800036d4:	05850793          	addi	a5,a0,88
    800036d8:	00f9f713          	andi	a4,s3,15
    800036dc:	071a                	slli	a4,a4,0x6
    800036de:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    800036e0:	00079703          	lh	a4,0(a5)
    800036e4:	c701                	beqz	a4,800036ec <ireclaim+0xac>
    800036e6:	00679783          	lh	a5,6(a5)
    800036ea:	dbc1                	beqz	a5,8000367a <ireclaim+0x3a>
    brelse(bp);
    800036ec:	854a                	mv	a0,s2
    800036ee:	f84ff0ef          	jal	ra,80002e72 <brelse>
    if (ip) {
    800036f2:	bf7d                	j	800036b0 <ireclaim+0x70>
}
    800036f4:	70e2                	ld	ra,56(sp)
    800036f6:	7442                	ld	s0,48(sp)
    800036f8:	74a2                	ld	s1,40(sp)
    800036fa:	7902                	ld	s2,32(sp)
    800036fc:	69e2                	ld	s3,24(sp)
    800036fe:	6a42                	ld	s4,16(sp)
    80003700:	6aa2                	ld	s5,8(sp)
    80003702:	6b02                	ld	s6,0(sp)
    80003704:	6121                	addi	sp,sp,64
    80003706:	8082                	ret
    80003708:	8082                	ret

000000008000370a <fsinit>:
fsinit(int dev) {
    8000370a:	7179                	addi	sp,sp,-48
    8000370c:	f406                	sd	ra,40(sp)
    8000370e:	f022                	sd	s0,32(sp)
    80003710:	ec26                	sd	s1,24(sp)
    80003712:	e84a                	sd	s2,16(sp)
    80003714:	e44e                	sd	s3,8(sp)
    80003716:	1800                	addi	s0,sp,48
    80003718:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    8000371a:	4585                	li	a1,1
    8000371c:	e4eff0ef          	jal	ra,80002d6a <bread>
    80003720:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003722:	0001c997          	auipc	s3,0x1c
    80003726:	8be98993          	addi	s3,s3,-1858 # 8001efe0 <sb>
    8000372a:	02000613          	li	a2,32
    8000372e:	05850593          	addi	a1,a0,88
    80003732:	854e                	mv	a0,s3
    80003734:	d66fd0ef          	jal	ra,80000c9a <memmove>
  brelse(bp);
    80003738:	854a                	mv	a0,s2
    8000373a:	f38ff0ef          	jal	ra,80002e72 <brelse>
  if(sb.magic != FSMAGIC)
    8000373e:	0009a703          	lw	a4,0(s3)
    80003742:	102037b7          	lui	a5,0x10203
    80003746:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000374a:	02f71363          	bne	a4,a5,80003770 <fsinit+0x66>
  initlog(dev, &sb);
    8000374e:	0001c597          	auipc	a1,0x1c
    80003752:	89258593          	addi	a1,a1,-1902 # 8001efe0 <sb>
    80003756:	8526                	mv	a0,s1
    80003758:	61e000ef          	jal	ra,80003d76 <initlog>
  ireclaim(dev);
    8000375c:	8526                	mv	a0,s1
    8000375e:	ee3ff0ef          	jal	ra,80003640 <ireclaim>
}
    80003762:	70a2                	ld	ra,40(sp)
    80003764:	7402                	ld	s0,32(sp)
    80003766:	64e2                	ld	s1,24(sp)
    80003768:	6942                	ld	s2,16(sp)
    8000376a:	69a2                	ld	s3,8(sp)
    8000376c:	6145                	addi	sp,sp,48
    8000376e:	8082                	ret
    panic("invalid file system");
    80003770:	00004517          	auipc	a0,0x4
    80003774:	f7050513          	addi	a0,a0,-144 # 800076e0 <syscalls+0x1b0>
    80003778:	810fd0ef          	jal	ra,80000788 <panic>

000000008000377c <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000377c:	1141                	addi	sp,sp,-16
    8000377e:	e422                	sd	s0,8(sp)
    80003780:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003782:	411c                	lw	a5,0(a0)
    80003784:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003786:	415c                	lw	a5,4(a0)
    80003788:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000378a:	04451783          	lh	a5,68(a0)
    8000378e:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003792:	04a51783          	lh	a5,74(a0)
    80003796:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000379a:	04c56783          	lwu	a5,76(a0)
    8000379e:	e99c                	sd	a5,16(a1)
}
    800037a0:	6422                	ld	s0,8(sp)
    800037a2:	0141                	addi	sp,sp,16
    800037a4:	8082                	ret

00000000800037a6 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800037a6:	457c                	lw	a5,76(a0)
    800037a8:	0cd7ef63          	bltu	a5,a3,80003886 <readi+0xe0>
{
    800037ac:	7159                	addi	sp,sp,-112
    800037ae:	f486                	sd	ra,104(sp)
    800037b0:	f0a2                	sd	s0,96(sp)
    800037b2:	eca6                	sd	s1,88(sp)
    800037b4:	e8ca                	sd	s2,80(sp)
    800037b6:	e4ce                	sd	s3,72(sp)
    800037b8:	e0d2                	sd	s4,64(sp)
    800037ba:	fc56                	sd	s5,56(sp)
    800037bc:	f85a                	sd	s6,48(sp)
    800037be:	f45e                	sd	s7,40(sp)
    800037c0:	f062                	sd	s8,32(sp)
    800037c2:	ec66                	sd	s9,24(sp)
    800037c4:	e86a                	sd	s10,16(sp)
    800037c6:	e46e                	sd	s11,8(sp)
    800037c8:	1880                	addi	s0,sp,112
    800037ca:	8b2a                	mv	s6,a0
    800037cc:	8bae                	mv	s7,a1
    800037ce:	8a32                	mv	s4,a2
    800037d0:	84b6                	mv	s1,a3
    800037d2:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800037d4:	9f35                	addw	a4,a4,a3
    return 0;
    800037d6:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800037d8:	08d76663          	bltu	a4,a3,80003864 <readi+0xbe>
  if(off + n > ip->size)
    800037dc:	00e7f463          	bgeu	a5,a4,800037e4 <readi+0x3e>
    n = ip->size - off;
    800037e0:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800037e4:	080a8f63          	beqz	s5,80003882 <readi+0xdc>
    800037e8:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800037ea:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800037ee:	5c7d                	li	s8,-1
    800037f0:	a80d                	j	80003822 <readi+0x7c>
    800037f2:	020d1d93          	slli	s11,s10,0x20
    800037f6:	020ddd93          	srli	s11,s11,0x20
    800037fa:	05890613          	addi	a2,s2,88
    800037fe:	86ee                	mv	a3,s11
    80003800:	963a                	add	a2,a2,a4
    80003802:	85d2                	mv	a1,s4
    80003804:	855e                	mv	a0,s7
    80003806:	b81fe0ef          	jal	ra,80002386 <either_copyout>
    8000380a:	05850763          	beq	a0,s8,80003858 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    8000380e:	854a                	mv	a0,s2
    80003810:	e62ff0ef          	jal	ra,80002e72 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003814:	013d09bb          	addw	s3,s10,s3
    80003818:	009d04bb          	addw	s1,s10,s1
    8000381c:	9a6e                	add	s4,s4,s11
    8000381e:	0559f163          	bgeu	s3,s5,80003860 <readi+0xba>
    uint addr = bmap(ip, off/BSIZE);
    80003822:	00a4d59b          	srliw	a1,s1,0xa
    80003826:	855a                	mv	a0,s6
    80003828:	8b7ff0ef          	jal	ra,800030de <bmap>
    8000382c:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003830:	c985                	beqz	a1,80003860 <readi+0xba>
    bp = bread(ip->dev, addr);
    80003832:	000b2503          	lw	a0,0(s6)
    80003836:	d34ff0ef          	jal	ra,80002d6a <bread>
    8000383a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000383c:	3ff4f713          	andi	a4,s1,1023
    80003840:	40ec87bb          	subw	a5,s9,a4
    80003844:	413a86bb          	subw	a3,s5,s3
    80003848:	8d3e                	mv	s10,a5
    8000384a:	2781                	sext.w	a5,a5
    8000384c:	0006861b          	sext.w	a2,a3
    80003850:	faf671e3          	bgeu	a2,a5,800037f2 <readi+0x4c>
    80003854:	8d36                	mv	s10,a3
    80003856:	bf71                	j	800037f2 <readi+0x4c>
      brelse(bp);
    80003858:	854a                	mv	a0,s2
    8000385a:	e18ff0ef          	jal	ra,80002e72 <brelse>
      tot = -1;
    8000385e:	59fd                	li	s3,-1
  }
  return tot;
    80003860:	0009851b          	sext.w	a0,s3
}
    80003864:	70a6                	ld	ra,104(sp)
    80003866:	7406                	ld	s0,96(sp)
    80003868:	64e6                	ld	s1,88(sp)
    8000386a:	6946                	ld	s2,80(sp)
    8000386c:	69a6                	ld	s3,72(sp)
    8000386e:	6a06                	ld	s4,64(sp)
    80003870:	7ae2                	ld	s5,56(sp)
    80003872:	7b42                	ld	s6,48(sp)
    80003874:	7ba2                	ld	s7,40(sp)
    80003876:	7c02                	ld	s8,32(sp)
    80003878:	6ce2                	ld	s9,24(sp)
    8000387a:	6d42                	ld	s10,16(sp)
    8000387c:	6da2                	ld	s11,8(sp)
    8000387e:	6165                	addi	sp,sp,112
    80003880:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003882:	89d6                	mv	s3,s5
    80003884:	bff1                	j	80003860 <readi+0xba>
    return 0;
    80003886:	4501                	li	a0,0
}
    80003888:	8082                	ret

000000008000388a <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    8000388a:	457c                	lw	a5,76(a0)
    8000388c:	0ed7ea63          	bltu	a5,a3,80003980 <writei+0xf6>
{
    80003890:	7159                	addi	sp,sp,-112
    80003892:	f486                	sd	ra,104(sp)
    80003894:	f0a2                	sd	s0,96(sp)
    80003896:	eca6                	sd	s1,88(sp)
    80003898:	e8ca                	sd	s2,80(sp)
    8000389a:	e4ce                	sd	s3,72(sp)
    8000389c:	e0d2                	sd	s4,64(sp)
    8000389e:	fc56                	sd	s5,56(sp)
    800038a0:	f85a                	sd	s6,48(sp)
    800038a2:	f45e                	sd	s7,40(sp)
    800038a4:	f062                	sd	s8,32(sp)
    800038a6:	ec66                	sd	s9,24(sp)
    800038a8:	e86a                	sd	s10,16(sp)
    800038aa:	e46e                	sd	s11,8(sp)
    800038ac:	1880                	addi	s0,sp,112
    800038ae:	8aaa                	mv	s5,a0
    800038b0:	8bae                	mv	s7,a1
    800038b2:	8a32                	mv	s4,a2
    800038b4:	8936                	mv	s2,a3
    800038b6:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800038b8:	00e687bb          	addw	a5,a3,a4
    800038bc:	0cd7e463          	bltu	a5,a3,80003984 <writei+0xfa>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800038c0:	00043737          	lui	a4,0x43
    800038c4:	0cf76263          	bltu	a4,a5,80003988 <writei+0xfe>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800038c8:	0a0b0a63          	beqz	s6,8000397c <writei+0xf2>
    800038cc:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800038ce:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800038d2:	5c7d                	li	s8,-1
    800038d4:	a825                	j	8000390c <writei+0x82>
    800038d6:	020d1d93          	slli	s11,s10,0x20
    800038da:	020ddd93          	srli	s11,s11,0x20
    800038de:	05848513          	addi	a0,s1,88
    800038e2:	86ee                	mv	a3,s11
    800038e4:	8652                	mv	a2,s4
    800038e6:	85de                	mv	a1,s7
    800038e8:	953a                	add	a0,a0,a4
    800038ea:	ae7fe0ef          	jal	ra,800023d0 <either_copyin>
    800038ee:	05850a63          	beq	a0,s8,80003942 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    800038f2:	8526                	mv	a0,s1
    800038f4:	690000ef          	jal	ra,80003f84 <log_write>
    brelse(bp);
    800038f8:	8526                	mv	a0,s1
    800038fa:	d78ff0ef          	jal	ra,80002e72 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800038fe:	013d09bb          	addw	s3,s10,s3
    80003902:	012d093b          	addw	s2,s10,s2
    80003906:	9a6e                	add	s4,s4,s11
    80003908:	0569f063          	bgeu	s3,s6,80003948 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    8000390c:	00a9559b          	srliw	a1,s2,0xa
    80003910:	8556                	mv	a0,s5
    80003912:	fccff0ef          	jal	ra,800030de <bmap>
    80003916:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    8000391a:	c59d                	beqz	a1,80003948 <writei+0xbe>
    bp = bread(ip->dev, addr);
    8000391c:	000aa503          	lw	a0,0(s5)
    80003920:	c4aff0ef          	jal	ra,80002d6a <bread>
    80003924:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003926:	3ff97713          	andi	a4,s2,1023
    8000392a:	40ec87bb          	subw	a5,s9,a4
    8000392e:	413b06bb          	subw	a3,s6,s3
    80003932:	8d3e                	mv	s10,a5
    80003934:	2781                	sext.w	a5,a5
    80003936:	0006861b          	sext.w	a2,a3
    8000393a:	f8f67ee3          	bgeu	a2,a5,800038d6 <writei+0x4c>
    8000393e:	8d36                	mv	s10,a3
    80003940:	bf59                	j	800038d6 <writei+0x4c>
      brelse(bp);
    80003942:	8526                	mv	a0,s1
    80003944:	d2eff0ef          	jal	ra,80002e72 <brelse>
  }

  if(off > ip->size)
    80003948:	04caa783          	lw	a5,76(s5)
    8000394c:	0127f463          	bgeu	a5,s2,80003954 <writei+0xca>
    ip->size = off;
    80003950:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003954:	8556                	mv	a0,s5
    80003956:	a11ff0ef          	jal	ra,80003366 <iupdate>

  return tot;
    8000395a:	0009851b          	sext.w	a0,s3
}
    8000395e:	70a6                	ld	ra,104(sp)
    80003960:	7406                	ld	s0,96(sp)
    80003962:	64e6                	ld	s1,88(sp)
    80003964:	6946                	ld	s2,80(sp)
    80003966:	69a6                	ld	s3,72(sp)
    80003968:	6a06                	ld	s4,64(sp)
    8000396a:	7ae2                	ld	s5,56(sp)
    8000396c:	7b42                	ld	s6,48(sp)
    8000396e:	7ba2                	ld	s7,40(sp)
    80003970:	7c02                	ld	s8,32(sp)
    80003972:	6ce2                	ld	s9,24(sp)
    80003974:	6d42                	ld	s10,16(sp)
    80003976:	6da2                	ld	s11,8(sp)
    80003978:	6165                	addi	sp,sp,112
    8000397a:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    8000397c:	89da                	mv	s3,s6
    8000397e:	bfd9                	j	80003954 <writei+0xca>
    return -1;
    80003980:	557d                	li	a0,-1
}
    80003982:	8082                	ret
    return -1;
    80003984:	557d                	li	a0,-1
    80003986:	bfe1                	j	8000395e <writei+0xd4>
    return -1;
    80003988:	557d                	li	a0,-1
    8000398a:	bfd1                	j	8000395e <writei+0xd4>

000000008000398c <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    8000398c:	1141                	addi	sp,sp,-16
    8000398e:	e406                	sd	ra,8(sp)
    80003990:	e022                	sd	s0,0(sp)
    80003992:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003994:	4639                	li	a2,14
    80003996:	b74fd0ef          	jal	ra,80000d0a <strncmp>
}
    8000399a:	60a2                	ld	ra,8(sp)
    8000399c:	6402                	ld	s0,0(sp)
    8000399e:	0141                	addi	sp,sp,16
    800039a0:	8082                	ret

00000000800039a2 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    800039a2:	7139                	addi	sp,sp,-64
    800039a4:	fc06                	sd	ra,56(sp)
    800039a6:	f822                	sd	s0,48(sp)
    800039a8:	f426                	sd	s1,40(sp)
    800039aa:	f04a                	sd	s2,32(sp)
    800039ac:	ec4e                	sd	s3,24(sp)
    800039ae:	e852                	sd	s4,16(sp)
    800039b0:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    800039b2:	04451703          	lh	a4,68(a0)
    800039b6:	4785                	li	a5,1
    800039b8:	00f71a63          	bne	a4,a5,800039cc <dirlookup+0x2a>
    800039bc:	892a                	mv	s2,a0
    800039be:	89ae                	mv	s3,a1
    800039c0:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    800039c2:	457c                	lw	a5,76(a0)
    800039c4:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    800039c6:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    800039c8:	e39d                	bnez	a5,800039ee <dirlookup+0x4c>
    800039ca:	a095                	j	80003a2e <dirlookup+0x8c>
    panic("dirlookup not DIR");
    800039cc:	00004517          	auipc	a0,0x4
    800039d0:	d2c50513          	addi	a0,a0,-724 # 800076f8 <syscalls+0x1c8>
    800039d4:	db5fc0ef          	jal	ra,80000788 <panic>
      panic("dirlookup read");
    800039d8:	00004517          	auipc	a0,0x4
    800039dc:	d3850513          	addi	a0,a0,-712 # 80007710 <syscalls+0x1e0>
    800039e0:	da9fc0ef          	jal	ra,80000788 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800039e4:	24c1                	addiw	s1,s1,16
    800039e6:	04c92783          	lw	a5,76(s2)
    800039ea:	04f4f163          	bgeu	s1,a5,80003a2c <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800039ee:	4741                	li	a4,16
    800039f0:	86a6                	mv	a3,s1
    800039f2:	fc040613          	addi	a2,s0,-64
    800039f6:	4581                	li	a1,0
    800039f8:	854a                	mv	a0,s2
    800039fa:	dadff0ef          	jal	ra,800037a6 <readi>
    800039fe:	47c1                	li	a5,16
    80003a00:	fcf51ce3          	bne	a0,a5,800039d8 <dirlookup+0x36>
    if(de.inum == 0)
    80003a04:	fc045783          	lhu	a5,-64(s0)
    80003a08:	dff1                	beqz	a5,800039e4 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80003a0a:	fc240593          	addi	a1,s0,-62
    80003a0e:	854e                	mv	a0,s3
    80003a10:	f7dff0ef          	jal	ra,8000398c <namecmp>
    80003a14:	f961                	bnez	a0,800039e4 <dirlookup+0x42>
      if(poff)
    80003a16:	000a0463          	beqz	s4,80003a1e <dirlookup+0x7c>
        *poff = off;
    80003a1a:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003a1e:	fc045583          	lhu	a1,-64(s0)
    80003a22:	00092503          	lw	a0,0(s2)
    80003a26:	f86ff0ef          	jal	ra,800031ac <iget>
    80003a2a:	a011                	j	80003a2e <dirlookup+0x8c>
  return 0;
    80003a2c:	4501                	li	a0,0
}
    80003a2e:	70e2                	ld	ra,56(sp)
    80003a30:	7442                	ld	s0,48(sp)
    80003a32:	74a2                	ld	s1,40(sp)
    80003a34:	7902                	ld	s2,32(sp)
    80003a36:	69e2                	ld	s3,24(sp)
    80003a38:	6a42                	ld	s4,16(sp)
    80003a3a:	6121                	addi	sp,sp,64
    80003a3c:	8082                	ret

0000000080003a3e <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003a3e:	711d                	addi	sp,sp,-96
    80003a40:	ec86                	sd	ra,88(sp)
    80003a42:	e8a2                	sd	s0,80(sp)
    80003a44:	e4a6                	sd	s1,72(sp)
    80003a46:	e0ca                	sd	s2,64(sp)
    80003a48:	fc4e                	sd	s3,56(sp)
    80003a4a:	f852                	sd	s4,48(sp)
    80003a4c:	f456                	sd	s5,40(sp)
    80003a4e:	f05a                	sd	s6,32(sp)
    80003a50:	ec5e                	sd	s7,24(sp)
    80003a52:	e862                	sd	s8,16(sp)
    80003a54:	e466                	sd	s9,8(sp)
    80003a56:	e06a                	sd	s10,0(sp)
    80003a58:	1080                	addi	s0,sp,96
    80003a5a:	84aa                	mv	s1,a0
    80003a5c:	8b2e                	mv	s6,a1
    80003a5e:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003a60:	00054703          	lbu	a4,0(a0)
    80003a64:	02f00793          	li	a5,47
    80003a68:	00f70f63          	beq	a4,a5,80003a86 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003a6c:	e5bfd0ef          	jal	ra,800018c6 <myproc>
    80003a70:	15053503          	ld	a0,336(a0)
    80003a74:	971ff0ef          	jal	ra,800033e4 <idup>
    80003a78:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003a7a:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003a7e:	4cb5                	li	s9,13
  len = path - s;
    80003a80:	4b81                	li	s7,0

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003a82:	4c05                	li	s8,1
    80003a84:	a879                	j	80003b22 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80003a86:	4585                	li	a1,1
    80003a88:	4505                	li	a0,1
    80003a8a:	f22ff0ef          	jal	ra,800031ac <iget>
    80003a8e:	8a2a                	mv	s4,a0
    80003a90:	b7ed                	j	80003a7a <namex+0x3c>
      iunlockput(ip);
    80003a92:	8552                	mv	a0,s4
    80003a94:	b8dff0ef          	jal	ra,80003620 <iunlockput>
      return 0;
    80003a98:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003a9a:	8552                	mv	a0,s4
    80003a9c:	60e6                	ld	ra,88(sp)
    80003a9e:	6446                	ld	s0,80(sp)
    80003aa0:	64a6                	ld	s1,72(sp)
    80003aa2:	6906                	ld	s2,64(sp)
    80003aa4:	79e2                	ld	s3,56(sp)
    80003aa6:	7a42                	ld	s4,48(sp)
    80003aa8:	7aa2                	ld	s5,40(sp)
    80003aaa:	7b02                	ld	s6,32(sp)
    80003aac:	6be2                	ld	s7,24(sp)
    80003aae:	6c42                	ld	s8,16(sp)
    80003ab0:	6ca2                	ld	s9,8(sp)
    80003ab2:	6d02                	ld	s10,0(sp)
    80003ab4:	6125                	addi	sp,sp,96
    80003ab6:	8082                	ret
      iunlock(ip);
    80003ab8:	8552                	mv	a0,s4
    80003aba:	a0bff0ef          	jal	ra,800034c4 <iunlock>
      return ip;
    80003abe:	bff1                	j	80003a9a <namex+0x5c>
      iunlockput(ip);
    80003ac0:	8552                	mv	a0,s4
    80003ac2:	b5fff0ef          	jal	ra,80003620 <iunlockput>
      return 0;
    80003ac6:	8a4e                	mv	s4,s3
    80003ac8:	bfc9                	j	80003a9a <namex+0x5c>
  len = path - s;
    80003aca:	40998633          	sub	a2,s3,s1
    80003ace:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80003ad2:	09acd063          	bge	s9,s10,80003b52 <namex+0x114>
    memmove(name, s, DIRSIZ);
    80003ad6:	4639                	li	a2,14
    80003ad8:	85a6                	mv	a1,s1
    80003ada:	8556                	mv	a0,s5
    80003adc:	9befd0ef          	jal	ra,80000c9a <memmove>
    80003ae0:	84ce                	mv	s1,s3
  while(*path == '/')
    80003ae2:	0004c783          	lbu	a5,0(s1)
    80003ae6:	01279763          	bne	a5,s2,80003af4 <namex+0xb6>
    path++;
    80003aea:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003aec:	0004c783          	lbu	a5,0(s1)
    80003af0:	ff278de3          	beq	a5,s2,80003aea <namex+0xac>
    ilock(ip);
    80003af4:	8552                	mv	a0,s4
    80003af6:	925ff0ef          	jal	ra,8000341a <ilock>
    if(ip->type != T_DIR){
    80003afa:	044a1783          	lh	a5,68(s4)
    80003afe:	f9879ae3          	bne	a5,s8,80003a92 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80003b02:	000b0563          	beqz	s6,80003b0c <namex+0xce>
    80003b06:	0004c783          	lbu	a5,0(s1)
    80003b0a:	d7dd                	beqz	a5,80003ab8 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003b0c:	865e                	mv	a2,s7
    80003b0e:	85d6                	mv	a1,s5
    80003b10:	8552                	mv	a0,s4
    80003b12:	e91ff0ef          	jal	ra,800039a2 <dirlookup>
    80003b16:	89aa                	mv	s3,a0
    80003b18:	d545                	beqz	a0,80003ac0 <namex+0x82>
    iunlockput(ip);
    80003b1a:	8552                	mv	a0,s4
    80003b1c:	b05ff0ef          	jal	ra,80003620 <iunlockput>
    ip = next;
    80003b20:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003b22:	0004c783          	lbu	a5,0(s1)
    80003b26:	01279763          	bne	a5,s2,80003b34 <namex+0xf6>
    path++;
    80003b2a:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003b2c:	0004c783          	lbu	a5,0(s1)
    80003b30:	ff278de3          	beq	a5,s2,80003b2a <namex+0xec>
  if(*path == 0)
    80003b34:	cb8d                	beqz	a5,80003b66 <namex+0x128>
  while(*path != '/' && *path != 0)
    80003b36:	0004c783          	lbu	a5,0(s1)
    80003b3a:	89a6                	mv	s3,s1
  len = path - s;
    80003b3c:	8d5e                	mv	s10,s7
    80003b3e:	865e                	mv	a2,s7
  while(*path != '/' && *path != 0)
    80003b40:	01278963          	beq	a5,s2,80003b52 <namex+0x114>
    80003b44:	d3d9                	beqz	a5,80003aca <namex+0x8c>
    path++;
    80003b46:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003b48:	0009c783          	lbu	a5,0(s3)
    80003b4c:	ff279ce3          	bne	a5,s2,80003b44 <namex+0x106>
    80003b50:	bfad                	j	80003aca <namex+0x8c>
    memmove(name, s, len);
    80003b52:	2601                	sext.w	a2,a2
    80003b54:	85a6                	mv	a1,s1
    80003b56:	8556                	mv	a0,s5
    80003b58:	942fd0ef          	jal	ra,80000c9a <memmove>
    name[len] = 0;
    80003b5c:	9d56                	add	s10,s10,s5
    80003b5e:	000d0023          	sb	zero,0(s10) # 1000 <_entry-0x7ffff000>
    80003b62:	84ce                	mv	s1,s3
    80003b64:	bfbd                	j	80003ae2 <namex+0xa4>
  if(nameiparent){
    80003b66:	f20b0ae3          	beqz	s6,80003a9a <namex+0x5c>
    iput(ip);
    80003b6a:	8552                	mv	a0,s4
    80003b6c:	a2dff0ef          	jal	ra,80003598 <iput>
    return 0;
    80003b70:	4a01                	li	s4,0
    80003b72:	b725                	j	80003a9a <namex+0x5c>

0000000080003b74 <dirlink>:
{
    80003b74:	7139                	addi	sp,sp,-64
    80003b76:	fc06                	sd	ra,56(sp)
    80003b78:	f822                	sd	s0,48(sp)
    80003b7a:	f426                	sd	s1,40(sp)
    80003b7c:	f04a                	sd	s2,32(sp)
    80003b7e:	ec4e                	sd	s3,24(sp)
    80003b80:	e852                	sd	s4,16(sp)
    80003b82:	0080                	addi	s0,sp,64
    80003b84:	892a                	mv	s2,a0
    80003b86:	8a2e                	mv	s4,a1
    80003b88:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003b8a:	4601                	li	a2,0
    80003b8c:	e17ff0ef          	jal	ra,800039a2 <dirlookup>
    80003b90:	e52d                	bnez	a0,80003bfa <dirlink+0x86>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003b92:	04c92483          	lw	s1,76(s2)
    80003b96:	c48d                	beqz	s1,80003bc0 <dirlink+0x4c>
    80003b98:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b9a:	4741                	li	a4,16
    80003b9c:	86a6                	mv	a3,s1
    80003b9e:	fc040613          	addi	a2,s0,-64
    80003ba2:	4581                	li	a1,0
    80003ba4:	854a                	mv	a0,s2
    80003ba6:	c01ff0ef          	jal	ra,800037a6 <readi>
    80003baa:	47c1                	li	a5,16
    80003bac:	04f51b63          	bne	a0,a5,80003c02 <dirlink+0x8e>
    if(de.inum == 0)
    80003bb0:	fc045783          	lhu	a5,-64(s0)
    80003bb4:	c791                	beqz	a5,80003bc0 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003bb6:	24c1                	addiw	s1,s1,16
    80003bb8:	04c92783          	lw	a5,76(s2)
    80003bbc:	fcf4efe3          	bltu	s1,a5,80003b9a <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003bc0:	4639                	li	a2,14
    80003bc2:	85d2                	mv	a1,s4
    80003bc4:	fc240513          	addi	a0,s0,-62
    80003bc8:	97efd0ef          	jal	ra,80000d46 <strncpy>
  de.inum = inum;
    80003bcc:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003bd0:	4741                	li	a4,16
    80003bd2:	86a6                	mv	a3,s1
    80003bd4:	fc040613          	addi	a2,s0,-64
    80003bd8:	4581                	li	a1,0
    80003bda:	854a                	mv	a0,s2
    80003bdc:	cafff0ef          	jal	ra,8000388a <writei>
    80003be0:	1541                	addi	a0,a0,-16
    80003be2:	00a03533          	snez	a0,a0
    80003be6:	40a00533          	neg	a0,a0
}
    80003bea:	70e2                	ld	ra,56(sp)
    80003bec:	7442                	ld	s0,48(sp)
    80003bee:	74a2                	ld	s1,40(sp)
    80003bf0:	7902                	ld	s2,32(sp)
    80003bf2:	69e2                	ld	s3,24(sp)
    80003bf4:	6a42                	ld	s4,16(sp)
    80003bf6:	6121                	addi	sp,sp,64
    80003bf8:	8082                	ret
    iput(ip);
    80003bfa:	99fff0ef          	jal	ra,80003598 <iput>
    return -1;
    80003bfe:	557d                	li	a0,-1
    80003c00:	b7ed                	j	80003bea <dirlink+0x76>
      panic("dirlink read");
    80003c02:	00004517          	auipc	a0,0x4
    80003c06:	b1e50513          	addi	a0,a0,-1250 # 80007720 <syscalls+0x1f0>
    80003c0a:	b7ffc0ef          	jal	ra,80000788 <panic>

0000000080003c0e <namei>:

struct inode*
namei(char *path)
{
    80003c0e:	1101                	addi	sp,sp,-32
    80003c10:	ec06                	sd	ra,24(sp)
    80003c12:	e822                	sd	s0,16(sp)
    80003c14:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003c16:	fe040613          	addi	a2,s0,-32
    80003c1a:	4581                	li	a1,0
    80003c1c:	e23ff0ef          	jal	ra,80003a3e <namex>
}
    80003c20:	60e2                	ld	ra,24(sp)
    80003c22:	6442                	ld	s0,16(sp)
    80003c24:	6105                	addi	sp,sp,32
    80003c26:	8082                	ret

0000000080003c28 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003c28:	1141                	addi	sp,sp,-16
    80003c2a:	e406                	sd	ra,8(sp)
    80003c2c:	e022                	sd	s0,0(sp)
    80003c2e:	0800                	addi	s0,sp,16
    80003c30:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003c32:	4585                	li	a1,1
    80003c34:	e0bff0ef          	jal	ra,80003a3e <namex>
}
    80003c38:	60a2                	ld	ra,8(sp)
    80003c3a:	6402                	ld	s0,0(sp)
    80003c3c:	0141                	addi	sp,sp,16
    80003c3e:	8082                	ret

0000000080003c40 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003c40:	1101                	addi	sp,sp,-32
    80003c42:	ec06                	sd	ra,24(sp)
    80003c44:	e822                	sd	s0,16(sp)
    80003c46:	e426                	sd	s1,8(sp)
    80003c48:	e04a                	sd	s2,0(sp)
    80003c4a:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003c4c:	0001d917          	auipc	s2,0x1d
    80003c50:	e5c90913          	addi	s2,s2,-420 # 80020aa8 <log>
    80003c54:	01892583          	lw	a1,24(s2)
    80003c58:	02492503          	lw	a0,36(s2)
    80003c5c:	90eff0ef          	jal	ra,80002d6a <bread>
    80003c60:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003c62:	02892683          	lw	a3,40(s2)
    80003c66:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003c68:	02d05863          	blez	a3,80003c98 <write_head+0x58>
    80003c6c:	0001d797          	auipc	a5,0x1d
    80003c70:	e6878793          	addi	a5,a5,-408 # 80020ad4 <log+0x2c>
    80003c74:	05c50713          	addi	a4,a0,92
    80003c78:	36fd                	addiw	a3,a3,-1
    80003c7a:	02069613          	slli	a2,a3,0x20
    80003c7e:	01e65693          	srli	a3,a2,0x1e
    80003c82:	0001d617          	auipc	a2,0x1d
    80003c86:	e5660613          	addi	a2,a2,-426 # 80020ad8 <log+0x30>
    80003c8a:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80003c8c:	4390                	lw	a2,0(a5)
    80003c8e:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003c90:	0791                	addi	a5,a5,4
    80003c92:	0711                	addi	a4,a4,4 # 43004 <_entry-0x7ffbcffc>
    80003c94:	fed79ce3          	bne	a5,a3,80003c8c <write_head+0x4c>
  }
  bwrite(buf);
    80003c98:	8526                	mv	a0,s1
    80003c9a:	9a6ff0ef          	jal	ra,80002e40 <bwrite>
  brelse(buf);
    80003c9e:	8526                	mv	a0,s1
    80003ca0:	9d2ff0ef          	jal	ra,80002e72 <brelse>
}
    80003ca4:	60e2                	ld	ra,24(sp)
    80003ca6:	6442                	ld	s0,16(sp)
    80003ca8:	64a2                	ld	s1,8(sp)
    80003caa:	6902                	ld	s2,0(sp)
    80003cac:	6105                	addi	sp,sp,32
    80003cae:	8082                	ret

0000000080003cb0 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003cb0:	0001d797          	auipc	a5,0x1d
    80003cb4:	e207a783          	lw	a5,-480(a5) # 80020ad0 <log+0x28>
    80003cb8:	0af05e63          	blez	a5,80003d74 <install_trans+0xc4>
{
    80003cbc:	715d                	addi	sp,sp,-80
    80003cbe:	e486                	sd	ra,72(sp)
    80003cc0:	e0a2                	sd	s0,64(sp)
    80003cc2:	fc26                	sd	s1,56(sp)
    80003cc4:	f84a                	sd	s2,48(sp)
    80003cc6:	f44e                	sd	s3,40(sp)
    80003cc8:	f052                	sd	s4,32(sp)
    80003cca:	ec56                	sd	s5,24(sp)
    80003ccc:	e85a                	sd	s6,16(sp)
    80003cce:	e45e                	sd	s7,8(sp)
    80003cd0:	0880                	addi	s0,sp,80
    80003cd2:	8b2a                	mv	s6,a0
    80003cd4:	0001da97          	auipc	s5,0x1d
    80003cd8:	e00a8a93          	addi	s5,s5,-512 # 80020ad4 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003cdc:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003cde:	00004b97          	auipc	s7,0x4
    80003ce2:	a52b8b93          	addi	s7,s7,-1454 # 80007730 <syscalls+0x200>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003ce6:	0001da17          	auipc	s4,0x1d
    80003cea:	dc2a0a13          	addi	s4,s4,-574 # 80020aa8 <log>
    80003cee:	a025                	j	80003d16 <install_trans+0x66>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003cf0:	000aa603          	lw	a2,0(s5)
    80003cf4:	85ce                	mv	a1,s3
    80003cf6:	855e                	mv	a0,s7
    80003cf8:	fcafc0ef          	jal	ra,800004c2 <printf>
    80003cfc:	a839                	j	80003d1a <install_trans+0x6a>
    brelse(lbuf);
    80003cfe:	854a                	mv	a0,s2
    80003d00:	972ff0ef          	jal	ra,80002e72 <brelse>
    brelse(dbuf);
    80003d04:	8526                	mv	a0,s1
    80003d06:	96cff0ef          	jal	ra,80002e72 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d0a:	2985                	addiw	s3,s3,1
    80003d0c:	0a91                	addi	s5,s5,4
    80003d0e:	028a2783          	lw	a5,40(s4)
    80003d12:	04f9d663          	bge	s3,a5,80003d5e <install_trans+0xae>
    if(recovering) {
    80003d16:	fc0b1de3          	bnez	s6,80003cf0 <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003d1a:	018a2583          	lw	a1,24(s4)
    80003d1e:	013585bb          	addw	a1,a1,s3
    80003d22:	2585                	addiw	a1,a1,1
    80003d24:	024a2503          	lw	a0,36(s4)
    80003d28:	842ff0ef          	jal	ra,80002d6a <bread>
    80003d2c:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003d2e:	000aa583          	lw	a1,0(s5)
    80003d32:	024a2503          	lw	a0,36(s4)
    80003d36:	834ff0ef          	jal	ra,80002d6a <bread>
    80003d3a:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003d3c:	40000613          	li	a2,1024
    80003d40:	05890593          	addi	a1,s2,88
    80003d44:	05850513          	addi	a0,a0,88
    80003d48:	f53fc0ef          	jal	ra,80000c9a <memmove>
    bwrite(dbuf);  // write dst to disk
    80003d4c:	8526                	mv	a0,s1
    80003d4e:	8f2ff0ef          	jal	ra,80002e40 <bwrite>
    if(recovering == 0)
    80003d52:	fa0b16e3          	bnez	s6,80003cfe <install_trans+0x4e>
      bunpin(dbuf);
    80003d56:	8526                	mv	a0,s1
    80003d58:	9d8ff0ef          	jal	ra,80002f30 <bunpin>
    80003d5c:	b74d                	j	80003cfe <install_trans+0x4e>
}
    80003d5e:	60a6                	ld	ra,72(sp)
    80003d60:	6406                	ld	s0,64(sp)
    80003d62:	74e2                	ld	s1,56(sp)
    80003d64:	7942                	ld	s2,48(sp)
    80003d66:	79a2                	ld	s3,40(sp)
    80003d68:	7a02                	ld	s4,32(sp)
    80003d6a:	6ae2                	ld	s5,24(sp)
    80003d6c:	6b42                	ld	s6,16(sp)
    80003d6e:	6ba2                	ld	s7,8(sp)
    80003d70:	6161                	addi	sp,sp,80
    80003d72:	8082                	ret
    80003d74:	8082                	ret

0000000080003d76 <initlog>:
{
    80003d76:	7179                	addi	sp,sp,-48
    80003d78:	f406                	sd	ra,40(sp)
    80003d7a:	f022                	sd	s0,32(sp)
    80003d7c:	ec26                	sd	s1,24(sp)
    80003d7e:	e84a                	sd	s2,16(sp)
    80003d80:	e44e                	sd	s3,8(sp)
    80003d82:	1800                	addi	s0,sp,48
    80003d84:	892a                	mv	s2,a0
    80003d86:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003d88:	0001d497          	auipc	s1,0x1d
    80003d8c:	d2048493          	addi	s1,s1,-736 # 80020aa8 <log>
    80003d90:	00004597          	auipc	a1,0x4
    80003d94:	9c058593          	addi	a1,a1,-1600 # 80007750 <syscalls+0x220>
    80003d98:	8526                	mv	a0,s1
    80003d9a:	d51fc0ef          	jal	ra,80000aea <initlock>
  log.start = sb->logstart;
    80003d9e:	0149a583          	lw	a1,20(s3)
    80003da2:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003da4:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003da8:	854a                	mv	a0,s2
    80003daa:	fc1fe0ef          	jal	ra,80002d6a <bread>
  log.lh.n = lh->n;
    80003dae:	4d34                	lw	a3,88(a0)
    80003db0:	d494                	sw	a3,40(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003db2:	02d05663          	blez	a3,80003dde <initlog+0x68>
    80003db6:	05c50793          	addi	a5,a0,92
    80003dba:	0001d717          	auipc	a4,0x1d
    80003dbe:	d1a70713          	addi	a4,a4,-742 # 80020ad4 <log+0x2c>
    80003dc2:	36fd                	addiw	a3,a3,-1
    80003dc4:	02069613          	slli	a2,a3,0x20
    80003dc8:	01e65693          	srli	a3,a2,0x1e
    80003dcc:	06050613          	addi	a2,a0,96
    80003dd0:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    80003dd2:	4390                	lw	a2,0(a5)
    80003dd4:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003dd6:	0791                	addi	a5,a5,4
    80003dd8:	0711                	addi	a4,a4,4
    80003dda:	fed79ce3          	bne	a5,a3,80003dd2 <initlog+0x5c>
  brelse(buf);
    80003dde:	894ff0ef          	jal	ra,80002e72 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003de2:	4505                	li	a0,1
    80003de4:	ecdff0ef          	jal	ra,80003cb0 <install_trans>
  log.lh.n = 0;
    80003de8:	0001d797          	auipc	a5,0x1d
    80003dec:	ce07a423          	sw	zero,-792(a5) # 80020ad0 <log+0x28>
  write_head(); // clear the log
    80003df0:	e51ff0ef          	jal	ra,80003c40 <write_head>
}
    80003df4:	70a2                	ld	ra,40(sp)
    80003df6:	7402                	ld	s0,32(sp)
    80003df8:	64e2                	ld	s1,24(sp)
    80003dfa:	6942                	ld	s2,16(sp)
    80003dfc:	69a2                	ld	s3,8(sp)
    80003dfe:	6145                	addi	sp,sp,48
    80003e00:	8082                	ret

0000000080003e02 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003e02:	1101                	addi	sp,sp,-32
    80003e04:	ec06                	sd	ra,24(sp)
    80003e06:	e822                	sd	s0,16(sp)
    80003e08:	e426                	sd	s1,8(sp)
    80003e0a:	e04a                	sd	s2,0(sp)
    80003e0c:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003e0e:	0001d517          	auipc	a0,0x1d
    80003e12:	c9a50513          	addi	a0,a0,-870 # 80020aa8 <log>
    80003e16:	d55fc0ef          	jal	ra,80000b6a <acquire>
  while(1){
    if(log.committing){
    80003e1a:	0001d497          	auipc	s1,0x1d
    80003e1e:	c8e48493          	addi	s1,s1,-882 # 80020aa8 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003e22:	4979                	li	s2,30
    80003e24:	a029                	j	80003e2e <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003e26:	85a6                	mv	a1,s1
    80003e28:	8526                	mv	a0,s1
    80003e2a:	9f4fe0ef          	jal	ra,8000201e <sleep>
    if(log.committing){
    80003e2e:	509c                	lw	a5,32(s1)
    80003e30:	fbfd                	bnez	a5,80003e26 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003e32:	4cd8                	lw	a4,28(s1)
    80003e34:	2705                	addiw	a4,a4,1
    80003e36:	0007069b          	sext.w	a3,a4
    80003e3a:	0027179b          	slliw	a5,a4,0x2
    80003e3e:	9fb9                	addw	a5,a5,a4
    80003e40:	0017979b          	slliw	a5,a5,0x1
    80003e44:	5498                	lw	a4,40(s1)
    80003e46:	9fb9                	addw	a5,a5,a4
    80003e48:	00f95763          	bge	s2,a5,80003e56 <begin_op+0x54>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003e4c:	85a6                	mv	a1,s1
    80003e4e:	8526                	mv	a0,s1
    80003e50:	9cefe0ef          	jal	ra,8000201e <sleep>
    80003e54:	bfe9                	j	80003e2e <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003e56:	0001d517          	auipc	a0,0x1d
    80003e5a:	c5250513          	addi	a0,a0,-942 # 80020aa8 <log>
    80003e5e:	cd54                	sw	a3,28(a0)
      release(&log.lock);
    80003e60:	da3fc0ef          	jal	ra,80000c02 <release>
      break;
    }
  }
}
    80003e64:	60e2                	ld	ra,24(sp)
    80003e66:	6442                	ld	s0,16(sp)
    80003e68:	64a2                	ld	s1,8(sp)
    80003e6a:	6902                	ld	s2,0(sp)
    80003e6c:	6105                	addi	sp,sp,32
    80003e6e:	8082                	ret

0000000080003e70 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003e70:	7139                	addi	sp,sp,-64
    80003e72:	fc06                	sd	ra,56(sp)
    80003e74:	f822                	sd	s0,48(sp)
    80003e76:	f426                	sd	s1,40(sp)
    80003e78:	f04a                	sd	s2,32(sp)
    80003e7a:	ec4e                	sd	s3,24(sp)
    80003e7c:	e852                	sd	s4,16(sp)
    80003e7e:	e456                	sd	s5,8(sp)
    80003e80:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003e82:	0001d497          	auipc	s1,0x1d
    80003e86:	c2648493          	addi	s1,s1,-986 # 80020aa8 <log>
    80003e8a:	8526                	mv	a0,s1
    80003e8c:	cdffc0ef          	jal	ra,80000b6a <acquire>
  log.outstanding -= 1;
    80003e90:	4cdc                	lw	a5,28(s1)
    80003e92:	37fd                	addiw	a5,a5,-1
    80003e94:	0007891b          	sext.w	s2,a5
    80003e98:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003e9a:	509c                	lw	a5,32(s1)
    80003e9c:	ef9d                	bnez	a5,80003eda <end_op+0x6a>
    panic("log.committing");
  if(log.outstanding == 0){
    80003e9e:	04091463          	bnez	s2,80003ee6 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003ea2:	0001d497          	auipc	s1,0x1d
    80003ea6:	c0648493          	addi	s1,s1,-1018 # 80020aa8 <log>
    80003eaa:	4785                	li	a5,1
    80003eac:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003eae:	8526                	mv	a0,s1
    80003eb0:	d53fc0ef          	jal	ra,80000c02 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003eb4:	549c                	lw	a5,40(s1)
    80003eb6:	04f04b63          	bgtz	a5,80003f0c <end_op+0x9c>
    acquire(&log.lock);
    80003eba:	0001d497          	auipc	s1,0x1d
    80003ebe:	bee48493          	addi	s1,s1,-1042 # 80020aa8 <log>
    80003ec2:	8526                	mv	a0,s1
    80003ec4:	ca7fc0ef          	jal	ra,80000b6a <acquire>
    log.committing = 0;
    80003ec8:	0204a023          	sw	zero,32(s1)
    wakeup(&log);
    80003ecc:	8526                	mv	a0,s1
    80003ece:	99cfe0ef          	jal	ra,8000206a <wakeup>
    release(&log.lock);
    80003ed2:	8526                	mv	a0,s1
    80003ed4:	d2ffc0ef          	jal	ra,80000c02 <release>
}
    80003ed8:	a00d                	j	80003efa <end_op+0x8a>
    panic("log.committing");
    80003eda:	00004517          	auipc	a0,0x4
    80003ede:	87e50513          	addi	a0,a0,-1922 # 80007758 <syscalls+0x228>
    80003ee2:	8a7fc0ef          	jal	ra,80000788 <panic>
    wakeup(&log);
    80003ee6:	0001d497          	auipc	s1,0x1d
    80003eea:	bc248493          	addi	s1,s1,-1086 # 80020aa8 <log>
    80003eee:	8526                	mv	a0,s1
    80003ef0:	97afe0ef          	jal	ra,8000206a <wakeup>
  release(&log.lock);
    80003ef4:	8526                	mv	a0,s1
    80003ef6:	d0dfc0ef          	jal	ra,80000c02 <release>
}
    80003efa:	70e2                	ld	ra,56(sp)
    80003efc:	7442                	ld	s0,48(sp)
    80003efe:	74a2                	ld	s1,40(sp)
    80003f00:	7902                	ld	s2,32(sp)
    80003f02:	69e2                	ld	s3,24(sp)
    80003f04:	6a42                	ld	s4,16(sp)
    80003f06:	6aa2                	ld	s5,8(sp)
    80003f08:	6121                	addi	sp,sp,64
    80003f0a:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f0c:	0001da97          	auipc	s5,0x1d
    80003f10:	bc8a8a93          	addi	s5,s5,-1080 # 80020ad4 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003f14:	0001da17          	auipc	s4,0x1d
    80003f18:	b94a0a13          	addi	s4,s4,-1132 # 80020aa8 <log>
    80003f1c:	018a2583          	lw	a1,24(s4)
    80003f20:	012585bb          	addw	a1,a1,s2
    80003f24:	2585                	addiw	a1,a1,1
    80003f26:	024a2503          	lw	a0,36(s4)
    80003f2a:	e41fe0ef          	jal	ra,80002d6a <bread>
    80003f2e:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003f30:	000aa583          	lw	a1,0(s5)
    80003f34:	024a2503          	lw	a0,36(s4)
    80003f38:	e33fe0ef          	jal	ra,80002d6a <bread>
    80003f3c:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003f3e:	40000613          	li	a2,1024
    80003f42:	05850593          	addi	a1,a0,88
    80003f46:	05848513          	addi	a0,s1,88
    80003f4a:	d51fc0ef          	jal	ra,80000c9a <memmove>
    bwrite(to);  // write the log
    80003f4e:	8526                	mv	a0,s1
    80003f50:	ef1fe0ef          	jal	ra,80002e40 <bwrite>
    brelse(from);
    80003f54:	854e                	mv	a0,s3
    80003f56:	f1dfe0ef          	jal	ra,80002e72 <brelse>
    brelse(to);
    80003f5a:	8526                	mv	a0,s1
    80003f5c:	f17fe0ef          	jal	ra,80002e72 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003f60:	2905                	addiw	s2,s2,1
    80003f62:	0a91                	addi	s5,s5,4
    80003f64:	028a2783          	lw	a5,40(s4)
    80003f68:	faf94ae3          	blt	s2,a5,80003f1c <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003f6c:	cd5ff0ef          	jal	ra,80003c40 <write_head>
    install_trans(0); // Now install writes to home locations
    80003f70:	4501                	li	a0,0
    80003f72:	d3fff0ef          	jal	ra,80003cb0 <install_trans>
    log.lh.n = 0;
    80003f76:	0001d797          	auipc	a5,0x1d
    80003f7a:	b407ad23          	sw	zero,-1190(a5) # 80020ad0 <log+0x28>
    write_head();    // Erase the transaction from the log
    80003f7e:	cc3ff0ef          	jal	ra,80003c40 <write_head>
    80003f82:	bf25                	j	80003eba <end_op+0x4a>

0000000080003f84 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003f84:	1101                	addi	sp,sp,-32
    80003f86:	ec06                	sd	ra,24(sp)
    80003f88:	e822                	sd	s0,16(sp)
    80003f8a:	e426                	sd	s1,8(sp)
    80003f8c:	e04a                	sd	s2,0(sp)
    80003f8e:	1000                	addi	s0,sp,32
    80003f90:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003f92:	0001d917          	auipc	s2,0x1d
    80003f96:	b1690913          	addi	s2,s2,-1258 # 80020aa8 <log>
    80003f9a:	854a                	mv	a0,s2
    80003f9c:	bcffc0ef          	jal	ra,80000b6a <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003fa0:	02892603          	lw	a2,40(s2)
    80003fa4:	47f5                	li	a5,29
    80003fa6:	04c7cc63          	blt	a5,a2,80003ffe <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003faa:	0001d797          	auipc	a5,0x1d
    80003fae:	b1a7a783          	lw	a5,-1254(a5) # 80020ac4 <log+0x1c>
    80003fb2:	04f05c63          	blez	a5,8000400a <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003fb6:	4781                	li	a5,0
    80003fb8:	04c05f63          	blez	a2,80004016 <log_write+0x92>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003fbc:	44cc                	lw	a1,12(s1)
    80003fbe:	0001d717          	auipc	a4,0x1d
    80003fc2:	b1670713          	addi	a4,a4,-1258 # 80020ad4 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80003fc6:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003fc8:	4314                	lw	a3,0(a4)
    80003fca:	04b68663          	beq	a3,a1,80004016 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80003fce:	2785                	addiw	a5,a5,1
    80003fd0:	0711                	addi	a4,a4,4
    80003fd2:	fef61be3          	bne	a2,a5,80003fc8 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003fd6:	0621                	addi	a2,a2,8
    80003fd8:	060a                	slli	a2,a2,0x2
    80003fda:	0001d797          	auipc	a5,0x1d
    80003fde:	ace78793          	addi	a5,a5,-1330 # 80020aa8 <log>
    80003fe2:	97b2                	add	a5,a5,a2
    80003fe4:	44d8                	lw	a4,12(s1)
    80003fe6:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003fe8:	8526                	mv	a0,s1
    80003fea:	f13fe0ef          	jal	ra,80002efc <bpin>
    log.lh.n++;
    80003fee:	0001d717          	auipc	a4,0x1d
    80003ff2:	aba70713          	addi	a4,a4,-1350 # 80020aa8 <log>
    80003ff6:	571c                	lw	a5,40(a4)
    80003ff8:	2785                	addiw	a5,a5,1
    80003ffa:	d71c                	sw	a5,40(a4)
    80003ffc:	a80d                	j	8000402e <log_write+0xaa>
    panic("too big a transaction");
    80003ffe:	00003517          	auipc	a0,0x3
    80004002:	76a50513          	addi	a0,a0,1898 # 80007768 <syscalls+0x238>
    80004006:	f82fc0ef          	jal	ra,80000788 <panic>
    panic("log_write outside of trans");
    8000400a:	00003517          	auipc	a0,0x3
    8000400e:	77650513          	addi	a0,a0,1910 # 80007780 <syscalls+0x250>
    80004012:	f76fc0ef          	jal	ra,80000788 <panic>
  log.lh.block[i] = b->blockno;
    80004016:	00878693          	addi	a3,a5,8
    8000401a:	068a                	slli	a3,a3,0x2
    8000401c:	0001d717          	auipc	a4,0x1d
    80004020:	a8c70713          	addi	a4,a4,-1396 # 80020aa8 <log>
    80004024:	9736                	add	a4,a4,a3
    80004026:	44d4                	lw	a3,12(s1)
    80004028:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000402a:	faf60fe3          	beq	a2,a5,80003fe8 <log_write+0x64>
  }
  release(&log.lock);
    8000402e:	0001d517          	auipc	a0,0x1d
    80004032:	a7a50513          	addi	a0,a0,-1414 # 80020aa8 <log>
    80004036:	bcdfc0ef          	jal	ra,80000c02 <release>
}
    8000403a:	60e2                	ld	ra,24(sp)
    8000403c:	6442                	ld	s0,16(sp)
    8000403e:	64a2                	ld	s1,8(sp)
    80004040:	6902                	ld	s2,0(sp)
    80004042:	6105                	addi	sp,sp,32
    80004044:	8082                	ret

0000000080004046 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80004046:	1101                	addi	sp,sp,-32
    80004048:	ec06                	sd	ra,24(sp)
    8000404a:	e822                	sd	s0,16(sp)
    8000404c:	e426                	sd	s1,8(sp)
    8000404e:	e04a                	sd	s2,0(sp)
    80004050:	1000                	addi	s0,sp,32
    80004052:	84aa                	mv	s1,a0
    80004054:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004056:	00003597          	auipc	a1,0x3
    8000405a:	74a58593          	addi	a1,a1,1866 # 800077a0 <syscalls+0x270>
    8000405e:	0521                	addi	a0,a0,8
    80004060:	a8bfc0ef          	jal	ra,80000aea <initlock>
  lk->name = name;
    80004064:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004068:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000406c:	0204a423          	sw	zero,40(s1)
}
    80004070:	60e2                	ld	ra,24(sp)
    80004072:	6442                	ld	s0,16(sp)
    80004074:	64a2                	ld	s1,8(sp)
    80004076:	6902                	ld	s2,0(sp)
    80004078:	6105                	addi	sp,sp,32
    8000407a:	8082                	ret

000000008000407c <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000407c:	1101                	addi	sp,sp,-32
    8000407e:	ec06                	sd	ra,24(sp)
    80004080:	e822                	sd	s0,16(sp)
    80004082:	e426                	sd	s1,8(sp)
    80004084:	e04a                	sd	s2,0(sp)
    80004086:	1000                	addi	s0,sp,32
    80004088:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000408a:	00850913          	addi	s2,a0,8
    8000408e:	854a                	mv	a0,s2
    80004090:	adbfc0ef          	jal	ra,80000b6a <acquire>
  while (lk->locked) {
    80004094:	409c                	lw	a5,0(s1)
    80004096:	c799                	beqz	a5,800040a4 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80004098:	85ca                	mv	a1,s2
    8000409a:	8526                	mv	a0,s1
    8000409c:	f83fd0ef          	jal	ra,8000201e <sleep>
  while (lk->locked) {
    800040a0:	409c                	lw	a5,0(s1)
    800040a2:	fbfd                	bnez	a5,80004098 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800040a4:	4785                	li	a5,1
    800040a6:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800040a8:	81ffd0ef          	jal	ra,800018c6 <myproc>
    800040ac:	591c                	lw	a5,48(a0)
    800040ae:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800040b0:	854a                	mv	a0,s2
    800040b2:	b51fc0ef          	jal	ra,80000c02 <release>
}
    800040b6:	60e2                	ld	ra,24(sp)
    800040b8:	6442                	ld	s0,16(sp)
    800040ba:	64a2                	ld	s1,8(sp)
    800040bc:	6902                	ld	s2,0(sp)
    800040be:	6105                	addi	sp,sp,32
    800040c0:	8082                	ret

00000000800040c2 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800040c2:	1101                	addi	sp,sp,-32
    800040c4:	ec06                	sd	ra,24(sp)
    800040c6:	e822                	sd	s0,16(sp)
    800040c8:	e426                	sd	s1,8(sp)
    800040ca:	e04a                	sd	s2,0(sp)
    800040cc:	1000                	addi	s0,sp,32
    800040ce:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800040d0:	00850913          	addi	s2,a0,8
    800040d4:	854a                	mv	a0,s2
    800040d6:	a95fc0ef          	jal	ra,80000b6a <acquire>
  lk->locked = 0;
    800040da:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800040de:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800040e2:	8526                	mv	a0,s1
    800040e4:	f87fd0ef          	jal	ra,8000206a <wakeup>
  release(&lk->lk);
    800040e8:	854a                	mv	a0,s2
    800040ea:	b19fc0ef          	jal	ra,80000c02 <release>
}
    800040ee:	60e2                	ld	ra,24(sp)
    800040f0:	6442                	ld	s0,16(sp)
    800040f2:	64a2                	ld	s1,8(sp)
    800040f4:	6902                	ld	s2,0(sp)
    800040f6:	6105                	addi	sp,sp,32
    800040f8:	8082                	ret

00000000800040fa <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800040fa:	7179                	addi	sp,sp,-48
    800040fc:	f406                	sd	ra,40(sp)
    800040fe:	f022                	sd	s0,32(sp)
    80004100:	ec26                	sd	s1,24(sp)
    80004102:	e84a                	sd	s2,16(sp)
    80004104:	e44e                	sd	s3,8(sp)
    80004106:	1800                	addi	s0,sp,48
    80004108:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000410a:	00850913          	addi	s2,a0,8
    8000410e:	854a                	mv	a0,s2
    80004110:	a5bfc0ef          	jal	ra,80000b6a <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80004114:	409c                	lw	a5,0(s1)
    80004116:	ef89                	bnez	a5,80004130 <holdingsleep+0x36>
    80004118:	4481                	li	s1,0
  release(&lk->lk);
    8000411a:	854a                	mv	a0,s2
    8000411c:	ae7fc0ef          	jal	ra,80000c02 <release>
  return r;
}
    80004120:	8526                	mv	a0,s1
    80004122:	70a2                	ld	ra,40(sp)
    80004124:	7402                	ld	s0,32(sp)
    80004126:	64e2                	ld	s1,24(sp)
    80004128:	6942                	ld	s2,16(sp)
    8000412a:	69a2                	ld	s3,8(sp)
    8000412c:	6145                	addi	sp,sp,48
    8000412e:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80004130:	0284a983          	lw	s3,40(s1)
    80004134:	f92fd0ef          	jal	ra,800018c6 <myproc>
    80004138:	5904                	lw	s1,48(a0)
    8000413a:	413484b3          	sub	s1,s1,s3
    8000413e:	0014b493          	seqz	s1,s1
    80004142:	bfe1                	j	8000411a <holdingsleep+0x20>

0000000080004144 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004144:	1141                	addi	sp,sp,-16
    80004146:	e406                	sd	ra,8(sp)
    80004148:	e022                	sd	s0,0(sp)
    8000414a:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000414c:	00003597          	auipc	a1,0x3
    80004150:	66458593          	addi	a1,a1,1636 # 800077b0 <syscalls+0x280>
    80004154:	0001d517          	auipc	a0,0x1d
    80004158:	a9c50513          	addi	a0,a0,-1380 # 80020bf0 <ftable>
    8000415c:	98ffc0ef          	jal	ra,80000aea <initlock>
}
    80004160:	60a2                	ld	ra,8(sp)
    80004162:	6402                	ld	s0,0(sp)
    80004164:	0141                	addi	sp,sp,16
    80004166:	8082                	ret

0000000080004168 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80004168:	1101                	addi	sp,sp,-32
    8000416a:	ec06                	sd	ra,24(sp)
    8000416c:	e822                	sd	s0,16(sp)
    8000416e:	e426                	sd	s1,8(sp)
    80004170:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004172:	0001d517          	auipc	a0,0x1d
    80004176:	a7e50513          	addi	a0,a0,-1410 # 80020bf0 <ftable>
    8000417a:	9f1fc0ef          	jal	ra,80000b6a <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000417e:	0001d497          	auipc	s1,0x1d
    80004182:	a8a48493          	addi	s1,s1,-1398 # 80020c08 <ftable+0x18>
    80004186:	0001e717          	auipc	a4,0x1e
    8000418a:	a2270713          	addi	a4,a4,-1502 # 80021ba8 <disk>
    if(f->ref == 0){
    8000418e:	40dc                	lw	a5,4(s1)
    80004190:	cf89                	beqz	a5,800041aa <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004192:	02848493          	addi	s1,s1,40
    80004196:	fee49ce3          	bne	s1,a4,8000418e <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000419a:	0001d517          	auipc	a0,0x1d
    8000419e:	a5650513          	addi	a0,a0,-1450 # 80020bf0 <ftable>
    800041a2:	a61fc0ef          	jal	ra,80000c02 <release>
  return 0;
    800041a6:	4481                	li	s1,0
    800041a8:	a809                	j	800041ba <filealloc+0x52>
      f->ref = 1;
    800041aa:	4785                	li	a5,1
    800041ac:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800041ae:	0001d517          	auipc	a0,0x1d
    800041b2:	a4250513          	addi	a0,a0,-1470 # 80020bf0 <ftable>
    800041b6:	a4dfc0ef          	jal	ra,80000c02 <release>
}
    800041ba:	8526                	mv	a0,s1
    800041bc:	60e2                	ld	ra,24(sp)
    800041be:	6442                	ld	s0,16(sp)
    800041c0:	64a2                	ld	s1,8(sp)
    800041c2:	6105                	addi	sp,sp,32
    800041c4:	8082                	ret

00000000800041c6 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800041c6:	1101                	addi	sp,sp,-32
    800041c8:	ec06                	sd	ra,24(sp)
    800041ca:	e822                	sd	s0,16(sp)
    800041cc:	e426                	sd	s1,8(sp)
    800041ce:	1000                	addi	s0,sp,32
    800041d0:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800041d2:	0001d517          	auipc	a0,0x1d
    800041d6:	a1e50513          	addi	a0,a0,-1506 # 80020bf0 <ftable>
    800041da:	991fc0ef          	jal	ra,80000b6a <acquire>
  if(f->ref < 1)
    800041de:	40dc                	lw	a5,4(s1)
    800041e0:	02f05063          	blez	a5,80004200 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    800041e4:	2785                	addiw	a5,a5,1
    800041e6:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800041e8:	0001d517          	auipc	a0,0x1d
    800041ec:	a0850513          	addi	a0,a0,-1528 # 80020bf0 <ftable>
    800041f0:	a13fc0ef          	jal	ra,80000c02 <release>
  return f;
}
    800041f4:	8526                	mv	a0,s1
    800041f6:	60e2                	ld	ra,24(sp)
    800041f8:	6442                	ld	s0,16(sp)
    800041fa:	64a2                	ld	s1,8(sp)
    800041fc:	6105                	addi	sp,sp,32
    800041fe:	8082                	ret
    panic("filedup");
    80004200:	00003517          	auipc	a0,0x3
    80004204:	5b850513          	addi	a0,a0,1464 # 800077b8 <syscalls+0x288>
    80004208:	d80fc0ef          	jal	ra,80000788 <panic>

000000008000420c <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000420c:	7139                	addi	sp,sp,-64
    8000420e:	fc06                	sd	ra,56(sp)
    80004210:	f822                	sd	s0,48(sp)
    80004212:	f426                	sd	s1,40(sp)
    80004214:	f04a                	sd	s2,32(sp)
    80004216:	ec4e                	sd	s3,24(sp)
    80004218:	e852                	sd	s4,16(sp)
    8000421a:	e456                	sd	s5,8(sp)
    8000421c:	0080                	addi	s0,sp,64
    8000421e:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004220:	0001d517          	auipc	a0,0x1d
    80004224:	9d050513          	addi	a0,a0,-1584 # 80020bf0 <ftable>
    80004228:	943fc0ef          	jal	ra,80000b6a <acquire>
  if(f->ref < 1)
    8000422c:	40dc                	lw	a5,4(s1)
    8000422e:	04f05963          	blez	a5,80004280 <fileclose+0x74>
    panic("fileclose");
  if(--f->ref > 0){
    80004232:	37fd                	addiw	a5,a5,-1
    80004234:	0007871b          	sext.w	a4,a5
    80004238:	c0dc                	sw	a5,4(s1)
    8000423a:	04e04963          	bgtz	a4,8000428c <fileclose+0x80>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000423e:	0004a903          	lw	s2,0(s1)
    80004242:	0094ca83          	lbu	s5,9(s1)
    80004246:	0104ba03          	ld	s4,16(s1)
    8000424a:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000424e:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004252:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004256:	0001d517          	auipc	a0,0x1d
    8000425a:	99a50513          	addi	a0,a0,-1638 # 80020bf0 <ftable>
    8000425e:	9a5fc0ef          	jal	ra,80000c02 <release>

  if(ff.type == FD_PIPE){
    80004262:	4785                	li	a5,1
    80004264:	04f90363          	beq	s2,a5,800042aa <fileclose+0x9e>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004268:	3979                	addiw	s2,s2,-2
    8000426a:	4785                	li	a5,1
    8000426c:	0327e663          	bltu	a5,s2,80004298 <fileclose+0x8c>
    begin_op();
    80004270:	b93ff0ef          	jal	ra,80003e02 <begin_op>
    iput(ff.ip);
    80004274:	854e                	mv	a0,s3
    80004276:	b22ff0ef          	jal	ra,80003598 <iput>
    end_op();
    8000427a:	bf7ff0ef          	jal	ra,80003e70 <end_op>
    8000427e:	a829                	j	80004298 <fileclose+0x8c>
    panic("fileclose");
    80004280:	00003517          	auipc	a0,0x3
    80004284:	54050513          	addi	a0,a0,1344 # 800077c0 <syscalls+0x290>
    80004288:	d00fc0ef          	jal	ra,80000788 <panic>
    release(&ftable.lock);
    8000428c:	0001d517          	auipc	a0,0x1d
    80004290:	96450513          	addi	a0,a0,-1692 # 80020bf0 <ftable>
    80004294:	96ffc0ef          	jal	ra,80000c02 <release>
  }
}
    80004298:	70e2                	ld	ra,56(sp)
    8000429a:	7442                	ld	s0,48(sp)
    8000429c:	74a2                	ld	s1,40(sp)
    8000429e:	7902                	ld	s2,32(sp)
    800042a0:	69e2                	ld	s3,24(sp)
    800042a2:	6a42                	ld	s4,16(sp)
    800042a4:	6aa2                	ld	s5,8(sp)
    800042a6:	6121                	addi	sp,sp,64
    800042a8:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800042aa:	85d6                	mv	a1,s5
    800042ac:	8552                	mv	a0,s4
    800042ae:	2ec000ef          	jal	ra,8000459a <pipeclose>
    800042b2:	b7dd                	j	80004298 <fileclose+0x8c>

00000000800042b4 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800042b4:	715d                	addi	sp,sp,-80
    800042b6:	e486                	sd	ra,72(sp)
    800042b8:	e0a2                	sd	s0,64(sp)
    800042ba:	fc26                	sd	s1,56(sp)
    800042bc:	f84a                	sd	s2,48(sp)
    800042be:	f44e                	sd	s3,40(sp)
    800042c0:	0880                	addi	s0,sp,80
    800042c2:	84aa                	mv	s1,a0
    800042c4:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800042c6:	e00fd0ef          	jal	ra,800018c6 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800042ca:	409c                	lw	a5,0(s1)
    800042cc:	37f9                	addiw	a5,a5,-2
    800042ce:	4705                	li	a4,1
    800042d0:	02f76f63          	bltu	a4,a5,8000430e <filestat+0x5a>
    800042d4:	892a                	mv	s2,a0
    ilock(f->ip);
    800042d6:	6c88                	ld	a0,24(s1)
    800042d8:	942ff0ef          	jal	ra,8000341a <ilock>
    stati(f->ip, &st);
    800042dc:	fb840593          	addi	a1,s0,-72
    800042e0:	6c88                	ld	a0,24(s1)
    800042e2:	c9aff0ef          	jal	ra,8000377c <stati>
    iunlock(f->ip);
    800042e6:	6c88                	ld	a0,24(s1)
    800042e8:	9dcff0ef          	jal	ra,800034c4 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800042ec:	46e1                	li	a3,24
    800042ee:	fb840613          	addi	a2,s0,-72
    800042f2:	85ce                	mv	a1,s3
    800042f4:	05093503          	ld	a0,80(s2)
    800042f8:	a58fd0ef          	jal	ra,80001550 <copyout>
    800042fc:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    80004300:	60a6                	ld	ra,72(sp)
    80004302:	6406                	ld	s0,64(sp)
    80004304:	74e2                	ld	s1,56(sp)
    80004306:	7942                	ld	s2,48(sp)
    80004308:	79a2                	ld	s3,40(sp)
    8000430a:	6161                	addi	sp,sp,80
    8000430c:	8082                	ret
  return -1;
    8000430e:	557d                	li	a0,-1
    80004310:	bfc5                	j	80004300 <filestat+0x4c>

0000000080004312 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004312:	7179                	addi	sp,sp,-48
    80004314:	f406                	sd	ra,40(sp)
    80004316:	f022                	sd	s0,32(sp)
    80004318:	ec26                	sd	s1,24(sp)
    8000431a:	e84a                	sd	s2,16(sp)
    8000431c:	e44e                	sd	s3,8(sp)
    8000431e:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004320:	00854783          	lbu	a5,8(a0)
    80004324:	cbc1                	beqz	a5,800043b4 <fileread+0xa2>
    80004326:	84aa                	mv	s1,a0
    80004328:	89ae                	mv	s3,a1
    8000432a:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    8000432c:	411c                	lw	a5,0(a0)
    8000432e:	4705                	li	a4,1
    80004330:	04e78363          	beq	a5,a4,80004376 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004334:	470d                	li	a4,3
    80004336:	04e78563          	beq	a5,a4,80004380 <fileread+0x6e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    8000433a:	4709                	li	a4,2
    8000433c:	06e79663          	bne	a5,a4,800043a8 <fileread+0x96>
    ilock(f->ip);
    80004340:	6d08                	ld	a0,24(a0)
    80004342:	8d8ff0ef          	jal	ra,8000341a <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004346:	874a                	mv	a4,s2
    80004348:	5094                	lw	a3,32(s1)
    8000434a:	864e                	mv	a2,s3
    8000434c:	4585                	li	a1,1
    8000434e:	6c88                	ld	a0,24(s1)
    80004350:	c56ff0ef          	jal	ra,800037a6 <readi>
    80004354:	892a                	mv	s2,a0
    80004356:	00a05563          	blez	a0,80004360 <fileread+0x4e>
      f->off += r;
    8000435a:	509c                	lw	a5,32(s1)
    8000435c:	9fa9                	addw	a5,a5,a0
    8000435e:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004360:	6c88                	ld	a0,24(s1)
    80004362:	962ff0ef          	jal	ra,800034c4 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    80004366:	854a                	mv	a0,s2
    80004368:	70a2                	ld	ra,40(sp)
    8000436a:	7402                	ld	s0,32(sp)
    8000436c:	64e2                	ld	s1,24(sp)
    8000436e:	6942                	ld	s2,16(sp)
    80004370:	69a2                	ld	s3,8(sp)
    80004372:	6145                	addi	sp,sp,48
    80004374:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004376:	6908                	ld	a0,16(a0)
    80004378:	34e000ef          	jal	ra,800046c6 <piperead>
    8000437c:	892a                	mv	s2,a0
    8000437e:	b7e5                	j	80004366 <fileread+0x54>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004380:	02451783          	lh	a5,36(a0)
    80004384:	03079693          	slli	a3,a5,0x30
    80004388:	92c1                	srli	a3,a3,0x30
    8000438a:	4725                	li	a4,9
    8000438c:	02d76663          	bltu	a4,a3,800043b8 <fileread+0xa6>
    80004390:	0792                	slli	a5,a5,0x4
    80004392:	0001c717          	auipc	a4,0x1c
    80004396:	7be70713          	addi	a4,a4,1982 # 80020b50 <devsw>
    8000439a:	97ba                	add	a5,a5,a4
    8000439c:	639c                	ld	a5,0(a5)
    8000439e:	cf99                	beqz	a5,800043bc <fileread+0xaa>
    r = devsw[f->major].read(1, addr, n);
    800043a0:	4505                	li	a0,1
    800043a2:	9782                	jalr	a5
    800043a4:	892a                	mv	s2,a0
    800043a6:	b7c1                	j	80004366 <fileread+0x54>
    panic("fileread");
    800043a8:	00003517          	auipc	a0,0x3
    800043ac:	42850513          	addi	a0,a0,1064 # 800077d0 <syscalls+0x2a0>
    800043b0:	bd8fc0ef          	jal	ra,80000788 <panic>
    return -1;
    800043b4:	597d                	li	s2,-1
    800043b6:	bf45                	j	80004366 <fileread+0x54>
      return -1;
    800043b8:	597d                	li	s2,-1
    800043ba:	b775                	j	80004366 <fileread+0x54>
    800043bc:	597d                	li	s2,-1
    800043be:	b765                	j	80004366 <fileread+0x54>

00000000800043c0 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800043c0:	715d                	addi	sp,sp,-80
    800043c2:	e486                	sd	ra,72(sp)
    800043c4:	e0a2                	sd	s0,64(sp)
    800043c6:	fc26                	sd	s1,56(sp)
    800043c8:	f84a                	sd	s2,48(sp)
    800043ca:	f44e                	sd	s3,40(sp)
    800043cc:	f052                	sd	s4,32(sp)
    800043ce:	ec56                	sd	s5,24(sp)
    800043d0:	e85a                	sd	s6,16(sp)
    800043d2:	e45e                	sd	s7,8(sp)
    800043d4:	e062                	sd	s8,0(sp)
    800043d6:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800043d8:	00954783          	lbu	a5,9(a0)
    800043dc:	0e078863          	beqz	a5,800044cc <filewrite+0x10c>
    800043e0:	892a                	mv	s2,a0
    800043e2:	8b2e                	mv	s6,a1
    800043e4:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800043e6:	411c                	lw	a5,0(a0)
    800043e8:	4705                	li	a4,1
    800043ea:	02e78263          	beq	a5,a4,8000440e <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800043ee:	470d                	li	a4,3
    800043f0:	02e78463          	beq	a5,a4,80004418 <filewrite+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800043f4:	4709                	li	a4,2
    800043f6:	0ce79563          	bne	a5,a4,800044c0 <filewrite+0x100>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800043fa:	0ac05163          	blez	a2,8000449c <filewrite+0xdc>
    int i = 0;
    800043fe:	4981                	li	s3,0
    80004400:	6b85                	lui	s7,0x1
    80004402:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004406:	6c05                	lui	s8,0x1
    80004408:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    8000440c:	a041                	j	8000448c <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    8000440e:	6908                	ld	a0,16(a0)
    80004410:	1e2000ef          	jal	ra,800045f2 <pipewrite>
    80004414:	8a2a                	mv	s4,a0
    80004416:	a071                	j	800044a2 <filewrite+0xe2>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004418:	02451783          	lh	a5,36(a0)
    8000441c:	03079693          	slli	a3,a5,0x30
    80004420:	92c1                	srli	a3,a3,0x30
    80004422:	4725                	li	a4,9
    80004424:	0ad76663          	bltu	a4,a3,800044d0 <filewrite+0x110>
    80004428:	0792                	slli	a5,a5,0x4
    8000442a:	0001c717          	auipc	a4,0x1c
    8000442e:	72670713          	addi	a4,a4,1830 # 80020b50 <devsw>
    80004432:	97ba                	add	a5,a5,a4
    80004434:	679c                	ld	a5,8(a5)
    80004436:	cfd9                	beqz	a5,800044d4 <filewrite+0x114>
    ret = devsw[f->major].write(1, addr, n);
    80004438:	4505                	li	a0,1
    8000443a:	9782                	jalr	a5
    8000443c:	8a2a                	mv	s4,a0
    8000443e:	a095                	j	800044a2 <filewrite+0xe2>
    80004440:	00048a9b          	sext.w	s5,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    80004444:	9bfff0ef          	jal	ra,80003e02 <begin_op>
      ilock(f->ip);
    80004448:	01893503          	ld	a0,24(s2)
    8000444c:	fcffe0ef          	jal	ra,8000341a <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004450:	8756                	mv	a4,s5
    80004452:	02092683          	lw	a3,32(s2)
    80004456:	01698633          	add	a2,s3,s6
    8000445a:	4585                	li	a1,1
    8000445c:	01893503          	ld	a0,24(s2)
    80004460:	c2aff0ef          	jal	ra,8000388a <writei>
    80004464:	84aa                	mv	s1,a0
    80004466:	00a05763          	blez	a0,80004474 <filewrite+0xb4>
        f->off += r;
    8000446a:	02092783          	lw	a5,32(s2)
    8000446e:	9fa9                	addw	a5,a5,a0
    80004470:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004474:	01893503          	ld	a0,24(s2)
    80004478:	84cff0ef          	jal	ra,800034c4 <iunlock>
      end_op();
    8000447c:	9f5ff0ef          	jal	ra,80003e70 <end_op>

      if(r != n1){
    80004480:	009a9f63          	bne	s5,s1,8000449e <filewrite+0xde>
        // error from writei
        break;
      }
      i += r;
    80004484:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80004488:	0149db63          	bge	s3,s4,8000449e <filewrite+0xde>
      int n1 = n - i;
    8000448c:	413a04bb          	subw	s1,s4,s3
    80004490:	0004879b          	sext.w	a5,s1
    80004494:	fafbd6e3          	bge	s7,a5,80004440 <filewrite+0x80>
    80004498:	84e2                	mv	s1,s8
    8000449a:	b75d                	j	80004440 <filewrite+0x80>
    int i = 0;
    8000449c:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    8000449e:	013a1f63          	bne	s4,s3,800044bc <filewrite+0xfc>
  } else {
    panic("filewrite");
  }

  return ret;
}
    800044a2:	8552                	mv	a0,s4
    800044a4:	60a6                	ld	ra,72(sp)
    800044a6:	6406                	ld	s0,64(sp)
    800044a8:	74e2                	ld	s1,56(sp)
    800044aa:	7942                	ld	s2,48(sp)
    800044ac:	79a2                	ld	s3,40(sp)
    800044ae:	7a02                	ld	s4,32(sp)
    800044b0:	6ae2                	ld	s5,24(sp)
    800044b2:	6b42                	ld	s6,16(sp)
    800044b4:	6ba2                	ld	s7,8(sp)
    800044b6:	6c02                	ld	s8,0(sp)
    800044b8:	6161                	addi	sp,sp,80
    800044ba:	8082                	ret
    ret = (i == n ? n : -1);
    800044bc:	5a7d                	li	s4,-1
    800044be:	b7d5                	j	800044a2 <filewrite+0xe2>
    panic("filewrite");
    800044c0:	00003517          	auipc	a0,0x3
    800044c4:	32050513          	addi	a0,a0,800 # 800077e0 <syscalls+0x2b0>
    800044c8:	ac0fc0ef          	jal	ra,80000788 <panic>
    return -1;
    800044cc:	5a7d                	li	s4,-1
    800044ce:	bfd1                	j	800044a2 <filewrite+0xe2>
      return -1;
    800044d0:	5a7d                	li	s4,-1
    800044d2:	bfc1                	j	800044a2 <filewrite+0xe2>
    800044d4:	5a7d                	li	s4,-1
    800044d6:	b7f1                	j	800044a2 <filewrite+0xe2>

00000000800044d8 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800044d8:	7179                	addi	sp,sp,-48
    800044da:	f406                	sd	ra,40(sp)
    800044dc:	f022                	sd	s0,32(sp)
    800044de:	ec26                	sd	s1,24(sp)
    800044e0:	e84a                	sd	s2,16(sp)
    800044e2:	e44e                	sd	s3,8(sp)
    800044e4:	e052                	sd	s4,0(sp)
    800044e6:	1800                	addi	s0,sp,48
    800044e8:	84aa                	mv	s1,a0
    800044ea:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800044ec:	0005b023          	sd	zero,0(a1)
    800044f0:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800044f4:	c75ff0ef          	jal	ra,80004168 <filealloc>
    800044f8:	e088                	sd	a0,0(s1)
    800044fa:	cd35                	beqz	a0,80004576 <pipealloc+0x9e>
    800044fc:	c6dff0ef          	jal	ra,80004168 <filealloc>
    80004500:	00aa3023          	sd	a0,0(s4)
    80004504:	c52d                	beqz	a0,8000456e <pipealloc+0x96>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004506:	d94fc0ef          	jal	ra,80000a9a <kalloc>
    8000450a:	892a                	mv	s2,a0
    8000450c:	cd31                	beqz	a0,80004568 <pipealloc+0x90>
    goto bad;
  pi->readopen = 1;
    8000450e:	4985                	li	s3,1
    80004510:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004514:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004518:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000451c:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004520:	00003597          	auipc	a1,0x3
    80004524:	2d058593          	addi	a1,a1,720 # 800077f0 <syscalls+0x2c0>
    80004528:	dc2fc0ef          	jal	ra,80000aea <initlock>
  (*f0)->type = FD_PIPE;
    8000452c:	609c                	ld	a5,0(s1)
    8000452e:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004532:	609c                	ld	a5,0(s1)
    80004534:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004538:	609c                	ld	a5,0(s1)
    8000453a:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000453e:	609c                	ld	a5,0(s1)
    80004540:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004544:	000a3783          	ld	a5,0(s4)
    80004548:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000454c:	000a3783          	ld	a5,0(s4)
    80004550:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004554:	000a3783          	ld	a5,0(s4)
    80004558:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000455c:	000a3783          	ld	a5,0(s4)
    80004560:	0127b823          	sd	s2,16(a5)
  return 0;
    80004564:	4501                	li	a0,0
    80004566:	a005                	j	80004586 <pipealloc+0xae>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004568:	6088                	ld	a0,0(s1)
    8000456a:	e501                	bnez	a0,80004572 <pipealloc+0x9a>
    8000456c:	a029                	j	80004576 <pipealloc+0x9e>
    8000456e:	6088                	ld	a0,0(s1)
    80004570:	c11d                	beqz	a0,80004596 <pipealloc+0xbe>
    fileclose(*f0);
    80004572:	c9bff0ef          	jal	ra,8000420c <fileclose>
  if(*f1)
    80004576:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    8000457a:	557d                	li	a0,-1
  if(*f1)
    8000457c:	c789                	beqz	a5,80004586 <pipealloc+0xae>
    fileclose(*f1);
    8000457e:	853e                	mv	a0,a5
    80004580:	c8dff0ef          	jal	ra,8000420c <fileclose>
  return -1;
    80004584:	557d                	li	a0,-1
}
    80004586:	70a2                	ld	ra,40(sp)
    80004588:	7402                	ld	s0,32(sp)
    8000458a:	64e2                	ld	s1,24(sp)
    8000458c:	6942                	ld	s2,16(sp)
    8000458e:	69a2                	ld	s3,8(sp)
    80004590:	6a02                	ld	s4,0(sp)
    80004592:	6145                	addi	sp,sp,48
    80004594:	8082                	ret
  return -1;
    80004596:	557d                	li	a0,-1
    80004598:	b7fd                	j	80004586 <pipealloc+0xae>

000000008000459a <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    8000459a:	1101                	addi	sp,sp,-32
    8000459c:	ec06                	sd	ra,24(sp)
    8000459e:	e822                	sd	s0,16(sp)
    800045a0:	e426                	sd	s1,8(sp)
    800045a2:	e04a                	sd	s2,0(sp)
    800045a4:	1000                	addi	s0,sp,32
    800045a6:	84aa                	mv	s1,a0
    800045a8:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800045aa:	dc0fc0ef          	jal	ra,80000b6a <acquire>
  if(writable){
    800045ae:	02090763          	beqz	s2,800045dc <pipeclose+0x42>
    pi->writeopen = 0;
    800045b2:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800045b6:	21848513          	addi	a0,s1,536
    800045ba:	ab1fd0ef          	jal	ra,8000206a <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800045be:	2204b783          	ld	a5,544(s1)
    800045c2:	e785                	bnez	a5,800045ea <pipeclose+0x50>
    release(&pi->lock);
    800045c4:	8526                	mv	a0,s1
    800045c6:	e3cfc0ef          	jal	ra,80000c02 <release>
    kfree((char*)pi);
    800045ca:	8526                	mv	a0,s1
    800045cc:	becfc0ef          	jal	ra,800009b8 <kfree>
  } else
    release(&pi->lock);
}
    800045d0:	60e2                	ld	ra,24(sp)
    800045d2:	6442                	ld	s0,16(sp)
    800045d4:	64a2                	ld	s1,8(sp)
    800045d6:	6902                	ld	s2,0(sp)
    800045d8:	6105                	addi	sp,sp,32
    800045da:	8082                	ret
    pi->readopen = 0;
    800045dc:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800045e0:	21c48513          	addi	a0,s1,540
    800045e4:	a87fd0ef          	jal	ra,8000206a <wakeup>
    800045e8:	bfd9                	j	800045be <pipeclose+0x24>
    release(&pi->lock);
    800045ea:	8526                	mv	a0,s1
    800045ec:	e16fc0ef          	jal	ra,80000c02 <release>
}
    800045f0:	b7c5                	j	800045d0 <pipeclose+0x36>

00000000800045f2 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800045f2:	711d                	addi	sp,sp,-96
    800045f4:	ec86                	sd	ra,88(sp)
    800045f6:	e8a2                	sd	s0,80(sp)
    800045f8:	e4a6                	sd	s1,72(sp)
    800045fa:	e0ca                	sd	s2,64(sp)
    800045fc:	fc4e                	sd	s3,56(sp)
    800045fe:	f852                	sd	s4,48(sp)
    80004600:	f456                	sd	s5,40(sp)
    80004602:	f05a                	sd	s6,32(sp)
    80004604:	ec5e                	sd	s7,24(sp)
    80004606:	e862                	sd	s8,16(sp)
    80004608:	1080                	addi	s0,sp,96
    8000460a:	84aa                	mv	s1,a0
    8000460c:	8aae                	mv	s5,a1
    8000460e:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004610:	ab6fd0ef          	jal	ra,800018c6 <myproc>
    80004614:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004616:	8526                	mv	a0,s1
    80004618:	d52fc0ef          	jal	ra,80000b6a <acquire>
  while(i < n){
    8000461c:	09405c63          	blez	s4,800046b4 <pipewrite+0xc2>
  int i = 0;
    80004620:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004622:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004624:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004628:	21c48b93          	addi	s7,s1,540
    8000462c:	a81d                	j	80004662 <pipewrite+0x70>
      release(&pi->lock);
    8000462e:	8526                	mv	a0,s1
    80004630:	dd2fc0ef          	jal	ra,80000c02 <release>
      return -1;
    80004634:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004636:	854a                	mv	a0,s2
    80004638:	60e6                	ld	ra,88(sp)
    8000463a:	6446                	ld	s0,80(sp)
    8000463c:	64a6                	ld	s1,72(sp)
    8000463e:	6906                	ld	s2,64(sp)
    80004640:	79e2                	ld	s3,56(sp)
    80004642:	7a42                	ld	s4,48(sp)
    80004644:	7aa2                	ld	s5,40(sp)
    80004646:	7b02                	ld	s6,32(sp)
    80004648:	6be2                	ld	s7,24(sp)
    8000464a:	6c42                	ld	s8,16(sp)
    8000464c:	6125                	addi	sp,sp,96
    8000464e:	8082                	ret
      wakeup(&pi->nread);
    80004650:	8562                	mv	a0,s8
    80004652:	a19fd0ef          	jal	ra,8000206a <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004656:	85a6                	mv	a1,s1
    80004658:	855e                	mv	a0,s7
    8000465a:	9c5fd0ef          	jal	ra,8000201e <sleep>
  while(i < n){
    8000465e:	05495c63          	bge	s2,s4,800046b6 <pipewrite+0xc4>
    if(pi->readopen == 0 || killed(pr)){
    80004662:	2204a783          	lw	a5,544(s1)
    80004666:	d7e1                	beqz	a5,8000462e <pipewrite+0x3c>
    80004668:	854e                	mv	a0,s3
    8000466a:	bf9fd0ef          	jal	ra,80002262 <killed>
    8000466e:	f161                	bnez	a0,8000462e <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004670:	2184a783          	lw	a5,536(s1)
    80004674:	21c4a703          	lw	a4,540(s1)
    80004678:	2007879b          	addiw	a5,a5,512
    8000467c:	fcf70ae3          	beq	a4,a5,80004650 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004680:	4685                	li	a3,1
    80004682:	01590633          	add	a2,s2,s5
    80004686:	faf40593          	addi	a1,s0,-81
    8000468a:	0509b503          	ld	a0,80(s3)
    8000468e:	f89fc0ef          	jal	ra,80001616 <copyin>
    80004692:	03650263          	beq	a0,s6,800046b6 <pipewrite+0xc4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004696:	21c4a783          	lw	a5,540(s1)
    8000469a:	0017871b          	addiw	a4,a5,1
    8000469e:	20e4ae23          	sw	a4,540(s1)
    800046a2:	1ff7f793          	andi	a5,a5,511
    800046a6:	97a6                	add	a5,a5,s1
    800046a8:	faf44703          	lbu	a4,-81(s0)
    800046ac:	00e78c23          	sb	a4,24(a5)
      i++;
    800046b0:	2905                	addiw	s2,s2,1
    800046b2:	b775                	j	8000465e <pipewrite+0x6c>
  int i = 0;
    800046b4:	4901                	li	s2,0
  wakeup(&pi->nread);
    800046b6:	21848513          	addi	a0,s1,536
    800046ba:	9b1fd0ef          	jal	ra,8000206a <wakeup>
  release(&pi->lock);
    800046be:	8526                	mv	a0,s1
    800046c0:	d42fc0ef          	jal	ra,80000c02 <release>
  return i;
    800046c4:	bf8d                	j	80004636 <pipewrite+0x44>

00000000800046c6 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800046c6:	715d                	addi	sp,sp,-80
    800046c8:	e486                	sd	ra,72(sp)
    800046ca:	e0a2                	sd	s0,64(sp)
    800046cc:	fc26                	sd	s1,56(sp)
    800046ce:	f84a                	sd	s2,48(sp)
    800046d0:	f44e                	sd	s3,40(sp)
    800046d2:	f052                	sd	s4,32(sp)
    800046d4:	ec56                	sd	s5,24(sp)
    800046d6:	e85a                	sd	s6,16(sp)
    800046d8:	0880                	addi	s0,sp,80
    800046da:	84aa                	mv	s1,a0
    800046dc:	892e                	mv	s2,a1
    800046de:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800046e0:	9e6fd0ef          	jal	ra,800018c6 <myproc>
    800046e4:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800046e6:	8526                	mv	a0,s1
    800046e8:	c82fc0ef          	jal	ra,80000b6a <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800046ec:	2184a703          	lw	a4,536(s1)
    800046f0:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800046f4:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800046f8:	02f71363          	bne	a4,a5,8000471e <piperead+0x58>
    800046fc:	2244a783          	lw	a5,548(s1)
    80004700:	cf99                	beqz	a5,8000471e <piperead+0x58>
    if(killed(pr)){
    80004702:	8552                	mv	a0,s4
    80004704:	b5ffd0ef          	jal	ra,80002262 <killed>
    80004708:	e151                	bnez	a0,8000478c <piperead+0xc6>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000470a:	85a6                	mv	a1,s1
    8000470c:	854e                	mv	a0,s3
    8000470e:	911fd0ef          	jal	ra,8000201e <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004712:	2184a703          	lw	a4,536(s1)
    80004716:	21c4a783          	lw	a5,540(s1)
    8000471a:	fef701e3          	beq	a4,a5,800046fc <piperead+0x36>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000471e:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004720:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004722:	05505363          	blez	s5,80004768 <piperead+0xa2>
    if(pi->nread == pi->nwrite)
    80004726:	2184a783          	lw	a5,536(s1)
    8000472a:	21c4a703          	lw	a4,540(s1)
    8000472e:	02f70d63          	beq	a4,a5,80004768 <piperead+0xa2>
    ch = pi->data[pi->nread % PIPESIZE];
    80004732:	1ff7f793          	andi	a5,a5,511
    80004736:	97a6                	add	a5,a5,s1
    80004738:	0187c783          	lbu	a5,24(a5)
    8000473c:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004740:	4685                	li	a3,1
    80004742:	fbf40613          	addi	a2,s0,-65
    80004746:	85ca                	mv	a1,s2
    80004748:	050a3503          	ld	a0,80(s4)
    8000474c:	e05fc0ef          	jal	ra,80001550 <copyout>
    80004750:	05650363          	beq	a0,s6,80004796 <piperead+0xd0>
      if(i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004754:	2184a783          	lw	a5,536(s1)
    80004758:	2785                	addiw	a5,a5,1
    8000475a:	20f4ac23          	sw	a5,536(s1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000475e:	2985                	addiw	s3,s3,1
    80004760:	0905                	addi	s2,s2,1
    80004762:	fd3a92e3          	bne	s5,s3,80004726 <piperead+0x60>
    80004766:	89d6                	mv	s3,s5
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004768:	21c48513          	addi	a0,s1,540
    8000476c:	8fffd0ef          	jal	ra,8000206a <wakeup>
  release(&pi->lock);
    80004770:	8526                	mv	a0,s1
    80004772:	c90fc0ef          	jal	ra,80000c02 <release>
  return i;
}
    80004776:	854e                	mv	a0,s3
    80004778:	60a6                	ld	ra,72(sp)
    8000477a:	6406                	ld	s0,64(sp)
    8000477c:	74e2                	ld	s1,56(sp)
    8000477e:	7942                	ld	s2,48(sp)
    80004780:	79a2                	ld	s3,40(sp)
    80004782:	7a02                	ld	s4,32(sp)
    80004784:	6ae2                	ld	s5,24(sp)
    80004786:	6b42                	ld	s6,16(sp)
    80004788:	6161                	addi	sp,sp,80
    8000478a:	8082                	ret
      release(&pi->lock);
    8000478c:	8526                	mv	a0,s1
    8000478e:	c74fc0ef          	jal	ra,80000c02 <release>
      return -1;
    80004792:	59fd                	li	s3,-1
    80004794:	b7cd                	j	80004776 <piperead+0xb0>
      if(i == 0)
    80004796:	fc0999e3          	bnez	s3,80004768 <piperead+0xa2>
        i = -1;
    8000479a:	89aa                	mv	s3,a0
    8000479c:	b7f1                	j	80004768 <piperead+0xa2>

000000008000479e <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    8000479e:	1141                	addi	sp,sp,-16
    800047a0:	e422                	sd	s0,8(sp)
    800047a2:	0800                	addi	s0,sp,16
    800047a4:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800047a6:	8905                	andi	a0,a0,1
    800047a8:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    800047aa:	8b89                	andi	a5,a5,2
    800047ac:	c399                	beqz	a5,800047b2 <flags2perm+0x14>
      perm |= PTE_W;
    800047ae:	00456513          	ori	a0,a0,4
    return perm;
}
    800047b2:	6422                	ld	s0,8(sp)
    800047b4:	0141                	addi	sp,sp,16
    800047b6:	8082                	ret

00000000800047b8 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800047b8:	de010113          	addi	sp,sp,-544
    800047bc:	20113c23          	sd	ra,536(sp)
    800047c0:	20813823          	sd	s0,528(sp)
    800047c4:	20913423          	sd	s1,520(sp)
    800047c8:	21213023          	sd	s2,512(sp)
    800047cc:	ffce                	sd	s3,504(sp)
    800047ce:	fbd2                	sd	s4,496(sp)
    800047d0:	f7d6                	sd	s5,488(sp)
    800047d2:	f3da                	sd	s6,480(sp)
    800047d4:	efde                	sd	s7,472(sp)
    800047d6:	ebe2                	sd	s8,464(sp)
    800047d8:	e7e6                	sd	s9,456(sp)
    800047da:	e3ea                	sd	s10,448(sp)
    800047dc:	ff6e                	sd	s11,440(sp)
    800047de:	1400                	addi	s0,sp,544
    800047e0:	892a                	mv	s2,a0
    800047e2:	dea43423          	sd	a0,-536(s0)
    800047e6:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800047ea:	8dcfd0ef          	jal	ra,800018c6 <myproc>
    800047ee:	84aa                	mv	s1,a0

  begin_op();
    800047f0:	e12ff0ef          	jal	ra,80003e02 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    800047f4:	854a                	mv	a0,s2
    800047f6:	c18ff0ef          	jal	ra,80003c0e <namei>
    800047fa:	c13d                	beqz	a0,80004860 <kexec+0xa8>
    800047fc:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800047fe:	c1dfe0ef          	jal	ra,8000341a <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004802:	04000713          	li	a4,64
    80004806:	4681                	li	a3,0
    80004808:	e5040613          	addi	a2,s0,-432
    8000480c:	4581                	li	a1,0
    8000480e:	8556                	mv	a0,s5
    80004810:	f97fe0ef          	jal	ra,800037a6 <readi>
    80004814:	04000793          	li	a5,64
    80004818:	00f51a63          	bne	a0,a5,8000482c <kexec+0x74>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    8000481c:	e5042703          	lw	a4,-432(s0)
    80004820:	464c47b7          	lui	a5,0x464c4
    80004824:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004828:	04f70063          	beq	a4,a5,80004868 <kexec+0xb0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    8000482c:	8556                	mv	a0,s5
    8000482e:	df3fe0ef          	jal	ra,80003620 <iunlockput>
    end_op();
    80004832:	e3eff0ef          	jal	ra,80003e70 <end_op>
  }
  return -1;
    80004836:	557d                	li	a0,-1
}
    80004838:	21813083          	ld	ra,536(sp)
    8000483c:	21013403          	ld	s0,528(sp)
    80004840:	20813483          	ld	s1,520(sp)
    80004844:	20013903          	ld	s2,512(sp)
    80004848:	79fe                	ld	s3,504(sp)
    8000484a:	7a5e                	ld	s4,496(sp)
    8000484c:	7abe                	ld	s5,488(sp)
    8000484e:	7b1e                	ld	s6,480(sp)
    80004850:	6bfe                	ld	s7,472(sp)
    80004852:	6c5e                	ld	s8,464(sp)
    80004854:	6cbe                	ld	s9,456(sp)
    80004856:	6d1e                	ld	s10,448(sp)
    80004858:	7dfa                	ld	s11,440(sp)
    8000485a:	22010113          	addi	sp,sp,544
    8000485e:	8082                	ret
    end_op();
    80004860:	e10ff0ef          	jal	ra,80003e70 <end_op>
    return -1;
    80004864:	557d                	li	a0,-1
    80004866:	bfc9                	j	80004838 <kexec+0x80>
  if((pagetable = proc_pagetable(p)) == 0)
    80004868:	8526                	mv	a0,s1
    8000486a:	962fd0ef          	jal	ra,800019cc <proc_pagetable>
    8000486e:	8b2a                	mv	s6,a0
    80004870:	dd55                	beqz	a0,8000482c <kexec+0x74>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004872:	e7042783          	lw	a5,-400(s0)
    80004876:	e8845703          	lhu	a4,-376(s0)
    8000487a:	c325                	beqz	a4,800048da <kexec+0x122>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000487c:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000487e:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80004882:	6a05                	lui	s4,0x1
    80004884:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80004888:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    8000488c:	6d85                	lui	s11,0x1
    8000488e:	7d7d                	lui	s10,0xfffff
    80004890:	a409                	j	80004a92 <kexec+0x2da>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004892:	00003517          	auipc	a0,0x3
    80004896:	f6650513          	addi	a0,a0,-154 # 800077f8 <syscalls+0x2c8>
    8000489a:	eeffb0ef          	jal	ra,80000788 <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    8000489e:	874a                	mv	a4,s2
    800048a0:	009c86bb          	addw	a3,s9,s1
    800048a4:	4581                	li	a1,0
    800048a6:	8556                	mv	a0,s5
    800048a8:	efffe0ef          	jal	ra,800037a6 <readi>
    800048ac:	2501                	sext.w	a0,a0
    800048ae:	18a91163          	bne	s2,a0,80004a30 <kexec+0x278>
  for(i = 0; i < sz; i += PGSIZE){
    800048b2:	009d84bb          	addw	s1,s11,s1
    800048b6:	013d09bb          	addw	s3,s10,s3
    800048ba:	1b74fc63          	bgeu	s1,s7,80004a72 <kexec+0x2ba>
    pa = walkaddr(pagetable, va + i);
    800048be:	02049593          	slli	a1,s1,0x20
    800048c2:	9181                	srli	a1,a1,0x20
    800048c4:	95e2                	add	a1,a1,s8
    800048c6:	855a                	mv	a0,s6
    800048c8:	e8cfc0ef          	jal	ra,80000f54 <walkaddr>
    800048cc:	862a                	mv	a2,a0
    if(pa == 0)
    800048ce:	d171                	beqz	a0,80004892 <kexec+0xda>
      n = PGSIZE;
    800048d0:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    800048d2:	fd49f6e3          	bgeu	s3,s4,8000489e <kexec+0xe6>
      n = sz - i;
    800048d6:	894e                	mv	s2,s3
    800048d8:	b7d9                	j	8000489e <kexec+0xe6>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800048da:	4901                	li	s2,0
  iunlockput(ip);
    800048dc:	8556                	mv	a0,s5
    800048de:	d43fe0ef          	jal	ra,80003620 <iunlockput>
  end_op();
    800048e2:	d8eff0ef          	jal	ra,80003e70 <end_op>
  p = myproc();
    800048e6:	fe1fc0ef          	jal	ra,800018c6 <myproc>
    800048ea:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    800048ec:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    800048f0:	6785                	lui	a5,0x1
    800048f2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800048f4:	97ca                	add	a5,a5,s2
    800048f6:	777d                	lui	a4,0xfffff
    800048f8:	8ff9                	and	a5,a5,a4
    800048fa:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800048fe:	4691                	li	a3,4
    80004900:	6609                	lui	a2,0x2
    80004902:	963e                	add	a2,a2,a5
    80004904:	85be                	mv	a1,a5
    80004906:	855a                	mv	a0,s6
    80004908:	917fc0ef          	jal	ra,8000121e <uvmalloc>
    8000490c:	8c2a                	mv	s8,a0
  ip = 0;
    8000490e:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004910:	12050063          	beqz	a0,80004a30 <kexec+0x278>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004914:	75f9                	lui	a1,0xffffe
    80004916:	95aa                	add	a1,a1,a0
    80004918:	855a                	mv	a0,s6
    8000491a:	acffc0ef          	jal	ra,800013e8 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    8000491e:	7afd                	lui	s5,0xfffff
    80004920:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80004922:	df043783          	ld	a5,-528(s0)
    80004926:	6388                	ld	a0,0(a5)
    80004928:	c135                	beqz	a0,8000498c <kexec+0x1d4>
    8000492a:	e9040993          	addi	s3,s0,-368
    8000492e:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80004932:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004934:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004936:	c80fc0ef          	jal	ra,80000db6 <strlen>
    8000493a:	0015079b          	addiw	a5,a0,1
    8000493e:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004942:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004946:	11596a63          	bltu	s2,s5,80004a5a <kexec+0x2a2>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    8000494a:	df043d83          	ld	s11,-528(s0)
    8000494e:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80004952:	8552                	mv	a0,s4
    80004954:	c62fc0ef          	jal	ra,80000db6 <strlen>
    80004958:	0015069b          	addiw	a3,a0,1
    8000495c:	8652                	mv	a2,s4
    8000495e:	85ca                	mv	a1,s2
    80004960:	855a                	mv	a0,s6
    80004962:	beffc0ef          	jal	ra,80001550 <copyout>
    80004966:	0e054e63          	bltz	a0,80004a62 <kexec+0x2aa>
    ustack[argc] = sp;
    8000496a:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    8000496e:	0485                	addi	s1,s1,1
    80004970:	008d8793          	addi	a5,s11,8
    80004974:	def43823          	sd	a5,-528(s0)
    80004978:	008db503          	ld	a0,8(s11)
    8000497c:	c911                	beqz	a0,80004990 <kexec+0x1d8>
    if(argc >= MAXARG)
    8000497e:	09a1                	addi	s3,s3,8
    80004980:	fb3c9be3          	bne	s9,s3,80004936 <kexec+0x17e>
  sz = sz1;
    80004984:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004988:	4a81                	li	s5,0
    8000498a:	a05d                	j	80004a30 <kexec+0x278>
  sp = sz;
    8000498c:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    8000498e:	4481                	li	s1,0
  ustack[argc] = 0;
    80004990:	00349793          	slli	a5,s1,0x3
    80004994:	f9078793          	addi	a5,a5,-112
    80004998:	97a2                	add	a5,a5,s0
    8000499a:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    8000499e:	00148693          	addi	a3,s1,1
    800049a2:	068e                	slli	a3,a3,0x3
    800049a4:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    800049a8:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    800049ac:	01597663          	bgeu	s2,s5,800049b8 <kexec+0x200>
  sz = sz1;
    800049b0:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    800049b4:	4a81                	li	s5,0
    800049b6:	a8ad                	j	80004a30 <kexec+0x278>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    800049b8:	e9040613          	addi	a2,s0,-368
    800049bc:	85ca                	mv	a1,s2
    800049be:	855a                	mv	a0,s6
    800049c0:	b91fc0ef          	jal	ra,80001550 <copyout>
    800049c4:	0a054363          	bltz	a0,80004a6a <kexec+0x2b2>
  p->trapframe->a1 = sp;
    800049c8:	058bb783          	ld	a5,88(s7)
    800049cc:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    800049d0:	de843783          	ld	a5,-536(s0)
    800049d4:	0007c703          	lbu	a4,0(a5)
    800049d8:	cf11                	beqz	a4,800049f4 <kexec+0x23c>
    800049da:	0785                	addi	a5,a5,1
    if(*s == '/')
    800049dc:	02f00693          	li	a3,47
    800049e0:	a039                	j	800049ee <kexec+0x236>
      last = s+1;
    800049e2:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    800049e6:	0785                	addi	a5,a5,1
    800049e8:	fff7c703          	lbu	a4,-1(a5)
    800049ec:	c701                	beqz	a4,800049f4 <kexec+0x23c>
    if(*s == '/')
    800049ee:	fed71ce3          	bne	a4,a3,800049e6 <kexec+0x22e>
    800049f2:	bfc5                	j	800049e2 <kexec+0x22a>
  safestrcpy(p->name, last, sizeof(p->name));
    800049f4:	4641                	li	a2,16
    800049f6:	de843583          	ld	a1,-536(s0)
    800049fa:	158b8513          	addi	a0,s7,344
    800049fe:	b86fc0ef          	jal	ra,80000d84 <safestrcpy>
  oldpagetable = p->pagetable;
    80004a02:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    80004a06:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    80004a0a:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004a0e:	058bb783          	ld	a5,88(s7)
    80004a12:	e6843703          	ld	a4,-408(s0)
    80004a16:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004a18:	058bb783          	ld	a5,88(s7)
    80004a1c:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004a20:	85ea                	mv	a1,s10
    80004a22:	82efd0ef          	jal	ra,80001a50 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004a26:	0004851b          	sext.w	a0,s1
    80004a2a:	b539                	j	80004838 <kexec+0x80>
    80004a2c:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004a30:	df843583          	ld	a1,-520(s0)
    80004a34:	855a                	mv	a0,s6
    80004a36:	81afd0ef          	jal	ra,80001a50 <proc_freepagetable>
  if(ip){
    80004a3a:	de0a99e3          	bnez	s5,8000482c <kexec+0x74>
  return -1;
    80004a3e:	557d                	li	a0,-1
    80004a40:	bbe5                	j	80004838 <kexec+0x80>
    80004a42:	df243c23          	sd	s2,-520(s0)
    80004a46:	b7ed                	j	80004a30 <kexec+0x278>
    80004a48:	df243c23          	sd	s2,-520(s0)
    80004a4c:	b7d5                	j	80004a30 <kexec+0x278>
    80004a4e:	df243c23          	sd	s2,-520(s0)
    80004a52:	bff9                	j	80004a30 <kexec+0x278>
    80004a54:	df243c23          	sd	s2,-520(s0)
    80004a58:	bfe1                	j	80004a30 <kexec+0x278>
  sz = sz1;
    80004a5a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004a5e:	4a81                	li	s5,0
    80004a60:	bfc1                	j	80004a30 <kexec+0x278>
  sz = sz1;
    80004a62:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004a66:	4a81                	li	s5,0
    80004a68:	b7e1                	j	80004a30 <kexec+0x278>
  sz = sz1;
    80004a6a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004a6e:	4a81                	li	s5,0
    80004a70:	b7c1                	j	80004a30 <kexec+0x278>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004a72:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004a76:	e0843783          	ld	a5,-504(s0)
    80004a7a:	0017869b          	addiw	a3,a5,1
    80004a7e:	e0d43423          	sd	a3,-504(s0)
    80004a82:	e0043783          	ld	a5,-512(s0)
    80004a86:	0387879b          	addiw	a5,a5,56
    80004a8a:	e8845703          	lhu	a4,-376(s0)
    80004a8e:	e4e6d7e3          	bge	a3,a4,800048dc <kexec+0x124>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004a92:	2781                	sext.w	a5,a5
    80004a94:	e0f43023          	sd	a5,-512(s0)
    80004a98:	03800713          	li	a4,56
    80004a9c:	86be                	mv	a3,a5
    80004a9e:	e1840613          	addi	a2,s0,-488
    80004aa2:	4581                	li	a1,0
    80004aa4:	8556                	mv	a0,s5
    80004aa6:	d01fe0ef          	jal	ra,800037a6 <readi>
    80004aaa:	03800793          	li	a5,56
    80004aae:	f6f51fe3          	bne	a0,a5,80004a2c <kexec+0x274>
    if(ph.type != ELF_PROG_LOAD)
    80004ab2:	e1842783          	lw	a5,-488(s0)
    80004ab6:	4705                	li	a4,1
    80004ab8:	fae79fe3          	bne	a5,a4,80004a76 <kexec+0x2be>
    if(ph.memsz < ph.filesz)
    80004abc:	e4043483          	ld	s1,-448(s0)
    80004ac0:	e3843783          	ld	a5,-456(s0)
    80004ac4:	f6f4efe3          	bltu	s1,a5,80004a42 <kexec+0x28a>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004ac8:	e2843783          	ld	a5,-472(s0)
    80004acc:	94be                	add	s1,s1,a5
    80004ace:	f6f4ede3          	bltu	s1,a5,80004a48 <kexec+0x290>
    if(ph.vaddr % PGSIZE != 0)
    80004ad2:	de043703          	ld	a4,-544(s0)
    80004ad6:	8ff9                	and	a5,a5,a4
    80004ad8:	fbbd                	bnez	a5,80004a4e <kexec+0x296>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004ada:	e1c42503          	lw	a0,-484(s0)
    80004ade:	cc1ff0ef          	jal	ra,8000479e <flags2perm>
    80004ae2:	86aa                	mv	a3,a0
    80004ae4:	8626                	mv	a2,s1
    80004ae6:	85ca                	mv	a1,s2
    80004ae8:	855a                	mv	a0,s6
    80004aea:	f34fc0ef          	jal	ra,8000121e <uvmalloc>
    80004aee:	dea43c23          	sd	a0,-520(s0)
    80004af2:	d12d                	beqz	a0,80004a54 <kexec+0x29c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004af4:	e2843c03          	ld	s8,-472(s0)
    80004af8:	e2042c83          	lw	s9,-480(s0)
    80004afc:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004b00:	f60b89e3          	beqz	s7,80004a72 <kexec+0x2ba>
    80004b04:	89de                	mv	s3,s7
    80004b06:	4481                	li	s1,0
    80004b08:	bb5d                	j	800048be <kexec+0x106>

0000000080004b0a <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004b0a:	7179                	addi	sp,sp,-48
    80004b0c:	f406                	sd	ra,40(sp)
    80004b0e:	f022                	sd	s0,32(sp)
    80004b10:	ec26                	sd	s1,24(sp)
    80004b12:	e84a                	sd	s2,16(sp)
    80004b14:	1800                	addi	s0,sp,48
    80004b16:	892e                	mv	s2,a1
    80004b18:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004b1a:	fdc40593          	addi	a1,s0,-36
    80004b1e:	ee7fd0ef          	jal	ra,80002a04 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004b22:	fdc42703          	lw	a4,-36(s0)
    80004b26:	47bd                	li	a5,15
    80004b28:	02e7e963          	bltu	a5,a4,80004b5a <argfd+0x50>
    80004b2c:	d9bfc0ef          	jal	ra,800018c6 <myproc>
    80004b30:	fdc42703          	lw	a4,-36(s0)
    80004b34:	01a70793          	addi	a5,a4,26 # fffffffffffff01a <end+0xffffffff7ffdd332>
    80004b38:	078e                	slli	a5,a5,0x3
    80004b3a:	953e                	add	a0,a0,a5
    80004b3c:	611c                	ld	a5,0(a0)
    80004b3e:	c385                	beqz	a5,80004b5e <argfd+0x54>
    return -1;
  if(pfd)
    80004b40:	00090463          	beqz	s2,80004b48 <argfd+0x3e>
    *pfd = fd;
    80004b44:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004b48:	4501                	li	a0,0
  if(pf)
    80004b4a:	c091                	beqz	s1,80004b4e <argfd+0x44>
    *pf = f;
    80004b4c:	e09c                	sd	a5,0(s1)
}
    80004b4e:	70a2                	ld	ra,40(sp)
    80004b50:	7402                	ld	s0,32(sp)
    80004b52:	64e2                	ld	s1,24(sp)
    80004b54:	6942                	ld	s2,16(sp)
    80004b56:	6145                	addi	sp,sp,48
    80004b58:	8082                	ret
    return -1;
    80004b5a:	557d                	li	a0,-1
    80004b5c:	bfcd                	j	80004b4e <argfd+0x44>
    80004b5e:	557d                	li	a0,-1
    80004b60:	b7fd                	j	80004b4e <argfd+0x44>

0000000080004b62 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004b62:	1101                	addi	sp,sp,-32
    80004b64:	ec06                	sd	ra,24(sp)
    80004b66:	e822                	sd	s0,16(sp)
    80004b68:	e426                	sd	s1,8(sp)
    80004b6a:	1000                	addi	s0,sp,32
    80004b6c:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004b6e:	d59fc0ef          	jal	ra,800018c6 <myproc>
    80004b72:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004b74:	0d050793          	addi	a5,a0,208
    80004b78:	4501                	li	a0,0
    80004b7a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004b7c:	6398                	ld	a4,0(a5)
    80004b7e:	cb19                	beqz	a4,80004b94 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004b80:	2505                	addiw	a0,a0,1
    80004b82:	07a1                	addi	a5,a5,8
    80004b84:	fed51ce3          	bne	a0,a3,80004b7c <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004b88:	557d                	li	a0,-1
}
    80004b8a:	60e2                	ld	ra,24(sp)
    80004b8c:	6442                	ld	s0,16(sp)
    80004b8e:	64a2                	ld	s1,8(sp)
    80004b90:	6105                	addi	sp,sp,32
    80004b92:	8082                	ret
      p->ofile[fd] = f;
    80004b94:	01a50793          	addi	a5,a0,26
    80004b98:	078e                	slli	a5,a5,0x3
    80004b9a:	963e                	add	a2,a2,a5
    80004b9c:	e204                	sd	s1,0(a2)
      return fd;
    80004b9e:	b7f5                	j	80004b8a <fdalloc+0x28>

0000000080004ba0 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004ba0:	715d                	addi	sp,sp,-80
    80004ba2:	e486                	sd	ra,72(sp)
    80004ba4:	e0a2                	sd	s0,64(sp)
    80004ba6:	fc26                	sd	s1,56(sp)
    80004ba8:	f84a                	sd	s2,48(sp)
    80004baa:	f44e                	sd	s3,40(sp)
    80004bac:	f052                	sd	s4,32(sp)
    80004bae:	ec56                	sd	s5,24(sp)
    80004bb0:	e85a                	sd	s6,16(sp)
    80004bb2:	0880                	addi	s0,sp,80
    80004bb4:	8b2e                	mv	s6,a1
    80004bb6:	89b2                	mv	s3,a2
    80004bb8:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004bba:	fb040593          	addi	a1,s0,-80
    80004bbe:	86aff0ef          	jal	ra,80003c28 <nameiparent>
    80004bc2:	84aa                	mv	s1,a0
    80004bc4:	10050b63          	beqz	a0,80004cda <create+0x13a>
    return 0;

  ilock(dp);
    80004bc8:	853fe0ef          	jal	ra,8000341a <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004bcc:	4601                	li	a2,0
    80004bce:	fb040593          	addi	a1,s0,-80
    80004bd2:	8526                	mv	a0,s1
    80004bd4:	dcffe0ef          	jal	ra,800039a2 <dirlookup>
    80004bd8:	8aaa                	mv	s5,a0
    80004bda:	c521                	beqz	a0,80004c22 <create+0x82>
    iunlockput(dp);
    80004bdc:	8526                	mv	a0,s1
    80004bde:	a43fe0ef          	jal	ra,80003620 <iunlockput>
    ilock(ip);
    80004be2:	8556                	mv	a0,s5
    80004be4:	837fe0ef          	jal	ra,8000341a <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004be8:	000b059b          	sext.w	a1,s6
    80004bec:	4789                	li	a5,2
    80004bee:	02f59563          	bne	a1,a5,80004c18 <create+0x78>
    80004bf2:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffdd35c>
    80004bf6:	37f9                	addiw	a5,a5,-2
    80004bf8:	17c2                	slli	a5,a5,0x30
    80004bfa:	93c1                	srli	a5,a5,0x30
    80004bfc:	4705                	li	a4,1
    80004bfe:	00f76d63          	bltu	a4,a5,80004c18 <create+0x78>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004c02:	8556                	mv	a0,s5
    80004c04:	60a6                	ld	ra,72(sp)
    80004c06:	6406                	ld	s0,64(sp)
    80004c08:	74e2                	ld	s1,56(sp)
    80004c0a:	7942                	ld	s2,48(sp)
    80004c0c:	79a2                	ld	s3,40(sp)
    80004c0e:	7a02                	ld	s4,32(sp)
    80004c10:	6ae2                	ld	s5,24(sp)
    80004c12:	6b42                	ld	s6,16(sp)
    80004c14:	6161                	addi	sp,sp,80
    80004c16:	8082                	ret
    iunlockput(ip);
    80004c18:	8556                	mv	a0,s5
    80004c1a:	a07fe0ef          	jal	ra,80003620 <iunlockput>
    return 0;
    80004c1e:	4a81                	li	s5,0
    80004c20:	b7cd                	j	80004c02 <create+0x62>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004c22:	85da                	mv	a1,s6
    80004c24:	4088                	lw	a0,0(s1)
    80004c26:	e8afe0ef          	jal	ra,800032b0 <ialloc>
    80004c2a:	8a2a                	mv	s4,a0
    80004c2c:	cd1d                	beqz	a0,80004c6a <create+0xca>
  ilock(ip);
    80004c2e:	fecfe0ef          	jal	ra,8000341a <ilock>
  ip->major = major;
    80004c32:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004c36:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004c3a:	4905                	li	s2,1
    80004c3c:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004c40:	8552                	mv	a0,s4
    80004c42:	f24fe0ef          	jal	ra,80003366 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004c46:	000b059b          	sext.w	a1,s6
    80004c4a:	03258563          	beq	a1,s2,80004c74 <create+0xd4>
  if(dirlink(dp, name, ip->inum) < 0)
    80004c4e:	004a2603          	lw	a2,4(s4)
    80004c52:	fb040593          	addi	a1,s0,-80
    80004c56:	8526                	mv	a0,s1
    80004c58:	f1dfe0ef          	jal	ra,80003b74 <dirlink>
    80004c5c:	06054363          	bltz	a0,80004cc2 <create+0x122>
  iunlockput(dp);
    80004c60:	8526                	mv	a0,s1
    80004c62:	9bffe0ef          	jal	ra,80003620 <iunlockput>
  return ip;
    80004c66:	8ad2                	mv	s5,s4
    80004c68:	bf69                	j	80004c02 <create+0x62>
    iunlockput(dp);
    80004c6a:	8526                	mv	a0,s1
    80004c6c:	9b5fe0ef          	jal	ra,80003620 <iunlockput>
    return 0;
    80004c70:	8ad2                	mv	s5,s4
    80004c72:	bf41                	j	80004c02 <create+0x62>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004c74:	004a2603          	lw	a2,4(s4)
    80004c78:	00003597          	auipc	a1,0x3
    80004c7c:	ba058593          	addi	a1,a1,-1120 # 80007818 <syscalls+0x2e8>
    80004c80:	8552                	mv	a0,s4
    80004c82:	ef3fe0ef          	jal	ra,80003b74 <dirlink>
    80004c86:	02054e63          	bltz	a0,80004cc2 <create+0x122>
    80004c8a:	40d0                	lw	a2,4(s1)
    80004c8c:	00003597          	auipc	a1,0x3
    80004c90:	b9458593          	addi	a1,a1,-1132 # 80007820 <syscalls+0x2f0>
    80004c94:	8552                	mv	a0,s4
    80004c96:	edffe0ef          	jal	ra,80003b74 <dirlink>
    80004c9a:	02054463          	bltz	a0,80004cc2 <create+0x122>
  if(dirlink(dp, name, ip->inum) < 0)
    80004c9e:	004a2603          	lw	a2,4(s4)
    80004ca2:	fb040593          	addi	a1,s0,-80
    80004ca6:	8526                	mv	a0,s1
    80004ca8:	ecdfe0ef          	jal	ra,80003b74 <dirlink>
    80004cac:	00054b63          	bltz	a0,80004cc2 <create+0x122>
    dp->nlink++;  // for ".."
    80004cb0:	04a4d783          	lhu	a5,74(s1)
    80004cb4:	2785                	addiw	a5,a5,1
    80004cb6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004cba:	8526                	mv	a0,s1
    80004cbc:	eaafe0ef          	jal	ra,80003366 <iupdate>
    80004cc0:	b745                	j	80004c60 <create+0xc0>
  ip->nlink = 0;
    80004cc2:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004cc6:	8552                	mv	a0,s4
    80004cc8:	e9efe0ef          	jal	ra,80003366 <iupdate>
  iunlockput(ip);
    80004ccc:	8552                	mv	a0,s4
    80004cce:	953fe0ef          	jal	ra,80003620 <iunlockput>
  iunlockput(dp);
    80004cd2:	8526                	mv	a0,s1
    80004cd4:	94dfe0ef          	jal	ra,80003620 <iunlockput>
  return 0;
    80004cd8:	b72d                	j	80004c02 <create+0x62>
    return 0;
    80004cda:	8aaa                	mv	s5,a0
    80004cdc:	b71d                	j	80004c02 <create+0x62>

0000000080004cde <sys_dup>:
{
    80004cde:	7179                	addi	sp,sp,-48
    80004ce0:	f406                	sd	ra,40(sp)
    80004ce2:	f022                	sd	s0,32(sp)
    80004ce4:	ec26                	sd	s1,24(sp)
    80004ce6:	e84a                	sd	s2,16(sp)
    80004ce8:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004cea:	fd840613          	addi	a2,s0,-40
    80004cee:	4581                	li	a1,0
    80004cf0:	4501                	li	a0,0
    80004cf2:	e19ff0ef          	jal	ra,80004b0a <argfd>
    return -1;
    80004cf6:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004cf8:	00054f63          	bltz	a0,80004d16 <sys_dup+0x38>
  if((fd=fdalloc(f)) < 0)
    80004cfc:	fd843903          	ld	s2,-40(s0)
    80004d00:	854a                	mv	a0,s2
    80004d02:	e61ff0ef          	jal	ra,80004b62 <fdalloc>
    80004d06:	84aa                	mv	s1,a0
    return -1;
    80004d08:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004d0a:	00054663          	bltz	a0,80004d16 <sys_dup+0x38>
  filedup(f);
    80004d0e:	854a                	mv	a0,s2
    80004d10:	cb6ff0ef          	jal	ra,800041c6 <filedup>
  return fd;
    80004d14:	87a6                	mv	a5,s1
}
    80004d16:	853e                	mv	a0,a5
    80004d18:	70a2                	ld	ra,40(sp)
    80004d1a:	7402                	ld	s0,32(sp)
    80004d1c:	64e2                	ld	s1,24(sp)
    80004d1e:	6942                	ld	s2,16(sp)
    80004d20:	6145                	addi	sp,sp,48
    80004d22:	8082                	ret

0000000080004d24 <sys_read>:
{
    80004d24:	7179                	addi	sp,sp,-48
    80004d26:	f406                	sd	ra,40(sp)
    80004d28:	f022                	sd	s0,32(sp)
    80004d2a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004d2c:	fd840593          	addi	a1,s0,-40
    80004d30:	4505                	li	a0,1
    80004d32:	ceffd0ef          	jal	ra,80002a20 <argaddr>
  argint(2, &n);
    80004d36:	fe440593          	addi	a1,s0,-28
    80004d3a:	4509                	li	a0,2
    80004d3c:	cc9fd0ef          	jal	ra,80002a04 <argint>
  if(argfd(0, 0, &f) < 0)
    80004d40:	fe840613          	addi	a2,s0,-24
    80004d44:	4581                	li	a1,0
    80004d46:	4501                	li	a0,0
    80004d48:	dc3ff0ef          	jal	ra,80004b0a <argfd>
    80004d4c:	87aa                	mv	a5,a0
    return -1;
    80004d4e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004d50:	0007ca63          	bltz	a5,80004d64 <sys_read+0x40>
  return fileread(f, p, n);
    80004d54:	fe442603          	lw	a2,-28(s0)
    80004d58:	fd843583          	ld	a1,-40(s0)
    80004d5c:	fe843503          	ld	a0,-24(s0)
    80004d60:	db2ff0ef          	jal	ra,80004312 <fileread>
}
    80004d64:	70a2                	ld	ra,40(sp)
    80004d66:	7402                	ld	s0,32(sp)
    80004d68:	6145                	addi	sp,sp,48
    80004d6a:	8082                	ret

0000000080004d6c <sys_write>:
{
    80004d6c:	7179                	addi	sp,sp,-48
    80004d6e:	f406                	sd	ra,40(sp)
    80004d70:	f022                	sd	s0,32(sp)
    80004d72:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004d74:	fd840593          	addi	a1,s0,-40
    80004d78:	4505                	li	a0,1
    80004d7a:	ca7fd0ef          	jal	ra,80002a20 <argaddr>
  argint(2, &n);
    80004d7e:	fe440593          	addi	a1,s0,-28
    80004d82:	4509                	li	a0,2
    80004d84:	c81fd0ef          	jal	ra,80002a04 <argint>
  if(argfd(0, 0, &f) < 0)
    80004d88:	fe840613          	addi	a2,s0,-24
    80004d8c:	4581                	li	a1,0
    80004d8e:	4501                	li	a0,0
    80004d90:	d7bff0ef          	jal	ra,80004b0a <argfd>
    80004d94:	87aa                	mv	a5,a0
    return -1;
    80004d96:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004d98:	0007ca63          	bltz	a5,80004dac <sys_write+0x40>
  return filewrite(f, p, n);
    80004d9c:	fe442603          	lw	a2,-28(s0)
    80004da0:	fd843583          	ld	a1,-40(s0)
    80004da4:	fe843503          	ld	a0,-24(s0)
    80004da8:	e18ff0ef          	jal	ra,800043c0 <filewrite>
}
    80004dac:	70a2                	ld	ra,40(sp)
    80004dae:	7402                	ld	s0,32(sp)
    80004db0:	6145                	addi	sp,sp,48
    80004db2:	8082                	ret

0000000080004db4 <sys_close>:
{
    80004db4:	1101                	addi	sp,sp,-32
    80004db6:	ec06                	sd	ra,24(sp)
    80004db8:	e822                	sd	s0,16(sp)
    80004dba:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004dbc:	fe040613          	addi	a2,s0,-32
    80004dc0:	fec40593          	addi	a1,s0,-20
    80004dc4:	4501                	li	a0,0
    80004dc6:	d45ff0ef          	jal	ra,80004b0a <argfd>
    return -1;
    80004dca:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004dcc:	02054063          	bltz	a0,80004dec <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004dd0:	af7fc0ef          	jal	ra,800018c6 <myproc>
    80004dd4:	fec42783          	lw	a5,-20(s0)
    80004dd8:	07e9                	addi	a5,a5,26
    80004dda:	078e                	slli	a5,a5,0x3
    80004ddc:	953e                	add	a0,a0,a5
    80004dde:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004de2:	fe043503          	ld	a0,-32(s0)
    80004de6:	c26ff0ef          	jal	ra,8000420c <fileclose>
  return 0;
    80004dea:	4781                	li	a5,0
}
    80004dec:	853e                	mv	a0,a5
    80004dee:	60e2                	ld	ra,24(sp)
    80004df0:	6442                	ld	s0,16(sp)
    80004df2:	6105                	addi	sp,sp,32
    80004df4:	8082                	ret

0000000080004df6 <sys_fstat>:
{
    80004df6:	1101                	addi	sp,sp,-32
    80004df8:	ec06                	sd	ra,24(sp)
    80004dfa:	e822                	sd	s0,16(sp)
    80004dfc:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004dfe:	fe040593          	addi	a1,s0,-32
    80004e02:	4505                	li	a0,1
    80004e04:	c1dfd0ef          	jal	ra,80002a20 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004e08:	fe840613          	addi	a2,s0,-24
    80004e0c:	4581                	li	a1,0
    80004e0e:	4501                	li	a0,0
    80004e10:	cfbff0ef          	jal	ra,80004b0a <argfd>
    80004e14:	87aa                	mv	a5,a0
    return -1;
    80004e16:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004e18:	0007c863          	bltz	a5,80004e28 <sys_fstat+0x32>
  return filestat(f, st);
    80004e1c:	fe043583          	ld	a1,-32(s0)
    80004e20:	fe843503          	ld	a0,-24(s0)
    80004e24:	c90ff0ef          	jal	ra,800042b4 <filestat>
}
    80004e28:	60e2                	ld	ra,24(sp)
    80004e2a:	6442                	ld	s0,16(sp)
    80004e2c:	6105                	addi	sp,sp,32
    80004e2e:	8082                	ret

0000000080004e30 <sys_link>:
{
    80004e30:	7169                	addi	sp,sp,-304
    80004e32:	f606                	sd	ra,296(sp)
    80004e34:	f222                	sd	s0,288(sp)
    80004e36:	ee26                	sd	s1,280(sp)
    80004e38:	ea4a                	sd	s2,272(sp)
    80004e3a:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e3c:	08000613          	li	a2,128
    80004e40:	ed040593          	addi	a1,s0,-304
    80004e44:	4501                	li	a0,0
    80004e46:	bf7fd0ef          	jal	ra,80002a3c <argstr>
    return -1;
    80004e4a:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e4c:	0c054663          	bltz	a0,80004f18 <sys_link+0xe8>
    80004e50:	08000613          	li	a2,128
    80004e54:	f5040593          	addi	a1,s0,-176
    80004e58:	4505                	li	a0,1
    80004e5a:	be3fd0ef          	jal	ra,80002a3c <argstr>
    return -1;
    80004e5e:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004e60:	0a054c63          	bltz	a0,80004f18 <sys_link+0xe8>
  begin_op();
    80004e64:	f9ffe0ef          	jal	ra,80003e02 <begin_op>
  if((ip = namei(old)) == 0){
    80004e68:	ed040513          	addi	a0,s0,-304
    80004e6c:	da3fe0ef          	jal	ra,80003c0e <namei>
    80004e70:	84aa                	mv	s1,a0
    80004e72:	c525                	beqz	a0,80004eda <sys_link+0xaa>
  ilock(ip);
    80004e74:	da6fe0ef          	jal	ra,8000341a <ilock>
  if(ip->type == T_DIR){
    80004e78:	04449703          	lh	a4,68(s1)
    80004e7c:	4785                	li	a5,1
    80004e7e:	06f70263          	beq	a4,a5,80004ee2 <sys_link+0xb2>
  ip->nlink++;
    80004e82:	04a4d783          	lhu	a5,74(s1)
    80004e86:	2785                	addiw	a5,a5,1
    80004e88:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004e8c:	8526                	mv	a0,s1
    80004e8e:	cd8fe0ef          	jal	ra,80003366 <iupdate>
  iunlock(ip);
    80004e92:	8526                	mv	a0,s1
    80004e94:	e30fe0ef          	jal	ra,800034c4 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004e98:	fd040593          	addi	a1,s0,-48
    80004e9c:	f5040513          	addi	a0,s0,-176
    80004ea0:	d89fe0ef          	jal	ra,80003c28 <nameiparent>
    80004ea4:	892a                	mv	s2,a0
    80004ea6:	c921                	beqz	a0,80004ef6 <sys_link+0xc6>
  ilock(dp);
    80004ea8:	d72fe0ef          	jal	ra,8000341a <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004eac:	00092703          	lw	a4,0(s2)
    80004eb0:	409c                	lw	a5,0(s1)
    80004eb2:	02f71f63          	bne	a4,a5,80004ef0 <sys_link+0xc0>
    80004eb6:	40d0                	lw	a2,4(s1)
    80004eb8:	fd040593          	addi	a1,s0,-48
    80004ebc:	854a                	mv	a0,s2
    80004ebe:	cb7fe0ef          	jal	ra,80003b74 <dirlink>
    80004ec2:	02054763          	bltz	a0,80004ef0 <sys_link+0xc0>
  iunlockput(dp);
    80004ec6:	854a                	mv	a0,s2
    80004ec8:	f58fe0ef          	jal	ra,80003620 <iunlockput>
  iput(ip);
    80004ecc:	8526                	mv	a0,s1
    80004ece:	ecafe0ef          	jal	ra,80003598 <iput>
  end_op();
    80004ed2:	f9ffe0ef          	jal	ra,80003e70 <end_op>
  return 0;
    80004ed6:	4781                	li	a5,0
    80004ed8:	a081                	j	80004f18 <sys_link+0xe8>
    end_op();
    80004eda:	f97fe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    80004ede:	57fd                	li	a5,-1
    80004ee0:	a825                	j	80004f18 <sys_link+0xe8>
    iunlockput(ip);
    80004ee2:	8526                	mv	a0,s1
    80004ee4:	f3cfe0ef          	jal	ra,80003620 <iunlockput>
    end_op();
    80004ee8:	f89fe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    80004eec:	57fd                	li	a5,-1
    80004eee:	a02d                	j	80004f18 <sys_link+0xe8>
    iunlockput(dp);
    80004ef0:	854a                	mv	a0,s2
    80004ef2:	f2efe0ef          	jal	ra,80003620 <iunlockput>
  ilock(ip);
    80004ef6:	8526                	mv	a0,s1
    80004ef8:	d22fe0ef          	jal	ra,8000341a <ilock>
  ip->nlink--;
    80004efc:	04a4d783          	lhu	a5,74(s1)
    80004f00:	37fd                	addiw	a5,a5,-1
    80004f02:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004f06:	8526                	mv	a0,s1
    80004f08:	c5efe0ef          	jal	ra,80003366 <iupdate>
  iunlockput(ip);
    80004f0c:	8526                	mv	a0,s1
    80004f0e:	f12fe0ef          	jal	ra,80003620 <iunlockput>
  end_op();
    80004f12:	f5ffe0ef          	jal	ra,80003e70 <end_op>
  return -1;
    80004f16:	57fd                	li	a5,-1
}
    80004f18:	853e                	mv	a0,a5
    80004f1a:	70b2                	ld	ra,296(sp)
    80004f1c:	7412                	ld	s0,288(sp)
    80004f1e:	64f2                	ld	s1,280(sp)
    80004f20:	6952                	ld	s2,272(sp)
    80004f22:	6155                	addi	sp,sp,304
    80004f24:	8082                	ret

0000000080004f26 <sys_unlink>:
{
    80004f26:	7151                	addi	sp,sp,-240
    80004f28:	f586                	sd	ra,232(sp)
    80004f2a:	f1a2                	sd	s0,224(sp)
    80004f2c:	eda6                	sd	s1,216(sp)
    80004f2e:	e9ca                	sd	s2,208(sp)
    80004f30:	e5ce                	sd	s3,200(sp)
    80004f32:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004f34:	08000613          	li	a2,128
    80004f38:	f3040593          	addi	a1,s0,-208
    80004f3c:	4501                	li	a0,0
    80004f3e:	afffd0ef          	jal	ra,80002a3c <argstr>
    80004f42:	12054b63          	bltz	a0,80005078 <sys_unlink+0x152>
  begin_op();
    80004f46:	ebdfe0ef          	jal	ra,80003e02 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004f4a:	fb040593          	addi	a1,s0,-80
    80004f4e:	f3040513          	addi	a0,s0,-208
    80004f52:	cd7fe0ef          	jal	ra,80003c28 <nameiparent>
    80004f56:	84aa                	mv	s1,a0
    80004f58:	c54d                	beqz	a0,80005002 <sys_unlink+0xdc>
  ilock(dp);
    80004f5a:	cc0fe0ef          	jal	ra,8000341a <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004f5e:	00003597          	auipc	a1,0x3
    80004f62:	8ba58593          	addi	a1,a1,-1862 # 80007818 <syscalls+0x2e8>
    80004f66:	fb040513          	addi	a0,s0,-80
    80004f6a:	a23fe0ef          	jal	ra,8000398c <namecmp>
    80004f6e:	10050a63          	beqz	a0,80005082 <sys_unlink+0x15c>
    80004f72:	00003597          	auipc	a1,0x3
    80004f76:	8ae58593          	addi	a1,a1,-1874 # 80007820 <syscalls+0x2f0>
    80004f7a:	fb040513          	addi	a0,s0,-80
    80004f7e:	a0ffe0ef          	jal	ra,8000398c <namecmp>
    80004f82:	10050063          	beqz	a0,80005082 <sys_unlink+0x15c>
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004f86:	f2c40613          	addi	a2,s0,-212
    80004f8a:	fb040593          	addi	a1,s0,-80
    80004f8e:	8526                	mv	a0,s1
    80004f90:	a13fe0ef          	jal	ra,800039a2 <dirlookup>
    80004f94:	892a                	mv	s2,a0
    80004f96:	0e050663          	beqz	a0,80005082 <sys_unlink+0x15c>
  ilock(ip);
    80004f9a:	c80fe0ef          	jal	ra,8000341a <ilock>
  if(ip->nlink < 1)
    80004f9e:	04a91783          	lh	a5,74(s2)
    80004fa2:	06f05463          	blez	a5,8000500a <sys_unlink+0xe4>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004fa6:	04491703          	lh	a4,68(s2)
    80004faa:	4785                	li	a5,1
    80004fac:	06f70563          	beq	a4,a5,80005016 <sys_unlink+0xf0>
  memset(&de, 0, sizeof(de));
    80004fb0:	4641                	li	a2,16
    80004fb2:	4581                	li	a1,0
    80004fb4:	fc040513          	addi	a0,s0,-64
    80004fb8:	c87fb0ef          	jal	ra,80000c3e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004fbc:	4741                	li	a4,16
    80004fbe:	f2c42683          	lw	a3,-212(s0)
    80004fc2:	fc040613          	addi	a2,s0,-64
    80004fc6:	4581                	li	a1,0
    80004fc8:	8526                	mv	a0,s1
    80004fca:	8c1fe0ef          	jal	ra,8000388a <writei>
    80004fce:	47c1                	li	a5,16
    80004fd0:	08f51563          	bne	a0,a5,8000505a <sys_unlink+0x134>
  if(ip->type == T_DIR){
    80004fd4:	04491703          	lh	a4,68(s2)
    80004fd8:	4785                	li	a5,1
    80004fda:	08f70663          	beq	a4,a5,80005066 <sys_unlink+0x140>
  iunlockput(dp);
    80004fde:	8526                	mv	a0,s1
    80004fe0:	e40fe0ef          	jal	ra,80003620 <iunlockput>
  ip->nlink--;
    80004fe4:	04a95783          	lhu	a5,74(s2)
    80004fe8:	37fd                	addiw	a5,a5,-1
    80004fea:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004fee:	854a                	mv	a0,s2
    80004ff0:	b76fe0ef          	jal	ra,80003366 <iupdate>
  iunlockput(ip);
    80004ff4:	854a                	mv	a0,s2
    80004ff6:	e2afe0ef          	jal	ra,80003620 <iunlockput>
  end_op();
    80004ffa:	e77fe0ef          	jal	ra,80003e70 <end_op>
  return 0;
    80004ffe:	4501                	li	a0,0
    80005000:	a079                	j	8000508e <sys_unlink+0x168>
    end_op();
    80005002:	e6ffe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    80005006:	557d                	li	a0,-1
    80005008:	a059                	j	8000508e <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    8000500a:	00003517          	auipc	a0,0x3
    8000500e:	81e50513          	addi	a0,a0,-2018 # 80007828 <syscalls+0x2f8>
    80005012:	f76fb0ef          	jal	ra,80000788 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005016:	04c92703          	lw	a4,76(s2)
    8000501a:	02000793          	li	a5,32
    8000501e:	f8e7f9e3          	bgeu	a5,a4,80004fb0 <sys_unlink+0x8a>
    80005022:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005026:	4741                	li	a4,16
    80005028:	86ce                	mv	a3,s3
    8000502a:	f1840613          	addi	a2,s0,-232
    8000502e:	4581                	li	a1,0
    80005030:	854a                	mv	a0,s2
    80005032:	f74fe0ef          	jal	ra,800037a6 <readi>
    80005036:	47c1                	li	a5,16
    80005038:	00f51b63          	bne	a0,a5,8000504e <sys_unlink+0x128>
    if(de.inum != 0)
    8000503c:	f1845783          	lhu	a5,-232(s0)
    80005040:	ef95                	bnez	a5,8000507c <sys_unlink+0x156>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005042:	29c1                	addiw	s3,s3,16
    80005044:	04c92783          	lw	a5,76(s2)
    80005048:	fcf9efe3          	bltu	s3,a5,80005026 <sys_unlink+0x100>
    8000504c:	b795                	j	80004fb0 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    8000504e:	00002517          	auipc	a0,0x2
    80005052:	7f250513          	addi	a0,a0,2034 # 80007840 <syscalls+0x310>
    80005056:	f32fb0ef          	jal	ra,80000788 <panic>
    panic("unlink: writei");
    8000505a:	00002517          	auipc	a0,0x2
    8000505e:	7fe50513          	addi	a0,a0,2046 # 80007858 <syscalls+0x328>
    80005062:	f26fb0ef          	jal	ra,80000788 <panic>
    dp->nlink--;
    80005066:	04a4d783          	lhu	a5,74(s1)
    8000506a:	37fd                	addiw	a5,a5,-1
    8000506c:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005070:	8526                	mv	a0,s1
    80005072:	af4fe0ef          	jal	ra,80003366 <iupdate>
    80005076:	b7a5                	j	80004fde <sys_unlink+0xb8>
    return -1;
    80005078:	557d                	li	a0,-1
    8000507a:	a811                	j	8000508e <sys_unlink+0x168>
    iunlockput(ip);
    8000507c:	854a                	mv	a0,s2
    8000507e:	da2fe0ef          	jal	ra,80003620 <iunlockput>
  iunlockput(dp);
    80005082:	8526                	mv	a0,s1
    80005084:	d9cfe0ef          	jal	ra,80003620 <iunlockput>
  end_op();
    80005088:	de9fe0ef          	jal	ra,80003e70 <end_op>
  return -1;
    8000508c:	557d                	li	a0,-1
}
    8000508e:	70ae                	ld	ra,232(sp)
    80005090:	740e                	ld	s0,224(sp)
    80005092:	64ee                	ld	s1,216(sp)
    80005094:	694e                	ld	s2,208(sp)
    80005096:	69ae                	ld	s3,200(sp)
    80005098:	616d                	addi	sp,sp,240
    8000509a:	8082                	ret

000000008000509c <sys_open>:

uint64
sys_open(void)
{
    8000509c:	7131                	addi	sp,sp,-192
    8000509e:	fd06                	sd	ra,184(sp)
    800050a0:	f922                	sd	s0,176(sp)
    800050a2:	f526                	sd	s1,168(sp)
    800050a4:	f14a                	sd	s2,160(sp)
    800050a6:	ed4e                	sd	s3,152(sp)
    800050a8:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800050aa:	f4c40593          	addi	a1,s0,-180
    800050ae:	4505                	li	a0,1
    800050b0:	955fd0ef          	jal	ra,80002a04 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800050b4:	08000613          	li	a2,128
    800050b8:	f5040593          	addi	a1,s0,-176
    800050bc:	4501                	li	a0,0
    800050be:	97ffd0ef          	jal	ra,80002a3c <argstr>
    800050c2:	87aa                	mv	a5,a0
    return -1;
    800050c4:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800050c6:	0807cd63          	bltz	a5,80005160 <sys_open+0xc4>

  begin_op();
    800050ca:	d39fe0ef          	jal	ra,80003e02 <begin_op>

  if(omode & O_CREATE){
    800050ce:	f4c42783          	lw	a5,-180(s0)
    800050d2:	2007f793          	andi	a5,a5,512
    800050d6:	c3c5                	beqz	a5,80005176 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    800050d8:	4681                	li	a3,0
    800050da:	4601                	li	a2,0
    800050dc:	4589                	li	a1,2
    800050de:	f5040513          	addi	a0,s0,-176
    800050e2:	abfff0ef          	jal	ra,80004ba0 <create>
    800050e6:	84aa                	mv	s1,a0
    if(ip == 0){
    800050e8:	c159                	beqz	a0,8000516e <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800050ea:	04449703          	lh	a4,68(s1)
    800050ee:	478d                	li	a5,3
    800050f0:	00f71763          	bne	a4,a5,800050fe <sys_open+0x62>
    800050f4:	0464d703          	lhu	a4,70(s1)
    800050f8:	47a5                	li	a5,9
    800050fa:	0ae7e963          	bltu	a5,a4,800051ac <sys_open+0x110>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800050fe:	86aff0ef          	jal	ra,80004168 <filealloc>
    80005102:	89aa                	mv	s3,a0
    80005104:	0c050963          	beqz	a0,800051d6 <sys_open+0x13a>
    80005108:	a5bff0ef          	jal	ra,80004b62 <fdalloc>
    8000510c:	892a                	mv	s2,a0
    8000510e:	0c054163          	bltz	a0,800051d0 <sys_open+0x134>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005112:	04449703          	lh	a4,68(s1)
    80005116:	478d                	li	a5,3
    80005118:	0af70163          	beq	a4,a5,800051ba <sys_open+0x11e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000511c:	4789                	li	a5,2
    8000511e:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80005122:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80005126:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    8000512a:	f4c42783          	lw	a5,-180(s0)
    8000512e:	0017c713          	xori	a4,a5,1
    80005132:	8b05                	andi	a4,a4,1
    80005134:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80005138:	0037f713          	andi	a4,a5,3
    8000513c:	00e03733          	snez	a4,a4
    80005140:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80005144:	4007f793          	andi	a5,a5,1024
    80005148:	c791                	beqz	a5,80005154 <sys_open+0xb8>
    8000514a:	04449703          	lh	a4,68(s1)
    8000514e:	4789                	li	a5,2
    80005150:	06f70c63          	beq	a4,a5,800051c8 <sys_open+0x12c>
    itrunc(ip);
  }

  iunlock(ip);
    80005154:	8526                	mv	a0,s1
    80005156:	b6efe0ef          	jal	ra,800034c4 <iunlock>
  end_op();
    8000515a:	d17fe0ef          	jal	ra,80003e70 <end_op>

  return fd;
    8000515e:	854a                	mv	a0,s2
}
    80005160:	70ea                	ld	ra,184(sp)
    80005162:	744a                	ld	s0,176(sp)
    80005164:	74aa                	ld	s1,168(sp)
    80005166:	790a                	ld	s2,160(sp)
    80005168:	69ea                	ld	s3,152(sp)
    8000516a:	6129                	addi	sp,sp,192
    8000516c:	8082                	ret
      end_op();
    8000516e:	d03fe0ef          	jal	ra,80003e70 <end_op>
      return -1;
    80005172:	557d                	li	a0,-1
    80005174:	b7f5                	j	80005160 <sys_open+0xc4>
    if((ip = namei(path)) == 0){
    80005176:	f5040513          	addi	a0,s0,-176
    8000517a:	a95fe0ef          	jal	ra,80003c0e <namei>
    8000517e:	84aa                	mv	s1,a0
    80005180:	c115                	beqz	a0,800051a4 <sys_open+0x108>
    ilock(ip);
    80005182:	a98fe0ef          	jal	ra,8000341a <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80005186:	04449703          	lh	a4,68(s1)
    8000518a:	4785                	li	a5,1
    8000518c:	f4f71fe3          	bne	a4,a5,800050ea <sys_open+0x4e>
    80005190:	f4c42783          	lw	a5,-180(s0)
    80005194:	d7ad                	beqz	a5,800050fe <sys_open+0x62>
      iunlockput(ip);
    80005196:	8526                	mv	a0,s1
    80005198:	c88fe0ef          	jal	ra,80003620 <iunlockput>
      end_op();
    8000519c:	cd5fe0ef          	jal	ra,80003e70 <end_op>
      return -1;
    800051a0:	557d                	li	a0,-1
    800051a2:	bf7d                	j	80005160 <sys_open+0xc4>
      end_op();
    800051a4:	ccdfe0ef          	jal	ra,80003e70 <end_op>
      return -1;
    800051a8:	557d                	li	a0,-1
    800051aa:	bf5d                	j	80005160 <sys_open+0xc4>
    iunlockput(ip);
    800051ac:	8526                	mv	a0,s1
    800051ae:	c72fe0ef          	jal	ra,80003620 <iunlockput>
    end_op();
    800051b2:	cbffe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    800051b6:	557d                	li	a0,-1
    800051b8:	b765                	j	80005160 <sys_open+0xc4>
    f->type = FD_DEVICE;
    800051ba:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    800051be:	04649783          	lh	a5,70(s1)
    800051c2:	02f99223          	sh	a5,36(s3)
    800051c6:	b785                	j	80005126 <sys_open+0x8a>
    itrunc(ip);
    800051c8:	8526                	mv	a0,s1
    800051ca:	b3afe0ef          	jal	ra,80003504 <itrunc>
    800051ce:	b759                	j	80005154 <sys_open+0xb8>
      fileclose(f);
    800051d0:	854e                	mv	a0,s3
    800051d2:	83aff0ef          	jal	ra,8000420c <fileclose>
    iunlockput(ip);
    800051d6:	8526                	mv	a0,s1
    800051d8:	c48fe0ef          	jal	ra,80003620 <iunlockput>
    end_op();
    800051dc:	c95fe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    800051e0:	557d                	li	a0,-1
    800051e2:	bfbd                	j	80005160 <sys_open+0xc4>

00000000800051e4 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800051e4:	7175                	addi	sp,sp,-144
    800051e6:	e506                	sd	ra,136(sp)
    800051e8:	e122                	sd	s0,128(sp)
    800051ea:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800051ec:	c17fe0ef          	jal	ra,80003e02 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800051f0:	08000613          	li	a2,128
    800051f4:	f7040593          	addi	a1,s0,-144
    800051f8:	4501                	li	a0,0
    800051fa:	843fd0ef          	jal	ra,80002a3c <argstr>
    800051fe:	02054363          	bltz	a0,80005224 <sys_mkdir+0x40>
    80005202:	4681                	li	a3,0
    80005204:	4601                	li	a2,0
    80005206:	4585                	li	a1,1
    80005208:	f7040513          	addi	a0,s0,-144
    8000520c:	995ff0ef          	jal	ra,80004ba0 <create>
    80005210:	c911                	beqz	a0,80005224 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005212:	c0efe0ef          	jal	ra,80003620 <iunlockput>
  end_op();
    80005216:	c5bfe0ef          	jal	ra,80003e70 <end_op>
  return 0;
    8000521a:	4501                	li	a0,0
}
    8000521c:	60aa                	ld	ra,136(sp)
    8000521e:	640a                	ld	s0,128(sp)
    80005220:	6149                	addi	sp,sp,144
    80005222:	8082                	ret
    end_op();
    80005224:	c4dfe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    80005228:	557d                	li	a0,-1
    8000522a:	bfcd                	j	8000521c <sys_mkdir+0x38>

000000008000522c <sys_mknod>:

uint64
sys_mknod(void)
{
    8000522c:	7135                	addi	sp,sp,-160
    8000522e:	ed06                	sd	ra,152(sp)
    80005230:	e922                	sd	s0,144(sp)
    80005232:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005234:	bcffe0ef          	jal	ra,80003e02 <begin_op>
  argint(1, &major);
    80005238:	f6c40593          	addi	a1,s0,-148
    8000523c:	4505                	li	a0,1
    8000523e:	fc6fd0ef          	jal	ra,80002a04 <argint>
  argint(2, &minor);
    80005242:	f6840593          	addi	a1,s0,-152
    80005246:	4509                	li	a0,2
    80005248:	fbcfd0ef          	jal	ra,80002a04 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000524c:	08000613          	li	a2,128
    80005250:	f7040593          	addi	a1,s0,-144
    80005254:	4501                	li	a0,0
    80005256:	fe6fd0ef          	jal	ra,80002a3c <argstr>
    8000525a:	02054563          	bltz	a0,80005284 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    8000525e:	f6841683          	lh	a3,-152(s0)
    80005262:	f6c41603          	lh	a2,-148(s0)
    80005266:	458d                	li	a1,3
    80005268:	f7040513          	addi	a0,s0,-144
    8000526c:	935ff0ef          	jal	ra,80004ba0 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005270:	c911                	beqz	a0,80005284 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005272:	baefe0ef          	jal	ra,80003620 <iunlockput>
  end_op();
    80005276:	bfbfe0ef          	jal	ra,80003e70 <end_op>
  return 0;
    8000527a:	4501                	li	a0,0
}
    8000527c:	60ea                	ld	ra,152(sp)
    8000527e:	644a                	ld	s0,144(sp)
    80005280:	610d                	addi	sp,sp,160
    80005282:	8082                	ret
    end_op();
    80005284:	bedfe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    80005288:	557d                	li	a0,-1
    8000528a:	bfcd                	j	8000527c <sys_mknod+0x50>

000000008000528c <sys_chdir>:

uint64
sys_chdir(void)
{
    8000528c:	7135                	addi	sp,sp,-160
    8000528e:	ed06                	sd	ra,152(sp)
    80005290:	e922                	sd	s0,144(sp)
    80005292:	e526                	sd	s1,136(sp)
    80005294:	e14a                	sd	s2,128(sp)
    80005296:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005298:	e2efc0ef          	jal	ra,800018c6 <myproc>
    8000529c:	892a                	mv	s2,a0
  
  begin_op();
    8000529e:	b65fe0ef          	jal	ra,80003e02 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800052a2:	08000613          	li	a2,128
    800052a6:	f6040593          	addi	a1,s0,-160
    800052aa:	4501                	li	a0,0
    800052ac:	f90fd0ef          	jal	ra,80002a3c <argstr>
    800052b0:	04054163          	bltz	a0,800052f2 <sys_chdir+0x66>
    800052b4:	f6040513          	addi	a0,s0,-160
    800052b8:	957fe0ef          	jal	ra,80003c0e <namei>
    800052bc:	84aa                	mv	s1,a0
    800052be:	c915                	beqz	a0,800052f2 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800052c0:	95afe0ef          	jal	ra,8000341a <ilock>
  if(ip->type != T_DIR){
    800052c4:	04449703          	lh	a4,68(s1)
    800052c8:	4785                	li	a5,1
    800052ca:	02f71863          	bne	a4,a5,800052fa <sys_chdir+0x6e>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800052ce:	8526                	mv	a0,s1
    800052d0:	9f4fe0ef          	jal	ra,800034c4 <iunlock>
  iput(p->cwd);
    800052d4:	15093503          	ld	a0,336(s2)
    800052d8:	ac0fe0ef          	jal	ra,80003598 <iput>
  end_op();
    800052dc:	b95fe0ef          	jal	ra,80003e70 <end_op>
  p->cwd = ip;
    800052e0:	14993823          	sd	s1,336(s2)
  return 0;
    800052e4:	4501                	li	a0,0
}
    800052e6:	60ea                	ld	ra,152(sp)
    800052e8:	644a                	ld	s0,144(sp)
    800052ea:	64aa                	ld	s1,136(sp)
    800052ec:	690a                	ld	s2,128(sp)
    800052ee:	610d                	addi	sp,sp,160
    800052f0:	8082                	ret
    end_op();
    800052f2:	b7ffe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    800052f6:	557d                	li	a0,-1
    800052f8:	b7fd                	j	800052e6 <sys_chdir+0x5a>
    iunlockput(ip);
    800052fa:	8526                	mv	a0,s1
    800052fc:	b24fe0ef          	jal	ra,80003620 <iunlockput>
    end_op();
    80005300:	b71fe0ef          	jal	ra,80003e70 <end_op>
    return -1;
    80005304:	557d                	li	a0,-1
    80005306:	b7c5                	j	800052e6 <sys_chdir+0x5a>

0000000080005308 <sys_exec>:

uint64
sys_exec(void)
{
    80005308:	7145                	addi	sp,sp,-464
    8000530a:	e786                	sd	ra,456(sp)
    8000530c:	e3a2                	sd	s0,448(sp)
    8000530e:	ff26                	sd	s1,440(sp)
    80005310:	fb4a                	sd	s2,432(sp)
    80005312:	f74e                	sd	s3,424(sp)
    80005314:	f352                	sd	s4,416(sp)
    80005316:	ef56                	sd	s5,408(sp)
    80005318:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000531a:	e3840593          	addi	a1,s0,-456
    8000531e:	4505                	li	a0,1
    80005320:	f00fd0ef          	jal	ra,80002a20 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005324:	08000613          	li	a2,128
    80005328:	f4040593          	addi	a1,s0,-192
    8000532c:	4501                	li	a0,0
    8000532e:	f0efd0ef          	jal	ra,80002a3c <argstr>
    80005332:	87aa                	mv	a5,a0
    return -1;
    80005334:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005336:	0a07c563          	bltz	a5,800053e0 <sys_exec+0xd8>
  }
  memset(argv, 0, sizeof(argv));
    8000533a:	10000613          	li	a2,256
    8000533e:	4581                	li	a1,0
    80005340:	e4040513          	addi	a0,s0,-448
    80005344:	8fbfb0ef          	jal	ra,80000c3e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005348:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    8000534c:	89a6                	mv	s3,s1
    8000534e:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005350:	02000a13          	li	s4,32
    80005354:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005358:	00391513          	slli	a0,s2,0x3
    8000535c:	e3040593          	addi	a1,s0,-464
    80005360:	e3843783          	ld	a5,-456(s0)
    80005364:	953e                	add	a0,a0,a5
    80005366:	e14fd0ef          	jal	ra,8000297a <fetchaddr>
    8000536a:	02054663          	bltz	a0,80005396 <sys_exec+0x8e>
      goto bad;
    }
    if(uarg == 0){
    8000536e:	e3043783          	ld	a5,-464(s0)
    80005372:	cf8d                	beqz	a5,800053ac <sys_exec+0xa4>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005374:	f26fb0ef          	jal	ra,80000a9a <kalloc>
    80005378:	85aa                	mv	a1,a0
    8000537a:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000537e:	cd01                	beqz	a0,80005396 <sys_exec+0x8e>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005380:	6605                	lui	a2,0x1
    80005382:	e3043503          	ld	a0,-464(s0)
    80005386:	e3efd0ef          	jal	ra,800029c4 <fetchstr>
    8000538a:	00054663          	bltz	a0,80005396 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    8000538e:	0905                	addi	s2,s2,1
    80005390:	09a1                	addi	s3,s3,8
    80005392:	fd4911e3          	bne	s2,s4,80005354 <sys_exec+0x4c>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005396:	f4040913          	addi	s2,s0,-192
    8000539a:	6088                	ld	a0,0(s1)
    8000539c:	c129                	beqz	a0,800053de <sys_exec+0xd6>
    kfree(argv[i]);
    8000539e:	e1afb0ef          	jal	ra,800009b8 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053a2:	04a1                	addi	s1,s1,8
    800053a4:	ff249be3          	bne	s1,s2,8000539a <sys_exec+0x92>
  return -1;
    800053a8:	557d                	li	a0,-1
    800053aa:	a81d                	j	800053e0 <sys_exec+0xd8>
      argv[i] = 0;
    800053ac:	0a8e                	slli	s5,s5,0x3
    800053ae:	fc0a8793          	addi	a5,s5,-64
    800053b2:	00878ab3          	add	s5,a5,s0
    800053b6:	e80ab023          	sd	zero,-384(s5)
  int ret = kexec(path, argv);
    800053ba:	e4040593          	addi	a1,s0,-448
    800053be:	f4040513          	addi	a0,s0,-192
    800053c2:	bf6ff0ef          	jal	ra,800047b8 <kexec>
    800053c6:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053c8:	f4040993          	addi	s3,s0,-192
    800053cc:	6088                	ld	a0,0(s1)
    800053ce:	c511                	beqz	a0,800053da <sys_exec+0xd2>
    kfree(argv[i]);
    800053d0:	de8fb0ef          	jal	ra,800009b8 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800053d4:	04a1                	addi	s1,s1,8
    800053d6:	ff349be3          	bne	s1,s3,800053cc <sys_exec+0xc4>
  return ret;
    800053da:	854a                	mv	a0,s2
    800053dc:	a011                	j	800053e0 <sys_exec+0xd8>
  return -1;
    800053de:	557d                	li	a0,-1
}
    800053e0:	60be                	ld	ra,456(sp)
    800053e2:	641e                	ld	s0,448(sp)
    800053e4:	74fa                	ld	s1,440(sp)
    800053e6:	795a                	ld	s2,432(sp)
    800053e8:	79ba                	ld	s3,424(sp)
    800053ea:	7a1a                	ld	s4,416(sp)
    800053ec:	6afa                	ld	s5,408(sp)
    800053ee:	6179                	addi	sp,sp,464
    800053f0:	8082                	ret

00000000800053f2 <sys_pipe>:

uint64
sys_pipe(void)
{
    800053f2:	7139                	addi	sp,sp,-64
    800053f4:	fc06                	sd	ra,56(sp)
    800053f6:	f822                	sd	s0,48(sp)
    800053f8:	f426                	sd	s1,40(sp)
    800053fa:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800053fc:	ccafc0ef          	jal	ra,800018c6 <myproc>
    80005400:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005402:	fd840593          	addi	a1,s0,-40
    80005406:	4501                	li	a0,0
    80005408:	e18fd0ef          	jal	ra,80002a20 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000540c:	fc840593          	addi	a1,s0,-56
    80005410:	fd040513          	addi	a0,s0,-48
    80005414:	8c4ff0ef          	jal	ra,800044d8 <pipealloc>
    return -1;
    80005418:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    8000541a:	0a054463          	bltz	a0,800054c2 <sys_pipe+0xd0>
  fd0 = -1;
    8000541e:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005422:	fd043503          	ld	a0,-48(s0)
    80005426:	f3cff0ef          	jal	ra,80004b62 <fdalloc>
    8000542a:	fca42223          	sw	a0,-60(s0)
    8000542e:	08054163          	bltz	a0,800054b0 <sys_pipe+0xbe>
    80005432:	fc843503          	ld	a0,-56(s0)
    80005436:	f2cff0ef          	jal	ra,80004b62 <fdalloc>
    8000543a:	fca42023          	sw	a0,-64(s0)
    8000543e:	06054063          	bltz	a0,8000549e <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005442:	4691                	li	a3,4
    80005444:	fc440613          	addi	a2,s0,-60
    80005448:	fd843583          	ld	a1,-40(s0)
    8000544c:	68a8                	ld	a0,80(s1)
    8000544e:	902fc0ef          	jal	ra,80001550 <copyout>
    80005452:	00054e63          	bltz	a0,8000546e <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005456:	4691                	li	a3,4
    80005458:	fc040613          	addi	a2,s0,-64
    8000545c:	fd843583          	ld	a1,-40(s0)
    80005460:	0591                	addi	a1,a1,4
    80005462:	68a8                	ld	a0,80(s1)
    80005464:	8ecfc0ef          	jal	ra,80001550 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005468:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000546a:	04055c63          	bgez	a0,800054c2 <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    8000546e:	fc442783          	lw	a5,-60(s0)
    80005472:	07e9                	addi	a5,a5,26
    80005474:	078e                	slli	a5,a5,0x3
    80005476:	97a6                	add	a5,a5,s1
    80005478:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000547c:	fc042783          	lw	a5,-64(s0)
    80005480:	07e9                	addi	a5,a5,26
    80005482:	078e                	slli	a5,a5,0x3
    80005484:	94be                	add	s1,s1,a5
    80005486:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000548a:	fd043503          	ld	a0,-48(s0)
    8000548e:	d7ffe0ef          	jal	ra,8000420c <fileclose>
    fileclose(wf);
    80005492:	fc843503          	ld	a0,-56(s0)
    80005496:	d77fe0ef          	jal	ra,8000420c <fileclose>
    return -1;
    8000549a:	57fd                	li	a5,-1
    8000549c:	a01d                	j	800054c2 <sys_pipe+0xd0>
    if(fd0 >= 0)
    8000549e:	fc442783          	lw	a5,-60(s0)
    800054a2:	0007c763          	bltz	a5,800054b0 <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800054a6:	07e9                	addi	a5,a5,26
    800054a8:	078e                	slli	a5,a5,0x3
    800054aa:	97a6                	add	a5,a5,s1
    800054ac:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800054b0:	fd043503          	ld	a0,-48(s0)
    800054b4:	d59fe0ef          	jal	ra,8000420c <fileclose>
    fileclose(wf);
    800054b8:	fc843503          	ld	a0,-56(s0)
    800054bc:	d51fe0ef          	jal	ra,8000420c <fileclose>
    return -1;
    800054c0:	57fd                	li	a5,-1
}
    800054c2:	853e                	mv	a0,a5
    800054c4:	70e2                	ld	ra,56(sp)
    800054c6:	7442                	ld	s0,48(sp)
    800054c8:	74a2                	ld	s1,40(sp)
    800054ca:	6121                	addi	sp,sp,64
    800054cc:	8082                	ret
	...

00000000800054d0 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    800054d0:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    800054d2:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    800054d4:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    800054d6:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    800054d8:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    800054da:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    800054dc:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    800054de:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    800054e0:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    800054e2:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    800054e4:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    800054e6:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    800054e8:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    800054ea:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    800054ec:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    800054ee:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    800054f0:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    800054f2:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    800054f4:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    800054f6:	b90fd0ef          	jal	ra,80002886 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    800054fa:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    800054fc:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    800054fe:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005500:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005502:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005504:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005506:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005508:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000550a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000550c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000550e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005510:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005512:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005514:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005516:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005518:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000551a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000551c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000551e:	10200073          	sret
	...

000000008000552e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000552e:	1141                	addi	sp,sp,-16
    80005530:	e422                	sd	s0,8(sp)
    80005532:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005534:	0c0007b7          	lui	a5,0xc000
    80005538:	4705                	li	a4,1
    8000553a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000553c:	c3d8                	sw	a4,4(a5)
}
    8000553e:	6422                	ld	s0,8(sp)
    80005540:	0141                	addi	sp,sp,16
    80005542:	8082                	ret

0000000080005544 <plicinithart>:

void
plicinithart(void)
{
    80005544:	1141                	addi	sp,sp,-16
    80005546:	e406                	sd	ra,8(sp)
    80005548:	e022                	sd	s0,0(sp)
    8000554a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    8000554c:	b4efc0ef          	jal	ra,8000189a <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005550:	0085171b          	slliw	a4,a0,0x8
    80005554:	0c0027b7          	lui	a5,0xc002
    80005558:	97ba                	add	a5,a5,a4
    8000555a:	40200713          	li	a4,1026
    8000555e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005562:	00d5151b          	slliw	a0,a0,0xd
    80005566:	0c2017b7          	lui	a5,0xc201
    8000556a:	97aa                	add	a5,a5,a0
    8000556c:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005570:	60a2                	ld	ra,8(sp)
    80005572:	6402                	ld	s0,0(sp)
    80005574:	0141                	addi	sp,sp,16
    80005576:	8082                	ret

0000000080005578 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005578:	1141                	addi	sp,sp,-16
    8000557a:	e406                	sd	ra,8(sp)
    8000557c:	e022                	sd	s0,0(sp)
    8000557e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005580:	b1afc0ef          	jal	ra,8000189a <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005584:	00d5151b          	slliw	a0,a0,0xd
    80005588:	0c2017b7          	lui	a5,0xc201
    8000558c:	97aa                	add	a5,a5,a0
  return irq;
}
    8000558e:	43c8                	lw	a0,4(a5)
    80005590:	60a2                	ld	ra,8(sp)
    80005592:	6402                	ld	s0,0(sp)
    80005594:	0141                	addi	sp,sp,16
    80005596:	8082                	ret

0000000080005598 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005598:	1101                	addi	sp,sp,-32
    8000559a:	ec06                	sd	ra,24(sp)
    8000559c:	e822                	sd	s0,16(sp)
    8000559e:	e426                	sd	s1,8(sp)
    800055a0:	1000                	addi	s0,sp,32
    800055a2:	84aa                	mv	s1,a0
  int hart = cpuid();
    800055a4:	af6fc0ef          	jal	ra,8000189a <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800055a8:	00d5151b          	slliw	a0,a0,0xd
    800055ac:	0c2017b7          	lui	a5,0xc201
    800055b0:	97aa                	add	a5,a5,a0
    800055b2:	c3c4                	sw	s1,4(a5)
}
    800055b4:	60e2                	ld	ra,24(sp)
    800055b6:	6442                	ld	s0,16(sp)
    800055b8:	64a2                	ld	s1,8(sp)
    800055ba:	6105                	addi	sp,sp,32
    800055bc:	8082                	ret

00000000800055be <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800055be:	1141                	addi	sp,sp,-16
    800055c0:	e406                	sd	ra,8(sp)
    800055c2:	e022                	sd	s0,0(sp)
    800055c4:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800055c6:	479d                	li	a5,7
    800055c8:	04a7ca63          	blt	a5,a0,8000561c <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800055cc:	0001c797          	auipc	a5,0x1c
    800055d0:	5dc78793          	addi	a5,a5,1500 # 80021ba8 <disk>
    800055d4:	97aa                	add	a5,a5,a0
    800055d6:	0187c783          	lbu	a5,24(a5)
    800055da:	e7b9                	bnez	a5,80005628 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800055dc:	00451693          	slli	a3,a0,0x4
    800055e0:	0001c797          	auipc	a5,0x1c
    800055e4:	5c878793          	addi	a5,a5,1480 # 80021ba8 <disk>
    800055e8:	6398                	ld	a4,0(a5)
    800055ea:	9736                	add	a4,a4,a3
    800055ec:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    800055f0:	6398                	ld	a4,0(a5)
    800055f2:	9736                	add	a4,a4,a3
    800055f4:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800055f8:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800055fc:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005600:	97aa                	add	a5,a5,a0
    80005602:	4705                	li	a4,1
    80005604:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005608:	0001c517          	auipc	a0,0x1c
    8000560c:	5b850513          	addi	a0,a0,1464 # 80021bc0 <disk+0x18>
    80005610:	a5bfc0ef          	jal	ra,8000206a <wakeup>
}
    80005614:	60a2                	ld	ra,8(sp)
    80005616:	6402                	ld	s0,0(sp)
    80005618:	0141                	addi	sp,sp,16
    8000561a:	8082                	ret
    panic("free_desc 1");
    8000561c:	00002517          	auipc	a0,0x2
    80005620:	24c50513          	addi	a0,a0,588 # 80007868 <syscalls+0x338>
    80005624:	964fb0ef          	jal	ra,80000788 <panic>
    panic("free_desc 2");
    80005628:	00002517          	auipc	a0,0x2
    8000562c:	25050513          	addi	a0,a0,592 # 80007878 <syscalls+0x348>
    80005630:	958fb0ef          	jal	ra,80000788 <panic>

0000000080005634 <virtio_disk_init>:
{
    80005634:	1101                	addi	sp,sp,-32
    80005636:	ec06                	sd	ra,24(sp)
    80005638:	e822                	sd	s0,16(sp)
    8000563a:	e426                	sd	s1,8(sp)
    8000563c:	e04a                	sd	s2,0(sp)
    8000563e:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005640:	00002597          	auipc	a1,0x2
    80005644:	24858593          	addi	a1,a1,584 # 80007888 <syscalls+0x358>
    80005648:	0001c517          	auipc	a0,0x1c
    8000564c:	68850513          	addi	a0,a0,1672 # 80021cd0 <disk+0x128>
    80005650:	c9afb0ef          	jal	ra,80000aea <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005654:	100017b7          	lui	a5,0x10001
    80005658:	4398                	lw	a4,0(a5)
    8000565a:	2701                	sext.w	a4,a4
    8000565c:	747277b7          	lui	a5,0x74727
    80005660:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005664:	12f71f63          	bne	a4,a5,800057a2 <virtio_disk_init+0x16e>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005668:	100017b7          	lui	a5,0x10001
    8000566c:	43dc                	lw	a5,4(a5)
    8000566e:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005670:	4709                	li	a4,2
    80005672:	12e79863          	bne	a5,a4,800057a2 <virtio_disk_init+0x16e>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005676:	100017b7          	lui	a5,0x10001
    8000567a:	479c                	lw	a5,8(a5)
    8000567c:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000567e:	12e79263          	bne	a5,a4,800057a2 <virtio_disk_init+0x16e>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005682:	100017b7          	lui	a5,0x10001
    80005686:	47d8                	lw	a4,12(a5)
    80005688:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000568a:	554d47b7          	lui	a5,0x554d4
    8000568e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005692:	10f71863          	bne	a4,a5,800057a2 <virtio_disk_init+0x16e>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005696:	100017b7          	lui	a5,0x10001
    8000569a:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000569e:	4705                	li	a4,1
    800056a0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800056a2:	470d                	li	a4,3
    800056a4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800056a6:	4b98                	lw	a4,16(a5)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800056a8:	c7ffe6b7          	lui	a3,0xc7ffe
    800056ac:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdca77>
    800056b0:	8f75                	and	a4,a4,a3
    800056b2:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800056b4:	472d                	li	a4,11
    800056b6:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800056b8:	5bbc                	lw	a5,112(a5)
    800056ba:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800056be:	8ba1                	andi	a5,a5,8
    800056c0:	0e078763          	beqz	a5,800057ae <virtio_disk_init+0x17a>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800056c4:	100017b7          	lui	a5,0x10001
    800056c8:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800056cc:	43fc                	lw	a5,68(a5)
    800056ce:	2781                	sext.w	a5,a5
    800056d0:	0e079563          	bnez	a5,800057ba <virtio_disk_init+0x186>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800056d4:	100017b7          	lui	a5,0x10001
    800056d8:	5bdc                	lw	a5,52(a5)
    800056da:	2781                	sext.w	a5,a5
  if(max == 0)
    800056dc:	0e078563          	beqz	a5,800057c6 <virtio_disk_init+0x192>
  if(max < NUM)
    800056e0:	471d                	li	a4,7
    800056e2:	0ef77863          	bgeu	a4,a5,800057d2 <virtio_disk_init+0x19e>
  disk.desc = kalloc();
    800056e6:	bb4fb0ef          	jal	ra,80000a9a <kalloc>
    800056ea:	0001c497          	auipc	s1,0x1c
    800056ee:	4be48493          	addi	s1,s1,1214 # 80021ba8 <disk>
    800056f2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800056f4:	ba6fb0ef          	jal	ra,80000a9a <kalloc>
    800056f8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800056fa:	ba0fb0ef          	jal	ra,80000a9a <kalloc>
    800056fe:	87aa                	mv	a5,a0
    80005700:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005702:	6088                	ld	a0,0(s1)
    80005704:	cd69                	beqz	a0,800057de <virtio_disk_init+0x1aa>
    80005706:	0001c717          	auipc	a4,0x1c
    8000570a:	4aa73703          	ld	a4,1194(a4) # 80021bb0 <disk+0x8>
    8000570e:	cb61                	beqz	a4,800057de <virtio_disk_init+0x1aa>
    80005710:	c7f9                	beqz	a5,800057de <virtio_disk_init+0x1aa>
  memset(disk.desc, 0, PGSIZE);
    80005712:	6605                	lui	a2,0x1
    80005714:	4581                	li	a1,0
    80005716:	d28fb0ef          	jal	ra,80000c3e <memset>
  memset(disk.avail, 0, PGSIZE);
    8000571a:	0001c497          	auipc	s1,0x1c
    8000571e:	48e48493          	addi	s1,s1,1166 # 80021ba8 <disk>
    80005722:	6605                	lui	a2,0x1
    80005724:	4581                	li	a1,0
    80005726:	6488                	ld	a0,8(s1)
    80005728:	d16fb0ef          	jal	ra,80000c3e <memset>
  memset(disk.used, 0, PGSIZE);
    8000572c:	6605                	lui	a2,0x1
    8000572e:	4581                	li	a1,0
    80005730:	6888                	ld	a0,16(s1)
    80005732:	d0cfb0ef          	jal	ra,80000c3e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005736:	100017b7          	lui	a5,0x10001
    8000573a:	4721                	li	a4,8
    8000573c:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000573e:	4098                	lw	a4,0(s1)
    80005740:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005744:	40d8                	lw	a4,4(s1)
    80005746:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    8000574a:	6498                	ld	a4,8(s1)
    8000574c:	0007069b          	sext.w	a3,a4
    80005750:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005754:	9701                	srai	a4,a4,0x20
    80005756:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    8000575a:	6898                	ld	a4,16(s1)
    8000575c:	0007069b          	sext.w	a3,a4
    80005760:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005764:	9701                	srai	a4,a4,0x20
    80005766:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    8000576a:	4705                	li	a4,1
    8000576c:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    8000576e:	00e48c23          	sb	a4,24(s1)
    80005772:	00e48ca3          	sb	a4,25(s1)
    80005776:	00e48d23          	sb	a4,26(s1)
    8000577a:	00e48da3          	sb	a4,27(s1)
    8000577e:	00e48e23          	sb	a4,28(s1)
    80005782:	00e48ea3          	sb	a4,29(s1)
    80005786:	00e48f23          	sb	a4,30(s1)
    8000578a:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    8000578e:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005792:	0727a823          	sw	s2,112(a5)
}
    80005796:	60e2                	ld	ra,24(sp)
    80005798:	6442                	ld	s0,16(sp)
    8000579a:	64a2                	ld	s1,8(sp)
    8000579c:	6902                	ld	s2,0(sp)
    8000579e:	6105                	addi	sp,sp,32
    800057a0:	8082                	ret
    panic("could not find virtio disk");
    800057a2:	00002517          	auipc	a0,0x2
    800057a6:	0f650513          	addi	a0,a0,246 # 80007898 <syscalls+0x368>
    800057aa:	fdffa0ef          	jal	ra,80000788 <panic>
    panic("virtio disk FEATURES_OK unset");
    800057ae:	00002517          	auipc	a0,0x2
    800057b2:	10a50513          	addi	a0,a0,266 # 800078b8 <syscalls+0x388>
    800057b6:	fd3fa0ef          	jal	ra,80000788 <panic>
    panic("virtio disk should not be ready");
    800057ba:	00002517          	auipc	a0,0x2
    800057be:	11e50513          	addi	a0,a0,286 # 800078d8 <syscalls+0x3a8>
    800057c2:	fc7fa0ef          	jal	ra,80000788 <panic>
    panic("virtio disk has no queue 0");
    800057c6:	00002517          	auipc	a0,0x2
    800057ca:	13250513          	addi	a0,a0,306 # 800078f8 <syscalls+0x3c8>
    800057ce:	fbbfa0ef          	jal	ra,80000788 <panic>
    panic("virtio disk max queue too short");
    800057d2:	00002517          	auipc	a0,0x2
    800057d6:	14650513          	addi	a0,a0,326 # 80007918 <syscalls+0x3e8>
    800057da:	faffa0ef          	jal	ra,80000788 <panic>
    panic("virtio disk kalloc");
    800057de:	00002517          	auipc	a0,0x2
    800057e2:	15a50513          	addi	a0,a0,346 # 80007938 <syscalls+0x408>
    800057e6:	fa3fa0ef          	jal	ra,80000788 <panic>

00000000800057ea <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800057ea:	7119                	addi	sp,sp,-128
    800057ec:	fc86                	sd	ra,120(sp)
    800057ee:	f8a2                	sd	s0,112(sp)
    800057f0:	f4a6                	sd	s1,104(sp)
    800057f2:	f0ca                	sd	s2,96(sp)
    800057f4:	ecce                	sd	s3,88(sp)
    800057f6:	e8d2                	sd	s4,80(sp)
    800057f8:	e4d6                	sd	s5,72(sp)
    800057fa:	e0da                	sd	s6,64(sp)
    800057fc:	fc5e                	sd	s7,56(sp)
    800057fe:	f862                	sd	s8,48(sp)
    80005800:	f466                	sd	s9,40(sp)
    80005802:	f06a                	sd	s10,32(sp)
    80005804:	ec6e                	sd	s11,24(sp)
    80005806:	0100                	addi	s0,sp,128
    80005808:	8aaa                	mv	s5,a0
    8000580a:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000580c:	00c52d03          	lw	s10,12(a0)
    80005810:	001d1d1b          	slliw	s10,s10,0x1
    80005814:	1d02                	slli	s10,s10,0x20
    80005816:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    8000581a:	0001c517          	auipc	a0,0x1c
    8000581e:	4b650513          	addi	a0,a0,1206 # 80021cd0 <disk+0x128>
    80005822:	b48fb0ef          	jal	ra,80000b6a <acquire>
  for(int i = 0; i < 3; i++){
    80005826:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80005828:	44a1                	li	s1,8
      disk.free[i] = 0;
    8000582a:	0001cb97          	auipc	s7,0x1c
    8000582e:	37eb8b93          	addi	s7,s7,894 # 80021ba8 <disk>
  for(int i = 0; i < 3; i++){
    80005832:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005834:	0001cc97          	auipc	s9,0x1c
    80005838:	49cc8c93          	addi	s9,s9,1180 # 80021cd0 <disk+0x128>
    8000583c:	a8a9                	j	80005896 <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    8000583e:	00fb8733          	add	a4,s7,a5
    80005842:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005846:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005848:	0207c563          	bltz	a5,80005872 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    8000584c:	2905                	addiw	s2,s2,1
    8000584e:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005850:	05690863          	beq	s2,s6,800058a0 <virtio_disk_rw+0xb6>
    idx[i] = alloc_desc();
    80005854:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005856:	0001c717          	auipc	a4,0x1c
    8000585a:	35270713          	addi	a4,a4,850 # 80021ba8 <disk>
    8000585e:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005860:	01874683          	lbu	a3,24(a4)
    80005864:	fee9                	bnez	a3,8000583e <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80005866:	2785                	addiw	a5,a5,1
    80005868:	0705                	addi	a4,a4,1
    8000586a:	fe979be3          	bne	a5,s1,80005860 <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    8000586e:	57fd                	li	a5,-1
    80005870:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005872:	01205b63          	blez	s2,80005888 <virtio_disk_rw+0x9e>
    80005876:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    80005878:	000a2503          	lw	a0,0(s4)
    8000587c:	d43ff0ef          	jal	ra,800055be <free_desc>
      for(int j = 0; j < i; j++)
    80005880:	2d85                	addiw	s11,s11,1
    80005882:	0a11                	addi	s4,s4,4
    80005884:	ff2d9ae3          	bne	s11,s2,80005878 <virtio_disk_rw+0x8e>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005888:	85e6                	mv	a1,s9
    8000588a:	0001c517          	auipc	a0,0x1c
    8000588e:	33650513          	addi	a0,a0,822 # 80021bc0 <disk+0x18>
    80005892:	f8cfc0ef          	jal	ra,8000201e <sleep>
  for(int i = 0; i < 3; i++){
    80005896:	f8040a13          	addi	s4,s0,-128
{
    8000589a:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    8000589c:	894e                	mv	s2,s3
    8000589e:	bf5d                	j	80005854 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800058a0:	f8042503          	lw	a0,-128(s0)
    800058a4:	00a50713          	addi	a4,a0,10
    800058a8:	0712                	slli	a4,a4,0x4

  if(write)
    800058aa:	0001c797          	auipc	a5,0x1c
    800058ae:	2fe78793          	addi	a5,a5,766 # 80021ba8 <disk>
    800058b2:	00e786b3          	add	a3,a5,a4
    800058b6:	01803633          	snez	a2,s8
    800058ba:	c690                	sw	a2,8(a3)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800058bc:	0006a623          	sw	zero,12(a3)
  buf0->sector = sector;
    800058c0:	01a6b823          	sd	s10,16(a3)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800058c4:	f6070613          	addi	a2,a4,-160
    800058c8:	6394                	ld	a3,0(a5)
    800058ca:	96b2                	add	a3,a3,a2
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800058cc:	00870593          	addi	a1,a4,8
    800058d0:	95be                	add	a1,a1,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    800058d2:	e28c                	sd	a1,0(a3)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800058d4:	0007b803          	ld	a6,0(a5)
    800058d8:	9642                	add	a2,a2,a6
    800058da:	46c1                	li	a3,16
    800058dc:	c614                	sw	a3,8(a2)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800058de:	4585                	li	a1,1
    800058e0:	00b61623          	sh	a1,12(a2)
  disk.desc[idx[0]].next = idx[1];
    800058e4:	f8442683          	lw	a3,-124(s0)
    800058e8:	00d61723          	sh	a3,14(a2)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800058ec:	0692                	slli	a3,a3,0x4
    800058ee:	9836                	add	a6,a6,a3
    800058f0:	058a8613          	addi	a2,s5,88
    800058f4:	00c83023          	sd	a2,0(a6)
  disk.desc[idx[1]].len = BSIZE;
    800058f8:	0007b803          	ld	a6,0(a5)
    800058fc:	96c2                	add	a3,a3,a6
    800058fe:	40000613          	li	a2,1024
    80005902:	c690                	sw	a2,8(a3)
  if(write)
    80005904:	001c3613          	seqz	a2,s8
    80005908:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000590c:	00166613          	ori	a2,a2,1
    80005910:	00c69623          	sh	a2,12(a3)
  disk.desc[idx[1]].next = idx[2];
    80005914:	f8842603          	lw	a2,-120(s0)
    80005918:	00c69723          	sh	a2,14(a3)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000591c:	00250693          	addi	a3,a0,2
    80005920:	0692                	slli	a3,a3,0x4
    80005922:	96be                	add	a3,a3,a5
    80005924:	58fd                	li	a7,-1
    80005926:	01168823          	sb	a7,16(a3)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000592a:	0612                	slli	a2,a2,0x4
    8000592c:	9832                	add	a6,a6,a2
    8000592e:	f9070713          	addi	a4,a4,-112
    80005932:	973e                	add	a4,a4,a5
    80005934:	00e83023          	sd	a4,0(a6)
  disk.desc[idx[2]].len = 1;
    80005938:	6398                	ld	a4,0(a5)
    8000593a:	9732                	add	a4,a4,a2
    8000593c:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    8000593e:	4609                	li	a2,2
    80005940:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[2]].next = 0;
    80005944:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005948:	00baa223          	sw	a1,4(s5)
  disk.info[idx[0]].b = b;
    8000594c:	0156b423          	sd	s5,8(a3)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005950:	6794                	ld	a3,8(a5)
    80005952:	0026d703          	lhu	a4,2(a3)
    80005956:	8b1d                	andi	a4,a4,7
    80005958:	0706                	slli	a4,a4,0x1
    8000595a:	96ba                	add	a3,a3,a4
    8000595c:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005960:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005964:	6798                	ld	a4,8(a5)
    80005966:	00275783          	lhu	a5,2(a4)
    8000596a:	2785                	addiw	a5,a5,1
    8000596c:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005970:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005974:	100017b7          	lui	a5,0x10001
    80005978:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    8000597c:	004aa783          	lw	a5,4(s5)
    sleep(b, &disk.vdisk_lock);
    80005980:	0001c917          	auipc	s2,0x1c
    80005984:	35090913          	addi	s2,s2,848 # 80021cd0 <disk+0x128>
  while(b->disk == 1) {
    80005988:	4485                	li	s1,1
    8000598a:	00b79a63          	bne	a5,a1,8000599e <virtio_disk_rw+0x1b4>
    sleep(b, &disk.vdisk_lock);
    8000598e:	85ca                	mv	a1,s2
    80005990:	8556                	mv	a0,s5
    80005992:	e8cfc0ef          	jal	ra,8000201e <sleep>
  while(b->disk == 1) {
    80005996:	004aa783          	lw	a5,4(s5)
    8000599a:	fe978ae3          	beq	a5,s1,8000598e <virtio_disk_rw+0x1a4>
  }

  disk.info[idx[0]].b = 0;
    8000599e:	f8042903          	lw	s2,-128(s0)
    800059a2:	00290713          	addi	a4,s2,2
    800059a6:	0712                	slli	a4,a4,0x4
    800059a8:	0001c797          	auipc	a5,0x1c
    800059ac:	20078793          	addi	a5,a5,512 # 80021ba8 <disk>
    800059b0:	97ba                	add	a5,a5,a4
    800059b2:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800059b6:	0001c997          	auipc	s3,0x1c
    800059ba:	1f298993          	addi	s3,s3,498 # 80021ba8 <disk>
    800059be:	00491713          	slli	a4,s2,0x4
    800059c2:	0009b783          	ld	a5,0(s3)
    800059c6:	97ba                	add	a5,a5,a4
    800059c8:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800059cc:	854a                	mv	a0,s2
    800059ce:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800059d2:	bedff0ef          	jal	ra,800055be <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800059d6:	8885                	andi	s1,s1,1
    800059d8:	f0fd                	bnez	s1,800059be <virtio_disk_rw+0x1d4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800059da:	0001c517          	auipc	a0,0x1c
    800059de:	2f650513          	addi	a0,a0,758 # 80021cd0 <disk+0x128>
    800059e2:	a20fb0ef          	jal	ra,80000c02 <release>
}
    800059e6:	70e6                	ld	ra,120(sp)
    800059e8:	7446                	ld	s0,112(sp)
    800059ea:	74a6                	ld	s1,104(sp)
    800059ec:	7906                	ld	s2,96(sp)
    800059ee:	69e6                	ld	s3,88(sp)
    800059f0:	6a46                	ld	s4,80(sp)
    800059f2:	6aa6                	ld	s5,72(sp)
    800059f4:	6b06                	ld	s6,64(sp)
    800059f6:	7be2                	ld	s7,56(sp)
    800059f8:	7c42                	ld	s8,48(sp)
    800059fa:	7ca2                	ld	s9,40(sp)
    800059fc:	7d02                	ld	s10,32(sp)
    800059fe:	6de2                	ld	s11,24(sp)
    80005a00:	6109                	addi	sp,sp,128
    80005a02:	8082                	ret

0000000080005a04 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005a04:	1101                	addi	sp,sp,-32
    80005a06:	ec06                	sd	ra,24(sp)
    80005a08:	e822                	sd	s0,16(sp)
    80005a0a:	e426                	sd	s1,8(sp)
    80005a0c:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005a0e:	0001c497          	auipc	s1,0x1c
    80005a12:	19a48493          	addi	s1,s1,410 # 80021ba8 <disk>
    80005a16:	0001c517          	auipc	a0,0x1c
    80005a1a:	2ba50513          	addi	a0,a0,698 # 80021cd0 <disk+0x128>
    80005a1e:	94cfb0ef          	jal	ra,80000b6a <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005a22:	10001737          	lui	a4,0x10001
    80005a26:	533c                	lw	a5,96(a4)
    80005a28:	8b8d                	andi	a5,a5,3
    80005a2a:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80005a2c:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005a30:	689c                	ld	a5,16(s1)
    80005a32:	0204d703          	lhu	a4,32(s1)
    80005a36:	0027d783          	lhu	a5,2(a5)
    80005a3a:	04f70663          	beq	a4,a5,80005a86 <virtio_disk_intr+0x82>
    __sync_synchronize();
    80005a3e:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005a42:	6898                	ld	a4,16(s1)
    80005a44:	0204d783          	lhu	a5,32(s1)
    80005a48:	8b9d                	andi	a5,a5,7
    80005a4a:	078e                	slli	a5,a5,0x3
    80005a4c:	97ba                	add	a5,a5,a4
    80005a4e:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005a50:	00278713          	addi	a4,a5,2
    80005a54:	0712                	slli	a4,a4,0x4
    80005a56:	9726                	add	a4,a4,s1
    80005a58:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80005a5c:	e321                	bnez	a4,80005a9c <virtio_disk_intr+0x98>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005a5e:	0789                	addi	a5,a5,2
    80005a60:	0792                	slli	a5,a5,0x4
    80005a62:	97a6                	add	a5,a5,s1
    80005a64:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005a66:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005a6a:	e00fc0ef          	jal	ra,8000206a <wakeup>

    disk.used_idx += 1;
    80005a6e:	0204d783          	lhu	a5,32(s1)
    80005a72:	2785                	addiw	a5,a5,1
    80005a74:	17c2                	slli	a5,a5,0x30
    80005a76:	93c1                	srli	a5,a5,0x30
    80005a78:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005a7c:	6898                	ld	a4,16(s1)
    80005a7e:	00275703          	lhu	a4,2(a4)
    80005a82:	faf71ee3          	bne	a4,a5,80005a3e <virtio_disk_intr+0x3a>
  }

  release(&disk.vdisk_lock);
    80005a86:	0001c517          	auipc	a0,0x1c
    80005a8a:	24a50513          	addi	a0,a0,586 # 80021cd0 <disk+0x128>
    80005a8e:	974fb0ef          	jal	ra,80000c02 <release>
}
    80005a92:	60e2                	ld	ra,24(sp)
    80005a94:	6442                	ld	s0,16(sp)
    80005a96:	64a2                	ld	s1,8(sp)
    80005a98:	6105                	addi	sp,sp,32
    80005a9a:	8082                	ret
      panic("virtio_disk_intr status");
    80005a9c:	00002517          	auipc	a0,0x2
    80005aa0:	eb450513          	addi	a0,a0,-332 # 80007950 <syscalls+0x420>
    80005aa4:	ce5fa0ef          	jal	ra,80000788 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
